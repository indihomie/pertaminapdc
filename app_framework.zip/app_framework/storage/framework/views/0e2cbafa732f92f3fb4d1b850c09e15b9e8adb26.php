<div>

    <div id="modal_notification"
         class="modal fade"
         data-bs-backdrop="static"
         data-bs-keyboard="false"
         wire:ignore.self>
        <div class="modal-dialog modal-lg modal-dialog-centered">

            <div class="modal-content overlay"
                 wire:loading.class.remove="overlay-block">

                <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded d-none"
                     wire:loading.class.remove="d-none">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>

                <div class="modal-body h-550px p-0 pt-0 d-flex flex-row">
                    <div class="w-325px d-flex flex-column">
                        <div class="p-4 pb-2 d-flex flex-column-auto flex-row justify-content-between align-items-center">
                            <h4 class="modal-title">
                                <?php echo e(__("Notifikasi")); ?>

                                <div class="w-30px border border-bottom border-primary"></div>
                            </h4>
                            <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                                 data-bs-dismiss="modal"
                                 aria-label="Close">
                                <span class="svg-icon svg-icon-2x">
                                    <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                                </span>
                            </div>
                        </div>
                        <div id="container_notification"
                             class="flex-row-fluid overflow-auto position-relative user-select-none"
                             wire:ignore>
                            <div id="notifications"></div>
                        </div>
                    </div>
                    <div class="flex-row-fluid p-4 border border-start-dashed border-gray-300 rounded-end">

                        <?php if($notification): ?>

                            <div class="d-flex flex-row align-items-center min-h-40px">

                                <h4 class="fs-6 mb-0"><?php echo e($notification->category); ?></h4>
                                <div class="fa fa-xs fa-circle mx-2 fs-10 text-gray-400"></div>
                                <div class="fs-8 text-gray-800"><?php echo e($notification->created_at->diffForHumans()); ?></div>

                                <div class="flex-fill"></div>

                                <div>
                                    <?php $__currentLoopData = $notification->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($path = $menu->menu_id == 0 ? "{$menu->path}/_" : "{$menu->menuParent->path}/{$menu->path}"); ?>
                                        <a class="ms-2 btn btn-link fs-7"
                                           href="<?php echo e(url("{$menu->module->path}/{$menu->moduleSub->path}/{$path}")); ?>"><?php echo e($menu->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div>

                            <?php if($notification->path_image): ?>
                                <a href="<?php echo e(asset("storage/{$notification->path_image}")); ?>"
                                   class="d-block w-400px h-150px my-4 mx-auto bg-light rounded bgi-no-repeat bgi-size-contain bgi-position-center"
                                   style="background-image: url('<?php echo e(asset("storage/{$notification->path_image}")); ?>')"
                                   data-fslightbox='gallery'>
                                </a>
                            <?php endif; ?>

                            <div class="fs-6 mb-2"><?php echo e($notification->title); ?></div>

                            <div class="text-gray-600">
                                <?php echo $notification->content; ?>

                            </div>

                            <?php if($notification->attachments): ?>
                                <div class="w-100 mt-4 mb-1 border-1 border-top-dashed border-gray-300"></div>
                                <div class="text-primary">
                                    <?php echo e(__("Attachment")); ?> :
                                </div>
                            <?php endif; ?>

                        <?php else: ?>
                            <div class="h-100 d-flex flex-center user-select-none">
                                <div class="text-center">
                                    <img alt="empty"
                                         src="<?php echo asset("assets/media/illustrations/sigma-1/15.png"); ?>"
                                         class="w-200px"
                                         loading="lazy">
                                    <div class="my-6"></div>
                                    <span class="text-gray-600"><?php echo e(__("Notifikasi belum dipilih")); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>

            </div>

        </div>
    </div>

    <script wire:ignore>

        const element_notification_container = document.getElementById("container_notification")
        const element_notification = document.getElementById("notifications")

        let more = true

        document.addEventListener("DOMContentLoaded", () => {
            Livewire.emit("notificationMore")
        })

        element_notification_container.onscroll = () => {
            if ((more && element_notification_container.clientHeight + element_notification_container.scrollTop + 1) >= element_notification.clientHeight) {
                Livewire.emit("notificationMore")
            }
        }

        Livewire.on("notifications", notifications => {

            more = notifications.length > 0

            element_notification.innerHTML += notifications
                .map(function (notification) {

                    return '' +
                        `<div class="p-4 rounded bg-hover-light-primary"
                            onclick="window.livewire.find('<?php echo e($_instance->id); ?>').show(${notification.id})">
                            <div class="d-flex flex-row">
                                <div class="flex-row-fluid text-dark fw-bold fs-7">${notification.category}</div>
                                <div class="d-flex align-items-center">
                                    <div class="flex-none fs-9 text-gray-500">${notification.datetime}</div>
                                    <div class="mx-1"></div>
                                    <i class="fa fa-xs fa-circle ${notification.read === 1 ? 'text-gray-200' : 'text-primary'}"></i>
                                </div>
                            </div>
                            <div class="d-block fs-7 text-gray-700">${notification.title}</div>
                        </div>`
                })
                .join("")

        })

    </script>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/app-notification.blade.php ENDPATH**/ ?>