<div id="modal_form_password_reset"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="savePassword"
                  autocomplete="off">

                <div class="modal-header pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e(__("Ubah Password")); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                </div>

                <div class="modal-body">

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Username")); ?></label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.username"
                                   disabled>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.username']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="my-4 separator separator-dashed"></div>

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Password")); ?></label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.password']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Konfirmasi Password")); ?></label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password_confirm">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.password_confirm']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.password_confirm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-toggle="modal"
                       data-bs-target="#modal_form"><?php echo e(__("Batal")); ?></a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("{$app_path}.update")): ?>
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            <?php echo e(__("Simpan")); ?>

                        </button>
                    <?php endif; ?>
                </div>

            </form>

        </div>

    </div>
</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/setting/setting-user/form-password-reset-dialog.blade.php ENDPATH**/ ?>