<div id="modal_form_manual"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off"
                  enctype="multipart/form-data">

                <div class="modal-header pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e(__("Buku Manual")); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                            <span class="svg-icon svg-icon-2x">
                                <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                            </span>
                    </div>
                </div>

                <div class="modal-body">

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Waktu diubah")); ?></label>
                        <div class="w-200px">
                            <input type="text"
                                   class="form-control bg-light"
                                   placeholder=""
                                   readonly
                                   wire:model.defer="manual.updated_at">
                        </div>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Diubah oleh")); ?></label>
                        <div class="">
                            <input type="text"
                                   class="form-control bg-light"
                                   placeholder=""
                                   readonly
                                   wire:model.defer="manual.updated_by.name">
                        </div>
                    </div>

                    <div class="fv-row mb-6">
                        <label class="fs-6 fw-bold mb-1"><?php echo e(__("Dokumen")); ?></label>
                        <div class="d-flex">
                            <div class="w-200px">
                                <label class="btn btn-sm btn-primary w-100">
                                    <?php echo e(__("Upload")); ?>

                                    <input type="file"
                                           class="d-none"
                                           accept=".pdf, .doc, .docx"
                                           wire:model="file">
                                </label>
                            </div>
                            <?php if($file): ?>
                                <a href="<?php echo e(url("view/" . encrypt($url_temp))); ?>"
                                   class="viewer ms-3"
                                   data-ext="document"
                                   data-title="<?php echo e(__("Buku Manual")); ?>"
                                   data-download="false">
                                    <span class="btn btn-sm btn-icon btn-light btn-active-light-dark"
                                          title="<?php echo e(__("Cetak")); ?>"
                                          data-bs-toggle="tooltip"
                                          data-bs-trigger="hover"
                                          data-bs-dismiss="click">
                                        <img src="<?php echo e(asset("assets/media/icons/document-view.png")); ?>"
                                             class="w-15px">
                                    </span>
                                </a>
                            <?php endif; ?>
                            <?php if($file || ($manual["path_document"] ?? false)): ?>
                                <a href="#"
                                   class="swal-livewire-confirm ms-3"
                                   data-message="<?php echo e(__("Konfirmasi hapus buku manual.")); ?>"
                                   data-event="removeManual"
                                   data-target="0"
                                   data-loader="true">
                                    <span class="btn btn-sm btn-icon btn-light btn-active-light-danger"
                                          title="<?php echo e(__("Hapus")); ?>"
                                          data-bs-toggle="tooltip"
                                          data-bs-trigger="hover"
                                          data-bs-dismiss="click">
                                        <img src="<?php echo e(asset("assets/media/icons/table-delete.png")); ?>"
                                             class="w-15px">
                                    </span>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">

                    <div>
                        <a class="btn btn-light btn-active-light-primary"
                           href="#"
                           data-bs-dismiss="modal">
                            <?php echo e(__("Batal")); ?>

                        </a>
                        <?php if(auth()->user()->type == \App\Models\AppUser::TYPE_DEVELOPER): ?>
                            <button type="submit"
                                    class="btn btn-primary ms-2">
                                <?php echo e(__("Simpan")); ?>

                            </button>
                        <?php endif; ?>
                    </div>
                </div>

            </form>

        </div>

    </div>
</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/app/manual/form-dialog.blade.php ENDPATH**/ ?>