<div id="modal_form"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off"
                  enctype="multipart/form-data">

                <div class="modal-header pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e(__("Profil")); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                            <span class="svg-icon svg-icon-2x">
                                <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                            </span>
                    </div>
                </div>

                <div class="modal-body">

                    <div class="d-flex justify-content-center mb-6">

                        <?php ($_path = $image["file"] ? $image["file"]->temporaryUrl() : ($account["path_photo"] ? asset("storage/{$account["path_photo"]}") : "")); ?>
                        <div class="image-input image-input-circle bgi-size-cover bg-light <?php echo e($_path ? "" : "image-input-empty"); ?>"
                             style="
                                 background-image: url('<?php echo e(asset("assets/media/avatars/blank.png")); ?>')
                                 ">
                            <a class="viewer d-block image-input-wrapper w-100px h-100px bgi-size-contain bgi-position-center"
                               href="<?php echo e($_path); ?>"
                               data-ext="image"
                               data-title="<?php echo e($account["name"]); ?>"
                               style="background-image: url('<?php echo e($_path); ?>')"></a>
                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow <?php echo e($_path ? "d-none" : ""); ?>"
                                   data-kt-image-input-action="change">
                                <i class="bi bi-pencil-fill fs-7"></i>
                                <input type="file"
                                       accept=".png, .jpg, .jpeg"
                                       wire:model="image.file"/>
                            </label>
                            <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                  data-kt-image-input-action="remove"
                                  wire:click="removeImage">
                                <i class="bi bi-x fs-2"></i>
                            </span>
                        </div>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Grup User")); ?></label>
                        <div class="w-lg-300px"
                             wire:ignore>
                            <select class="form-select"
                                    data-controls="select2"
                                    data-placeholder="<?php echo e(__("- Pilih Grup User -")); ?>"
                                    wire:model.defer="account.role_id">
                                <option value=""></option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($_role->id); ?>"><?php echo e($_role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.role_id']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.role_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Nama")); ?></label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.name">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Username")); ?></label>
                        <div class="w-lg-200px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   autocomplete="off"
                                   wire:model.defer="account.username">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.username']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4 <?php echo e($state == \App\Const\State::EDIT ? "d-none" : ""); ?>">
                        <label class="form-label required"><?php echo e(__("Password")); ?></label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.password']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4 <?php echo e($state == \App\Const\State::EDIT ? "d-none" : ""); ?>">
                        <label class="form-label required"><?php echo e(__("Konfirmasi Password")); ?></label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password_confirm">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.password_confirm']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.password_confirm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Email")); ?></label>
                        <div class="w-lg-300px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.email">
                        </div>
                        <div class="text-muted fs-8"><?php echo e(__("Email bersifat unik, gunakan email aktif untuk menyelesaikan verifikasi email saat email diubah.")); ?></div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.email']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Telepon")); ?></label>
                        <div class="w-lg-200px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   data-controls="mask"
                                   data-mask="(9999) 9999 9999 9999"
                                   data-unmask="true"
                                   wire:model.defer="account.phone">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.phone']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Verifikasi Email")); ?></label>
                        <div class="w-200px">
                            <input type="text"
                                   class="form-control bg-light"
                                   placeholder=""
                                   readonly
                                   wire:model.defer="account.email_verified_at">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.email_verified_at']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.email_verified_at']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Catatan")); ?></label>
                        <div>
                            <textarea type="text"
                                      class="form-control"
                                      placeholder=""
                                      wire:model.defer="account.description"></textarea>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.description']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.description']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row">
                        <label class="fs-6 fw-bold mb-2"><?php echo e(__("Status")); ?></label>
                        <div>
                            <div class="form-check form-check-solid form-switch">
                                <input type="checkbox"
                                       class="form-check-input w-45px h-30px"
                                       wire:model.defer="account.status">
                                <label class="form-check-label"></label>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0 d-flex justify-content-between">
                    <div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("{$app_path}.update")): ?>
                            <?php if($state == \App\Const\State::EDIT): ?>
                                <button type="button"
                                        class="btn btn-light btn-light"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modal_form_password_reset"><?php echo e(__("Ubah Password")); ?></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <a class="btn btn-light btn-active-light-primary"
                           href="#"
                           data-bs-dismiss="modal"><?php echo e(__("Batal")); ?></a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(["{$app_path}.create", "{$app_path}.update"])): ?>
                            <button type="submit"
                                    class="btn btn-primary ms-2">
                                <?php echo e(__("Simpan")); ?>

                            </button>
                        <?php endif; ?>
                    </div>
                </div>

            </form>

        </div>

    </div>
</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/setting/setting-user/form-dialog.blade.php ENDPATH**/ ?>