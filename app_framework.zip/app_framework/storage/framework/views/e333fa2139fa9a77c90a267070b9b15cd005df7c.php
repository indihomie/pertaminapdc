<div class="livewire">

    <div class="mb-8">
        <div class="fs-2 fw-bold">
            <?php echo e($app_menu->name); ?>

            <div class="w-30px border border-bottom border-primary"></div>
        </div>
    </div>

    <div class="d-flex flex-column flex-lg-row justify-content-between mb-4">
        <div class="d-flex mb-4 mb-lg-0">

            <div class="d-flex align-items-center position-relative">
                <span class="svg-icon svg-icon-1 position-absolute ms-4">
                    <?php echo asset_svg("assets/media/icons/duotune/general/gen021.svg"); ?>

                </span>
                <input type="text"
                       class="form-control form-control-solid w-250px ps-15"
                       placeholder="<?php echo e(__("Cari")); ?>"
                       wire:model.debounce.500ms="search"/>
            </div>

        </div>
        <div class="d-flex">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("{$app_path}.store")): ?>
                <a href="#"
                   class="btn btn-primary"
                   data-bs-toggle="modal"
                   data-bs-target="#modal_form"
                   wire:click="create">
                    <span class="svg-icon svg-icon-2">
                        <?php echo asset_svg("assets/media/icons/duotune/arrows/arr075.svg"); ?>

                    </span>
                    <?php echo e(__("Tambah")); ?>

                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="dataTables_wrapper">
        <div class="table-responsive table-loading">
            <div class="table-loading-message d-none"
                 wire:loading.class.remove="d-none">
                <?php echo e(__("Loading...")); ?>

            </div>
            <table class="table table-row-dashed table-hover dataTable gy-3 gx-3">
                <thead class="fs-7 fw-bolder text-gray-800 text-uppercase border border-dashed user-select-none">
                <tr class="align-middle text-center">
                    <th class="w-30px pe-3">#</th>
                    <th class="w-75px min-w-75px"><?php echo e(__("Foto")); ?></th>
                    <th class="w-150px min-w-150px pe-3 border-start-0 sorting <?php echo e($sortBy == "username" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : ""); ?>"
                        wire:click="sortBy('username')"><?php echo e(__("Useranme")); ?></th>
                    <th class="w-auto min-w-250px pe-3 border-start-0 sorting <?php echo e($sortBy == "name" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : ""); ?>"
                        wire:click="sortBy('name')"><?php echo e(__("Nama")); ?></th>
                    <th class="w-250px min-w-250px"><?php echo e(__("Grup")); ?></th>
                    <th class="w-150px min-w-150px pe-3 border-start-0 sorting <?php echo e($sortBy == "login_at" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : ""); ?>"
                        wire:click="sortBy('login_at')"><?php echo e(__("Login Terakhir")); ?></th>
                    <th class="w-50px w-50px pe-3 border-start-0"><?php echo e(__("Status")); ?></th>
                    <th class="w-75px min-w-100px pe-3"><?php echo e(__("Kontrol")); ?></th>
                </tr>
                </thead>
                <tbody class="">
                <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="align-middle">
                        <td class="text-end"><?php echo e($loop->iteration); ?>.</td>
                        <td class="text-center">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.viewer-image','data' => ['class' => 'w-20px h-20px','href' => asset($_account->path_photo ? "storage/{$_account->path_photo}" : "assets/media/avatars/blank.png"),'ext' => 'image','title' => $_account->name,'download' => false]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('viewer-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-20px h-20px','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset($_account->path_photo ? "storage/{$_account->path_photo}" : "assets/media/avatars/blank.png")),'ext' => 'image','title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($_account->name),'download' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </td>
                        <td class="text-start"><?php echo e($_account->username); ?></td>
                        <td class="text-start"><?php echo e($_account->name); ?></td>
                        <td class="text-start"><?php echo e($_account->role->name ?? "-"); ?></td>
                        <td class="text-center font-monospace"><?php echo e($_account->login_at->format("d/m/Y H:i")); ?></td>
                        <td class="text-center"><?php echo $_account->status_image; ?></td>
                        <td class="text-end">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("{$app_path}.update")): ?>
                                <a href="#"
                                   data-bs-toggle="modal"
                                   data-bs-target="#modal_form"
                                   wire:click="edit(<?php echo e($_account->id); ?>)">
                                    <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                          title="<?php echo e(__("Ubah")); ?>"
                                          data-bs-toggle="tooltip"
                                          data-bs-trigger="hover"
                                          data-bs-dismiss="click">
                                        <img src="<?php echo e(asset("assets/media/icons/table-edit.png")); ?>"
                                             class="w-15px">
                                    </span>
                                </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("{$app_path}.delete")): ?>
                                <?php if(!in_array($_account->id, [1, 2])): ?>
                                    <a href="#"
                                       class="swal-livewire-confirm"
                                       data-message="<?php echo e(__("Konfirmasi hapus user dipilih.")); ?>"
                                       data-event="destroy"
                                       data-target="<?php echo e($_account->id); ?>"
                                       data-loader="true">
                                        <span class="btn btn-sm btn-icon btn-color-danger btn-active-light-danger"
                                              title="<?php echo e(__("Hapus")); ?>"
                                              data-bs-toggle="tooltip"
                                              data-bs-trigger="hover"
                                              data-bs-dismiss="click">
                                            <img src="<?php echo e(asset("assets/media/icons/table-delete.png")); ?>"
                                                 class="w-15px">
                                        </span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8"
                            class="p-6 bg-light text-center text-gray-600">
                            <?php echo e(__("Tidak ada data")); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-start">
                <div class="dataTables_length me-5"
                     wire:ignore>
                    <select class="form-select form-select-solid w-80px"
                            data-controls="select2"
                            data-search="false"
                            wire:model="perPage">
                        <?php $__currentLoopData = config("paramter.pagination"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_key => $_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($_key); ?>"><?php echo e($_value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="dataTables_info fs-6 fw-bold text-gray-700">
                    <?php echo e(__("Showing")); ?> <?php echo e($accounts->firstItem()); ?> <?php echo e(__("to")); ?> <?php echo e($accounts->lastItem()); ?> <?php echo e(__("of")); ?> <?php echo e($accounts->total()); ?> <?php echo e(__("entries")); ?>

                </div>
            </div>
            <div class="dataTables_paginate ms-0 col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
                <?php echo e($accounts->links()); ?>

            </div>
        </div>
    </div>

    <?php echo $__env->make("livewire.setting.setting-user.form-dialog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("livewire.setting.setting-user.form-password-reset-dialog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/setting/setting-user.blade.php ENDPATH**/ ?>