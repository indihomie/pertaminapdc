<!DOCTYPE html>
<html lang="<?php echo e(str_replace("_", "-", app()->getLocale())); ?>">
<head>

    <meta charset="utf-8">

    <title><?php echo $__env->yieldPushContent("title", config("app.name", "Laravel")); ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset("assets/info/icon.png") . "?" . config("environments.APP_VERSION")); ?>"/>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
    <!-- End Fonts -->

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/style.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/global/plugins.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">

    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/datatables/datatables.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/flatpickr/flatpickr.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/global/plugins-custom.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->make("app.style", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Styles -->

    <!-- Scripts -->
    <script src="<?php echo e(asset("assets/plugins/global/plugins.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/js/scripts.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>

    <script src="<?php echo e(asset("assets/plugins/custom/alpinejs/alpinejs.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/datatables/datatables.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/flatpickr/flatpickr.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/typedjs/typedjs.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <!-- End Scripts -->

    <?php echo $__env->yieldContent("style"); ?>

</head>
<body id="kt_body"
      class="blockui <?php echo $__env->yieldPushContent("body-class"); ?>">

<div class="d-flex flex-column flex-root">
    <div class="page d-flex flex-row flex-column-fluid">

        <?php echo $__env->yieldContent("body"); ?>

    </div>

</div>

<?php echo $__env->yieldContent("modals"); ?>

<div id="kt_scrolltop"
     class="scrolltop"
     data-kt-scrolltop="true">
    <span class="svg-icon">
        <?php echo asset_svg("assets/media/icons/duotone/Navigation/Up-2.svg"); ?>

    </span>
</div>

<div class="blockui-overlay rounded bg-light bg-opacity-50 d-none"
     wire:loading.class.remove="d-none">
    <span class="spinner-border text-primary"></span>
</div>

<?php echo $__env->yieldPushContent("script"); ?>
<?php echo $__env->make("app.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/sinergic/app_framework/resources/views/app/guest.blade.php ENDPATH**/ ?>