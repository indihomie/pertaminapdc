<div class="livewire">

    <div id="drawer_manual_book"
         class="bg-body drawer drawer-end"
         data-kt-drawer="true"
         data-kt-drawer-name="manual_book"
         data-kt-drawer-activate="true"
         data-kt-drawer-overlay="true"
         data-kt-drawer-width="{default: '100%', lg: '900px'}"
         data-kt-drawer-direction="end"
         data-kt-drawer-toggle="#drawer_manual_book_toggle"
         data-kt-drawer-close="#drawer_manual_book_close"
         style="width: 900px !important;"
         wire:ignore.self>

        <div class="w-100 card rounded-0 shadow-none">
            <div class="card-header">
                <h3 class="card-title fw-bolder text-dark"><?php echo e(__("Buku Manual")); ?></h3>
                <div class="card-toolbar">

                    <?php if($state == \App\Http\Livewire\AppManualBook::TYPE_MANUAL_MODULE_SUB && auth()->user()->type == \App\Models\AppUser::TYPE_DEVELOPER): ?>
                        <a class="btn btn-light btn-active-light-primary"
                           href="#"
                           data-bs-toggle="modal"
                           data-bs-target="#modal_form_manual">
                            <?php echo e(__("Ubah")); ?>

                        </a>
                    <?php endif; ?>

                    <button type="button"
                            id="drawer_manual_book_close"
                            class="btn btn-sm btn-icon btn-active-light-primary me-n5"
                            wire:click="clear">
                        <span class="svg-icon svg-icon-1">
                            <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                        </span>
                    </button>

                </div>
            </div>
            <div class="card-body p-0 overflow-hidden">
                <?php if($url): ?>
                    <iframe src="<?php echo e($url); ?>" class="w-100 h-100 m-0"></iframe>
                <?php else: ?>
                    <div class="w-100 h-100 d-flex flex-center">
                        <div class="text-center">
                            <img alt="not found"
                                 class="w-200px h-200px"
                                 src="<?php echo e(asset("assets/media/illustrations/sigma-1/4.png")); ?>"
                                 loading="lazy">
                            <div class="my-4"></div>
                            <div class="fs-5 text-gray-600">
                                <?php echo e(__("Buku Manual modul saat ini belum tersedia,")); ?>

                                <br>
                                <?php echo e(__("kami akan sediakan secepatnya.")); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <?php echo $__env->make("livewire.app.manual.form-dialog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/app-manual.blade.php ENDPATH**/ ?>