<?php $__env->startPush("content-class", "h-100 d-flex flex-center"); ?>

<?php $__env->startSection("content"); ?>
    <div class="text-center user-select-none">
        <img alt="info"
             class="w-200px h-200px"
             src="<?php echo e(asset("assets/media/illustrations/sigma-1/10.png")); ?>"
             loading="lazy">
        <div class="my-8"></div>
        <div class="fs-6 text-gray-600"><?php echo e(__("Halaman sedang dalam pengembangan")); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/empty.blade.php ENDPATH**/ ?>