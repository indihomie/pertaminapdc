<div>

    <div id="modal_news"
         class="modal fade"
         data-bs-backdrop="static"
         data-bs-keyboard="false"
         wire:ignore.self>

        <div class="modal-dialog modal-md modal-dialog-centered">

            <div class="modal-content overlay overlay-block overlay-hidden"
                 wire:loading.class.remove="overlay-hidden">

                <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>

                <div class="modal-header p-4 pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e($news->name ?? __("Berita")); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                        <span class="svg-icon svg-icon-2x">
                            <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                        </span>
                    </div>
                </div>

                <div class="modal-body h-550px p-4 overflow-auto position-relative">

                    <?php if(!$news): ?>
                        <?php $__currentLoopData = $newss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="p-4 d-flex flex-row bg-hover-light rounded user-select-none"
                               href="#"
                               wire:click="select(<?php echo e($_news->id); ?>)">
                                <div class="symbol symbol-40px symbol-2by3 flex-shrink-0 me-4">
                                    <img src="<?php echo e(asset("storage/{$_news->path_image}")); ?>"
                                         class="mw-100"
                                         alt=""
                                         loading="lazy">
                                </div>
                                <div class="">
                                    <div class="fs-6 fw-bold text-gray-800"><?php echo e($_news->name); ?></div>
                                    <div class="fs-7 text-gray-700">
                                        <?php echo e($_news->updated_at->format("d F Y H:i")); ?> - <?php echo e($_news->updatedBy->name); ?>

                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div>

                            <a href="<?php echo e(asset("storage/{$news->path_image}")); ?>"
                               class="d-block h-150px bg-light bgi-no-repeat bgi-size-contain bgi-position-center rounded"
                               data-fslightbox='gallery'
                               style="background-image: url('<?php echo e(asset("storage/{$news->path_image}")); ?>')"></a>

                            <div class="fs-7 text-primary my-2"><?php echo e($news->updated_at->format("d F Y H:i")); ?> - <?php echo e($news->updatedBy->name); ?></div>

                            <?php echo $news->content; ?>


                            <div class="border border-top border-dashed border-gray-300"></div>
                            <div class="fs-8 p-1"><?php echo e($news->source); ?></div>
                        </div>
                    <?php endif; ?>

                </div>

                <div class="modal-footer p-4 border-top-0 justify-content-center">
                    <?php if(!$news): ?>
                        <?php echo e($newss->links()); ?>

                    <?php else: ?>
                        <a href="#"
                           class="w-100 btn btn-sm btn-light-primary text-hover-light"
                           wire:click="back"><?php echo e(__("Kembali")); ?></a>
                    <?php endif; ?>
                </div>

            </div>

        </div>
    </div>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/app-news.blade.php ENDPATH**/ ?>