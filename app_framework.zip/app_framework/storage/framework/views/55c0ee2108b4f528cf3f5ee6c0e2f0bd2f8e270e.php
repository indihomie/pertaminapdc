<?php $__env->startPush("title", __("Forbidden")); ?>

<?php $__env->startPush("body-class", "bg-light"); ?>

<?php $__env->startSection("body"); ?>
    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid">

            <div class="d-flex flex-column flex-column-fluid text-center justify-content-center p-10 py-lg-15">

                <a href="<?php echo e(url("/")); ?>"
                   class="mb-10 pt-lg-10">
                    <img alt="Logo"
                         src="<?php echo e(asset("assets/info/logo.png")); ?>"
                         class="h-40px mb-5"
                         loading="lazy"/>
                </a>

                <div class="pt-lg-10 mb-10">

                    <div class="mb-10 d-flex flex-row-auto bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom min-h-200px"
                         style="background-image: url('<?php echo e(asset("assets/media/illustrations/sigma-1/12.png")); ?>')"></div>

                    <div class="fw-bold fs-3 text-muted mb-15">
                        <?php echo e(__("Halaman kadaluarsa karena masalah keamanan,")); ?>

                        <br>
                        <?php echo e(__("Silahkan kembali dan lakukan proses ulang.")); ?>

                    </div>

                    <div class="text-center">
                        <a href="<?php echo e(url("/")); ?>" class="btn btn-lg btn-primary fw-bolder"><?php echo e(__("Kembali")); ?></a>
                    </div>

                </div>

            </div>

            <?php echo $__env->make("app.guest-footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("app.guest", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/errors/419.blade.php ENDPATH**/ ?>