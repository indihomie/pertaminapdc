<div>

    <div id="modal_announcement"
         class="modal fade"
         data-bs-backdrop="static"
         data-bs-keyboard="false"
         wire:ignore.self>
        <div class="modal-dialog modal-md modal-dialog-centered">

            <div class="modal-content overlay overlay-block overlay-hidden"
                 wire:loading.class.remove="overlay-hidden">

                <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>

                <div class="modal-header p-4 pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e($announcement->name ?? __("Pengumuman")); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                        <span class="svg-icon svg-icon-2x">
                            <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                        </span>
                    </div>
                </div>

                <div class="modal-body h-550px p-4 overflow-auto position-relative">

                    <?php if(!$announcement): ?>
                        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="p-4 d-flex flex-row bg-hover-light rounded user-select-none"
                               href="#"
                               wire:click="select(<?php echo e($_announcement->id); ?>)">
                                <div class="symbol symbol-40px symbol-2by3 flex-shrink-0 me-4">
                                    <img src="<?php echo e(asset("storage/{$_announcement->path_image}")); ?>"
                                         class="mw-100"
                                         alt=""
                                         loading="lazy">
                                </div>
                                <div class="">
                                    <div class="fs-6 fw-bold text-gray-800"><?php echo e($_announcement->name); ?></div>
                                    <div class="fs-7 text-gray-700">
                                        <?php echo e($_announcement->updated_at->format("d F Y H:i")); ?> - <?php echo e($_announcement->updatedBy->name); ?>

                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div>

                            <a href="<?php echo e(asset("storage/{$announcement->path_image}")); ?>"
                               class="viewer d-block h-150px bg-light bgi-no-repeat bgi-size-contain bgi-position-center rounded"
                               data-title="<?php echo e($announcement->name); ?>"
                               data-ext="<?php echo e(File::extension($announcement->path_image)); ?>"
                               data-download="true"
                               style="background-image: url('<?php echo e(asset("storage/{$announcement->path_image}")); ?>')"></a>

                            <div class="fs-7 text-primary my-2"><?php echo e($announcement->updated_at->format("d F Y H:i")); ?> - <?php echo e($announcement->updatedBy->name); ?></div>

                            <?php echo $announcement->content; ?>


                            <div class="border border-top border-dashed border-gray-300"></div>
                            <div class="fs-8 p-1"><?php echo e($announcement->source); ?></div>
                        </div>
                    <?php endif; ?>

                </div>

                <div class="modal-footer p-4 border-top-0 justify-content-center">
                    <?php if(!$announcement): ?>
                        <?php echo e($announcements->links()); ?>

                    <?php else: ?>
                        <a href="#"
                           class="w-100 btn btn-sm btn-light-primary text-hover-light"
                           wire:click="back"><?php echo e(__("Kembali")); ?></a>
                    <?php endif; ?>
                </div>

            </div>

        </div>
    </div>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/app-announcement.blade.php ENDPATH**/ ?>