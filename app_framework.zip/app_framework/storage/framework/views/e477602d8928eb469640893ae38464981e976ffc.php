<?php $__env->startSection("content"); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("other.safety.safety",
        compact("app_module", "app_module_sub", "app_menu", "app_path"))->html();
} elseif ($_instance->childHasBeenRendered('5TZs5t4')) {
    $componentId = $_instance->getRenderedChildComponentId('5TZs5t4');
    $componentTag = $_instance->getRenderedChildComponentTagName('5TZs5t4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5TZs5t4');
} else {
    $response = \Livewire\Livewire::mount("other.safety.safety",
        compact("app_module", "app_module_sub", "app_menu", "app_path"));
    $html = $response->html();
    $_instance->logRenderedChild('5TZs5t4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/other/safety/safety.blade.php ENDPATH**/ ?>