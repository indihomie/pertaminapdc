<?php $__env->startPush("title", "{$app_module->name} - {$app_information->company}"); ?>

<?php $__env->startPush("body-class", "aside-enabled aside-fixed bg-white"); ?>

<?php $__env->startSection("body"); ?>
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div id="kt_aside"
                 class="aside aside-light aside-hoverable"
                 data-kt-drawer="true"
                 data-kt-drawer-name="aside"
                 data-kt-drawer-activate="{default: true, lg: false}"
                 data-kt-drawer-overlay="true"
                 data-kt-drawer-width="{default:'200px', '300px': '250px'}"
                 data-kt-drawer-direction="start"
                 data-kt-drawer-toggle="#kt_aside_mobile_toggle">

                <div id="kt_aside_logo"
                     class="aside-logo flex-column-auto">
                    <a href="<?php echo e(url("/home")); ?>">
                        <img alt="Logo"
                             src="<?php echo e(asset("assets/info/logo.png")); ?>"
                             class="h-35px logo"
                             loading="lazy"/>
                    </a>
                    <div id="kt_aside_toggle"
                         class="btn btn-icon w-auto px-0 btn-active-color-primary aside-toggle"
                         data-kt-toggle="true"
                         data-kt-toggle-state="active"
                         data-kt-toggle-target="body"
                         data-kt-toggle-name="aside-minimize">
                        <span class="svg-icon svg-icon-1 rotate-180">
                            <?php echo asset_svg("assets/media/icons/duotune/arrows/arr079.svg"); ?>

                        </span>
                    </div>
                </div>

                <div class="aside-menu flex-column-fluid">
                    <div id="kt_aside_menu_wrapper"
                         class="hover-scroll-overlay-y my-5 my-lg-5 user-select-none"
                         data-kt-scroll="true"
                         data-kt-scroll-activate="{default: false, lg: true}"
                         data-kt-scroll-height="auto"
                         data-kt-scroll-dependencies="#kt_aside_logo, #kt_aside_footer"
                         data-kt-scroll-wrappers="#kt_aside_menu"
                         data-kt-scroll-offset="0">

                        <div id="#kt_aside_menu"
                             class="menu menu-column menu-active-bg menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500"
                             data-kt-menu="true"
                             data-kt-menu-expand="false">
                            <?php $__currentLoopData = $app_module_sub->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    if ($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_MASTER) {
                                        $target = "master";
                                    } else if ($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_LINK) {
                                        $target = "link";
                                    } else {
                                        $target = "";
                                    }
                                ?>
                                <div
                                    class="menu-item <?php echo e($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_DROPDOWN ? "menu-accordion" : ""); ?> <?php echo e($_menu->path == $request->segment(3) ? "here show" : ""); ?>"
                                    <?php echo e($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_DROPDOWN ? "data-kt-menu-trigger='click'" : ""); ?>>

                                    <a class="menu-link <?php echo e($_menu->path == $request->segment(3) ? "active" : ""); ?>"
                                       href="<?php echo e(url("{$request->segment(1)}/{$request->segment(2)}/{$_menu->path}/_/{$target}")); ?>">
                                        <span class="menu-icon bgi-size-cover"
                                              style="
                                            width: 18px;
                                            height: 18px;
                                            background-image: url('<?php echo e(asset($_menu->path_icon ? "/storage/{$_menu->path_icon}" : "/storage/_/menu/_blank.png")); ?>');
                                            ">
                                        </span>
                                        <span class="menu-title"><?php echo e($_menu->name); ?></span>
                                        <?php if($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_DROPDOWN): ?>
                                            <span class="menu-arrow"></span>
                                        <?php endif; ?>
                                    </a>

                                    <?php $__currentLoopData = $_menu->menuSubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_menu_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if ($_menu_sub->target_type == \App\Models\AppMenu::MENU_TARGET_MASTER) {
                                                $target = "master";
                                            } else if ($_menu_sub->target_type == \App\Models\AppMenu::MENU_TARGET_LINK) {
                                                $target = "link";
                                            } else {
                                                $target = "";
                                            }
                                        ?>
                                        <div class="menu-sub menu-sub-accordion">
                                            <div class="menu-item">
                                                <a class="menu-link <?php echo e($_menu_sub->path == $request->segment(4) ? "active" : ""); ?>"
                                                   href="<?php echo e(url("{$request->segment(1)}/{$request->segment(2)}/{$_menu->path}/{$_menu_sub->path}/{$target}")); ?>">
                                                    <span class="menu-bullet">
                                                        <span class="bullet bullet-dot"></span>
                                                    </span>
                                                    <span class="menu-title"><?php echo e($_menu_sub->name); ?></span>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>

                <div id="kt_aside_footer"
                     class="aside-footer flex-column-auto p-3">
                    <a class="w-100 btn btn-custom btn-light"
                       href="#"
                       title="<?php echo e(__("Versi " . config("environment.APP_VERSION"))); ?>"
                       data-bs-toggle="tooltip"
                       data-bs-trigger="hover"
                       data-bs-dismiss-="click">
                        <span class="btn-label"><?php echo e(config("environment.APP_VERSION")); ?></span>
                        <span class="svg-icon btn-icon svg-icon-2">
                            <?php echo asset_svg("assets/media/icons/duotune/general/gen005.svg"); ?>

                        </span>
                    </a>
                </div>

            </div>

            <div id="kt_wrapper"
                 class="wrapper d-flex flex-column flex-row-fluid">

                <div id="kt_header"
                     class="header align-items-stretch">
                    <div class="container-fluid d-flex align-items-stretch justify-content-between">

                        <div class="d-flex align-items-center d-lg-none ms-n2 me-2"
                             title="Show aside menu">
                            <div id="kt_aside_mobile_toggle"
                                 class="btn btn-icon btn-active-light-primary w-30px h-30px w-md-40px h-md-40px">
                                <span class="svg-icon svg-icon-1">
                                    <?php echo asset_svg("assets/media/icons/duotune/abstract/abs015.svg"); ?>

                                </span>
                            </div>
                        </div>

                        <div class="d-none d-lg-none align-items-center flex-grow-0 me-4">
                            <a href="<?php echo e(url("/")); ?>">
                                <img alt="Logo"
                                     src="<?php echo e(asset("assets/info/icon.png")); ?>"
                                     class="h-30px"
                                     loading="lazy"/>
                            </a>
                        </div>

                        <div class="d-flex align-items-stretch justify-content-between flex-grow-1">

                            <div
                                class="d-flex flex-column justify-content-center">
                                <h1 class="text-dark fw-bolder fs-3 mb-0"><?php echo e($app_module->category->name); ?></h1>
                                <div class="text-muted"><?php echo e($app_module->name); ?> - <?php echo e($app_module_sub->name); ?></div>
                            </div>

                            <div id="kt_header_nav"
                                 class="d-flex align-items-stretch flex-shrink-0">

                                <div class="d-lg-flex"
                                     data-kt-drawer="true"
                                     data-kt-drawer-name="header-menu"
                                     data-kt-drawer-activate="{default: true, lg: false}"
                                     data-kt-drawer-overlay="true"
                                     data-kt-drawer-width="{default:'200px', '300px': '250px'}"
                                     data-kt-drawer-direction="end"
                                     data-kt-drawer-toggle="#kt_header_menu_mobile_toggle"
                                     data-kt-swapper="true"
                                     data-kt-swapper-mode="prepend"
                                     data-kt-swapper-parent="{default: '#kt_body', lg: '#kt_header_nav'}">
                                    <div id="#kt_header_menu"
                                         class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch"
                                         data-kt-menu="true">
                                        <?php $__currentLoopData = $app_module->moduleSubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_module_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="menu-item menu-lg-down-accordion me-lg-1 <?php echo e($_module_sub->path == $request->segment(2) ? "here show" : ""); ?>"
                                               href="<?php echo e(url("{$app_module->path}/{$_module_sub->path}")); ?>">
                                                <span class="menu-link py-3">
                                                    <span class="menu-title"><?php echo e($_module_sub->name); ?></span>
                                                </span>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="mx-3 d-none d-lg-flex align-items-center">
                                    <div class="h-30px border-start border-gray-300"></div>
                                </div>

                                <div class="d-flex align-items-center"
                                     title="<?php echo e(__("Buku Manual")); ?>"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div id="drawer_manual_book_toggle"
                                         class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
                                         onclick="Livewire.emit('selectManual', <?php echo e($app_module_sub->id); ?>)">
                                        <span class="svg-icon svg-icon-1">
                                            <?php echo asset_svg("assets/media/icons/duotune/general/gen046.svg"); ?>

                                        </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center"
                                     title="<?php echo e(__("Notifikasi")); ?>"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
                                         data-bs-toggle="modal"
                                         data-bs-target="#modal_notification">
                                        <span class="svg-icon svg-icon-1">
                                            <?php echo asset_svg("assets/media/icons/duotune/general/gen007.svg"); ?>

                                        </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center"
                                     title="<?php echo e(__("Beranda")); ?>"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <a class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
                                       href="<?php echo e(url("/home")); ?>">
                                        <span class="svg-icon svg-icon-1">
                                            <?php echo asset_svg("assets/media/icons/duotune/general/gen001.svg"); ?>

                                        </span>
                                    </a>
                                </div>

                                <div class="mx-2"></div>

                                <div id="kt_header_user_menu_toggle"
                                     class="d-flex align-items-center"
                                     title="<?php echo e(__("Profil")); ?>"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div class="cursor-pointer symbol symbol-30px symbol-md-40px"
                                         data-kt-menu-trigger="click"
                                         data-kt-menu-attach="parent"
                                         data-kt-menu-placement="bottom-end">
                                        <img alt="user"
                                             src="<?php echo e(asset($user?->path_photo ? "storage/{$user->path_photo}" : "assets/media/avatars/blank.png")); ?>"
                                             loading="lazy"/>
                                    </div>
                                    <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-325px"
                                         data-kt-menu="true">

                                        <div class="menu-item px-3">
                                            <div class="menu-content d-flex align-items-center px-3">
                                                <div class="symbol symbol-50px me-5">
                                                    <img alt="Logo"
                                                         src="<?php echo e(asset($user?->path_photo ? "storage/{$user?->path_photo}" : "assets/media/avatars/blank.png")); ?>"
                                                         loading="lazy"/>
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <div class="fw-bolder fs-5"><?php echo e($user->name); ?></div>
                                                    <div class="fw-bolder fs-8"><?php echo e($user->roles->first()?->name ?? "-"); ?></div>
                                                    <a href="#" class="fw-bold text-muted text-hover-primary fs-7"><?php echo e($user->email); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="separator my-2"></div>
                                        <div class="menu-item px-5">
                                            <a href="#"
                                               class="menu-link px-5"
                                               data-bs-toggle="modal"
                                               data-bs-target="#modal_profile"><?php echo e(__("Profil Saya")); ?></a>
                                        </div>
                                        <div class="menu-item px-5">
                                            <a href="#"
                                               class="menu-link px-5 button-ajax"
                                               data-action="<?php echo e(route("logout")); ?>"
                                               data-method="post"
                                               data-csrf="<?php echo e(csrf_token()); ?>"
                                               data-reload="true"><?php echo e(__("Keluar Aplikasi")); ?></a>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center d-lg-none ms-2 me-n3"
                                     title="Show header menu">
                                    <div id="kt_header_menu_mobile_toggle"
                                         class="btn btn-icon btn-active-light-primary w-30px h-30px w-md-40px h-md-40px">
                                        <span class="svg-icon svg-icon-1">
                                            <?php echo asset_svg("assets/media/icons/duotune/text/txt001.svg"); ?>

                                        </span>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>

                <div id="kt_content"
                     class="content py-lg-3 d-flex flex-column flex-column-fluid <?php echo $__env->yieldPushContent("content-container-class"); ?>">

                    <div id="kt_toolbar"
                         class="toolbar">

                        <div id="kt_toolbar_container"
                             class="container-fluid d-flex flex-stack">

                            <div class="d-block d-lg-none"></div>

                            <div class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                 data-kt-swapper="true"
                                 data-kt-swapper-mode="prepend"
                                 data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}">
                                <?php if($app_menu->toolbar_title): ?>
                                    <h2 class="d-flex align-items-center text-dark fw-bolder fs-4 my-1"><?php echo e($app_menu->name); ?></h2>
                                    <span class="h-20px border-gray-300 border-start mx-4"></span>
                                <?php endif; ?>
                                <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-8 my-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="<?php echo e(url("/home")); ?>"
                                           class="text-muted text-hover-primary"><?php echo e(__("Beranda")); ?></a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-dark"><?php echo e($app_module_name); ?></li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-dark"><?php echo e($app_module_sub_name); ?></li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-dark"><?php echo e($app_menu_name); ?></li>
                                    <?php if($app_menu_sub_name): ?>
                                        <li class="breadcrumb-item">
                                            <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                        </li>
                                        <li class="breadcrumb-item text-dark"><?php echo e($app_menu_sub_name); ?></li>
                                    <?php endif; ?>
                                </ul>
                            </div>

                            <div class="d-flex align-items-center">
                                <div class="clock-tick d-none d-lg-block fs-7 text-center user-select-none font-monospace">
                                    <?php echo e(now()->locale("id")->translatedFormat("l, d F Y H:i:s")); ?>

                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="container-fluid <?php echo $__env->yieldPushContent("content-class", "my-4"); ?>"
                         style="<?php echo $__env->yieldPushContent("content-style"); ?>">
                        <?php echo $__env->yieldContent("content"); ?>
                    </div>

                </div>

                <?php echo $__env->make("app.app-footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("livewire"); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("app-profile", compact(["user", "user_role"]))->html();
} elseif ($_instance->childHasBeenRendered('Oja5TZi')) {
    $componentId = $_instance->getRenderedChildComponentId('Oja5TZi');
    $componentTag = $_instance->getRenderedChildComponentTagName('Oja5TZi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Oja5TZi');
} else {
    $response = \Livewire\Livewire::mount("app-profile", compact(["user", "user_role"]));
    $html = $response->html();
    $_instance->logRenderedChild('Oja5TZi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("app-notification", compact("user"))->html();
} elseif ($_instance->childHasBeenRendered('E6Hr6xP')) {
    $componentId = $_instance->getRenderedChildComponentId('E6Hr6xP');
    $componentTag = $_instance->getRenderedChildComponentTagName('E6Hr6xP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E6Hr6xP');
} else {
    $response = \Livewire\Livewire::mount("app-notification", compact("user"));
    $html = $response->html();
    $_instance->logRenderedChild('E6Hr6xP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("app-manual-book")->html();
} elseif ($_instance->childHasBeenRendered('c5buVvq')) {
    $componentId = $_instance->getRenderedChildComponentId('c5buVvq');
    $componentTag = $_instance->getRenderedChildComponentTagName('c5buVvq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('c5buVvq');
} else {
    $response = \Livewire\Livewire::mount("app-manual-book");
    $html = $response->html();
    $_instance->logRenderedChild('c5buVvq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("app.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/main.blade.php ENDPATH**/ ?>