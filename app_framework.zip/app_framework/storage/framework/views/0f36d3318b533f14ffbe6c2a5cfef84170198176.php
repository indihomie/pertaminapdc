<!DOCTYPE html>
<html lang="<?php echo e(str_replace("_", "-", app()->getLocale())); ?>">
<head>

    <meta charset="utf-8">

    <title><?php echo $__env->yieldPushContent("title", config("app.name", "Laravel")); ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset("assets/info/icon.png") . "?" . config("environments.APP_VERSION")); ?>"/>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
    <!-- End Fonts -->

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset("assets/css/style.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/global/plugins.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">

    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/datatables/datatables.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/flatpickr/flatpickr.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/custom/dragsort/dragsort.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("assets/plugins/global/plugins-custom.bundle.css") . "?" . config("environments.APP_VERSION")); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->make("app.style", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Styles -->

    <!-- Scripts -->
    <script src="<?php echo e(asset("assets/plugins/global/plugins.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/js/scripts.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>

    <script src="<?php echo e(asset("assets/plugins/custom/datatables/datatables.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/flatpickr/flatpickr.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/typedjs/typedjs.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/dragsort/dragsort.bundle.js") . "?" . config("environments.APP_VERSION")); ?>"></script>
    <script src="<?php echo e(asset("assets/plugins/custom/ckeditor/ckeditor.js") . "?" . config("environments.APP_VERSION")); ?>"></script>

    <!-- Temporary for test library -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    <!-- End Temporary for test library -->

    <?php echo \Livewire\Livewire::scripts(); ?>

    <!-- End Scripts -->

    <?php echo $__env->yieldPushContent("style"); ?>

</head>
<body id="kt_body"
      class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed <?php echo $__env->yieldPushContent("body-class"); ?> scroll-y overlay overlay-block overlay-hidden"
      style="--kt-toolbar-height: 48px; --kt-toolbar-height-tablet-and-mobile: 48px; <?php echo $__env->yieldPushContent("body-style"); ?>">

<?php echo $__env->yieldContent("body"); ?>

<?php echo $__env->yieldPushContent("livewire"); ?>
<?php echo $__env->yieldPushContent("modals"); ?>

<div id="modal_viewer"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header py-3 border-bottom-0">
                <h3 class="modal-title">
                    <div id="modal_viewer_title"></div>
                    <div class="w-30px border border-bottom border-primary"></div>
                </h3>
                <div class="d-flex">
                    <a id="modal_viewer_download"
                       class="btn btn-sm btn-light"
                       href=""
                       target="_blank">
                        <?php echo e(__("Unduh")); ?>

                    </a>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                        </span>
                    </div>
                </div>
            </div>

            <iframe id="modal_viewer_frame"
                    src=""
                    class="modal-body p-0 w-100"
                    style="height: 80vh; margin: 0"></iframe>

        </div>
    </div>
</div>

<div id="kt_scrolltop"
     class="scrolltop"
     data-kt-scrolltop="true">
    <span class="svg-icon">
        <?php echo asset_svg("assets/media/icons/duotune/arrows/arr081.svg"); ?>

    </span>
</div>

<div class="overlay-layer bg-light bg-opacity-75 rounded"
     style="z-index: 200">
    <div class="spinner-border text-primary" role="status"></div>
</div>

<?php echo $__env->yieldPushContent("script"); ?>
<?php echo $__env->make("app.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/sinergic/app_framework/resources/views/app/app.blade.php ENDPATH**/ ?>