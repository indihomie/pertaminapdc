<div class="livewire">

    <div class="mb-8">
        <div class="fs-2 fw-bold">
            <?php echo e($app_menu->name); ?>

            <div class="w-30px border border-bottom border-primary"></div>
        </div>
    </div>

    <div class="d-flex flex-column flex-lg-row justify-content-between mb-4">
        <div class="d-flex mb-4 mb-lg-0">

            <div class="row g-2">
                <div class="col">

                    <div class="d-flex align-items-center position-relative">
                        <span class="svg-icon svg-icon-1 position-absolute ms-4">
                            <?php echo asset_svg("assets/media/icons/duotune/general/gen021.svg"); ?>

                        </span>
                        <input type="text"
                               class="form-control form-control-solid w-250px ps-15"
                               placeholder="<?php echo e(__("Cari")); ?>"
                               wire:model.debounce.500ms="search"/>
                    </div>

                </div>
                <div class="col">

                    <div class="w-lg-200px position-relative d-flex align-items-center">
                        <div class="svg-icon svg-icon-2 position-absolute mx-4">
                            <?php echo asset_svg("assets/media/icons/duotune/general/gen014.svg"); ?>

                        </div>
                        <input type="text"
                               class="form-control form-control-solid ps-12"
                               placeholder=""
                               readonly
                               data-controls="date-picker"
                               wire:model="date_start">
                    </div>

                </div>
                <div class="col">

                    <div class="w-lg-200px position-relative d-flex align-items-center">
                        <div class="svg-icon svg-icon-2 position-absolute mx-4">
                            <?php echo asset_svg("assets/media/icons/duotune/general/gen014.svg"); ?>

                        </div>
                        <input type="text"
                               class="form-control form-control-solid ps-12"
                               placeholder=""
                               readonly
                               data-controls="date-picker"
                               wire:model="date_end">
                    </div>

                </div>
            </div>

        </div>
        <div class="d-flex">
        </div>
    </div>

    <div class="dataTables_wrapper">
        <div class="table-responsive table-loading">
            <div class="table-loading-message d-none"
                 wire:loading.class.remove="d-none">
                <?php echo e(__("Loading...")); ?>

            </div>
            <table class="table table-row-dashed table-hover dataTable gy-3 gx-3">
                <thead class="fs-7 fw-bolder text-gray-800 text-uppercase border border-dashed user-select-none">
                <tr class="align-middle text-center">
                    <th class="w-30px pe-3">#</th>
                    <th class="w-200px min-w-200px pe-3 border-start-0"><?php echo e(__("Nama")); ?></th>
                    <th class="w-auto max-w-250px"><?php echo e(__("Halaman")); ?></th>
                    <th class="w-100px min-w-100px"><?php echo e(__("Alamat IP")); ?></th>
                    <th class="w-50px min-w-50px pe-3 border-start-0"><?php echo e(__("Metode")); ?></th>
                    <th class="w-125px min-w-125px pe-3 border-start-0"><?php echo e(__("Status")); ?></th>
                    <th class="w-150px min-w-150px pe-3 border-start-0 sorting <?php echo e($sortBy == "created_at" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : ""); ?>"
                        wire:click="sortBy('created_at')"><?php echo e(__("Waktu Akses")); ?></th>
                </tr>
                </thead>
                <tbody class="">
                <?php $__empty_1 = true; $__currentLoopData = $access_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_access_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="align-middle">
                        <td class="text-end"><?php echo e($loop->iteration); ?>.</td>
                        <td class="text-start"><?php echo e($_access_log->user->name ?? "guest"); ?></td>
                        <td class="text-start"><?php echo e(Str::limit($_access_log->path, 88, "...")); ?></td>
                        <td class="text-start font-monospace"><?php echo e($_access_log->ip_address); ?></td>
                        <td class="text-start"><?php echo e($_access_log->method); ?></td>
                        <td class="text-start">
                            <span class="badge <?php echo e($status_codes[$_access_log->status]["class"]); ?>">
                                <?php echo e($_access_log->status); ?>

                                <?php echo e($status_codes[$_access_log->status]["message"]); ?>

                            </span>
                        </td>
                        <td class="text-center font-monospace"><?php echo e($_access_log->created_at->format("d/m/Y H:i:s")); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8"
                            class="p-6 bg-light text-center text-gray-600">
                            <?php echo e(__("Tidak ada data")); ?>

                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-start">
                <div class="dataTables_length me-5"
                     wire:ignore>
                    <select class="form-select form-select-solid w-80px"
                            data-controls="select2"
                            data-search="false"
                            wire:model="perPage">
                        <?php $__currentLoopData = config("paramter.pagination"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_key => $_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($_key); ?>"><?php echo e($_value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="dataTables_info fs-6 fw-bold text-gray-700">
                    <?php echo e(__("Showing")); ?> <?php echo e($access_logs->firstItem()); ?> <?php echo e(__("to")); ?> <?php echo e($access_logs->lastItem()); ?> <?php echo e(__("of")); ?> <?php echo e($access_logs->total()); ?> <?php echo e(__("entries")); ?>

                </div>
            </div>
            <div class="dataTables_paginate ms-0 col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
                <?php echo e($access_logs->links()); ?>

            </div>
        </div>
    </div>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/monitor/access-log.blade.php ENDPATH**/ ?>