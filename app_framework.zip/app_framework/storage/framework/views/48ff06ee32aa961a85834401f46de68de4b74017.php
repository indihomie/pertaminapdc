<script>

    toastr.options = {
        "closeButton": true,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toastr-top-center",
        "preventDuplicates": false,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "2000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    <?php if(session("success")): ?>
    toastr.success(`<?php echo e(session("success")); ?>`)
    <?php endif; ?>

    <?php if(session("info")): ?>
    toastr.info(`<?php echo e(session("info")); ?>`)
    <?php endif; ?>

    <?php if(session("warning")): ?>
    toastr.warning(`<?php echo e(session("warning")); ?>`)
    <?php endif; ?>

    <?php if(session("error")): ?>
    toastr.error(`<?php echo e(session("error")); ?>`)
    <?php endif; ?>

    window.livewire.on("loader", (show) => {

        $("#kt_body")
            .toggleClass("overlay-hidden", !show)

    })

    // form
    window.livewire.on("reset", (id) => {
        $(`#${id}`).trigger("reset")
    })

    // modal
    window.livewire.on("show", (id) => {
        $(`#${id}`).modal("show")
    })

    window.livewire.on("dismiss", (id) => {
        $(`#${id}`).modal("hide")
    })
    // end modal

    // window
    window.livewire.on("download", (path) => {
        window.open(`/download?f=${path}`, "Download")
    })

    window.livewire.on("print", (path) => {
        window.open(`/print?f=${path}`, "Print")
    })

    window.livewire.on("export", (path) => {
        window.open(path, "Export")
    })
    // end window

    window.livewire.on("notification", (response) => {

        switch (response.type) {
            case "success":
                toastr.success(response.message)
                break;
            case "info":
                toastr.info(response.message)
                break;
            case "warning":
                toastr.warning(response.message)
                break;
            case "error":
                toastr.error(response.message)
                break;
            default:
                toastr.info(response.message)
                break;
        }

    })

    Livewire.hook("element.updated", (el, component) => {
        // KTApp.initInputMask()
    })

    Livewire.hook("message.received", (el, component) => {
        KTApp.initSelect2()
    })

    Livewire.hook("message.processed", (el, component) => {

        KTApp.initBootstrapTooltips()

        KTApp.initDateMonthPicker()
        KTApp.initDatePicker()
        KTApp.initDateRangePicker()
        KTApp.initDateTimePicker()
        KTApp.initTimePicker()
        KTApp.initSelect2()
        // KTApp.initTagify()

        KTApp.initInputMask()

        KTPasswordMeter.init()

        initCKEditor()
        initCKEditor2()

    })

    $(document).ready(() => {

        setInterval(() => {
            $(".clock-tick").html(moment().locale("id").format('dddd, DD MMMM YYYY HH:mm:ss'))
        }, 1000)

        KTApp.initViewer()

        initLivewireSwalConfirm()
        initLivewireSwalAlert()

    })

    var initCKEditorReady = false
    const initCKEditor = () => {

        let editor = document.getElementById("editor")

        if (!editor) {
            return
        }

        if (initCKEditorReady) {
            CKEDITOR.instances.editor.setData(editor.value)
            return
        }

        CKEDITOR
            .replace(editor)
            .on("change", function () {
                editor.value = this.getData()
                editor.dispatchEvent(new Event("input"))
            })

        initCKEditorReady = true
    }

    var initCKEditorReady2 = false
    const initCKEditor2 = () => {

        let editor2 = document.getElementById("editor2")

        if (!editor2) {
            return
        }

        if (initCKEditorReady2) {
            CKEDITOR.instances.editor2.setData(editor2.value)
            return
        }

        CKEDITOR
            .replace(editor2)
            .on("change", function () {
                editor2.value = this.getData()
                editor2.dispatchEvent(new Event("input"))
            })

        initCKEditorReady2 = true
    }

    const initLivewireSwalConfirm = () => {

        $("#kt_body")
            .on("click", ".swal-livewire-confirm", function () {

                let wire = $(this).parents(".livewire").attr("wire:id")

                let icon = $(this).attr("data-icon")
                let message = $(this).attr("data-message")
                let textConfirm = $(this).attr("data-text-confirm")
                let textCancel = $(this).attr("data-text-cancel")

                let event = $(this).attr("data-event")
                let target = $(this).attr("data-target")
                let loader = $(this).attr("data-loader")

                if (event === undefined || target === undefined) {
                    return
                }

                Swal
                    .fire({
                        text: message ?? "<?php echo e(__("Konfirmasi")); ?>",
                        icon: icon ?? "warning",
                        padding: ".75rem",
                        buttonsStyling: false,
                        showCancelButton: true,
                        confirmButtonText: textConfirm || "<?php echo e(__("konfirmasi")); ?>",
                        cancelButtonText: textCancel || "<?php echo e(__("Batal")); ?>",
                        customClass: {
                            confirmButton: "btn btn-primary",
                            cancelButton: "btn btn-light"
                        }
                    })
                    .then(result => {

                        if (result.value) {
                            Livewire.emit("loader", true)
                            Livewire.find(wire).call(event, target)
                        }

                    })

            })

    }

    const initLivewireSwalAlert = () => {

        $("#kt_body")
            .on("click", ".swal-alert", function () {

                let icon = $(this).data("icon")
                let message = $(this).data("message")
                let textConfirm = $(this).data("text-confirm")

                Swal
                    .fire({
                        text: message ?? "<?php echo e(__("Konfirmasi")); ?>",
                        icon: icon ?? "warning",
                        padding: ".75rem",
                        buttonsStyling: false,
                        confirmButtonText: textConfirm ?? "<?php echo e(__("konfirmasi")); ?>",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        }
                    })

            })

    }

</script>
<?php /**PATH /home/sinergic/app_framework/resources/views/app/script.blade.php ENDPATH**/ ?>