<?php $__env->startSection("content"); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("app-setting.setting-user",
        compact("app_module", "app_module_sub", "app_menu", "app_path"))->html();
} elseif ($_instance->childHasBeenRendered('lguBNs4')) {
    $componentId = $_instance->getRenderedChildComponentId('lguBNs4');
    $componentTag = $_instance->getRenderedChildComponentTagName('lguBNs4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lguBNs4');
} else {
    $response = \Livewire\Livewire::mount("app-setting.setting-user",
        compact("app_module", "app_module_sub", "app_menu", "app_path"));
    $html = $response->html();
    $_instance->logRenderedChild('lguBNs4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/app-setting/setting-user.blade.php ENDPATH**/ ?>