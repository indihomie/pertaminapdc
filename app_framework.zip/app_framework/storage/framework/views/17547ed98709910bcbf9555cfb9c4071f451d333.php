<div class="d-flex flex-center flex-column-auto p-10">
    <div class="d-flex flex-center fw-bold fs-6">
        <a class="text-muted text-hover-primary px-2"
           href="<?php echo e(url("/#about-us")); ?>"
           target="_blank"><?php echo e(__("Tentang")); ?></a>
        <a class="text-muted text-hover-primary px-2"
           href="<?php echo e(url("/help")); ?>"
           target="_blank"><?php echo e(__("Bantuan")); ?></a>
    </div>
</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/app/guest-footer.blade.php ENDPATH**/ ?>