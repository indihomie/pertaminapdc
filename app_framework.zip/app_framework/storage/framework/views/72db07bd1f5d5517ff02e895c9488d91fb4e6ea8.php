<div id="kt_footer"
     class="footer py-2 d-flex flex-lg-column">
    <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-bold me-1">©<?php echo e(now()->format("Y")); ?></span>
            <a class="text-gray-800 text-hover-primary"
               href="https://sinergics.net"
               target="_blank"><?php echo e($app_information->copyright); ?></a>
        </div>
        <ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">
            <li class="menu-item">
                <a class="menu-link px-2"
                   href="<?php echo e(url("/#about-us")); ?>"
                   target="_blank"><?php echo e(__("Tentang")); ?></a>
            </li>
            <li class="menu-item">
                <a class="menu-link px-2"
                   href="<?php echo e(url("/help")); ?>"
                   target="_blank"><?php echo e(__("Bantuan")); ?></a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/app/app-footer.blade.php ENDPATH**/ ?>