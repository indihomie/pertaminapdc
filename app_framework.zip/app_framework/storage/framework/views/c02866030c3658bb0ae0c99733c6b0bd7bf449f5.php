<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-md modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e($app_menu->name); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Nama")); ?></label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="group.name">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'group.name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'group.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Guard")); ?></label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="group.guard_name">
                        </div>
                        <div class="fs-8 text-muted"><?php echo e(__("gunakan web untup grup user web")); ?></div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'group.guard_name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'group.guard_name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="scroll-x">
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x fs-6 user-select-none">
                            <?php $__currentLoopData = $module_categories->sortByDesc("order"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e($loop->first ? "active" : ""); ?>"
                                       href="#sub_<?php echo e($_category->id); ?>"
                                       data-bs-toggle="tab"
                                    ><?php echo e($_category->name); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <div class="py-4 tab-content min-h-250px">
                        <?php $__currentLoopData = $module_categories->sortByDesc("order"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="sub_<?php echo e($_category->id); ?>"
                                 class="tab-pane fade <?php echo e($loop->first ? "active show" : ""); ?>">

                                <?php $__currentLoopData = ($modules[$_category->id] ?? collect())->sortBy("order"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="my-2 form-check form-check-custom form-check-solid user-select-none">
                                        <input class="form-check-input w-25px h-25px"
                                               type="checkbox"
                                               wire:model.defer="group.permissions.module_<?php echo e($_module->id); ?>">
                                        <span class="form-check-label"><?php echo e($_module->name); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal"><?php echo e(__("Batal")); ?></a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(["{$app_path}.create", "{$app_path}.update"])): ?>
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            <?php echo e(__("Simpan")); ?>

                        </button>
                    <?php endif; ?>
                </div>

            </form>

        </div>

    </div>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/setting/setting-group-user/form-dialog.blade.php ENDPATH**/ ?>