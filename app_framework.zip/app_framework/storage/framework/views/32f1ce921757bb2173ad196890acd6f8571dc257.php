<?php $__env->startSection("content"); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("app-setting.setting-group-user",
        compact("app_module", "app_module_sub", "app_menu", "app_path"))->html();
} elseif ($_instance->childHasBeenRendered('dAPJmeA')) {
    $componentId = $_instance->getRenderedChildComponentId('dAPJmeA');
    $componentTag = $_instance->getRenderedChildComponentTagName('dAPJmeA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dAPJmeA');
} else {
    $response = \Livewire\Livewire::mount("app-setting.setting-group-user",
        compact("app_module", "app_module_sub", "app_menu", "app_path"));
    $html = $response->html();
    $_instance->logRenderedChild('dAPJmeA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/app-setting/setting-group-user.blade.php ENDPATH**/ ?>