<?php $__env->startPush("title", "Masuk Aplikasi"); ?>

<?php $__env->startPush("body-class", "bg-body"); ?>

<?php $__env->startSection("body"); ?>
    <div class="d-flex flex-column flex-root">

        <div class="d-flex flex-column flex-lg-row flex-column-fluid">

            <div class="d-flex flex-column flex-lg-row-auto w-xl-600px position-xl-relative bg-secondary">

                <div class="d-flex flex-column position-xl-fixed top-0 bottom-0 w-xl-600px scroll-y">
                    <div class="d-flex flex-row-fluid flex-column text-center p-10 pt-lg-20">
                        <a class="py-9 mb-4"
                           href="<?php echo e(url("/")); ?>">
                            <img alt="Logo" src="<?php echo e(asset("assets/info/logo.png")); ?>"
                                 class="h-60px"
                                 loading="lazy"/>
                        </a>
                        <h1 class="fw-bolder fs-2 mb-4">
                            <?php echo e($app_information->company); ?>

                        </h1>
                        <p class="fw-bold fs-3">
                            <?php echo e($app_information->name); ?>

                        </p>
                    </div>
                    <div class="d-flex flex-row-auto bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom min-h-100px min-h-lg-350px"
                         style="background-image: url('<?php echo e(asset("assets/media/illustrations/sigma-1/7.png")); ?>')"></div>
                </div>

            </div>

            <div class="d-flex flex-column flex-lg-row-fluid">

                <div class="d-flex flex-center flex-column flex-column-fluid">
                    <div class="w-lg-500px p-10 p-lg-15 mx-auto">

                        <form action="<?php echo e(route("login")); ?>"
                              method="post"
                              class="form w-100"
                              novalidate="novalidate">

                            <?php echo csrf_field(); ?>

                            <div class="text-center mb-12">
                                <h1 class="text-dark mb-4"><?php echo e(__("Masuk Aplikasi")); ?></h1>
                                <?php if(\Laravel\Fortify\Features::enabled(\Laravel\Fortify\Features::registration())): ?>
                                    <div class="text-gray-400">
                                        <?php echo e(__("Belum punya akun?")); ?>

                                        <a href="<?php echo e(route("register")); ?>"
                                           class="link-primary fw-bolder"><?php echo e(__("Buat Akun")); ?></a>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="fv-row mb-6">
                                <label class="form-label fw-bolder text-dark"><?php echo e(__("Username")); ?></label>
                                <div>
                                    <input type="text"
                                           name="username"
                                           class="form-control form-control-solid"
                                           autocomplete="off"/>
                                </div>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'username']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>

                            <div class="fv-row mb-6">
                                <div class="d-flex flex-stack mb-2">
                                    <label class="form-label fw-bolder text-dark mb-0"><?php echo e(__("Password")); ?></label>
                                    <a href="<?php echo e(route("password.request")); ?>"
                                       class="link-primary"><?php echo e(__("Lupa Sandi?")); ?></a>
                                </div>
                                <div>
                                    <div>
                                        <input type="password"
                                               name="password"
                                               class="form-control form-control-solid"
                                               autocomplete="off"/>
                                    </div>
                                </div>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'password']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>

                            <div class="fv-row mb-12">
                                <div class="form-check form-check-solid user-select-none">
                                    <input type="checkbox"
                                           name="remember"
                                           id="remember"
                                           class="form-check-input"
                                           value="">
                                    <label class="form-check-label"
                                           for="remember"><?php echo e(__("Ingat Saya")); ?></label>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit"
                                        class="btn btn-primary w-100 mb-5">
                                    <?php echo e(__("Masuk")); ?>

                                </button>
                            </div>

                        </form>

                    </div>
                </div>

                <?php echo $__env->make("app.guest-footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("app.guest", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/app-auth/login.blade.php ENDPATH**/ ?>