<div id="modal_form"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off"
                  enctype="multipart/form-data">

                <div class="modal-header pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e(__("Hubungan")); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                            <span class="svg-icon svg-icon-2x">
                                <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                            </span>
                    </div>
                </div>

                <div class="modal-body">

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Nama")); ?></label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   disabled
                                   wire:model.defer="account.name">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label"><?php echo e(__("Login Terakhir")); ?></label>
                        <div class="w-250px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   disabled
                                   wire:model.defer="account.login_at">
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.login_at']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.login_at']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['class' => 'mb-2','for' => 'account.relations']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2','for' => 'account.relations']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <div class="d-flex align-items-center justify-content-between">
                        <div class="fs-5 fw-bold"><?php echo e(__("Daftar")); ?></div>
                        <div>
                            <a href="#"
                               wire:click="editAdd">
                                <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                      title="<?php echo e(__("Tambah")); ?>"
                                      data-bs-toggle="tooltip"
                                      data-bs-trigger="hover"
                                      data-bs-dismiss="click">
                                    <img src="<?php echo e(asset("assets/media/icons/table-add.png")); ?>"
                                         class="w-15px">
                                </span>
                            </a>
                        </div>
                    </div>

                    <div class="separator separator-dashed my-2"></div>

                    <?php $__empty_1 = true; $__currentLoopData = $account["relations"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-2 d-flex flex-row">
                            <div class="flex-row-fluid">
                                <select class="form-select"
                                        data-controls="select2"
                                        data-placeholder="<?php echo e(__("- Pilih User -")); ?>"
                                        wire:model="account.relations.<?php echo e($loop->index); ?>.relation_id">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($_user->id); ?>"><?php echo e($_user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'account.relations.'.e($loop->index).'.relation_id']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'account.relations.'.e($loop->index).'.relation_id']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                            <div class="w-10px"></div>
                            <div class="w-row-auto">
                                <a href="#"
                                wire:click="editRemove(<?php echo e($loop->index); ?>)">
                                    <span class="btn btn-sm btn-icon btn-color-danger btn-active-light-danger"
                                          title="<?php echo e(__("Hapus")); ?>"
                                          data-bs-toggle="tooltip"
                                          data-bs-trigger="hover"
                                          data-bs-dismiss="click">
                                        <img src="<?php echo e(asset("assets/media/icons/table-delete.png")); ?>"
                                             class="w-15px">
                                    </span>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="min-h-100px d-flex flex-center"><?php echo e(__("Tidak ada data")); ?></div>
                    <?php endif; ?>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <div>
                        <a class="btn btn-light btn-active-light-primary"
                           href="#"
                           data-bs-dismiss="modal"><?php echo e(__("Batal")); ?></a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(["{$app_path}.create", "{$app_path}.update"])): ?>
                            <button type="submit"
                                    class="btn btn-primary ms-2">
                                <?php echo e(__("Simpan")); ?>

                            </button>
                        <?php endif; ?>
                    </div>
                </div>

            </form>

        </div>

    </div>
</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/other/safety/safety/form-dialog.blade.php ENDPATH**/ ?>