<div>

    <div id="modal_profile"
         class="modal fade"
         data-bs-backdrop="static"
         data-bs-keyboard="false"
         wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content overlay overlay-block overlay-hidden"
                 wire:loading.class.remove="overlay-hidden">

                <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>

                <form action="#"
                      method="post"
                      wire:submit.prevent="save"
                      autocomplete="off"
                      enctype="multipart/form-data">

                    <div class="modal-header pb-0 border-bottom-0">
                        <h3 class="modal-title">
                            <?php echo e(__("Profil")); ?>

                            <div class="w-30px border border-bottom border-primary"></div>
                        </h3>
                        <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                             data-bs-dismiss="modal"
                             aria-label="Close">
                            <span class="svg-icon svg-icon-2x">
                                <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                            </span>
                        </div>
                    </div>

                    <div class="modal-body">

                        <div class="d-flex justify-content-center">
                            <div class="image-input image-input-circle bg-light <?php echo e($user["path_photo"] ? "" : "image-input-empty"); ?>"
                                 data-kt-image-input="true"
                                 style="
                                     background-image: url('<?php echo e(asset("assets/media/avatars/blank.png")); ?>')
                                     "
                                 wire:ignore>
                                <a class="viewer d-block image-input-wrapper w-100px h-100px bgi-size-contain bgi-position-center"
                                   href="<?php echo e(asset("storage/{$user["path_photo"]}")); ?>"
                                   data-ext="<?php echo e(File::extension($user["path_photo"])); ?>"
                                   data-title="<?php echo e(__("Profil")); ?>"
                                   data-download="false"
                                   style="background-image: url('<?php echo e($user["path_photo"] ? asset("storage/{$user["path_photo"]}") : ""); ?>')"></a>
                                <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                       data-kt-image-input-action="change"
                                       data-bs-toggle="tooltip"
                                       data-bs-dismiss="click"
                                       title="<?php echo e(__("Ubah Foto")); ?>">
                                    <i class="bi bi-pencil-fill fs-7"></i>
                                    <input type="file"
                                           name="icon"
                                           accept=".png, .jpg, .jpeg"
                                           wire:model="image"/>
                                    <input type="hidden"
                                           name="icon_remove"
                                           wire:model="image_remove"/>
                                </label>
                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                      data-kt-image-input-action="cancel"
                                      data-bs-toggle="tooltip"
                                      data-bs-dismiss="click"
                                      title="<?php echo e(__("Batalkan Foto")); ?>">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                      data-kt-image-input-action="remove"
                                      data-bs-toggle="tooltip"
                                      data-bs-dismiss="click"
                                      title="<?php echo e(__("Hapus Foto")); ?>"
                                      wire:click="removeImage">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                            </div>
                        </div>

                        <div class="fv-row mb-4">
                            <label class="form-label required"><?php echo e(__("Nama")); ?></label>
                            <div>
                                <input type="text"
                                       class="form-control"
                                       placeholder=""
                                       wire:model.defer="user.name">
                            </div>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'user.name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                        <div class="fv-row mb-4">
                            <label class="form-label"><?php echo e(__("Grup User")); ?></label>
                            <div class="w-lg-300px">
                                <input type="text"
                                       class="form-control bg-light"
                                       placeholder=""
                                       readonly
                                       wire:model.defer="user.role">
                            </div>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'user.role']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.role']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                        <div class="fv-row mb-4">
                            <label class="form-label"><?php echo e(__("Username")); ?></label>
                            <div class="w-lg-200px">
                                <input type="text"
                                       class="form-control bg-light"
                                       placeholder=""
                                       readonly
                                       wire:model.defer="user.username">
                            </div>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'user.username']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                        <div class="fv-row mb-4">
                            <label class="form-label required"><?php echo e(__("Email")); ?></label>
                            <div class="w-lg-300px">
                                <input type="text"
                                       class="form-control"
                                       placeholder=""
                                       wire:model.defer="user.email">
                            </div>
                            <div class="text-muted fs-8"><?php echo e(__("Email bersifat unik, gunakan email aktif untuk menyelesaikan verifikasi email saat email diubah.")); ?></div>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'user.email']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                        <div class="fv-row mb-4">
                            <label class="form-label"><?php echo e(__("Telepon")); ?></label>
                            <div class="w-lg-225px">
                                <input type="text"
                                       class="form-control"
                                       placeholder=""
                                       data-controls="mask"
                                       data-mask="(9999) 9999 9999 9999"
                                       data-unmask="true"
                                       wire:model.defer="user.phone">
                            </div>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'user.phone']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.phone']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                        <div class="fv-row mb-4">
                            <label class="form-label"><?php echo e(__("Verifikasi Email")); ?></label>
                            <div class="w-lg-200px">
                                <input type="text"
                                       class="form-control bg-light"
                                       placeholder=""
                                       readonly
                                       wire:model.defer="user.email_verified_at">
                            </div>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'user.email_verified_at']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.email_verified_at']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                        <div class="fv-row">
                            <label class="form-label"><?php echo e(__("Catatan")); ?></label>
                            <textarea type="text"
                                      class="form-control"
                                      placeholder=""
                                      wire:model.defer="user.description"></textarea>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'user.description']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'user.description']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                    </div>

                    <div class="modal-footer pt-0 border-top-0">
                        <a class="btn btn-light btn-active-light-primary"
                           href="#"
                           data-bs-dismiss="modal"><?php echo e(__("Batal")); ?></a>
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            <?php echo e(__("Simpan")); ?>

                        </button>
                    </div>

                </form>

            </div>

        </div>
    </div>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/app-profile.blade.php ENDPATH**/ ?>