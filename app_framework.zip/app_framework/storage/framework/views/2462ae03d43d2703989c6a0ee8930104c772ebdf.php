<?php $__env->startPush("title", "Password Reset"); ?>

<?php $__env->startSection("body"); ?>

    <div class="flex justify-center font-sans antialiased">

        <div class="w-96">
            <div class="mt-10"></div>
            <img class="w-64 block mx-auto"
                 src="<?php echo e(asset("storage/_/info/logo.png")); ?>"
                 loading="lazy"/>
            <div class="mt-8"></div>
            <div class="p-4 border border-solid border-gray-300 rounded">

                <form action="<?php echo e(route("password.email")); ?>" method="post" autocomplete="off">

                    <?php echo csrf_field(); ?>

                    <h3 class="text-red-600">Lupa Password</h3>
                    <div class="text-md text-gray-500">Masukan email untuk menerima link reset password.</div>

                    <div class="h-4"></div>

                    <?php if(session()->get("success")): ?>
                        <div class="
                            mb-4
                            block
                            text-sm text-left text-white
                            bg-green-500
                            flex
                            items-center
                            p-2
                            rounded-md
                          " role="alert"><?php echo e(session()->get("success")); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__errorArgs = ["failed"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="
                            mb-4
                            block
                            text-sm text-left text-white
                            bg-red-500
                            flex
                            items-center
                            p-2
                            rounded-md
                          " role="alert"><?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div>
                        <div class="text-md font-bold">Email</div>
                        <input type="email"
                               name="email"
                               class="w-full box-border rounded border-2 hover:border-red-400 focus:border-red-400 shadow-none"/>
                        <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-xs text-red-400 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="text-xs text-gray-400">Masukan email akun anda.</div>
                    </div>

                    <div class="h-4"></div>

                    <div class="my-4 border-t border-solid border-gray-300"></div>

                    <div class="flex">
                        <a href="<?php echo e(route("login")); ?>"
                           class="py-1 px-4 bg-transparent hover:bg-red-100 border border-solid border-red-500 rounded font-bold uppercase text-red-500">
                            Kembali
                        </a>
                        <div class="mx-1"></div>
                        <button type="submit"
                                class="flex-1 py-2 px-4 bg-red-500 hover:bg-red-600 rounded font-bold uppercase text-white">
                            Kirim
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("app.guest", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sinergic/app_framework/resources/views/app-auth/forgot-password.blade.php ENDPATH**/ ?>