<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-xl modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        <?php echo e($app_menu->name); ?>

                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            <?php echo asset_svg("assets/media/icons/duotune/arrows/arr061.svg"); ?>

                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="fv-row mb-4">
                        <label class="form-label required"><?php echo e(__("Nama")); ?></label>
                        <div class="w-300px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="group.name"
                                   disabled>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input-error','data' => ['for' => 'group.name']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'group.name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x fs-6">
                        <?php $__currentLoopData = $module_subs->sortBy("order"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e($loop->first ? "active" : ""); ?>"
                                   href="#sub_<?php echo e($_sub->id); ?>"
                                   data-bs-toggle="tab"
                                ><?php echo e($_sub->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <div class="py-4 tab-content overflow-scroll scroll-y"
                         style="height: 50vh">
                        <?php $__currentLoopData = $module_subs->sortBy("order"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_module_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($module_sub_path_replaced = str_replace("-", "", $_module_sub->path)); ?>
                            <div id="sub_<?php echo e($_module_sub->id); ?>"
                                 class="tab-pane fade <?php echo e($loop->first ? "active show" : ""); ?>">

                                <div class="table-responsive table-loading">
            <div class="table-loading-message d-none"
                 wire:loading.class.remove="d-none">
                <?php echo e(__("Loading...")); ?>

            </div>
                                    <table class="table border-gray-300 align-middle gy-3">
                                        <tbody class="fs-6">
                                        <?php $__currentLoopData = $_module_sub->menus->sortBy("order"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php ($menu_path_replaced = str_replace("-", "", $_menu->path)); ?>
                                            <tr>
                                                <td class="min-w-300px fs-7 fw-bold border-bottom border-dashed">
                                                    <?php echo e($_menu->name); ?>

                                                </td>
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_permission => $_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php ($wire_name = "{$module_sub_path_replaced}_{$menu_path_replaced}___{$_permission}"); ?>
                                                    <td class="w-60px">
                                                        <?php if(in_array($_permission, $_menu->permissions)): ?>
                                                            <label class="form-check form-check-custom form-check-solid user-select-none">
                                                                <input class="form-check-input w-20px h-20px"
                                                                       type="checkbox"
                                                                       value="<?php echo e($app_module->path); ?>.<?php echo e($_module_sub->path); ?>.<?php echo e($_menu->path); ?>._.<?php echo e($_permission); ?>"
                                                                       wire:model.defer="group.permissions.<?php echo e($wire_name); ?>">
                                                                <span class="form-check-label fs-7">
                                                                    <?php echo e($_name); ?>

                                                                </span>
                                                            </label>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <?php $__currentLoopData = $_menu->menuSubs->sortBy("order"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_menu_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php ($menu_sub_path_replaced = str_replace("-", "", $_menu_sub->path)); ?>
                                                <tr>
                                                    <td class="min-w-300px fs-7 border-bottom border-dashed">
                                                        <?php echo e($_menu_sub->name); ?>

                                                    </td>
                                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_permission => $_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php ($wire_name = "{$module_sub_path_replaced}_{$menu_path_replaced}_{$menu_sub_path_replaced}_{$_permission}"); ?>
                                                        <td class="w-60px">
                                                            <?php if(in_array($_permission, $_menu_sub->permissions)): ?>
                                                                <label class="form-check form-check-custom form-check-solid user-select-none">
                                                                    <input class="form-check-input w-20px h-20px"
                                                                           type="checkbox"
                                                                           value="<?php echo e($app_module->path); ?>.<?php echo e($_module_sub->path); ?>.<?php echo e($_menu->path); ?>.<?php echo e($_menu_sub->path); ?>.<?php echo e($_permission); ?>"
                                                                           wire:model.defer="group.permissions.<?php echo e($wire_name); ?>">
                                                                    <span class="form-check-label fs-7"><?php echo e($_name); ?></span>
                                                                </label>
                                                            <?php endif; ?>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal"><?php echo e(__("Batal")); ?></a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(["{$app_path}.update"])): ?>
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            <?php echo e(__("Simpan")); ?>

                        </button>
                    <?php endif; ?>
                </div>

            </form>

        </div>

    </div>

</div>
<?php /**PATH /home/sinergic/app_framework/resources/views/livewire/setting/setting-group-access/form-dialog.blade.php ENDPATH**/ ?>