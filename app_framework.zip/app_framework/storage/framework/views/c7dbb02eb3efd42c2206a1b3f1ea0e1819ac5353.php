<style>

    /* color primary */
    #kt_body .text-primary,
    #kt_body .link-primary,
    #kt_body .btn.btn-link,
    #kt_body .page-link:focus,
    #kt_body .page-link:hover,
    #kt_body .btn.btn-light-primary,
    #kt_body .text-hover-primary:hover,
    #kt_body .show > .btn.btn-active-light-primary,
    #kt_body .menu-state-title-primary .menu-item.show > .menu-link .menu-title,
    #kt_body .menu-hover-primary .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here),
    #kt_body .menu-hover-primary .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here),
    #kt_body .menu-state-title-primary .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here) .menu-title,
    #kt_body .menu-state-title-primary .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here) .menu-title,
    #kt_body .btn-check:active + .btn.btn-active-light-primary,
    #kt_body .btn-check:checked + .btn.btn-active-light-primary,
    #kt_body .btn.btn-active-light-primary.active,
    #kt_body .btn.btn-active-light-primary.show,
    #kt_body .btn.btn-active-light-primary:active:not(.btn-active),
    #kt_body .btn.btn-active-light-primary:focus:not(.btn-active),
    #kt_body .btn.btn-active-light-primary:hover:not(.btn-active),
    #kt_body .aside-light .menu .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here) .menu-title,
    #kt_body .aside-light .menu .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here) .menu-title,
    #kt_body .menu-state-primary .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here),
    #kt_body .menu-state-primary .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here),
    #kt_body .menu-state-title-primary .menu-item .menu-link.active .menu-title,
    #kt_body .menu-state-title-primary .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here),
    #kt_body .menu-state-title-primary .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here),
    #kt_body .select2-container--bootstrap5 .select2-dropdown .select2-results__option.select2-results__option--highlighted,
    #kt_body .flatpickr-day.inRange,
    #kt_body .flatpickr-day.nextMonthDay.inRange,
    #kt_body .flatpickr-day.nextMonthDay.today.inRange,
    #kt_body .flatpickr-day.nextMonthDay:focus,
    #kt_body .flatpickr-day.nextMonthDay:hover,
    #kt_body .flatpickr-day.prevMonthDay.inRange,
    #kt_body .flatpickr-day.prevMonthDay.today.inRange,
    #kt_body .flatpickr-day.prevMonthDay:focus,
    #kt_body .flatpickr-day.prevMonthDay:hover,
    #kt_body .flatpickr-day.today.inRange,
    #kt_body .flatpickr-day:focus,
    #kt_body .flatpickr-day:hover,
    #kt_body .btn-check:active + .btn.btn-active-color-primary,
    #kt_body .btn-check:active + .btn.btn-active-color-primary i,
    #kt_body .btn-check:checked + .btn.btn-active-color-primary,
    #kt_body .btn-check:checked + .btn.btn-active-color-primary i,
    #kt_body .btn.btn-active-color-primary.active,
    #kt_body .btn.btn-active-color-primary.active i,
    #kt_body .btn.btn-active-color-primary.show,
    #kt_body .btn.btn-active-color-primary.show i,
    #kt_body .btn.btn-active-color-primary:active:not(.btn-active),
    #kt_body .btn.btn-active-color-primary:active:not(.btn-active) i,
    #kt_body .btn.btn-active-color-primary:focus:not(.btn-active),
    #kt_body .btn.btn-active-color-primary:focus:not(.btn-active) i,
    #kt_body .btn.btn-active-color-primary:hover:not(.btn-active),
    #kt_body .btn.btn-active-color-primary:hover:not(.btn-active) i,
    #kt_body .btn.btn-color-primary.dropdown-toggle:after,
    #kt_body .show > .btn.btn-active-color-primary,
    #kt_body .show > .btn.btn-active-color-primary i {
        color: <?php echo e($app_information->color_primary); ?> !important;
    }

    /* color primary dark */
    #kt_body .btn.btn-link:hover {
        color: <?php echo e($app_information->color_primary_dark); ?> !important;
    }

    /* color white */
    #kt_body .btn-light-primary:hover,
    #kt_body .btn-light-primary:focus,
    #kt_body .page-item.active .page-link:hover,
    #kt_body .select2-container--bootstrap5 .select2-dropdown .select2-results__option.select2-results__option--selected,
    #kt_body .flatpickr-day.endRange,
    #kt_body .flatpickr-day.endRange.inRange,
    #kt_body .flatpickr-day.endRange.nextMonthDay,
    #kt_body .flatpickr-day.endRange.prevMonthDay,
    #kt_body .flatpickr-day.endRange:focus,
    #kt_body .flatpickr-day.endRange:hover,
    #kt_body .flatpickr-day.selected,
    #kt_body .flatpickr-day.selected.inRange,
    #kt_body .flatpickr-day.selected.nextMonthDay,
    #kt_body .flatpickr-day.selected.prevMonthDay,
    #kt_body .flatpickr-day.selected:focus,
    #kt_body .flatpickr-day.selected:hover,
    #kt_body .flatpickr-day.startRange,
    #kt_body .flatpickr-day.startRange.inRange,
    #kt_body .flatpickr-day.startRange.nextMonthDay,
    #kt_body .flatpickr-day.startRange.prevMonthDay,
    #kt_body .flatpickr-day.startRange:focus,
    #kt_body .flatpickr-day.startRange:hover {
        color: #fff !important;
    }

    #kt_body .btn-primary,
    #kt_body .show > .btn.btn-light-primary,
    #kt_body .btn-check:active + .btn.btn-light-primary,
    #kt_body .btn-check:checked + .btn.btn-light-primary,
    #kt_body .btn.btn-light-primary.active,
    #kt_body .btn.btn-light-primary.show,
    #kt_body .btn.btn-light-primary:active:not(.btn-active),
    #kt_body .btn.btn-light-primary:focus:not(.btn-active),
    #kt_body .btn.btn-light-primary:hover:not(.btn-active) {
        background-color: <?php echo e($app_information->color_primary); ?> !important;
        border-color: <?php echo e($app_information->color_primary); ?> !important;
    }

    #kt_body .btn-primary:hover {
        background-color: <?php echo e($app_information->color_primary_dark); ?> !important;
        border-color: <?php echo e($app_information->color_primary_dark); ?> !important;
    }

    /* bg primary transparent */
    #kt_body .bg-light-primary,
    #kt_body .page-link:focus,
    #kt_body .page-link:hover,
    #kt_body .btn.btn-light-primary,
    #kt_body .bg-hover-light-primary:hover,
    #kt_body .show > .btn.btn-active-light-primary,
    #kt_body .btn-check:active + .btn.btn-active-light-primary,
    #kt_body .btn-check:checked + .btn.btn-active-light-primary,
    #kt_body .btn.btn-active-light-primary.active,
    #kt_body .btn.btn-active-light-primary.show,
    #kt_body .btn.btn-active-light-primary:active:not(.btn-active),
    #kt_body .btn.btn-active-light-primary:focus:not(.btn-active),
    #kt_body .btn.btn-active-light-primary:hover:not(.btn-active),
    #kt_body .select2-container--bootstrap5 .select2-dropdown .select2-results__option.select2-results__option--highlighted,
    #kt_body .flatpickr-day.inRange,
    #kt_body .flatpickr-day.nextMonthDay.inRange,
    #kt_body .flatpickr-day.nextMonthDay.today.inRange,
    #kt_body .flatpickr-day.nextMonthDay:focus,
    #kt_body .flatpickr-day.nextMonthDay:hover,
    #kt_body .flatpickr-day.prevMonthDay.inRange,
    #kt_body .flatpickr-day.prevMonthDay.today.inRange,
    #kt_body .flatpickr-day.prevMonthDay:focus,
    #kt_body .flatpickr-day.prevMonthDay:hover,
    #kt_body .flatpickr-day.today.inRange,
    #kt_body .flatpickr-day:focus,
    #kt_body .flatpickr-day:hover {
        background-color: <?php echo e($app_information->color_primary); ?>0d !important;
    }

    /* bg primary */
    #kt_body .scrolltop,
    #kt_body .bg-primary,
    #kt_body .page-item.active .page-link,
    #kt_body .form-check.form-check-solid .form-check-input:checked,
    #kt_body .menu-state-bullet-primary .menu-item .menu-link.active .menu-bullet .bullet,
    #kt_body .aside-light .menu .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here) .menu-bullet .bullet,
    #kt_body .aside-light .menu .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here) .menu-bullet .bullet,
    #kt_body .select2-container--bootstrap5 .select2-dropdown .select2-results__option.select2-results__option--selected,
    #kt_body .flatpickr-day.endRange,
    #kt_body .flatpickr-day.endRange.inRange,
    #kt_body .flatpickr-day.endRange.nextMonthDay,
    #kt_body .flatpickr-day.endRange.prevMonthDay,
    #kt_body .flatpickr-day.endRange:focus,
    #kt_body .flatpickr-day.endRange:hover,
    #kt_body .flatpickr-day.selected,
    #kt_body .flatpickr-day.selected.inRange,
    #kt_body .flatpickr-day.selected.nextMonthDay,
    #kt_body .flatpickr-day.selected.prevMonthDay,
    #kt_body .flatpickr-day.selected:focus,
    #kt_body .flatpickr-day.selected:hover,
    #kt_body .flatpickr-day.startRange,
    #kt_body .flatpickr-day.startRange.inRange,
    #kt_body .flatpickr-day.startRange.nextMonthDay,
    #kt_body .flatpickr-day.startRange.prevMonthDay,
    #kt_body .flatpickr-day.startRange:focus,
    #kt_body .flatpickr-day.startRange:hover {
        background-color: <?php echo e($app_information->color_primary); ?> !important;
    }

    /* bg primary dark */
    #kt_body .bg-primary:hover {
        background-color: <?php echo e($app_information->color_primary_dark); ?> !important;
    }

    #kt_body .border-primary,
    #kt_body .nav-line-tabs .nav-item .nav-link.active,
    #kt_body .nav-line-tabs .nav-item .nav-link:hover:not(.disabled),
    #kt_body .nav-line-tabs .nav-item.show .nav-link {
        border-color: <?php echo e($app_information->color_primary); ?> !important;
    }

    #kt_body .aside-light .menu .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here) .menu-arrow:after,
    #kt_body .aside-light .menu .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here) .menu-arrow:after {
        background-image: url("data:image/svg+xml;charset=utf-8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 9' fill='<?php echo e(urlencode($app_information->color_primary)); ?>'><path fill-rule='evenodd' clip-rule='evenodd' d='M5.935 4.579c.103.2.084.457-.064.635l-3 3.609a.47.47 0 0 1-.706.032.589.589 0 0 1-.035-.777l2.676-3.22-2.65-2.922a.589.589 0 0 1 .001-.777.469.469 0 0 1 .707.001l2.988 3.296a.53.53 0 0 1 .083.123Z'/></svg>") !important;
    }

    #kt_body .svg-icon.svg-icon-primary svg [fill]:not(.permanent):not(g),
    #kt_body .show > .btn.btn-active-light-primary .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .menu-state-icon-primary .menu-item .menu-link.active .menu-icon .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .aside-light .menu .menu-item.hover:not(.here) > .menu-link:not(.disabled):not(.active):not(.here) .menu-icon .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .aside-light .menu .menu-item:not(.here) .menu-link:hover:not(.disabled):not(.active):not(.here) .menu-icon .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn-check:active + .btn.btn-active-light-primary .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn-check:checked + .btn.btn-active-light-primary .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-light-primary.active .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-light-primary.show .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-light-primary:active:not(.btn-active) .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-light-primary:focus:not(.btn-active) .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-light-primary:hover:not(.btn-active) .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn-check:active + .btn.btn-active-color-primary .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn-check:checked + .btn.btn-active-color-primary .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-color-primary.active .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-color-primary.show .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-color-primary:active:not(.btn-active) .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-color-primary:focus:not(.btn-active) .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .btn.btn-active-color-primary:hover:not(.btn-active) .svg-icon svg [fill]:not(.permanent):not(g),
    #kt_body .show > .btn.btn-active-color-primary .svg-icon svg [fill]:not(.permanent):not(g) {
        fill: <?php echo e($app_information->color_primary); ?> !important;
    }

    .cke_reset_all {
        z-index: 10100 !important;
    }

    .cke_dialog {
        z-index: 10101 !important;
    }

</style>
<?php /**PATH /home/sinergic/app_framework/resources/views/app/style.blade.php ENDPATH**/ ?>