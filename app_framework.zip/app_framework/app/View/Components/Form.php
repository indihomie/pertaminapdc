<?php

namespace App\View\Components;

class Form
{

    //CREATED BY : ANGGIT

    //FORM COMPONENT WITH LABEL
    public static function inputLabelText($_label, $_name, $_value, $_required = "", $_label_class = "", $_class_input = "", $_event = "", $maxlength = "", $_attribute = "", $sideAttr = "")
    {
        global $errors;

        $_class_input = $_class_input ?: "mediuminput";
        $_label_class = $_label_class ?: "l-input-small";

        $spanRequired = $_required ? "<span class='required'>*</span>" : '';
        $maxLength = $maxlength ? "maxlength='{$maxlength}'" : '';

        $_value = old($_name, $_value);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$_label_class}'>{$_label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='text' id='{$_name}' name='{$_name}' value='{$_value}' class='{$_class_input}' {$_event} $maxLength {$_attribute}> {$sideAttr}";
        $component .= "</div>";

        foreach ($errors[$_name] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelNumber($label, $id, $value, $required = "", $classLabel = "l-input-small", $classInput = "vsmallinput", $event = "", $maxlength = "", $attr = "", $sideAttr = "")
    {
        global $errors;

        $spanRequired = $required ? "<span class='required'>*</span>" : '';
        $maxLength = $maxlength ? "maxlength='{$maxlength}'" : '';

        $value = old($id, $value);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='number' id='{$id}' name='{$id}' value='{$value}' class='{$classInput}' {$event} $maxLength {$attr}> {$sideAttr}";
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelPassword($label, $id, $required = "", $classLabel = "l-input-small", $classInput = "mediuminput", $attr = "")
    {
        global $errors;

        $spanRequired = $required ? "<span class='required'>*</span>" : '';

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='password' id='{$id}' name='{$id}' class='{$classInput}' {$attr}>";
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelEmail($label, $id, $value, $required = "", $classLabel = "l-input-small", $classInput = "mediuminput", $event = "", $maxlength = "", $attr = "", $sideAttr = "")
    {
        global $errors;

        $spanRequired = $required ? "<span class='required'>*</span>" : '';
        $maxLength = $maxlength ? "maxlength='{$maxlength}'" : '';

        $value = old($id, $value);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='email' id='{$id}' name='{$id}' value='{$value}' class='{$classInput}' {$event} $maxLength {$attr}> {$sideAttr}";
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelTags($label, $id, $value, $required = "", $classLabel = "", $classInput = "", $event = "", $maxlength = "", $attr = "", $sideAttr = "")
    {
        global $errors;

        $classInput = $classInput ?: "mediuminput";
        $classLabel = $classLabel ?: "l-input-small";

        $spanRequired = $required ? "<span class='required'>*</span>" : '';
        $maxLength = $maxlength ? "maxlength='{$maxlength}'" : '';

        $value = old($id, $value);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='text' id='{$id}' name='{$id}' value='{$value}' class='tags {$classInput}' {$event} $maxLength {$attr}> {$sideAttr}";
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelDatePicker(
        string      $label,
        string      $id,
        string|null $value,
        string      $required = "",
        string      $classLabel = "",
        string      $classInput = "",
        string      $attribute = "",
        string      $_min_date = ""
    )
    {
        global $errors;

        $classInput = $classInput ?: "small";
        $classLabel = $classLabel ?: "l-input-small";

        $with_required = $required ? "<span class='required'>*</span>" : '';

        $date = !$value || $value == "0000-00-00" ? "" : getTanggal($value);

        $date = old($id, $date);

        $_min_date = $value < $_min_date ? $value : $_min_date;

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$with_required}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='text' id='{$id}' name='{$id}' value='{$date}' class='hasDatePicker {$classInput}' date-min='$_min_date' {$attribute}>";
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelTimePicker(string $label, string $name, string $value, string|bool $required = "", string $classLabel = "l-input-small", string $classInput = "mediuminput", string $attribute = "")
    {
        global $errors;

        $spanRequired = $required ? "<span class='required'>*</span>" : '';

        $value = old($name, $value);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='text' id='{$name}' name='{$name}' value='{$value}' class='{$classInput} hasTimePicker' {$attribute}>";
        $component .= "</div>";

        foreach ($errors[$name] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelDateTimePicker($label, $idDatePicker, $idTimePicker, $valueDatePicker, $valueTimePicker, $required = "", $classLabel = "l-input-small", $event = "", $attributes = "")
    {
        global $errors;

        $spanRequired = $required ? "<span class='required'>*</span>" : '';

        $valueTimePicker = old($idTimePicker, $valueTimePicker);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='text' id='{$idDatePicker}' name='{$idDatePicker}' value='" . old($idDatePicker, getTanggal($valueDatePicker)) . "' class='hasDatePicker' {$event} {$attributes}>";
        $component .= " ";
        $component .= "<input type='text' id='{$idTimePicker}' name='{$idTimePicker}' value='{$valueTimePicker}' class='hasTimePicker' {$event} {$attributes}>";
        $component .= "</div>";

        foreach ($errors[$idDatePicker] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        foreach ($errors[$idTimePicker] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelSelect($label, $query, $key, $value, $id, $selectedValue, $required = "", $classLabel = "l-input-small", $event = "", $width = "250px", $all = " ")
    {
        global $errors;

        $spanRequired = $required ? "<span class='required'>*</span>" : '';

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= comboData($query, $key, $value, $id, $all, $selectedValue, $event, $width, 'chosen-select');
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelSelectArray(string $_label, string $_name, $datas, string $_index, string $_column, string|int|null $_select, bool|string $_required = "", string $_all = "", string $_class_label = "", string $_class_input = "", string $_attribute = "", string $_width = "")
    {
        global $errors;

        $_class_input = $_class_input ?: "mediuminput";
        $_class_label = $_class_label ?: "l-input-small";

        $label_required = $_required ? "<span class='required'>*</span>" : '';

        $_select = old($_name, $_select);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$_class_label}'>{$_label} {$label_required}</label>";
        $component .= "<div class='field'>";
        $component .= static::selectArray($_label, $_name, $datas, $_index, $_column, $_select, $_all, $_attribute, $_width, $_class_input);
        $component .= "</div>";

        foreach ($errors[$_name] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelRadio(string $_label, string $_name, $datas, string|int|null $_selected, bool|string $_required = "", string $_label_class = "l-input-small", string $_attribute = "")
    {
        global $errors;

        $spanRequired = $_required ? "<span class='required'>*</span>" : '';

        $component = "<div class='my-1'>";
        $component .= "<label {$_label_class}>{$_label} {$spanRequired}</label>";
        $component .= "<div class='fradio'>";

        $position = -1;

        $_selected = old($_name, $_selected);

        foreach ($datas as $key => $value) {

            $position++;

            $checked = ($key == $_selected || ($position == 0 && !$_selected)) ? "checked" : "";

            $component .= "<input type='radio' name='{$_name}' value='{$key}' id='{$_name}-{$key}' {$_attribute} {$checked}/>";
            $component .= "<span class='sradio'> {$value}</span>";

        }

        $component .= "</div>";

        foreach ($errors[$_name] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelSingleCheckBox($label, $id, $value, $selectedValue, $text = "", $required = "", $classLabel = "l-input-small", $event = "")
    {
        global $errors;

        $checked = $selectedValue == $value ? "checked = 'checked'" : "";

        $spanRequired = $required ? "<span class='required'>*</span>" : '';

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='checkbox' id='{$id}' name='{$id}' value='{$value}' {$checked} {$event}> {$text}";
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelCheckBoxes(string $label, string $id, array $checkboxes, string $name = "name", string $value = "value", string $title = "title", array $checks = [], bool $required = false, string $classLabel = "l-input-small")
    {
        global $errors;

        $with_required = $required ? "<span class='required'>*</span>" : '';

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$with_required}</label>";
        $component .= "<div class='field flex items-center'>";

        foreach ($checkboxes as $_ => $checkbox) {
            $checked = $checks[$checkbox[$name]] == $checkbox[$value] ? "checked" : "";
            $component .= "<input type='checkbox' name='{$checkbox[$name]}' id='{$id}-{$checkbox[$name]}' value='{$checkbox[$value]}' {$checked} /> {$checkbox[$title]} &emsp;";
        }

        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelTextArea($label, $id, $value, $required = "", $classLabel = "l-input-small", $classInput = "mediuminput", $event = "", $attr = "")
    {
        global $errors;

        $spanRequired = $required ? "<span class='required'>*</span>" : '';

        $value = old($id, $value);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$classLabel}'>{$label} {$spanRequired}</label>";
        $component .= "<div class='field'>";
        $component .= "<textarea name='{$id}' id='{$id}' class='{$classInput}' {$attr} {$event}>{$value}</textarea>";
        $component .= "</div>";

        foreach ($errors[$id] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelDocument($label, $name, $value, $required = "", $class_label = "l-input-small", $accepts = "", $disabled = false, $view = true, $download = false)
    {
        global $errors;
        static $id;

        $id++;

        $with_required = $required ? " <span class='required'>*</span>" : '';
        $upload = $value ? "none" : "block";
        $delete = $value && !$disabled ? "block" : "none";
        $with_disabled = $disabled ? "disabled" : "";

        $component = "<div class='my-1'>";
        $component .= "<label class='{$class_label}'>{$label}{$with_required}</label>";
        $component .= "<div style='display: flex; align-items: center;'>";
        $component .= "<div class='uploader w' id='{$name}-uploader' style='display: {$upload}'>";
        $component .= "<input type='file' name='{$name}' size='20' id='{$name}-input' class='file-change' for='{$name}' accept='{$accepts}' {$with_disabled} style='opacity: 0;'>";
        $component .= "<input type='hidden' name='{$name}_delete' id='{$name}-status' for='{$name}' value='0'>";
        $component .= "</div>";

        if ($value && $view) {

            $array = explode(".", $value);
            $extension = strtolower(end($array));

            if (in_array($extension, ["png", "jpg", "jpeg", "gif", "ico"])) {

                $component .= "<a href='storage/{$value}' data-fslightbox='gallery' id='{$name}-viewer' class='stdbtn' style='margin-left: .2rem;'>";
                $component .= "<i class='fa fa-eye'></i>";
                $component .= "</a>";

            } else if (in_array($extension, ["pdf", "doc", "docx", "xls", "xlsx"])) {

                $encrypted = encrypt($value);

                $component .= "<a id='{$name}-viewer' class='stdbtn' style='margin-left: .2rem;' onclick='openViewer(`view/{$encrypted}`, `1000`, `600`)'>";
                $component .= "<i class='fa fa-eye'></i>";
                $component .= "</a>";

            } else {
                $component .= "<a id='{$name}-viewer' class='stdbtn' style='margin-left: .2rem;' >?</a>";
            }

        }

        if ($value && $download) {
            $component .= "<a href='storage/{$value}' id='{$name}-download' class='stdbtn' style='margin-left: .2rem;' download>";
            $component .= "<i class='fa fa-download'></i>";
            $component .= "</a>";
        }

        $component .= "<a href='#' id='{$name}-delete' class='stdbtn btn_red file-delete' for='{$name}' style='margin-left: .2rem; display: {$delete}'>";
        $component .= "<i class='fa fa-trash'></i>";
        $component .= "</a>";

        $component .= "</div>";

        foreach ($errors[$name] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    public static function inputLabelTextOption(string $_label, string $_name, string|null $_value, string|null $_value_fake, bool $_required = false, string $_label_class = "l-input-small", string $_class_input = "mediuminput", string $_attribute = "readonly", bool $disabled = false)
    {
        global $errors;

        $with_required = $_required ? "<span class='required'>*</span>" : '';

        $_value_fake = old("{$_name}_fake", $_value_fake);
        $_value = old("{$_name}", $_value);

        $option = !$disabled ? "block" : "none";
        $delete = $_value && !$disabled ? "block" : "none";

        $component = "<div class='my-1'>";
        $component .= "<label class='{$_label_class}'>{$_label} {$with_required}</label>";
        $component .= "<div class='field'>";
        $component .= "<input type='text' id='{$_name}_fake' name='{$_name}_fake' value='{$_value_fake}' class='text-option {$_class_input}' for='{$_name}' {$_attribute} readonly> ";
        $component .= "<input type='hidden' id='{$_name}' name='{$_name}' value='{$_value}'> ";

        $component .= "<div class='inline-flex'>";
        $component .= "<a id='{$_name}-option' class='stdbtn' style='display: {$option}'>";
        $component .= "<i class='fa fa-ellipsis-h'></i>";
        $component .= "</a>";
        $component .= "<a id='{$_name}-remove' class='stdbtn btn_red ml-1 text-option-remove' for='{$_name}' style='display: {$delete}'>";
        $component .= "<i class='fa fa-trash'></i>";
        $component .= "</a>";
        $component .= "</div>";

        $component .= "</div>";

        foreach ($errors[$_name] ?? [] as $message) {
            $component .= "<small class='desc text-red-500'>{$message}</small>";
        }

        $component .= "</div>";

        echo $component;
    }

    //FORM COMPONENT WITHOUT LABEL

    public static function inputDate($_label, $_id, $_value, $_classInput = "", $_event = "")
    {

        $date = !$_value || $_value == "0000-00-00" ? "" : getTanggal($_value);

        return "<input type='text' id='{$_id}' name='{$_id}' value='{$date}' class='hasDatePicker {$_classInput}' title='{$_label}' {$_event}>";
    }

    public static function inputCheckboxes($id, $datas = [], $checks = [], $name, $value, $title, $style = "horizontal")
    {

        $style = $style == "horizontal" ? "&emsp;" : "<br>";

        $component = "";

        foreach ($datas as $k => $values) {
            $checked = $checks[$values[$name]] == $values[$value] ? "checked" : "";
            $component .= "<input type='checkbox' name='{$id}[{$values[$name]}]' id='{$id}-{$values[$name]}' value='{$values[$value]}' {$checked} /> {$values[$title]} $style";
        }

        echo $component;
    }

    public static function spanLabel(string $_label, string|int|null $_value, string $_id = "", string $class_label = "l-input-small", $class_input = "w-6/12")
    {

        $_value = old("{$_id}", $_value);

        $component = "<div class='my-1'>";
        $component .= "<label class='{$class_label}'>{$_label}</label>";
        $component .= "<input type='text' name='{$_id}' id='{$_id}' class='{$class_input} field border-gray-200 bg-white shadow-none border-t-0 border-r-0 border-l-0' value='{$_value}' readonly>";
        $component .= "</div>";

        echo $component;
    }

    // SELECT

    public static function selectArray(string $title, string $name, $datas, string $index, string $column, string|int|null $select, string $all = "", string $java = "", string $width = "200px;", string $class = "")
    {

        $style = $width ? "width: $width;" : "";

        $component = "<select id='$name' class='chosen-select $class' name='$name' title='$title' style='$style' $java>";
        $component .= $all ? "<option value=''>$all</option>" : "";

        foreach ($datas as $key => $data) {

            $key = $index ? $data[$index] : $key;
            $value = $column ? $data[$column] : $data;

            $selected = $key == $select ? "selected" : "";

            $component .= "<option value='$key' $selected>$value</option>";
        }

        $component .= "</select>";

        return $component;
    }

    public static function selectYear(string $_title, string $_name, int $_select, string $_all = "", int $_range = 0, string $_start = "", string $_end = "", string $_class = "", string $_width = "150px", string $_java = "")
    {

        $_range = $_range ?: 5;

        $_start = $_start ?: (($_select ?: date('Y')) - $_range);
        $_end = $_end ?: (($_select ?: date('Y')) + $_range);

        $style = $_width ? "width: $_width;" : "";
        $component = "<select id='$_name' class='chosen-select $_class' name='$_name' title='$_title' style='$style' $_java>";

        $component .= $_all != "" ? "<option value=''>$_all</option>" : "";

        for ($year = $_start; $year <= $_end; $year++) {

            $selected = $year == $_select ? "selected" : "";

            $component .= "<option value='$year' $selected>$year</option>";

        }

        $component .= "</select>";

        return $component;
    }

    public static function selectMonth(string $_title, string $_name, string $_select, string $_all = "", array $_only = [], string $_class = "", string $_width = "150px", string $_java = "")
    {
        global $arr_month;

        $style = $_width ? "width: $_width;" : "";

        $component = "<select id='$_name' class='chosen-select $_class' name='$_name' title='$_title' style='$style' $_java>";

        $component .= $_all ? "<option value=''>$_all</option>" : "";

        for ($month = 1; $month <= 12; $month++) {

            if (count($_only) > 0 && !in_array($month, $_only)) {
                continue;
            }

            $selected = $month == $_select ? "selected" : "";

            $component .= "<option value='{$month}' {$selected}>{$arr_month[$month - 1]}</option>";

        }

        $component .= "</select>";

        return $component;
    }

    public static function CSRF()
    {
        echo "<input type='hidden' name='_token' value='" . csrf_token() . "'>";
    }

}
