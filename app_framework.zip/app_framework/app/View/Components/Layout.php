<?php

namespace App\View\Components;

class Layout
{

    public static function title($isPopup = false, $title = "", $desc = "&nbsp;")
    {
        global $module, $module_sub, $menu, $menu_sub;

        $title = $title ?: $menu['name'];

        $popup_style = $isPopup ? "style='margin: 0 .2rem;'" : "";

        $component = "<div class='pageheader'>";
        $component .= "<h1 class='pagetitle' {$popup_style}>" . strtoupper($title) . "</h1>";
        if (!$isPopup) {
            $component .= "<ul class='breadcrumbs'>";
            $component .= "<li><a href='home' target='_top'>Home</a></li>";
            $component .= "<li><a href='#' target='_top'>{$module["name"]}</a></li>";
            $component .= "<li><a href='#' target='_top'>{$module_sub["name"]}</a></li>";
            $component .= "<li><a href='#' target='_top'>{$menu["name"]}</a></li>";
            $component .= $menu_sub["name"] ? "<li><a href='#' target='_top'>{$menu_sub["name"]}</a></li>" : "";
            $component .= "</ul>";
        }
        $component .= "<span class='pagedesc'>{$desc}</span>";
        $component .= "</div>";

        echo $component;
    }

    public static function formBtnSubmit($isPopup = false, $back = "lihat", $backPar = "mode", $event = "")
    {

        $component = "<p style='position: absolute; right: 20px; top: 10px;'>";
        $component .= "<input type='submit' class='submit radius2' name='btnSimpan' value='Simpan' {$event}/>";
        if(!$isPopup) {
            $component .= "<input type='button' class='cancel radius2' value='Kembali' onclick='window.location='?par[mode]=$back".getPar($par, $backPar)."';'/>";
        }
        $component .= "</p>";

        echo $component;
    }

}
