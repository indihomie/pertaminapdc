<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class TemplateMail extends Mailable
{
    use Queueable, SerializesModels;

    public string $title;
    public string $content;
    public string $path_image;
    public array $path_attachments;

    public function __construct($title, $content, $path_image, $path_attachments)
    {
        $this->title = $title;
        $this->content = $content;
        $this->path_image = $path_image;
        $this->path_attachments = $path_attachments;
    }

    public function build()
    {

        ini_set('memory_limit', '256M');

        $title = $this->title;
        $content = $this->content;
        $image = $this->path_image;
        $attachments = $this->path_attachments;

        return $this
            ->view("app.template-email")
            ->with([
                "image" => $image,
                "title" => $title,
                "content" => $content,
            ])
            ->when(count($attachments) > 0, function ($mail) use ($attachments) {

                foreach ($attachments as $attachment) {
                    $mail->attachFromStorageDisk("public", $attachment);
                }

            })
            ->subject($title);
    }
}
