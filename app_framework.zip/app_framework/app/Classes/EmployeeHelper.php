<?php

namespace App\Classes;

use App\Models\Employee\Employee;
use App\Models\Employee\EmployeePhist;
use App\View\Components\Form;

class EmployeeHelper
{

    public static function detailEmployee()
    {
        global $employee;

        ?>

        <fieldset class="rounded p-4">

            <div class="flex">
                <div class="w-56 flex justify-center">
                    <div class="w-32 h-36 bg-gray-200 rounded border border-solid border-gray-300 bg-cover bg-center bg-no-repeat"
                         style="background-image: url('<?= $employee->photo ? "storage/{$employee->photo}" : "assets/images/photo.png" ?>')"></div>
                </div>
                <div class="w-4"></div>
                <div class="flex-auto flex">
                    <div class="flex-1">

                        <?= Form::spanLabel("Nama", $employee->name) ?>
                        <?= Form::spanLabel("Panggilan", $employee->nickname) ?>
                        <?= Form::spanLabel("Nomor", $employee->number) ?>
                        <?= Form::spanLabel("Kategori", $employee->category->name) ?>

                    </div>
                    <div class="w-4"></div>
                    <div class="flex-1">

                        <?= Form::spanLabel("Posisi", $employee->phist->position->name ?? "?") ?>
                        <?= Form::spanLabel("Struktur 1", "") ?>
                        <?= Form::spanLabel("Struktur 2", "") ?>
                        <?= Form::spanLabel("Struktur 3", "") ?>

                    </div>
                </div>
            </div>

        </fieldset>

        <?php
    }

    public static function selectEmployee(bool $self = false)
    {
        global $user, $par, $json, $search;

        if ($json) {

            $employees = Employee::query()
                ->select([
                    "employees.id",
                    "employees.name",
                    "employees.number",
                    "employee_phists.position_id",
                    "app_masters.name as position"
                ])
                ->join("employee_phists", "employee_phists.employee_id", "=", "employees.id")
                ->leftJoin("app_masters", "app_masters.id", "=", "employee_phists.position_id")
                ->where("employee_phists.status", EmployeePhist::STATUS_ACTIVE)
                ->when($search, function ($query) use ($search) {
                    $query->where(function ($query) use ($search) {
                        $query->orWhere("employees.name", "like", "%{$search}%");
                        $query->orWhere("employees.number", "like", "{$search}%");
                    });
                })
                ->when(!$self, function ($query) use ($user) {
                    $query->where("employees.id", "<>", $user->employee_id);
                })
                ->orderBy("employees.name")
                ->limit(10)
                ->get();

            echo $employees->toJson();

            exit();
        }

        ?>
        <div class="stdform"
             x-data="{ search: '' }"
             x-init="fetchEmployee($data)">

            <form action=""
                  class="stdform"
                  onsubmit="return false">

                <div class="filter_container">
                    <div class="filter_left">

                        <input type="text"
                               class="search m-0"
                               placeholder="Cari..."
                               x-model="search"
                               @input.debounce.500ms="fetchEmployee($data)">

                    </div>
                    <div class="filter_right">
                    </div>
                </div>

            </form>

            <table id="table" class="stdtable stdtablequick">
                <thead>
                <tr>
                    <th width="*" class="align-middle">Nama</th>
                    <th width="100" class="align-middle">Nomor</th>
                    <th width="120" class="align-middle">Jabatan</th>
                    <th width="40" class="align-middle">Pilih</th>
                </tr>
                </thead>
                <tbody id="tbody">
                </tbody>
            </table>

            <script>

                let datas = []

                function fetchEmployee({search}) {

                    toggleLoader(true)

                    axios.post("void?<?= getPar($par) ?>&json=1", {
                        search: search
                    }).then(response => {

                        datas = response.data

                        jQuery("#tbody").html(response.data.map(data => {

                            return `
                                <tr>
                                    <td>${data.name}</td>
                                    <td>${data.number}</td>
                                    <td>${data.position}</td>
                                    <td class="text-center">
                                        <a href="#"
                                            class="text-green-500 hover:text-green-700"
                                            @click="selectEmployee(${data.id})">
                                            <i class="fa fa-check-circle fa-2x"></i>
                                        </a>
                                    </td>
                                </tr>
                            `
                        }).join(""))

                    }).catch(error => {

                        let html = `
                        <tr>
                            <td colspan="4" class="text-center">
                                Data gagal dimuat!
                            </td>
                        </tr>
                        `

                        jQuery("#tbody").html(html)

                    }).finally(_ => {
                        toggleLoader(false)
                    })

                }

                function selectEmployee(_id) {

                    let _detail = datas.find(data => data.id === _id)

                    parent.window.dispatchEvent(new CustomEvent('employee', {
                        detail: _detail
                    }))

                    closeBox()
                }

            </script>

        </div>
        <?php
    }

}
