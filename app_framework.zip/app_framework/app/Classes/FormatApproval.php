<?php

namespace App\Classes;

use App\Models\AppApproval;
use App\Models\AppApprovalStep;
use App\Models\AppFormatApproval;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class FormatApproval
{

    public static function generate($code, $menu_code, $reference_type, $reference_id, $dataset = [], $type = "default")
    {

        $user = auth()->user();
        $approval = AppFormatApproval::query()->firstWhere("code", $code);

        if (!$approval) {

            Log::error("Format Approval tidak ditemukan");

            return ["Error", "Format Approval tidak ditemukan"];
        }

        $approval->load([
            "groups" => function ($query) {
                $query->orderBy("order", "asc");
            },
            "groups.actors" => function ($query) {
                $query->orderBy("operator", "asc");
            },
        ]);

        DB::beginTransaction();

        try {

            $delete = $approval->generated()
                ->where("menu_code", $menu_code)
                ->where("reference_type", $reference_type)
                ->where("reference_id", $reference_id)
                ->where("type", $type)
                ->first();
            $delete?->steps()->delete();
            $delete?->delete();


            $generate = $approval->generated()
                ->create([
                    "menu_code" => $menu_code,
                    "reference_type" => $reference_type,
                    "reference_id" => $reference_id,
                    "type" => $type,
                    "dataset" => ["zzz" => "zzz"],
                    "status" => AppApproval::STATUS_PENDING,
                    "position" => 1,
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            foreach ($approval->groups->sortBy("order") as $group) {

                if (count($group->conditions) == 0) {

                    foreach ($group->actors->sortBy("operator") as $actor) {

                        $generate->steps()
                            ->create([
                                "order" => $group->order,
                                "operator" => $actor->operator,
                                "step_prev" => $group->step_prev,
                                "step_next" => $group->step_next,
                                "status" => AppApprovalStep::STATUS_PENDING,
                                "reference_type" => $actor->reference_type,
                                "reference_id" => $actor->reference_id,
                            ]);

                    }

                    continue;
                }

                $condition_and_count = collect($group->conditions)->where("join", "and")->count();
                $condition_and = 0;
                $condition_or = 0;

                foreach ($group->conditions as $condition) {

                    if ($condition["operator"] == "==" && @$dataset[$condition["parameter"]] == $condition["value"]) {
                        $condition_and += $condition["join"] == "and" ? 1 : 0;
                        $condition_or += $condition["join"] == "or" ? 1 : 0;
                    }

                }

                if ($condition_and == $condition_and_count || $condition_or > 0) {

                    foreach ($group->actors->sortBy("operator") as $actor) {

                        $generate->steps()
                            ->create([
                                "group" => $group->order,
                                "operator" => $actor->operator,
                                "step_prev" => $group->step_prev,
                                "step_next" => $group->step_next,
                                "status" => AppApprovalStep::STATUS_PENDING,
                                "reference_type" => $actor->reference_type,
                                "reference_id" => $actor->reference_id,
                            ]);

                    }

                    if ($group->step_next == 99) {
                        break;
                    }

                }

            }

            if ($generate->steps()->count() == 0) {
                throw new Exception("Tidak ada tahapan approval dibuat.");
            }

            DB::commit();
            return ["OK", null];

        } catch (Exception $e) {

            DB::rollback();
            Log::error($e);

            return ["Error", $e->getMessage()];
        }

    }

    public static function approve($id, $datetime, $user_id, $status, $message = null)
    {

        $approval_step = AppApprovalStep::query()->find($id);
        $approval = $approval_step?->approval;

        if (!($approval_step && $approval)) {
            return ["Error", "Approval not found"];
        }

        DB::beginTransaction();

        try {

            $approval_step->update([
                "approved_at" => $datetime,
                "approved_by" => $user_id,
                "approved_message" => $message,
                "status" => $status,
            ]);

            $steps = $approval->steps()
                ->where("group", $approval_step->group)
                ->get();

            $total = $steps->count();
            $total_pending = $steps->where("status", AppApprovalStep::STATUS_PENDING)->count();
            $total_approved = $steps->where("status", AppApprovalStep::STATUS_APPROVED)->count();
            $total_rejected = $steps->where("status", AppApprovalStep::STATUS_REJECTED)->count();

            $_status = "";
            if ($status == AppApproval::STATUS_PENDING) {
                $_status = AppApproval::STATUS_PENDING;
            }
            if ($status == AppApproval::STATUS_APPROVED) {
                $_status = $approval_step->step_next == 99 ? AppApproval::STATUS_APPROVED : AppApproval::STATUS_PENDING;
            }
            if ($status == AppApproval::STATUS_REJECTED) {
                $_status = AppApproval::STATUS_REJECTED;
            }

            // and || numeric
            if ($approval_step->operator == "and" || is_numeric($approval_step->operator)) {

                // approved progress
                if ($status == AppApprovalStep::STATUS_APPROVED && $total_approved < $total) {
                    $approval->update([
                        "position" => $approval_step->group,
                        "status" => AppApproval::STATUS_PROGRESS,
                    ]);
                }

                // approved
                if ($total_approved == $total || $total_approved == $approval_step->operator) {
                    $approval->update([
                        "position" => $approval_step->step_next,
                        "status" => $_status,
                    ]);
                }

                // pending
                if ($total_pending == $total || $total_pending == $approval_step->operator) {
                    $approval->update([
                        "status" => $_status,
                    ]);
                }

                // rejected
                if ($total_rejected == $total || $total_rejected == $approval_step->operator) {

                    if ($approval_step->step_prev <> 0) {
                        $_status = AppApproval::STATUS_PROGRESS;
                    }

                    $approval->update([
                        "position" => $approval_step->step_prev,
                        "status" => $_status,
                    ]);

                    if ($approval_step->order <> 1) {

                        $step_prev = $approval_step->step_prev;
                        $step_next = $approval_step->order - 1;

                        $approval->steps()
                            ->whereBetween("group", [$step_prev, $step_next])
                            ->update([
                                "approved_at" => $datetime,
                                "approved_by" => null,
                                "approved_message" => null,
                                "status" => AppApprovalStep::STATUS_PENDING,
                            ]);
                    }

                }

            }

            if ($approval_step->operator == "or") {

                if ($status == AppApprovalStep::STATUS_APPROVED) {
                    $approval->update([
                        "position" => $approval_step->step_next,
                        "status" => $_status,
                    ]);
                }

                if ($status == AppApprovalStep::STATUS_PENDING) {
                    $approval->update([
                        "status" => $_status,
                    ]);
                }

                if ($status == AppApprovalStep::STATUS_REJECTED) {

                    if ($approval_step->step_prev == 0) {
                        $_status = AppApproval::STATUS_REJECTED;
                    }

                    $approval->update([
                        "position" => $approval_step->step_prev,
                        "status" => $_status,
                    ]);

                    if ($approval_step->order <> 1) {

                        $step_prev = $approval_step->step_prev;
                        $step_next = $approval_step->order - 1;

                        $approval->steps()
                            ->whereBetween("group", [$step_prev, $step_next])
                            ->update([
                                "approved_at" => $datetime,
                                "approved_by" => null,
                                "approved_message" => null,
                                "status" => AppApprovalStep::STATUS_PENDING,
                            ]);
                    }

                }

            }

            DB::commit();

            return ["OK", null];

        } catch (Exception $e) {

            DB::rollback();
            Log::error($e);

            return ["Error", $e->getMessage()];

        }

    }

}
