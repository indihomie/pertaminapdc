<?php

namespace App\Classes;

use App\Models\AppFormatDocument;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use mikehaertl\wkhtmlto\Pdf;
use Ramsey\Uuid\Uuid;

class FormatDocument
{

    public static function generate(
        string $code,
        array  $dataset,
        string $path = "_pdf",
        string $filename = null
    ): array
    {

        $filename = $filename ?: Uuid::uuid4() . ".pdf";
        $document = AppFormatDocument::query()->firstWhere("code", $code);
        $storage = Storage::disk("public");

        if (!$document) {

            Log::error("Format dokumen tidak ditemukan");

            return ["Error", "Format dokumen tidak ditemukan"];
        }

        $path_root = $storage->path($path);
        $content = $document->content;

        foreach ($dataset as $key => $data) {
            $content = Str::replace($key, $data, $content);
        }

        $pdf = new Pdf([
            "margin-top" => $document->margin_top,
            "margin-right" => $document->margin_right,
            "margin-bottom" => $document->margin_bottom,
            "margin-left" => $document->margin_left,

            // Default page options
            "disable-smart-shrinking",
            "page-size" => $document->paper->description,
        ]);

        $pdf->addPage($content);
        $pdf->saveAs("{$path_root}/{$filename}");

        if ($pdf->getError()) {

            Log::error($pdf->getError());

            return ["Error", $pdf->getError()];
        }

        return ["{$path}/{$filename}", null];
    }

}
