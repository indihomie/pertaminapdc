<?php
namespace App\Classes;
use App\Models\AppApproval;
use App\Models\AppApprovalAktor;
use App\Models\AppApprovalCondition;
use App\Models\AppApprovalDetail;
use App\Models\AppApprovalMaster;
use App\Models\AppApprovalStep;
use App\Models\AppGroup;
use App\View\Components\Form;
use App\View\Components\Layout;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class Approval
{
    public static function create($kodeApproval = null, $kodeMasterMenu = null, $id = null, $dataSet = null, $tipe = "default",  $onSuccess = null, $onError = null)
    {
        global $user;

        DB::beginTransaction();

        try
        {
            $master = AppApprovalMaster::query()->where("kode", $kodeApproval)->first();

            if (!$master)
            {
                $result['success'] = false;
                $result['message'] = "Kode Approval tidak ditemukan";
                return $result;
            }

            $exist = AppApproval::query()->where(["master_id" => $master->id, "menu" => $kodeMasterMenu, "dokumen" => $id])->first();

            if ($exist)
            {
                AppApprovalDetail::query()->where(["approval_id" => $exist->id])->delete();
                $exist->delete();
            }

            $approval = AppApproval::create([
                'master_id' => $master->id,
                'menu' => $kodeMasterMenu,
                'dokumen' => $id,
                'tipe' => $tipe,
                'posisi' => 1,
                'status' => 'new',
                'parameter' => json_encode($dataSet),
                'created_by' => $user->id
            ]);

            $getStep = AppApprovalStep::query()->where("master_id", $master->id)->get();

            if ($getStep->isEmpty())
            {
                $result['success'] = false;
                $result['message'] = "Step Approval {$kodeApproval} tidak ditemukan";
                return $result;
            }

            foreach ($getStep as $step)
            {
                $createDetail = 0;
                $getCondition = AppApprovalCondition::query()->where(["master_id" => $master->id, "step_id" => $step->id])->get();

                if (count($getCondition) == 0) $createDetail++;

                $has_condition = 0;
                foreach ($getCondition as $condition)
                {
                    if ($condition['kondisi'] == ">" && $dataSet[$condition['tipe']] > $condition['nilai']) $has_condition++;

                    if ($condition['kondisi'] == ">=" && $dataSet[$condition['tipe']] >= $condition['nilai']) $has_condition++;

                    if ($condition['kondisi'] == "!=" && $dataSet[$condition['tipe']] != $condition['nilai']) $has_condition++;

                    if ($condition['kondisi'] == "==" && $dataSet[$condition['tipe']] == $condition['nilai']) $has_condition++;

                    if ($condition['kondisi'] == "<=" && $dataSet[$condition['tipe']] <= $condition['nilai']) $has_condition++;

                    if ($condition['kondisi'] == "<" && $dataSet[$condition['tipe']] < $condition['nilai']) $has_condition++;
                }

                if (
                    (is_numeric($condition['parameter']) && $condition['parameter'] == $has_condition) ||
                    ($condition['parameter'] == 'and' && count($getCondition) == $has_condition) ||
                    ($condition['parameter'] == 'or' && $has_condition > 0)
                ) $createDetail++;

                if ($createDetail > 0)
                {
                    $getAktor = AppApprovalAktor::query()->where(["master_id" => $step->master_id, "group" => $step->group])->get();

                    if ($getAktor->isEmpty())
                    {
                        $result['success'] = false;
                        $result['message'] = "Aktor Approval {$kodeApproval} tidak ditemukan";
                        return $result;
                    }

                    foreach ($getAktor as $aktor)
                    {
                        AppApprovalDetail::query()->create([
                            "approval_id" => $approval->id,
                            "urut" => $step->urut,
                            "parameter" => $aktor->parameter,
                            "role_type" => AppGroup::class,
                            "role_id" => $aktor->aktor,
                            "level" => 1,
                            "prev" => $step->prev,
                            "next" => $step->next,
                            "created_by" => $user->id
                        ]);
                    }
                }
            }

            DB::commit();

            $result['success'] = true;
            $result['message'] = "Approval {$kodeApproval} created";
        }
        catch (\Exception $e)
        {
            DB::rollBack();
            Log::error($e);

            $result['success'] = false;
            $result['message'] = "Approval {$kodeApproval} : {$e}";
        }

        return $result;
    }

    public static function view($kodeMenu, $idDokumen, $mode = "formApproval")
    {
        global $par, $user;

        $appr = AppApproval::query()->where(['menu' => $kodeMenu, 'dokumen' => $idDokumen])->first();
        $title = $appr->posisi;
        if ($appr->posisi == 99) $title = "Approved";
        if ($appr->posisi == 0) $title = "Rejected";

        ?>
        <fieldset class="rounded">
            <legend class="px-2">Posisi Approval : <?= $title ?></legend>
            <table class="stdtable stdtablequick">
                <thead>
                <tr>
                    <th width="50">No</th>
                    <th width="200">Role</th>
                    <th width="50">Posisi</th>
                    <th width="150">Kondisi</th>
                    <th width="200">Nama</th>
                    <th width="70">tanggal</th>
                    <th width="200">keterangan</th>
                    <th width="70">status</th>
                    <th width="50">Kontrol</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $apprDetail = AppApprovalDetail::query()
                    ->with([
                        "user:id,name",
                        "role:id,name"
                    ])
                    ->where('approval_id', $appr->id)->orderBy('urut', 'asc')->get();
                $no = 0;
                foreach ($apprDetail as $dtl)
                {
                    $no++;

                    if ($dtl->parameter == "and") $kondisi = "Semua";

                    if ($dtl->parameter == "or") $kondisi = "Salah Satu";

                    if (is_numeric($dtl->parameter)) $kondisi = "Membutuhkan $dtl->parameter Approval";

                    $control = "";
                    if ( ($user->id == 1) or ($appr->posisi == $dtl->urut and $user->group_id == $dtl->role_id) ) $control = "<a  href=\"#\" onclick=\"openBox('popup?par[mode]={$mode}&par[approval_detail_id]={$dtl->id}". getPar($par, "mode, approval_detail_id")."', 600, 300);\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";

                    ?>
                    <tr>
                        <td align="center"><?= $no ?></td>
                        <td align="left"><?= $dtl->role->name ?></td>
                        <td align="center"><?= $dtl->urut ?></td>
                        <td align="left"><?= $kondisi ?></td>
                        <td align="left"><?= $dtl->user->name ?></td>
                        <td align="center"><?= getTanggal($dtl->tanggal) ?></td>
                        <td align="left"><?= $dtl->keterangan ?></td>
                        <td align="center"><?= $dtl->status ?></td>
                        <td align="center"><?= $control ?></td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
        </fieldset>
        <?php
    }

    public static function save()
    {
        global $par, $user, $request;

        $detail = AppApprovalDetail::find($par['approval_detail_id']);

        DB::beginTransaction();

        try
        {
            $detail->update([
                'user_id' => $user->id,
                'tanggal' => setTanggal($request->tanggal),
                'keterangan' => $request->keterangan,
                'status' => $request->status,
                'updated_by' => $user->id
                ]);

            $approval = $detail->approval;

            $details = $approval->details()
                ->select(['id', 'status'])
                ->where('urut', $detail['urut'])
                ->get();

            // total
            $total = $details->count();

            $total_approved = $details->filter(function ($detail) {
                return $detail->status == "approved";
            })->count();

            $total_pending = $details->filter(function ($detail) {
                return $detail->status == "pending";
            })->count();

            $total_rejected = $details->filter(function ($detail) {
                return $detail->status == "rejected";
            })->count();

            // status
            $status = "";
            if ($request->status == "approved")  $status = $detail->next != 99 ? "progress" : "approved";
            if ($request->status == "pending")   $status = "pending";
            if ($request->status == "rejected")  $status = "rejected";


            //////////////////////////////////////// begin th logic ////////////////////////////////////////

            // numeric || ==
            if (is_numeric($detail['parameter']) || $detail['parameter'] == 'and')
            {
                // progress
                if ($status == "approved" && $total_approved < $total)
                {
                    $status = "progress";
                    $approval->update([
                        'posisi' => $detail->urut,
                        'status' => $status
                    ]);
                }

                // approved
                if ($total_approved == $total || (string)$total_approved == $detail['parameter'])
                {
                    $approval->update([
                        'posisi' => $detail['next'],
                        'status' => $status
                    ]);
                }

                // pending
                if ($total_pending == $total || (string)$total_pending == $detail['parameter'])
                {
                    $approval->update([
                        'status' => $status
                    ]);
                }

                // reject
                if ($total_rejected == $total || (string)$total_rejected == $detail['parameter'])
                {
                    if ($detail['prev'] != 0) $status = "progress";

                    $approval->update([
                        'posisi' => $detail['prev'],
                        'status' => $status
                    ]);

                    if ($detail['urut'] != 1)
                    {
                        $end = $detail['urut'] - 1;

                        $approval->details()
                            ->whereRaw("`urut` BETWEEN '$detail[prev]' AND '$end'")
                            ->update([
                                'tanggal' => setTanggal($request->tanggal),
                                'status' => null,
                                'keterangan' => null
                            ]);
                    }
                }
            }

            // ||
            if ($detail['parameter'] == "or")
            {
                if ($request->status == 'approved')
                {
                    $approval->update([
                        'posisi' => $detail['next'],
                        'status' => $status
                    ]);
                }

                if ($request->status == "pending")
                {
                    $approval->update([
                        'status' => $status
                    ]);
                }

                if ($request->status == "rejected")
                {
                    if ($detail['prev'] == 0) $status = "rejected";

                    $approval->update([
                        'posisi' => $detail['prev'],
                        'status' => $status
                    ]);

                    if ($detail['urut'] != 1)
                    {
                        $end = $detail['urut'] - 1;
                        $approval->details()
                            ->whereRaw("`urut` BETWEEN '$detail[prev]' AND '$end'")
                            ->update([
                                'tanggal' => setTanggal($request->tanggal),
                                'status' => null,
                                'keterangan' => null
                            ]);
                    }
                }
            }

            DB::commit();

            $result['success'] = true;
            $result['status'] = $status;
            $result['message'] = "Approval saved";
        }
        catch (\Exception $e)
        {
            DB::rollBack();

            $result['success'] = false;
            $result['status'] = "";
            $result['message'] = $e;
        }

        return $result;
    }

    public static function form()
    {
        global $par;

        $data = AppApprovalDetail::find($par['approval_detail_id']);

        Layout::title(true, "Approval");

        ?>
        <div id="contentwrapper" class="contentwrapper">
            <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
                  onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
                  autocomplete="off">

                <input type="hidden" name="_token" value="<?= csrf_token() ?>">

                <p style="position:absolute;right:5px;top:5px;">
                    <?= Layout::formBtnSubmit(true) ?>
                </p>
                <div id="general" class="subcontent">
                    <?php
                    Form::inputLabelDatePicker("Tanggal", "tanggal", $data->tanggal ?? date("Y-m-d"));
                    Form::inputLabelTextArea("Keterangan", "keterangan", $data->keterangan);
                    Form::inputLabelRadio("Status", "status", ['approved' => 'Approve', 'pending' => 'Pending', 'rejected' => 'Reject'], $data->status);
                    ?>
                </div>
            </form>
        </div>
        <?php
    }
}


?>
