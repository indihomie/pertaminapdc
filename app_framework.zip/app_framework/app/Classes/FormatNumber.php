<?php

namespace App\Classes;

use App\Models\AppFormatNumber;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Riskihajar\Terbilang\Facades\Terbilang;

class FormatNumber
{

    static function generate(string $code, bool $increment = false): ?string
    {

        DB::beginTransaction();

        try {

            $format_number = AppFormatNumber::query()->where("code", $code)->first();

            $columns = $format_number
                ->only([
                    "parameter_1",
                    "parameter_2",
                    "parameter_3",
                    "parameter_4",
                    "parameter_5",
                    "parameter_1_type",
                    "parameter_2_type",
                    "parameter_3_type",
                    "parameter_4_type",
                    "parameter_5_type",
                    "parameter_1_value",
                    "parameter_2_value",
                    "parameter_3_value",
                    "parameter_4_value",
                    "parameter_5_value",
                ]);
            $columns = collect($columns);

            $key_sequence = $columns->flip()->get("sequence");

            if (!$key_sequence) {
                return "Sequence belum diseting";
            }

            $number = [];
            $reset = false;

            $sequence = $columns["{$key_sequence}_value"];
            $sequence_length = $columns["{$key_sequence}_type"];

            for ($n = 1; $n <= 5; $n++) {

                $parameter = $columns["parameter_{$n}"];
                $type = $columns["parameter_{$n}_type"];
                $value = $columns["parameter_{$n}_value"];

                if (!$parameter) {
                    $number[""] = "";
                    continue;
                }

                if ($parameter == "code") {

                    $reset = $reset ?: $type != $value;
                    $number["code"] = $type;

                    continue;
                }

                if ($parameter == "year") {

                    if ($type == "year_4") {
                        $_year = date("Y");
                    } else if ($type == "year_2") {
                        $_year = date("y");
                    } else if ($type == "roman_4") {
                        $_year = Terbilang::roman(date("Y"));
                    } else if ($type == "roman_2") {
                        $_year = Terbilang::roman(date("y"));
                    } else {
                        $_year = "";
                    }

                    $reset = $reset ?: $_year != $value;
                    $number["year"] = $_year;

                    continue;
                }

                if ($parameter == "month") {

                    if ($type == "month") {
                        $_month = date("F");
                    } else if ($type == "month_2") {
                        $_month = date("m");
                    } else if ($type == "month_3") {
                        $_month = Str::upper(date("M"));
                    } else if ($type == "roman") {
                        $_month = Terbilang::roman(date("m"));
                    } else {
                        $_month = "";
                    }

                    $reset = $reset ?: $_month != $value;
                    $number["month"] = $_month;

                    continue;
                }

                if ($parameter == "sequence") {
                    $number["sequence"] = intval($sequence) + 1;
                    continue;
                }

            }

            $number["sequence"] = Str::padLeft($reset ? 1 : ($sequence + 1), $sequence_length, '0');

            if ($increment) {

                $index = 0;
                $update = [];

                foreach ($number as $key => $value) {
                    $index++;
                    $update["parameter_{$index}_value"] = $key != "sequence" ? $value : ((int)$value);
                }

                $format_number->disableLogging();
                $format_number->withoutTimestamps()->update($update);
            }

            DB::commit();

            return implode($format_number->delimiter, array_filter($number));

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            return null;
        }

    }

}
