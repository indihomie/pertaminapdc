<?php

namespace App\Classes;

use Illuminate\Support\Str;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExportExcel
{

    static function simple(
        string $title,
        string $filename = "export.xlsx",
        string $path = "_exports",
        array  $headers = [],
        array  $width = [5],
        array  $datas = [],
        array  $datas_align = []
    )
    {
        global $user;

        $alphabets = range("A", "Z");
        $creator = $user->name ?? config("environments.APP_NAME");

        $header_length = collect($headers)->flatten()->count();
        $header_index = 0;

        $excel_columns = [];
        for ($n = 0; $n < ($header_length + 1); $n++) {
            $excel_columns[$n + 1] = $n < 26 ? $alphabets[$n] : $alphabets[$n / 26 - 1] . $alphabets[$n % 26];
        }

        $spreadsheet = new Spreadsheet();

        $spreadsheet->getProperties()
            ->setCreator($creator)
            ->setTitle($title)
            ->setSubject($title)
            ->setDescription("Report {$title}");


        $spreadsheet->setActiveSheetIndex(0);
        $spreadsheet->getActiveSheet()->setTitle($title);

        $spreadsheet->getActiveSheet()->getSheetView()->setZoomScale(90);
        $spreadsheet->getActiveSheet()->getPageSetup()->setScale(70);
        $spreadsheet->getActiveSheet()->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
        $spreadsheet->getActiveSheet()->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);


        $spreadsheet->getActiveSheet()->getRowDimension(1)->setRowHeight(25);
        $spreadsheet->getActiveSheet()->getStyle(1)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

        // title
        $spreadsheet->getActiveSheet()->mergeCells("{$excel_columns[1]}1:{$excel_columns[$header_length]}1");
        $spreadsheet->getActiveSheet()->setCellValue("{$excel_columns[1]}1", $title_header);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}1")->getFont()->setSize(16)->setBold(true);

        // information
        $spreadsheet->getActiveSheet()->mergeCells("{$excel_columns[1]}2:{$excel_columns[$header_length]}2");
        $spreadsheet->getActiveSheet()->setCellValue("{$excel_columns[1]}2", "exported: " . now()->format("d F Y H:i") . " - " . $creator);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}2")->getFont()->setSize(12);

        // header
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}3:{$excel_columns[$header_length]}3")->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}4:{$excel_columns[$header_length]}4")->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}3")->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_length]}3")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
        $spreadsheet->getActiveSheet()->getStyle(3)->getAlignment()->setVertical(Alignment::HORIZONTAL_CENTER);
        $spreadsheet->getActiveSheet()->getStyle(3)->getAlignment()->setHorizontal(Alignment::VERTICAL_CENTER);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}3:{$excel_columns[$header_length]}3")->getFont()->setBold(true);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}3:{$excel_columns[$header_length]}3")->getFill()->setFillType(Fill::FILL_SOLID);
        $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}3:{$excel_columns[$header_length]}3")->getFill()->getStartColor()->setRGB("EFEFEF");

        if (count($headers) != $header_length) {
            $spreadsheet->getActiveSheet()->getRowDimension(3)->setRowHeight(20);
            $spreadsheet->getActiveSheet()->getRowDimension(4)->setRowHeight(20);
        }

        foreach ($headers as $title => $title_subs) {

            $header_index++;

            if (!is_array($title_subs)) {

                $title = $title_subs;

                $spreadsheet->getActiveSheet()->setCellValue("{$excel_columns[$header_index]}3", Str::upper($title));

                $spreadsheet->getActiveSheet()->getColumnDimension($excel_columns[$header_index])->setWidth($width[$header_index - 1] ?? 30);

                $spreadsheet->getActiveSheet()->mergeCells("{$excel_columns[$header_index]}3:{$excel_columns[$header_index]}4");
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index]}3:{$excel_columns[$header_index]}4")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

                continue;
            }

            $header_sub_length = count($title_subs);

            $spreadsheet->getActiveSheet()->setCellValue("{$excel_columns[$header_index]}3", Str::upper($title));
            $spreadsheet->getActiveSheet()->mergeCells("{$excel_columns[$header_index]}3:{$excel_columns[$header_index + $header_sub_length - 1]}3");
            $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index]}3:{$excel_columns[$header_index + $header_sub_length - 1]}3")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            foreach ($title_subs as $index => $title) {

                $spreadsheet->getActiveSheet()->setCellValue("{$excel_columns[$header_index + $index]}4", Str::upper($title));

                $spreadsheet->getActiveSheet()->getColumnDimension($excel_columns[$header_index + $index])->setWidth($width[$header_index + $index - 1] ?? 20);

                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index + $index]}4")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index + $index]}4")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index + $index]}4")->getFont()->setBold(true);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index + $index]}4")->getFill()->setFillType(Fill::FILL_SOLID);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index + $index]}4")->getFill()->getStartColor()->setRGB("EFEFEF");

                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index + $index]}4")->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_index + $index]}4")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
            }

            $header_index += $header_sub_length - 1;
        }

        $record_row = 4;
        $record_column = 0;
        foreach ($datas as $columns) {

            $record_row++;
            $record_column = 0;

            if (is_string($columns)) {

                $title = $columns;

                $spreadsheet->getActiveSheet()->setCellValue("{$excel_columns[1]}{$record_row}", $title);

                $spreadsheet->getActiveSheet()->mergeCells("{$excel_columns[1]}{$record_row}:{$excel_columns[$header_length]}{$record_row}");

                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_length]}{$record_row}")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}{$record_row}:{$excel_columns[$header_length]}{$record_row}")->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);

                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}{$record_row}")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}{$record_row}")->getFont()->setBold(true);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}{$record_row}")->getFill()->setFillType(Fill::FILL_SOLID);
                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}{$record_row}")->getFill()->getStartColor()->setRGB("EFEFEF");

                continue;
            }

            foreach ($columns as $index => $column) {

                if ($index >= $header_length)
                    continue;

                $record_column++;
                $align = $datas_align[$index] ?? false;

                $spreadsheet->getActiveSheet()->setCellValue("{$excel_columns[$record_column]}{$record_row}", $column);

                $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$record_column]}{$record_row}")
                    ->getAlignment()
                    ->setHorizontal(
                        $align == "center" ? Alignment::HORIZONTAL_CENTER : ($align == "right" ? Alignment::HORIZONTAL_RIGHT : Alignment::HORIZONTAL_LEFT)
                    );

            }

            $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[$header_length]}{$record_row}")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
            $spreadsheet->getActiveSheet()->getStyle("{$excel_columns[1]}{$record_row}:{$excel_columns[$header_length]}{$record_row}")->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
        }

        $writer = new Xlsx($spreadsheet);
        $writer->save(storage_path("app/public/{$path}/{$filename}"));
    }

}
