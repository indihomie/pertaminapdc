<?php

namespace App\Classes;

class ClassFinder
{

    private static $composer = null;
    private static $classes = [];

    public function __construct()
    {

        self::$composer = null;
        self::$classes = [];

        self::$composer = require base_path("vendor/autoload.php");

        if (false === empty(self::$composer)) {
            self::$classes = array_keys(self::$composer->getClassMap());
        }
    }

    public function getClasses()
    {
        $allClasses = [];

        if (false === empty(self::$classes)) {
            foreach (self::$classes as $class) {
                $allClasses[] = "\\{$class}";
            }
        }

        return $allClasses;
    }

    public function getClassesByNamespace($namespace)
    {

        if (!str_starts_with($namespace, "\\")) {
            $namespace = "\\{$namespace}";
        }

        $termUpper = strtoupper($namespace);

        return array_filter($this->getClasses(), function ($class) use ($termUpper) {

            $className = strtoupper($class);

            if (
                str_starts_with($className, $termUpper) &&
                !str_contains($className, strtoupper('abstract')) &&
                !str_contains($className, strtoupper('interface'))
            ) {
                return $class;
            }

            return false;
        });
    }

    public function getClassesWithTerm($term)
    {

        $termUpper = strtoupper($term);

        return array_filter($this->getClasses(), function ($class) use ($termUpper) {

            $className = strtoupper($class);

            if (
                str_contains($className, $termUpper) &&
                !str_contains($className, strtoupper('abstract')) &&
                !str_contains($className, strtoupper('interface'))
            ) {
                return $class;
            }

            return false;
        });
    }

}
