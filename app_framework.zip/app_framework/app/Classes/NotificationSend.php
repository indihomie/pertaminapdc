<?php

namespace App\Classes;

use App\Jobs\NotificationApplicationJob;
use App\Jobs\NotificationEmailJob;
use App\Jobs\NotificationSMSJob;
use App\Models\AppFormatNotification;
use App\Models\AppUser;
use Exception;
use Illuminate\Support\Str;

class NotificationSend
{

    /**
     * @throws Exception
     */
    public static function send(
        string $code,
        array  $dataset,
        int    $user_id,
        string $title = "",
        string $menu = "",
        string $reference_type = "",
        int    $reference_id = 0,
        string $path_image = "",
        array  $attachment = []
    )
    {

        try {

            $user = AppUser::query()->find($user_id, ["id", "phone", "email"]);
            $master = AppFormatNotification::query()->where("code", $code)->firstOrFail();

            $dataset_keys = array_keys($dataset);
            $dataset_values = array_values($dataset);

            $category = $master->category;
            $title = Str::replace("{{title}}", $title, $master->title);

            if ($master->target_application) {

                $template = $master->content_application;
                $content = Str::replace($dataset_keys, $dataset_values, $template);

                NotificationApplicationJob::dispatch(
                    $user->id,
                    $category,
                    $title,
                    $content,
                    $path_image,
                    $attachment,
                    $menu,
                    $reference_type,
                    $reference_id
                );
            }

            if ($master->target_email) {

                $template = $master->content_email;
                $content = Str::replace($dataset_keys, $dataset_values, $template);

                NotificationEmailJob::dispatch(
                    $user->email,
                    $category,
                    $title,
                    $content,
                    $path_image,
                    $attachment,
                    $menu,
                    $reference_type,
                    $reference_id
                );
            }

            if ($master->target_sms) {

                $template = $master->content_sms;
                $content = Str::replace($dataset_keys, $dataset_values, $template);

                NotificationSMSJob::dispatch(
                    $user->phone,
                    $category,
                    $title,
                    $content,
                    $path_image,
                    $attachment,
                    $menu,
                    $reference_type,
                    $reference_id
                );
            }

        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode(), $e->getPrevious());
        }

    }

}
