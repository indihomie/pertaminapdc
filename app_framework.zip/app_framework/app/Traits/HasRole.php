<?php

namespace App\Traits;

trait HasRole
{

    public function hasRole()
    {
        return $this->hasRoles()->first();
    }

}
