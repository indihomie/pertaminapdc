<?php

namespace App\Traits;

use App\Models\AppUser;
use App\Models\Other\SafetyLocationHistories;

trait DependUserToOther
{

    public function relations()
    {
        return $this->belongsToMany(AppUser::class, "safety_relations", "user_id", "relation_id");
    }

    public function locationHistories()
    {
        return $this->hasMany(SafetyLocationHistories::class, "user_id", "id");
    }

}
