<?php

namespace App\Traits;

trait WithSorting
{

    public string $sortBy = "";
    public bool $sortAsc = true;

    public function sortBy($field)
    {
        $this->sortAsc = $this->sortBy === $field ? $this->sortReverse() : true;
        $this->sortBy = $field;
    }

    public function sortReverse()
    {
        return !$this->sortAsc;
    }

}
