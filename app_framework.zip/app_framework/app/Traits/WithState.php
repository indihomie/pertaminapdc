<?php

namespace App\Traits;

trait WithState
{

    public int $STATE_DEL = -1;
    public int $STATE_ADD = 1;
    public int $STATE_EDIT = 2;

}
