<?php

namespace App\Traits;

use App\Models\AppUser;

trait CreatedBy
{

    public function createdBy()
    {
        return $this->hasOne(AppUser::class, "id", "created_by");
    }

}
