<?php

namespace App\Traits;

trait WithStatus
{

    public function getStatusLabelAttribute()
    {
        return config("paramter.status_label")[$this->status] ?? "";
    }

    public function getStatusImageAttribute()
    {
        return config("paramter.status_image")[$this->status] ?? "";
    }

}
