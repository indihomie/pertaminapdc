<?php

namespace App\Traits;

trait WithoutTimestamps
{

    public function scopeWithoutTimestamps()
    {
        $this->timestamps = false;
        return $this;
    }

}
