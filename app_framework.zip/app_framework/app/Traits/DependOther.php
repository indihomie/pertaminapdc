<?php

namespace App\Traits;

class DependOther
{

}
