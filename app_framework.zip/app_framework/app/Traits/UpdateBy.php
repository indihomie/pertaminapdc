<?php

namespace App\Traits;

use App\Models\AppUser;

trait UpdateBy
{

    public function updatedBy()
    {
        return $this->hasOne(AppUser::class, "id", "updated_by");
    }

}
