<?php

namespace App\Traits\Attendance;

use App\Models\Attendance;
use App\Models\Attendance\AttMasterShift;
use App\Models\Attendance\AttSchedule;

trait EmployeePhistToAttendance
{

    public function shift()
    {
        return $this->hasOne(AttMasterShift::class, "id", "shift_id");
    }

    public function schedules()
    {
        return $this->hasMany(AttSchedule::class, "employee_id", "employee_id");
    }

    public function attendances()
    {
        return $this->hasMany(Attendance::class, "employee_id", "employee_id");
    }

}
