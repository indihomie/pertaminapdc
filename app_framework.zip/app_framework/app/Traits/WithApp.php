<?php

namespace App\Traits;

trait WithApp
{

    public $app_module;
    public $app_module_sub;
    public $app_menu;
    public $app_path;

}
