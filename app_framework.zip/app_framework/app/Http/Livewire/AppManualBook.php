<?php

namespace App\Http\Livewire;

use App\Models\AppManualBook as Manual;
use App\Models\AppModuleSub;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Livewire\Component;
use Livewire\WithFileUploads;

class AppManualBook extends Component
{
    use WithFileUploads;

    const TYPE_MANUAL_APP = 0;
    const TYPE_MANUAL_MODULE_SUB = 1;

    protected $listeners = [
        "selectManualApp" => "selectManualApp",
        "selectManual" => "selectManual",
    ];

    public $state;

    public $module_sub;

    public $url;
    public $url_temp;
    public $manual;

    public $file;

    public function mount()
    {
        $this->url = null;
        $this->file = null;
    }

    public function render()
    {

        return view("livewire.app-manual");
    }

    public function updatedFile()
    {

        $file_name = $this->file->getFilename();

        $this->url_temp = "_tmp/{$file_name}";
    }

    public function clear()
    {
        $this->url = "";
    }

    public function select($url)
    {
        $this->url = config("environment.APP_URL") . "/view/" . encrypt($url);
    }

    public function selectManualApp()
    {
        $this->state = self::TYPE_MANUAL_APP;

        $manual = Manual::query()->find(1);

        $this->url = config("environment.APP_URL") . "/view/" . encrypt($manual->path_document);
    }

    public function selectManual(AppModuleSub $module_sub)
    {
        $this->state = self::TYPE_MANUAL_MODULE_SUB;

        $user = auth()->user();

        $manual = $module_sub->manual()
            ->firstOrCreate([
                "created_by" => $user->id,
                "updated_by" => $user->id,
            ]);

        $manual->load("updatedBy:id,name");

        $this->manual = $manual->toArray();
        $this->manual["updated_at"] = $manual->updated_at->format("d F Y H:i");

        $this->url = $manual->path_document ? (config("environment.APP_URL") . "/view/" . encrypt($manual->path_document)) : null;
        $this->url_temp = null;

        $this->file = null;
    }

    public function save()
    {
        $this->update();
    }

    public function removeManual()
    {

        $this->manual["path_document"] = null;
        $this->file = null;

        $this->emit("loader", false);
    }

    private function update()
    {

        $user = auth()->user();
        $manual = $this->manual;

        $file = $this->file;

        DB::beginTransaction();

        try {

            $update = Manual::query()
                ->find($manual["id"]);

            $update->update([
                "updated_by" => $user->id,
            ]);

            if (!$manual["path_document"]) {
                $update->deleteDocument();
            }

            if ($file) {
                $update->uploadDocument($file);
            }

            DB::commit();

            $this->url = $update->path_document ? (config("environment.APP_URL") . "/view/" . encrypt($update->path_document)) : null;

            $this->emit("dismiss", "modal_form_manual");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Buku Manual berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Buku Manual gagal diubah")
            ]);

        }

    }

}
