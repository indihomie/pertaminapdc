<?php

namespace App\Http\Livewire;

use App\Models\AppInformationNews;
use Livewire\Component;
use Livewire\WithPagination;

class AppNews extends Component
{
    use WithPagination;

    public $paginationTheme = "bootstrap";

    protected $listeners = [
        "newsMore" => "more",
        "newsSelect" => "select",
    ];

    public $perPage = 10;

    public $news;

    public function mount()
    {
    }

    public function render()
    {

        return view("livewire.app-news", [
            "newss" => AppInformationNews::query()
                ->with("updatedBy:id,name")
                ->paginate($this->perPage)
        ]);
    }

    public function more()
    {
        $this->news = null;
        $this->page = 1;
    }

    public function select(AppInformationNews $news)
    {
        $this->news = $news;
    }

    public function back()
    {
        $this->news = null;
    }

}
