<?php

namespace App\Http\Livewire\AppMonitor;

use App\Models\AppLogAccess;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Livewire\Component;
use Livewire\WithPagination;
use function auth;
use function view;

class AccessLog extends Component
{
    use WithApp,
        WithPagination,
        WithSorting;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 25;

    public $search;
    public $date_start;
    public $date_end;

    public function mount()
    {
        $this->sortAsc = false;

        $this->date_start = now()->format("Y-m-d");
        $this->date_end = now()->format("Y-m-d");

    }

    public function render()
    {
        $module = $this->app_module;
        $module_sub = $this->app_module_sub;

        $date_start = carbon($this->date_start)->startOfDay()->format("Y-m-d H:i:s");
        $date_end = carbon($this->date_end)->endOfDay()->format("Y-m-d H:i:s");

        $user = auth()->user();

        $status_codes = [
            200 => [
                "message" => "OK",
                "class" => "badge-light-success",
            ],
            202 => [
                "message" => "Invalid",
                "class" => "badge-light-info",
            ],
            302 => [
                "message" => "Redirect",
                "class" => "badge-light",
            ],
            400 => [
                "message" => "Not Found",
                "class" => "badge-light-danger",
            ],
            401 => [
                "message" => "Unauthorized",
                "class" => "badge-light-warning",
            ],
            403 => [
                "message" => "Forbidden",
                "class" => "badge-light-danger",
            ],
            404 => [
                "message" => "Not Found",
                "class" => "badge-light-danger",
            ],
            500 => [
                "message" => "Error",
                "class" => "badge-light-danger",
            ],
        ];

        return view("livewire.monitor.access-log", [
            "status_codes" => $status_codes,
            "access_logs" => AppLogAccess::query()
                ->with([
                    "user:id,name"
                ])
                ->whereBetween("created_at", [$date_start, $date_end])
                ->when(!($module->id == 1 || $module_sub->path == "user-akses"), function ($query) use ($module) {
                    $query->where("path", "LIKE", "{$module->path}%");
                })
                ->when($user->type > 0, function ($query) {
                    $query->where("user_id", ">", 2);
                })
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("ip_address", "like", "%{$this->search}%");
                        $query->orWhere("path", "like", "%{$this->search}%");
                        $query->orWhere("status", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "created_at", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

}
