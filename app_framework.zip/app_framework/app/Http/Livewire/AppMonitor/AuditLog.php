<?php

namespace App\Http\Livewire\AppMonitor;

use App\Classes\ClassFinder;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithPagination;
use Spatie\Activitylog\Models\Activity;
use function view;

class AuditLog extends Component
{
    use WithApp,
        WithPagination,
        WithSorting;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $model_class;
    public $model_status;
    public $date_start;
    public $date_end;

    public $model_classes;
    public $model_statuses;

    public $log;

    public function mount()
    {
        $this->sortAsc = false;

        $class_finder = new ClassFinder();
        $models = $class_finder->getClassesByNamespace("\App\Models");
        $models = collect($models)->mapWithKeys(fn($model) => [Str::substr($model, 1) => Str::replace("\App\Models\\", "", $model)])->toArray();

        $statuses = [
            "created" => "created",
            "updated" => "updated",
            "deleted" => "deleted"
        ];

        $this->model_classes = $models;
        $this->model_statuses = $statuses;

        $this->date_start = now()->format("Y-m-d");
        $this->date_end = now()->format("Y-m-d");
    }

    public function render()
    {

        $status_colors = [
            "created" => "badge-light-success",
            "updated" => "badge-light-warning",
            "deleted" => "badge-light-danger"
        ];

        $date_start = carbon($this->date_start)->startOfDay()->format("Y-m-d H:i:s");
        $date_end = carbon($this->date_end)->endOfDay()->format("Y-m-d H:i:s");

        return view("livewire.monitor.audit-log", [
            "status_colors" => $status_colors,
            "logs" => Activity::query()
                ->with([
                    "subject",
                    "causer"
                ])
                ->whereBetween("created_at", [$date_start, $date_end])
                ->when($this->model_class, function ($query, $subject_type) {
                    $query->where("subject_type", $subject_type);
                })
                ->when($this->model_status, function ($query, $description) {
                    $query->where("description", $description);
                })
                ->orderBy($this->sortBy ?: "created_at", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function detail(Activity $activity)
    {

        $activity->load([
            "causer:id,name"
        ]);

        $attributes = $activity->properties[$activity->description == "updated" ? "attributes" : "old"] ?? null;
        $old = $activity->properties[$activity->description == "updated" ? "old" : "attributes"] ?? null;

        $this->log = $activity->toArray();
        $this->log["created_at"] = $activity->created_at->format("d F Y H:i:s");
        $this->log["attributes"] =  e(json_encode($attributes, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        $this->log["old"] =  e(json_encode($old, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }


}
