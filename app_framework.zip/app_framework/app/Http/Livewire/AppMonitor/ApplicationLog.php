<?php

namespace App\Http\Livewire\AppMonitor;

use App\Traits\WithApp;
use App\Traits\WithSorting;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Jackiedo\LogReader\Exceptions\UnableToRetrieveLogFilesException;
use Jackiedo\LogReader\Facades\LogReader;
use Livewire\Component;
use Livewire\WithPagination;

class ApplicationLog extends Component
{
    use WithApp,
        WithPagination,
        WithSorting;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 25;

    public $log_filenames;
    public $log_filename;

    public $log;

    public function mount()
    {
        $this->sortAsc = false;

        $files = Storage::disk("log")->files("/");
        $files = collect($files)
            ->filter(fn($file) => !Str::contains($file, ".gitignore"))
            ->mapWithKeys(function ($file) {
                return [$file => $file];
            })
            ->reverse();

        $this->log_filename = $files->first();
        $this->log_filenames = $files;

        $this->log = null;
    }

    public function render()
    {

        $level_classes = [
            "emergency" => "badge-light-danger",
            "alert" => "badge-light-danger",
            "critical" => "badge-light-danger",
            "error" => "badge-light-danger",
            "warning" => "badge-light-warning",
            "notice" => "badge-light-info",
            "info" => "badge-light-info",
            "debug" => "badge-light-success",
        ];

        $logReader = LogReader::getFacadeRoot();

        try {

            $logReader->filename($this->log_filename);
            $logReader->orderBy($this->sortBy, $this->sortAsc ? "asc" : "desc");
            $logs = $logReader->paginate($this->perPage, $this->page);

        } catch (UnableToRetrieveLogFilesException $exception) {
            $logs = Paginator::empty();
        }

        return view("livewire.monitor.application-log", [
            "level_classes" => $level_classes,
            "logs" => $logs,
        ]);
    }

    public function detail($log_id)
    {

        $log = LogReader::getFacadeRoot()
            ->filename($this->log_filename)
            ->find($log_id);

        $this->log = [
            "environment" => $log->environment,
            "date" => $log->date->format("d F Y H:i:s"),
            "level" => $log->level,
            "error" => e(json_encode($log->context, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)),
            "trace" => e(json_encode($log->stack_traces, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)),
        ];
    }

}
