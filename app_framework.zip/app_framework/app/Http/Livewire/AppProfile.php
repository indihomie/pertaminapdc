<?php

namespace App\Http\Livewire;

use App\Models\AppUser;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class AppProfile extends Component
{
    use WithFileUploads;

    public $url;

    public $user;
    public $user_role;

    public $image;
    public $image_remove;

    public function mount($user, $user_role)
    {
        $this->url = url()->current();

        $this->user = [
            "id" => $user->id,
            "name" => $user->name,
            "role" => $user_role->name,
            "username" => $user->username,
            "phone" => $user->phone,
            "email" => $user->email,
            "email_verified_at" => $user->email_verified_at?->translatedFormat('d F Y H:i') ?? "-",
            "description" => $user->description,
            "path_photo" => $user->path_photo,
        ];

        $this->image = null;
        $this->image_remove = false;
    }

    public function render()
    {
        return view("livewire.app-profile");
    }

    public function save()
    {
        $user = $this->user;

        $this->validate([
            "user.image" => "sometimes|image|mimes:jpeg,png,jpg,gif|max:1048",
            "user.name" => "required|min:3",
            "user.phone" => "required|min:10",
            "user.email" => "required|email:rfc,dns|unique:app_users,email,{$user["id"]}",
            "user.description" => "sometimes|nullable|min:3",
        ]);

        $this->update();
    }

    public function removeImage()
    {
        $this->image_remove = true;
    }

    private function update()
    {
        $user = $this->user;
        $image = $this->image;
        $image_remove = $this->image_remove;

        $account = auth()->user();

        DB::beginTransaction();

        try {

            $account->update([
                "name" => $user["name"],
                "phone" => $user["phone"],
                "email" => $user["email"],
                "description" => $user["description"],
            ]);

            if ($user["email"] != $account->email) {
                $account->update([
                    "email_verified_at" => null
                ]);
            }

            if ($image_remove) {
                $account->deleteImage();
            }

            if ($image) {
                $account->uploadImage($image);
            }

            DB::commit();

            return redirect()->to($this->url)->with("success", __("Profile berhasil diubah"));

        } catch (Exception $e) {

            DB::rollback();
            Log::error($e);

            $this->emit("dismiss", "modal_profile");
            $this->emit("error", __("Profil gagal disimpan"));
        }

    }

}
