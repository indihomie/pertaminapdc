<?php

namespace App\Http\Livewire;

use App\Models\AppInformationAnnouncement;
use Livewire\Component;
use Livewire\WithPagination;

class AppAnnouncement extends Component
{
    use WithPagination;

    public $paginationTheme = "bootstrap";

    protected $listeners = [
        "announcementMore" => "more",
        "announcementSelect" => "select",
    ];

    public $perPage = 10;

    public $announcement;

    public function mount()
    {
    }

    public function render()
    {

        return view("livewire.app-announcement", [
            "announcements" => AppInformationAnnouncement::query()
                ->with("updatedBy:id,name")
                ->paginate($this->perPage)
        ]);
    }

    public function more()
    {
        $this->announcement = null;
        $this->page = 1;
    }

    public function select(AppInformationAnnouncement $announcement)
    {
        $this->announcement = $announcement;
    }

    public function back()
    {
        $this->announcement = null;
    }

}
