<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AppNotification extends Component
{

    protected $listeners = [
        "notificationMore" => "loadMore",
        "notificationSelect" => "show"
    ];

    public $user;

    public $per_page = 15;
    public $last_at = "";

    public $notification;

    public function mount()
    {

        $last_at = now()->format("Y-m-d H:i:s");

        $this->last_at = $last_at;
    }

    public function render()
    {
        return view("livewire.app-notification");
    }

    public function loadMore()
    {

        $last_at = $this->last_at;

        $user = $this->user;
        $notifications = $user->notifications()
            ->latest()
            ->where("created_at", "<", $last_at)
            ->limit($this->per_page)
            ->get();

        $this->last_at = $notifications->isNotEmpty() ? $notifications->last()->created_at->format("Y-m-d H:i:s") : $last_at;

        $this->emit(
            "notifications",
            $notifications->map(function ($notification) {
                $notification->datetime = $notification->created_at->diffForHumans();
                return $notification;
            })
        );

    }

    public function show($id)
    {
        $user = $this->user;

        $notification = $user->notifications()->findOrFail($id);;
        $notification->load([
            "menus",
            "menus.module:id,path",
            "menus.moduleSub:id,path",
            "menus.menuParent:id,path",
        ]);

        $notification->update([
            "read" => 1
        ]);

        $this->notification = $notification;
    }

}
