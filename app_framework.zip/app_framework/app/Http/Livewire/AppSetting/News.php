<?php

namespace App\Http\Livewire\AppSetting;

use App\Const\State;
use App\Models\AppInformationNews;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class News extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $news;

    public $image;

    public function mount()
    {
        $this->sortAsc = false;

        $this->create();
    }

    public function render()
    {

        return view("livewire.setting.news", [
            "newss" => AppInformationNews::query()
                ->when($this->search, function ($query) {
                    return $query->where("name", "like", "%{$this->search}%");
                })
                ->orderBy($this->sortBy ?: "datetime", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->news = [
            "id" => "",
            "datetime" => "",
            "name" => "",
            "content" => "",
            "source" => "",
            "path_image" => "",
            "status" => AppInformationNews::STATUS_ACTIVE,
        ];
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function edit(AppInformationNews $news)
    {
        $this->state = State::EDIT;
        $this->news = $news->toArray();
        $this->news["datetime"] = $news->datetime->format("Y-m-d H:i");
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function removeImage()
    {
        $this->news["path_image"] = null;
        $this->image = [
            "file" => null,
            "remove" => true
        ];
    }

    public function save()
    {

        $this->validate([
            "image.file" => ["nullable", "image", "mimes:jpeg,png,jpg,gif", "max:2048"],
            "news.datetime" => ["required", "date_format:Y-m-d H:i"],
            "news.name" => ["required"],
            "news.source" => ["nullable"],
            "news.status" => ["required", "boolean"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $news = $this->news;

        DB::beginTransaction();

        try {

            $create = AppInformationNews::query()
                ->create([
                    "datetime" => $news["datetime"],
                    "name" => $news["name"],
                    "source" => $news["source"],
                    "content" => $news["content"],
                    "status" => $news["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            if ($this->image["file"]) {
                $create->uploadImage($this->image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Berita berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Berita gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $news = $this->news;

        DB::beginTransaction();

        try {

            $update = AppInformationNews::query()->find($news["id"]);

            $update->update([
                "datetime" => $news["datetime"],
                "name" => $news["name"],
                "source" => $news["source"],
                "content" => $news["content"],
                "status" => $news["status"],
                "updated_by" => $user->id,
            ]);

            if ($this->image["remove"]) {
                $update->deleteImage();
            }

            if ($this->image["file"]) {
                $update->uploadImage($this->image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Berita berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Berita gagal diubah")
            ]);
        }

    }

    public function destroy(AppInformationNews $news)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $news->deleteImage();
            $news->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Berita berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Berita gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
