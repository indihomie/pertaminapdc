<?php

namespace App\Http\Livewire\AppSetting;

use App\Const\State;
use App\Models\AppModule;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Livewire\Component;
use Livewire\WithPagination;
use Spatie\Permission\Models\Role;

class SettingGroupUser extends Component
{
    use WithApp,
        WithPagination,
        WithSorting;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $group;

    public function mount()
    {
        $this->sortBy = "name";

        $this->create();
    }

    public function render()
    {

        $modules = AppModule::query()
            ->with("category")
            ->get();
        $module_categories = $modules->pluck("category")->unique();

        return view("livewire.setting.setting-group-user", [
            "module_categories" => $module_categories,
            "modules" => $modules->groupBy("category_id"),
            "groups" => Role::query()
                ->withCount("users")
                ->when($this->search, function ($query) {
                    return $query->where("name", "like", "%{$this->search}%");
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->group = [
            "id" => "",
            "name" => "",
            "guard_name" => "web",
        ];
    }

    public function edit(Role $role)
    {
        $permissions = $role->permissions()
            ->where("name", "like", "module_%")
            ->pluck("name")
            ->mapWithKeys(function ($permission) {
                return [$permission => true];
            });

        $this->state = State::EDIT;
        $this->group = $role->toArray();
        $this->group["permissions"] = $permissions;
    }

    public function save()
    {

        $this->validate([
            "group.name" => "required|max:255",
            "group.guard_name" => "required|max:255",
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $group = $this->group;

        DB::beginTransaction();

        try {

            $create = Role::query()
                ->create([
                    "name" => $group["name"],
                    "guard_name" => $group["guard_name"],
                ]);

            $permissions = array_filter($group["permissions"]);
            $permissions = array_keys($permissions);

            $create->givePermissionTo($permissions);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Grup User berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Grup User gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $group = $this->group;

        DB::beginTransaction();

        try {

            $update = Role::query()->find($group["id"]);

            $update->update([
                "name" => $group["name"],
                "guard_name" => $group["guard_name"],
            ]);

            $permissions = array_filter($group["permissions"]);
            $permissions = array_keys($permissions);

            $permission_exists = $update->permissions()
                ->where("name", "like", "module_%")
                ->pluck("name", "id");
            $permission_removes = $permission_exists->diff($permissions)->keys();

            $update->permissions()->detach($permission_removes);
            $update->givePermissionTo($permissions);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Grup User berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Grup User gagal diubah")
            ]);
        }

    }

    public function destroy(Role $role)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $role->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Grup User berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Grup User gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
