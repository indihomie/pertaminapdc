<?php

namespace App\Http\Livewire\AppSetting;

use App\Const\State;
use App\Models\AppModuleSub;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\WithPagination;

class SettingModuleSub extends Component
{
    use WithApp,
        WithPagination,
        WithSorting;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $module_sub;

    public function mount()
    {
        $this->sortBy = "order";

        $this->create();
    }

    public function render()
    {
        $module = $this->app_module;

        return view("livewire.setting.setting-module-sub", [
            "module_subs" => AppModuleSub::query()
                ->withCount("menus")
                ->where("module_id", $module->id)
                ->when($this->search, function ($query) {
                    return $query->where("name", "like", "%{$this->search}%");
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $module = $this->app_module;
        $order = $module->moduleSubs()->orderByDesc("order")->first()->order;

        $this->state = State::CREATE;
        $this->module_sub = [
            "id" => "",
            "path" => "",
            "name" => "",
            "order" => ($order ?? 0) + 1,
            "status" => true,
        ];
    }

    public function edit(AppModuleSub $module_sub)
    {
        $this->state = State::EDIT;
        $this->module_sub = $module_sub->toArray();
    }

    public function save()
    {
        $module = $this->app_module;
        $module_sub = $this->module_sub;

        $this->validate([
            "module_sub.path" => [
                "required",
                Rule::unique("app_module_subs", "path")
                    ->where("module_id", $module->id)
                    ->ignore($module_sub["id"]),
            ],
            "module_sub.name" => "required",
            "module_sub.order" => "required|numeric",
            "module_sub.status" => "sometimes|bool",
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $module = $this->app_module;
        $module_sub = $this->module_sub;

        DB::beginTransaction();

        try {

            $module->moduleSubs()
                ->create([
                    "path" => Str::lower($module_sub["path"]),
                    "name" => $module_sub["name"],
                    "order" => $module_sub["order"],
                    "status" => $module_sub["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Sub Modul berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Sub Modul gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $module_sub = $this->module_sub;

        DB::beginTransaction();

        try {

            AppModuleSub::query()
                ->find($module_sub["id"])
                ->update([
                    "path" => $module_sub["path"],
                    "name" => $module_sub["name"],
                    "order" => $module_sub["order"],
                    "status" => $module_sub["status"],
                    "updated_by" => $user->id,
                ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Sub Modul berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Sub Modul gagal diubah")
            ]);
        }

    }

    public function destroy(AppModuleSub $module_sub)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $module_sub->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Sub Modul berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Sub Modul gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
