<?php

namespace App\Http\Livewire\AppSetting;

use App\Const\State;
use App\Models\AppMaster;
use App\Models\AppMenu;
use App\Models\AppModule;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class SettingModule extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;
    public $category_id;

    public $categories;
    public $types;

    public $state;
    public $module;

    public $image;

    public function mount()
    {
        $this->sortBy = "order";

        $this->categories = AppMaster::query()->where("category_id", "S001")->pluck("name", "id")->toArray();
        $this->types = AppModule::TYPES;

        $this->create();
    }

    public function render()
    {

        $permission_modules = Permission::query()

            ->withCount([
                "roles" => function ($query) {
                    $query->where("name", "like", "Super Admin");
                }
            ])
            ->where("name", "LIKE", "module_%")
            ->get()
            ->filter(fn($permission) => $permission->roles_count > 0)
            ->mapWithKeys(fn($permission) => [$permission->name => $permission->roles_count])
            ->toArray();

        return view("livewire.setting.setting-module", [
            "permission_modules" => $permission_modules,
            "modules" => AppModule::query()
                ->with("category:id,name")
                ->when($this->category_id, function ($query) {
                    return $query->where("category_id", $this->category_id);
                })
                ->when($this->search, function ($query) {
                    return $query->where("name", "like", "%{$this->search}%");
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function updatedModuleCategoryId($category_id)
    {
        $module = AppModule::query()->orderByDesc("order")->firstWhere("category_id", $category_id);

        $this->module["order"] = $module ? $module->order + 1 : 1;
    }

    public function removeImage()
    {
        $this->module["path_icon"] = null;
        $this->image = [
            "file" => null,
            "remove" => true
        ];
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->module = [
            "id" => "",
            "category_id" => "",
            "path" => "",
            "name" => "",
            "order" => 1,
            "type" => AppModule::TYPE_MODULE,
            "link" => "",
            "path_icon" => "",
            "status" => true,
        ];
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function edit(AppModule $module)
    {
        $this->state = State::EDIT;
        $this->module = $module->toArray();
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function save()
    {
        $module = $this->module;

        $this->validate([
            "image.file" => "nullable|image|mimes:jpeg,png,jpg,gif|max:1048",
            "module.category_id" => "required|exists:app_masters,id",
            "module.path" => "required|unique:app_modules,path,{$module["id"]}",
            "module.name" => "required",
            "module.order" => "required|numeric",
            "module.type" => "required|in:" . implode(",", array_keys(AppModule::TYPES)),
            "module.status" => "sometimes|bool",
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $role = Role::findById(1);

        $_module = $this->module;
        $image = $this->image;

        $permissions = [];
        $accesses = $this->templateAccess();

        DB::beginTransaction();

        try {

            $module = AppModule::query()
                ->create([
                    "category_id" => $_module["category_id"],
                    "path" => Str::lower($_module["path"]),
                    "name" => $_module["name"],
                    "type" => $_module["type"],
                    "link" => $_module["link"],
                    "order" => $_module["order"],
                    "status" => $_module["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            if ($image["file"]) {
                $module->uploadImage($image["file"]);
            }

            $module_sub = $module->moduleSubs()
                ->create([
                    "path" => $accesses["path"],
                    "name" => $accesses["name"],
                    "description" => $accesses["description"],
                    "path_icon" => $accesses["path_icon"],
                    "order" => $accesses["order"],
                    "status" => $accesses["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            foreach ($accesses["menus"] as $_menu) {

                $menu = $module_sub->menus()
                    ->create([
                        "module_id" => $module->id,
                        "module_sub_id" => 0,
                        "menu_id" => 0,
                        "level" => 1,
                        "path" => $_menu["path"],
                        "code" => "",
                        "name" => $_menu["name"],
                        "parameter" => $_menu["parameter"],
                        "target_type" => $_menu["target_type"],
                        "target" => $_menu["target"],
                        "permissions" => $_menu["permissions"],
                        "order" => $_menu["order"],
                        "path_icon" => $_menu["path_icon"],
                        "toolbar_side" => $_menu["toolbar_side"],
                        "status" => $_menu["status"],
                        "created_by" => $user->id,
                        "updated_by" => $user->id,
                    ]);

                foreach ($_menu["permissions"] as $_permission) {
                    $permissions[] = "{$module->path}.{$module_sub->path}.{$menu->path}._.{$_permission}";
                }

                foreach ($_menu["subs"] as $_menu_sub) {

                    $menu_sub = $menu->menuSubs()
                        ->create([
                            "module_id" => $module->id,
                            "module_sub_id" => $module_sub->id,
                            "menu_id" => $menu->id,
                            "level" => 2,
                            "path" => $_menu_sub["path"],
                            "code" => "",
                            "name" => $_menu_sub["name"],
                            "parameter" => $_menu_sub["parameter"],
                            "target_type" => $_menu_sub["target_type"],
                            "target" => $_menu_sub["target"],
                            "permissions" => $_menu_sub["permissions"],
                            "path_icon" => $_menu_sub["path_icon"],
                            "order" => $_menu_sub["order"],
                            "toolbar_side" => $_menu_sub["toolbar_side"],
                            "status" => $_menu_sub["status"],
                            "created_by" => $user->id,
                            "updated_by" => $user->id,
                        ]);

                    foreach ($_menu_sub["permissions"] as $_permission) {
                        $permissions[] = "{$module->path}.{$module_sub->path}.{$menu->path}.{$menu_sub->path}.{$_permission}";
                    }

                }

            }

            $role->permissions()->create([
                "name" => "module_{$module->id}"
            ]);

            foreach ($permissions as $permission) {
                $role->permissions()->create([
                    "name" => $permission
                ]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Modul berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Modul gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $module = $this->module;
        $image = $this->image;

        DB::beginTransaction();

        try {

            $update = AppModule::query()->find($module["id"]);

            $update->update([
                "category_id" => $module["category_id"],
                "path" => $module["path"],
                "name" => $module["name"],
                "type" => $module["type"],
                "order" => $module["order"],
                "link" => $module["link"],
                "status" => $module["status"],
                "updated_by" => $user->id
            ]);

            if ($image["remove"]) {
                $update->deleteImage();
            }

            if ($image["file"]) {
                $update->uploadImage($image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Modul berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Modul gagal diubah")
            ]);
        }

    }

    public function destroy(AppModule $module)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            Permission::query()->where("name", "module_{$module->id}")->delete();
            Permission::query()->where("name", "like", "{$module->path}.%")->delete();

            $module->moduleSubs()->delete();
            $module->menus()->delete();

            $module->deleteImage();
            $module->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Modul berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Modul gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

    private function templateAccess()
    {

        return collect([
            "path" => "pengaturan",
            "name" => "Pengaturan",
            "path_icon" => "_/module_sub/_setting.png",
            "description" => "",
            "order" => 1,
            "status" => 1,
            "menus" => [
                [
                    "path" => "user-manajemen",
                    "name" => "User Manajemen",
                    "parameter" => "",
                    "target_type" => AppMenu::MENU_TARGET_DROPDOWN,
                    "target" => "",
                    "permissions" => ["view"],
                    "path_icon" => "_/menu/_user_management.png",
                    "order" => 1,
                    "toolbar_side" => 1,
                    "status" => 1,
                    "subs" => [
                        [
                            "path" => "user",
                            "name" => "User",
                            "parameter" => "",
                            "target_type" => AppMenu::MENU_TARGET_MENU,
                            "target" => "",
                            "permissions" => ["view", "store", "update", "delete"],
                            "path_icon" => "",
                            "order" => 1,
                            "toolbar_side" => 1,
                            "status" => 1,
                        ],
                        [
                            "path" => "grup-akses",
                            "name" => "Grup Akses",
                            "parameter" => "",
                            "target_type" => AppMenu::MENU_TARGET_MENU,
                            "target" => "",
                            "permissions" => ["view", "store", "update", "delete"],
                            "path_icon" => "",
                            "order" => 2,
                            "toolbar_side" => 1,
                            "status" => 1,
                        ],
                        [
                            "path" => "akses-log",
                            "name" => "Akses Log",
                            "parameter" => "",
                            "target_type" => AppMenu::MENU_TARGET_MENU,
                            "target" => "",
                            "permissions" => ["view", "store", "update", "delete"],
                            "path_icon" => "",
                            "order" => 3,
                            "toolbar_side" => 1,
                            "status" => 1,
                        ],
                    ],
                ],
                [
                    "path" => "data-spesifik",
                    "name" => "Data Spesifik",
                    "parameter" => "",
                    "target_type" => AppMenu::MENU_TARGET_DROPDOWN,
                    "target" => "",
                    "permissions" => ["view"],
                    "path_icon" => "_/menu/_specific.png",
                    "order" => 2,
                    "toolbar_side" => 1,
                    "status" => 1,
                    "subs" => [
                        [
                            "path" => "sub-modul",
                            "name" => "Sub Modul",
                            "parameter" => "",
                            "target_type" => AppMenu::MENU_TARGET_MENU,
                            "target" => "",
                            "permissions" => ["view", "store", "update", "delete"],
                            "path_icon" => "",
                            "order" => 1,
                            "toolbar_side" => 1,
                            "status" => 1,
                        ],
                        [
                            "path" => "menu",
                            "name" => "Menu",
                            "parameter" => "",
                            "target_type" => AppMenu::MENU_TARGET_MENU,
                            "target" => "",
                            "permissions" => ["view", "store", "update", "delete"],
                            "path_icon" => "",
                            "order" => 2,
                            "toolbar_side" => 1,
                            "status" => 1,
                        ],
                    ]
                ],
                [
                    "path" => "data-master",
                    "name" => "Data Master",
                    "parameter" => "",
                    "target_type" => AppMenu::MENU_TARGET_DROPDOWN,
                    "target" => "",
                    "permissions" => ["view", "store", "update", "delete"],
                    "path_icon" => "_/menu/_master.png",
                    "order" => 3,
                    "toolbar_side" => 1,
                    "status" => 1,
                    "subs" => []
                ]
            ]
        ]);
    }

}
