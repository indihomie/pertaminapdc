<?php

namespace App\Http\Livewire\AppSetting;

use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Spatie\Permission\Models\Role;

class SettingGroupAccess extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $group;
    public $group_access;

    public function mount()
    {
        $this->sortBy = "name";
    }

    public function render()
    {
        $permissions = config("paramter.permissions");

        $module = $this->app_module;
        $module_subs = $module->moduleSubs()
            ->with([
                "menus" => function ($query) {
                    $query->where("menu_id", 0);
                    $query->orderBy("order");
                },
                "menus.menuSubs" => function ($query) {
                    $query->where("menu_id", "<>", 0);
                    $query->orderBy("order");
                },
            ])
            ->orderBy("name")
            ->get();

        return view("livewire.setting.setting-group-access", [
            "permissions" => $permissions,
            "module_subs" => $module_subs,
            "groups" => Role::query()
                ->withCount("users")
                ->when($this->search, function ($query) {
                    return $query->where("name", "like", "%{$this->search}%");
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function edit(Role $role)
    {
        $module = $this->app_module;
        $permissions = $role->permissions()
            ->where("name", "like", "{$module->path}.%")
            ->pluck("name")
            ->mapWithKeys(function ($permission_name) {

                list($_, $module_sub_path, $menu_path, $menu_sub_path, $permission) = explode(".", str_replace("-", "", $permission_name));

                return ["{$module_sub_path}_{$menu_path}_{$menu_sub_path}_{$permission}" => $permission_name];
            });

        $this->group = $role->toArray();
        $this->group["permissions"] = $permissions;
    }

    public function save()
    {
        $this->update();
    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $module = $this->app_module;
        $group = $this->group;

        DB::beginTransaction();

        try {

            $role = Role::query()->find($group["id"]);

            $permissions = array_filter($group["permissions"]);
            $permissions = array_values($permissions);

            $permission_exists = $role->permissions()
                ->where("name", "like", "{$module->path}.%")
                ->pluck("name", "id");
            $permission_removes = $permission_exists->diff($permissions)->keys();

            $role->permissions()->detach($permission_removes);
            $role->givePermissionTo($permissions);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Grup Akses berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Grup Akses gagal diubah")
            ]);
        }

    }

}
