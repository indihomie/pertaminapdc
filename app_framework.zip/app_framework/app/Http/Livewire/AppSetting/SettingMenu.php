<?php

namespace App\Http\Livewire\AppSetting;

use App\Const\State;
use App\Models\AppMenu;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class SettingMenu extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;
    public $module_sub_id;

    public $module_subs;
    public $permissions;

    public $state;
    public $menu;
    public $menu_types;

    public $image;

    public function mount()
    {
        $module_subs = $this->app_module
            ->moduleSubs()
            ->orderBy("order")
            ->pluck("name", "id");

        $this->sortBy = "order";

        $this->module_subs = $module_subs;
        $this->module_sub_id = $module_subs->keys()->first();

        $this->permissions = config("paramter.permissions");

        $this->menu_types = [];
        $this->create();
    }

    public function render()
    {
        $module = $this->app_module;

        $permission_menus = Permission::query()
            ->withCount([
                "roles" => function ($query) {
                    $query->where("name", "like", "Super Admin");
                }
            ])
            ->where("name", "LIKE", "{$module->path}.%.view")
            ->get()
            ->filter(fn($permission) => $permission->roles_count > 0)
            ->mapWithKeys(fn($permission) => [$permission->name => $permission->roles_count])
            ->toArray();

        return view("livewire.setting.setting-menu", [
            "permission_menus" => $permission_menus,
            "menu_sides" => AppMenu::MENU_SIDES,
            "menus" => AppMenu::query()
                ->with([
                    "module:id,path",
                    "moduleSub:id,path",
                    "menuSubs" => function ($query) {
                        $query->orderBy("order");
                    },
                    "menuSubs.module:id,path",
                    "menuSubs.moduleSub:id,path",
                ])
                ->where("module_id", $this->app_module->id)
                ->where("module_sub_id", $this->module_sub_id)
                ->where("menu_id", 0)
                ->when($this->search, function ($query) {
                    return $query->where("name", "like", "%{$this->search}%");
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function updatedMenuSubId($menu_sub_id)
    {
        $module = AppMenu::query()->orderByDesc("order")->firstWhere("menu_id", $menu_sub_id);

        $this->menu["order"] = $module ? $module->order + 1 : 1;
    }

    public function updatedMenuTargetType()
    {
        $this->menu["target"] = "";
    }

    public function removeImage()
    {
        $this->menu["path_icon"] = null;
        $this->image = [
            "file" => null,
            "remove" => true
        ];
    }

    public function dropdownTargetTypeParent()
    {
        $this->menu_types = [
            AppMenu::MENU_TARGET_MENU => AppMenu::MENU_TARGETS[AppMenu::MENU_TARGET_MENU],
            AppMenu::MENU_TARGET_DROPDOWN => AppMenu::MENU_TARGETS[AppMenu::MENU_TARGET_DROPDOWN],
            AppMenu::MENU_TARGET_LINK => AppMenu::MENU_TARGETS[AppMenu::MENU_TARGET_LINK],
        ];
    }

    public function dropdownTargetTypeChild()
    {
        $this->menu_types = [
            AppMenu::MENU_TARGET_MENU => AppMenu::MENU_TARGETS[AppMenu::MENU_TARGET_MENU],
            AppMenu::MENU_TARGET_MASTER => AppMenu::MENU_TARGETS[AppMenu::MENU_TARGET_MASTER],
            AppMenu::MENU_TARGET_LINK => AppMenu::MENU_TARGETS[AppMenu::MENU_TARGET_LINK],
        ];
    }

    public function create()
    {

        $order = AppMenu::query()
                ->where("module_sub_id", $this->module_sub_id)
                ->where("menu_id", 0)
                ->orderByDesc("order")
                ->first("order")
                ->order ?? 0;

        $this->state = State::CREATE;
        $this->menu = [
            "id" => "",
            "menu_id" => 0,
            "level" => 1,
            "path" => "",
            "code" => "",
            "name" => "",
            "parameter" => "",
            "target_type" => AppMenu::MENU_TARGET_MENU,
            "target" => "",
            "description" => "",
            "permissions" => ["view" => true],
            "toolbar_side" => AppMenu::MENU_SIDE_SHOW,
            "order" => ++$order,
            "path_icon" => "",
            "status" => true,
        ];
        $this->image = [
            "file" => null,
            "remove" => false
        ];

        $this->dropdownTargetTypeParent();
    }

    public function createChild(AppMenu $parent)
    {

        $order = AppMenu::query()
                ->where("module_sub_id", $this->module_sub_id)
                ->where("menu_id", $parent->id)
                ->orderByDesc("order")
                ->first("order")
                ->order ?? 0;

        $this->state = State::CREATE;
        $this->menu = [
            "id" => "",
            "menu_id" => $parent->id,
            "parent" => $parent->name,
            "level" => 2,
            "path" => "",
            "code" => "",
            "name" => "",
            "parameter" => "",
            "target_type" => AppMenu::MENU_TARGET_MENU,
            "target" => "",
            "description" => "",
            "permissions" => ["view" => true],
            "toolbar_side" => AppMenu::MENU_SIDE_SHOW,
            "order" => ++$order,
            "path_icon" => "",
            "status" => true,
        ];
        $this->image = [
            "file" => null,
            "remove" => false
        ];

        $this->dropdownTargetTypeChild();
    }

    public function edit(AppMenu $menu)
    {

        $this->state = State::EDIT;
        $this->menu = $menu->toArray();
        $this->menu["permissions"] = collect($menu["permissions"])->mapWithKeys(fn($permission) => [$permission => true]);
        $this->image = [
            "file" => null,
            "remove" => false
        ];

        $this->dropdownTargetTypeParent();
    }

    public function editChild(AppMenu $menu)
    {

        $this->state = State::EDIT;
        $this->menu = $menu->toArray();
        $this->menu["parent"] = $menu->menuParent->name;
        $this->menu["permissions"] = collect($menu["permissions"])->mapWithKeys(fn($permission) => [$permission => true]);
        $this->image = [
            "file" => null,
            "remove" => false
        ];

        $this->dropdownTargetTypeChild();
    }

    public function save()
    {
        $menu = $this->menu;

        $this->validate([
            "image.file" => "nullable|image|mimes:jpeg,png,jpg,gif|max:1048",
            "menu.path" => [
                "required",
                Rule::unique("app_menus", "path")->where(function ($query) use ($menu) {
                    return $query
                        ->where("module_id", $this->app_module->id)
                        ->where("module_sub_id", $this->module_sub_id)
                        ->where("menu_id", $menu["menu_id"])
                        ->where("id", "<>", $menu["id"]);
                })
            ],
            "menu.code" => "sometimes",
            "menu.name" => "required",
            "menu.parameter" => "sometimes",
            "menu.target_type" => "required|in:" . implode(",", array_keys(AppMenu::MENU_TARGETS)),
            "menu.target" => in_array($menu["target_type"], [AppMenu::MENU_TARGET_MASTER, AppMenu::MENU_TARGET_LINK]) ? "required" : "nullable",
            "menu.description" => "sometimes|string",
            "menu.permissions" => "sometimes",
            "menu.toolbar_side" => "required|in:" . implode(",", array_keys(AppMenu::MENU_SIDES)),
            "menu.order" => "required|numeric",
            "menu.status" => "sometimes|bool",
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $role = Role::findById(1);

        $module = $this->app_module;
        $module_sub = $this->app_module_sub;
        $menu = $this->menu;
        $image = $this->image;

        DB::beginTransaction();

        try {

            $menu["permissions"] = array_filter($menu["permissions"]);

            $create = AppMenu::query()
                ->create([
                    "module_id" => $module->id,
                    "module_sub_id" => $this->module_sub_id,
                    "menu_id" => $menu["menu_id"],
                    "level" => $menu["level"],
                    "path" => Str::lower($menu["path"]),
                    "code" => $menu["code"],
                    "name" => $menu["name"],
                    "parameter" => $menu["parameter"],
                    "target_type" => $menu["target_type"],
                    "target" => $menu["target"],
                    "description" => $menu["description"],
                    "permissions" => array_keys($menu["permissions"]),
                    "toolbar_side" => $menu["toolbar_side"],
                    "order" => $menu["order"],
                    "status" => $menu["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            if ($image["file"]) {
                $create->uploadImage($image["file"]);
            }

            foreach ($menu["permissions"] as $permission => $_) {

                $path = $create->menu_id == 0 ? "{$create->path}._" : "{$create->menuParent->path}.{$create->path}";

                $role->permissions()
                    ->updateOrCreate([
                        "name" => "{$module->path}.{$create->moduleSub->path}.{$path}.{$permission}"
                    ]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Menu berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Menu gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $role = Role::findById(1);

        $module = $this->app_module;
        $menu = $this->menu;
        $image = $this->image;

        DB::beginTransaction();

        try {

            $update = AppMenu::query()
                ->with([
                    "moduleSub",
                    "menuParent"
                ])
                ->find($menu["id"]);

            $menu["permissions"] = array_filter($menu["permissions"]);

            $update->update([
                "code" => $menu["code"],
                "name" => $menu["name"],
                "parameter" => $menu["parameter"],
                "target_type" => $menu["target_type"],
                "target" => $menu["target"],
                "description" => $menu["description"],
                "permissions" => array_keys($menu["permissions"]),
                "toolbar_side" => $menu["toolbar_side"],
                "order" => $menu["order"],
                "status" => $menu["status"],
                "updated_by" => $user->id,
            ]);

            if ($image["remove"]) {
                $update->deleteImage();
            }

            if ($image["file"]) {
                $update->uploadImage($image["file"]);
            }

            foreach ($menu["permissions"] as $key => $_) {

                $path = $update->menu_id == 0 ? "{$update->path}._" : "{$update->menuParent->path}.{$update->path}";

                $role->permissions()
                    ->updateOrCreate([
                        "name" => "{$module->path}.{$update->moduleSub->path}.{$path}.{$key}"
                    ]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Menu berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Menu gagal diubah")
            ]);
        }

    }

    public function destroy(AppMenu $menu)
    {
        Gate::authorize("{$this->app_path}.delete");

        $module = $this->app_module;

        DB::beginTransaction();

        try {

            $path = $menu->menu_id == 0 ? "{$menu->path}._" : "{$menu->menuParent->path}.{$menu->path}";

            Permission::query()
                ->where("name", "like", "{$module->path}.{$menu->moduleSub->path}.{$path}.%")
                ->delete();

            $menu->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Menu berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Menu gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
