<?php

namespace App\Http\Livewire\AppSetting;

use App\Const\State;
use App\Models\AppUser;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules\Password;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class SettingUser extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $account;

    public $image;

    public function mount()
    {
        $this->create();
    }

    public function render()
    {
        $module = $this->app_module;
        $module_sub = $this->app_module_sub;

        $roles = Role::query()
            ->when($module->id > 1, function ($query) {
                $query->where("id", ">", 1);
            })
            ->get();

        $role_has_access_modules = Permission::query()
            ->with("roles:id")
            ->firstWhere("name", "module_{$module->id}");

        if ($module_sub->path == "user-akses") {
            $role_ids = $roles->pluck("id");
        } else {
            $role_ids = $role_has_access_modules->roles->pluck("id");
        }

        return view("livewire.setting.setting-user", [
            "roles" => $roles,
            "accounts" => AppUser::query()
                ->when($module->id > 1, function ($query) use ($role_ids) {
                    $query->where("type", AppUser::TYPE_USER);
                    $query->whereHas("roles", function ($query) use ($role_ids) {
                        $query->whereIn("id", $role_ids);
                    });
                }, function ($query) {
                    $query->where("type", AppUser::TYPE_DEVELOPER);
                })
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("name", "like", "%{$this->search}%");
                        $query->orWhere("email", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function removeImage()
    {
        $this->account["path_photo"] = null;
        $this->image = [
            "file" => null,
            "remove" => true
        ];
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->account = [
            "id" => 0,
            "role_id" => 0,
            "username" => "",
            "password" => "",
            "password_confirm" => "",
            "name" => "",
            "phone" => "",
            "email" => "",
            "email_verified_at" => "-",
            "description" => "",
            "status" => true,
            "path_photo" => ""
        ];
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function edit(AppUser $account)
    {
        $this->state = State::EDIT;
        $this->account = $account->toArray();
        $this->account["role_id"] = $account->role->id ?? 0;
        $this->account["password"] = "";
        $this->account["password_confirm"] = "";
        $this->account["email_verified_at"] = $account->email_verified_at ? $account->email_verified_at->locale("id")->translatedFormat("d F Y H:i") : "-";
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function save()
    {
        $state = $this->state;
        $account = $this->account;

        $this->validate([
            "image.file" => "nullable|image|mimes:jpeg,png,jpg,gif|max:1048",
            "account.role_id" => "required|exists:app_roles,id",
            "account.username" => "required|min:8|unique:app_users,username,{$account["id"]}",
            "account.password" => $state == State::CREATE ? ["required", Password::min(8)->letters()->numbers()] : "",
            "account.password_confirm" => $state == State::CREATE ? ["required", "same:account.password"] : "",
            "account.name" => "required",
            "account.phone" => "sometimes|unique:app_users,phone,{$account["id"]}",
            "account.email" => "required|unique:app_users,email,{$account["id"]}",
            "account.description" => "sometimes",
        ]);

        if ($state == State::EDIT) {
            $this->update();
        }

        if ($state == State::CREATE) {
            $this->store();
        }

    }

    public function savePassword()
    {

        $this->validate([
            "account.password" => ["required", Password::min(8)->letters()->numbers()],
            "account.password_confirm" => ["required", "same:account.password"],
        ]);

        $this->updatePassword();
    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $module = $this->app_module;

        $user = auth()->user();
        $account = $this->account;
        $image = $this->image;

        DB::beginTransaction();

        try {

            $role = Role::findById($account["role_id"]);

            $create = AppUser::query()
                ->create([
                    "type" => $module->id == 1 ? AppUser::TYPE_DEVELOPER : AppUser::TYPE_USER,
                    "username" => $account["username"],
                    "password" => Hash::make($account["password"]),
                    "name" => $account["name"],
                    "phone" => $account["phone"],
                    "email" => $account["email"],
                    "email_verified_at" => null,
                    "description" => $account["description"],
                    "status" => $account["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            $create->syncRoles([$role->name]);

            if ($image["file"]) {
                $create->uploadImage($image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("User berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("User gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $account = $this->account;
        $image = $this->image;

        DB::beginTransaction();

        try {

            $role = Role::findById($account["role_id"]);
            $update = AppUser::query()->find($account["id"]);

            if ($account["email"] != $update->email) {
                $update->update([
                    "email_verified_at" => null
                ]);
            }

            $update->update([
                "username" => $account["username"],
                "name" => $account["name"],
                "phone" => $account["phone"],
                "email" => $account["email"],
                "description" => $account["description"],
                "status" => $account["status"],
                "updated_by" => $user->id,
            ]);

            $update->syncRoles([$role->name]);

            if ($image["remove"]) {
                $update->deleteImage();
            }

            if ($image["file"]) {
                $update->uploadImage($image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("User berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("User gagal diubah")
            ]);
        }

    }

    private function updatePassword()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $account = $this->account;

        DB::beginTransaction();

        try {

            $update = AppUser::query()->find($account["id"]);

            $update->update([
                "password" => Hash::make($account["password"]),
                "updated_by" => $user->id,
            ]);

            DB::commit();

            $this->emit("dismiss", "modal_form_password_reset");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Password User berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form_password_reset");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Password User gagal diubah")
            ]);
        }

    }

    public function destroy(AppUser $account)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $account->deleteImage();
            $account->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("User berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("User gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
