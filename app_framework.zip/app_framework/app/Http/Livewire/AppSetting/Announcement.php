<?php

namespace App\Http\Livewire\AppSetting;

use App\Const\State;
use App\Models\AppInformationAnnouncement;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class Announcement extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $announcement;

    public $image;

    public function mount()
    {
        $this->sortAsc = false;

        $this->create();
    }

    public function render()
    {

        return view("livewire.setting.announcement", [
            "announcements" => AppInformationAnnouncement::query()
                ->when($this->search, function ($query) {
                    return $query->where("name", "like", "%{$this->search}%");
                })
                ->orderBy($this->sortBy ?: "datetime", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->announcement = [
            "id" => "",
            "datetime" => "",
            "name" => "",
            "content" => "",
            "source" => "",
            "path_image" => "",
            "status" => AppInformationAnnouncement::STATUS_ACTIVE,
        ];
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function edit(AppInformationAnnouncement $announcement)
    {
        $this->state = State::EDIT;
        $this->announcement = $announcement->toArray();
        $this->announcement["datetime"] = $announcement->datetime->format("Y-m-d H:i");
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function removeImage()
    {
        $this->announcement["path_image"] = null;
        $this->image = [
            "file" => null,
            "remove" => true
        ];
    }

    public function save()
    {

        $this->validate([
            "image.file" => ["nullable", "image", "mimes:jpeg,png,jpg,gif", "max:2048"],
            "announcement.datetime" => ["required", "date_format:Y-m-d H:i"],
            "announcement.name" => ["required"],
            "announcement.source" => ["nullable"],
            "announcement.status" => ["required", "boolean"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $announcement = $this->announcement;

        DB::beginTransaction();

        try {

            $create = AppInformationAnnouncement::query()
                ->create([
                    "datetime" => $announcement["datetime"],
                    "name" => $announcement["name"],
                    "source" => $announcement["source"],
                    "content" => $announcement["content"],
                    "status" => $announcement["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            if ($this->image["file"]) {
                $create->uploadImage($this->image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Pengumuman berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Pengumuman gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $announcement = $this->announcement;

        DB::beginTransaction();

        try {

            $update = AppInformationAnnouncement::query()->find($announcement["id"]);

            $update->update([
                "datetime" => $announcement["datetime"],
                "name" => $announcement["name"],
                "source" => $announcement["source"],
                "content" => $announcement["content"],
                "status" => $announcement["status"],
                "updated_by" => $user->id,
            ]);

            if ($this->image["remove"]) {
                $update->deleteImage();
            }

            if ($this->image["file"]) {
                $update->uploadImage($this->image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Pengumuman berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Pengumuman gagal diubah")
            ]);
        }

    }

    public function destroy(AppInformationAnnouncement $announcement)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $announcement->deleteImage();
            $announcement->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Pengumuman berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Pengumuman gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
