<?php

namespace App\Http\Livewire\Other\Safety;

use App\Const\State;
use App\Models\AppUser;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Livewire\Component;
use Livewire\WithPagination;

class Safety extends Component
{
    use WithApp,
        WithPagination,
        WithSorting;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $users;

    public $state;
    public $account;

    public function mount()
    {
        $this->users = AppUser::query()->select(["id", "name"])->get();
        $this->account["relations"] = [];
    }

    public function render()
    {

        return view("livewire.other.safety.safety", [
            "accounts" => AppUser::query()
                ->withCount([
                    "relations"
                ])
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("name", "like", "%{$this->search}%");
                        $query->orWhere("email", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function edit(AppUser $account)
    {
        $this->state = State::EDIT;
        $this->account = $account->toArray();
        $this->account["login_at"] = $account->login_at->format("d F Y H:i:s");

        $this->account["relations"] = $account->relations()
            ->select(["relation_id"])
            ->get()
            ->toArray();

    }

    public function editAdd()
    {
        $this->account["relations"][] = [
            "relation_id" => 0
        ];
    }

    public function editRemove($index)
    {
        $relations = $this->account["relations"];

        $this->account["relations"] = collect($relations)
            ->filter(fn($relation, $key) => $key != $index)
            ->values()
            ->toArray();

    }

    public function save()
    {
        $state = $this->state;
        $account = $this->account;

        $this->validate([
            "account.relations.*.relation_id" => ["required", "exists:app_users,id"]
        ]);

        if ($state == State::EDIT) {
            $this->update();
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $account = $this->account;

        DB::beginTransaction();

        try {

            $update = AppUser::query()->find($account["id"]);

            $update->relations()
                ->sync(collect($account["relations"])->pluck("relation_id"));

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Hubungan berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Hubungan gagal diubah")
            ]);
        }

    }

}
