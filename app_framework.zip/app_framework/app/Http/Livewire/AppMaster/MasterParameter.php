<?php

namespace App\Http\Livewire\AppMaster;

use App\Const\State;
use App\Models\AppParameter;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class MasterParameter extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $parameter;

    public function mount()
    {
        $this->sortAsc = false;
        $this->create();
    }

    public function render()
    {

        return view("livewire.master.master-parameter", [
            "parameters" => AppParameter::query()
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("id", "like", "{$this->search}%");
                        $query->orWhere("name", "like", "%{$this->search}%");
                        $query->orWhere("value", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "updated_at", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->parameter = [
            "id" => "",
            "name" => "",
            "value" => "",
            "data" => "{}",
        ];
    }

    public function edit(AppParameter $parameter)
    {
        $this->state = State::EDIT;
        $this->parameter = $parameter->toArray();
        $this->parameter["old_id"] = $parameter->id;
        $this->parameter["data"] = $parameter->data ? json_encode($parameter->data, JSON_PRETTY_PRINT) : "{}";
    }

    public function save()
    {
        $parameter = $this->parameter;

        $this->validate([
            "parameter.id" => ["required", $parameter["id"] ? "" : "unique:app_parameters", "min:4"],
            "parameter.name" => ["required", "max:255"],
            "parameter.value" => ["required"],
            "parameter.data" => ["required", "json"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $parameter = $this->parameter;

        DB::beginTransaction();

        try {

            AppParameter::query()
                ->create([
                    "id" => Str::upper($parameter["id"]),
                    "name" => $parameter["name"],
                    "value" => $parameter["value"],
                    "data" => json_decode($parameter["data"]),
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Parameter berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Parameter gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $parameter = $this->parameter;

        DB::beginTransaction();

        try {

            $update = AppParameter::query()->find($parameter["old_id"]);

            $update->update([
                "id" => Str::upper($parameter["id"]),
                "name" => $parameter["name"],
                "value" => $parameter["value"],
                "data" => json_decode($parameter["data"]),
                "updated_by" => $user->id,
            ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Parameter berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Parameter gagal diubah")
            ]);
        }

    }

    public function destroy(AppParameter $parameter)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $parameter->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Parameter berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Parameter gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
