<?php

namespace App\Http\Livewire\AppMaster;

use App\Const\State;
use App\Models\AppFormatApproval;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Spatie\Permission\Models\Role;

class MasterApproval extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $index;
    public $index_reference;

    public $operator_simples = [];
    public $operators = [];

    public $reference_types = [];
    public $references = [];

    public $approval;
    public $approval_group;
    public $approval_group_condition;
    public $approval_group_actor;

    public function mount()
    {

        $this->operator_simples = [
            "and",
            "or",
        ];
        $this->operators = [
            "==",
            "!=",
            ">",
            ">=",
            "<",
            "<=",
        ];

        $this->reference_types = [
            Role::class => "Grup User"
        ];

        $this->create();
    }

    public function render()
    {

        return view("livewire.master.master-approval", [
            "approvals" => AppFormatApproval::query()
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("code", "like", "{$this->search}%");
                        $query->orWhere("name", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function updatedApprovalGroupActorReferenceType()
    {
        $reference_type = $this->approval_group_actor["reference_type"];

        if (!$reference_type) {
            $this->references = [];
            return;
        }

        $model = $reference_type::query()->pluck("name", "id");

        $this->references = $model;
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->approval = [
            "id" => 0,
            "code" => "",
            "name" => "",
            "description" => "",
            "dataset" => "",
            "groups" => []
        ];
        $this->approval_group = [];
        $this->approval_group_condition = [];
        $this->approval_group_actor = [];
    }

    public function edit(AppFormatApproval $approval)
    {

        $approval->load([
            "groups",
            "groups.actors",
            "groups.actors.reference:id,name",
        ]);

        $this->state = State::EDIT;
        $this->approval = $approval->toArray();
    }

    public function editGroup($index)
    {
        $approval = $this->approval;

        $this->index = $index;

        if ($index >= 0) {
            $this->approval_group = $approval["groups"][$index];
        } else {
            $this->approval_group = [
                "id" => 0,
                "approval_id" => 0,
                "order" => 1,
                "step_prev" => 0,
                "step_next" => 0,
                "conditions" => [],
                "actors" => []
            ];
        }

        $this->emit("show", "modal_form_group");
    }

    public function editGroupCondition($group_index, $index)
    {
        $approval = $this->approval;
        $approval_group = $approval["groups"][$group_index];

        $this->index_reference = $group_index;
        $this->index = $index;

        if ($index >= 0) {
            $this->approval_group_condition = $approval_group["conditions"][$index];
        } else {
            $this->approval_group_condition = [
                "parameter" => "",
                "operator" => "",
                "value" => 0,
                "join" => "",
            ];
        }

        $this->emit("show", "modal_form_group_condition");
    }

    public function editGroupActor($group_index, $index)
    {
        $approval = $this->approval;
        $approval_group = $approval["groups"][$group_index];

        $this->index_reference = $group_index;
        $this->index = $index;

        if ($index >= 0) {
            $this->approval_group_actor = $approval_group["actors"][$index];
        } else {
            $this->approval_group_actor = [
                "id" => 0,
                "reference_type" => "",
                "reference_id" => "",
                "operator" => "",
            ];
        }

        $this->updatedApprovalGroupActorReferenceType();
        $this->emit("show", "modal_form_group_actor");
    }

    public function save()
    {
        $approval = $this->approval;

        $this->validate([
            "approval.code" => ["required", "unique:app_format_approvals,code,{$approval["id"]}", "min:4"],
            "approval.name" => ["required", "max:255"],
            "approval.description" => ["sometimes"],
            "approval.dataset" => ["required"],
            "approval.groups" => ["required", "array"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    public function saveGroup()
    {
        $index = $this->index;

        $approval = $this->approval;
        $approval_group = $this->approval_group;

        $approval_group_ids = collect($approval["groups"])
            ->where(fn($_, $key) => $key != $index)
            ->pluck("order");

        $this->validate([
            "approval_group.order" => ["required", "numeric", "between:1,8", Rule::notIn($approval_group_ids)],
            "approval_group.step_prev" => ["required", "numeric", "between:0,98"],
            "approval_group.step_next" => ["required", "numeric", "between:1,99"],
        ]);

        if ($index >= 0) {
            $this->approval["groups"][$index] = $approval_group;
        } else {
            $this->approval["groups"][] = $approval_group;
        }

        $this->emit("dismiss", "modal_form_group");
    }

    public function saveGroupCondition()
    {
        $index = $this->index;
        $index_reference = $this->index_reference;

        $approval = $this->approval;
        $approval_group_condition = $this->approval_group_condition;

        $this->validate([
            "approval_group_condition.dataset" => ["required", Rule::in(explode(",", $approval["dataset"]))],
            "approval_group_condition.operator" => ["required", Rule::in($this->operators)],
            "approval_group_condition.value" => ["required"],
            "approval_group_condition.join" => ["required"],
        ]);

        if ($index >= 0) {
            $this->approval["groups"][$index_reference]["conditions"][$index] = $approval_group_condition;
        } else {
            $this->approval["groups"][$index_reference]["conditions"][] = $approval_group_condition;
        }

        $this->emit("dismiss", "modal_form_group_condition");
    }

    public function saveGroupActor()
    {
        $index = $this->index;
        $index_reference = $this->index_reference;

        $approval = $this->approval;
        $approval_group_actor = $this->approval_group_actor;

        $roles = $this->references;

        $this->validate([
            "approval_group_actor.reference_type" => ["required"],
            "approval_group_actor.reference_id" => ["required"],
            "approval_group_actor.operator" => ["required", intval($approval_group_actor["operator"]) == 0 ? Rule::in($this->operator_simples) : ""],
        ]);

        $approval_group_actor["reference"] = [
            "id" => 0,
            "name" => $roles[$approval_group_actor["reference_id"]]
        ];

        if ($index >= 0) {
            $this->approval["groups"][$index_reference]["actors"][$index] = $approval_group_actor;
        } else {
            $this->approval["groups"][$index_reference]["actors"][] = $approval_group_actor;
        }

        $this->emit("dismiss", "modal_form_group_actor");
    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $approval = $this->approval;

        DB::beginTransaction();

        try {

            $create = AppFormatApproval::query()
                ->create([
                    "code" => Str::upper($approval["code"]),
                    "name" => $approval["name"],
                    "description" => $approval["description"],
                    "dataset" => $approval["dataset"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            foreach ($approval["groups"] as $group) {

                $approval_group = $create->groups()
                    ->create([
                        "order" => $group["order"],
                        "conditions" => $group["conditions"],
                        "step_prev" => $group["step_prev"],
                        "step_next" => $group["step_next"],
                        "created_by" => $user->id,
                        "updated_by" => $user->id,
                    ]);

                foreach ($group["actors"] as $actor) {

                    $approval_group->actors()
                        ->create([
                            "approval_id" => $create->id,
                            "reference_type" => $actor["reference_type"],
                            "reference_id" => $actor["reference_id"],
                            "operator" => $actor["operator"],
                            "created_by" => $user->id,
                            "updated_by" => $user->id,
                        ]);

                }

            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Approval berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Approval gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $approval = $this->approval;

        DB::beginTransaction();

        try {

            $update = AppFormatApproval::query()->find($approval["id"]);

            $update->update([
                "code" => Str::upper($approval["code"]),
                "name" => $approval["name"],
                "description" => $approval["description"],
                "dataset" => $approval["dataset"],
                "updated_by" => $user->id,
            ]);


            $group_id_whitelist = collect($approval["groups"])->pluck("id");

            $update->groups()
                ->whereNotIn("id", $group_id_whitelist)
                ->delete();

            $update->actors()
                ->whereNotIn("id", $group_id_whitelist)
                ->delete();

            foreach ($approval["groups"] as $group) {

                $approval_group = $update->groups()
                    ->firstOrCreate([
                        "id" => $group["id"],
                    ], [
                        "created_by" => $user->id,
                    ]);

                $approval_group->update([
                    "order" => $group["order"],
                    "conditions" => $group["conditions"],
                    "step_prev" => $group["step_prev"],
                    "step_next" => $group["step_next"],
                    "updated_by" => $user->id,
                ]);

                $approval_group->actors()
                    ->whereNotIn("id", collect($group["actors"])->pluck("id"))
                    ->delete();

                foreach ($group["actors"] as $actor) {

                    $approval_group->actors()
                        ->firstOrCreate([
                            "id" => $actor["id"],
                        ], [
                            "created_by" => $user->id,
                        ])
                        ->update([
                            "approval_id" => $update->id,
                            "reference_type" => $actor["reference_type"],
                            "reference_id" => $actor["reference_id"],
                            "operator" => $actor["operator"],
                            "updated_by" => $user->id,
                        ]);

                }

            }

            DB::commit();

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Approval berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Approval gagal diubah")
            ]);
        }

    }

    public function destroy(AppFormatApproval $approval)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $approval->actors()->delete();
            $approval->groups()->delete();
            $approval->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Approval berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Approval gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

    public function destroyGroup($index)
    {
        $approval = $this->approval;
        $approval_groups = $approval["groups"];

        $this->approval["groups"] = collect($approval_groups)
            ->filter(fn($_, $key) => $key != $index)
            ->values();
        $this->emit("loader", false);
    }

    public function destroyGroupCondition($group_index_with_condition_index)
    {
        $approval = $this->approval;
        $approval_groups = $approval["groups"];

        list($group_index, $condition_index) = explode("_", $group_index_with_condition_index);

        $this->approval["groups"][$group_index]["conditions"] = collect($approval_groups[$group_index]["conditions"])
            ->filter(fn($_, $key) => $key != $condition_index)
            ->values();
        $this->emit("loader", false);
    }

    public function destroyGroupActor($group_index_with_actor_index)
    {
        $approval = $this->approval;
        $approval_groups = $approval["groups"];

        list($group_index, $actor_id) = explode("_", $group_index_with_actor_index);

        $this->approval["groups"][$group_index]["actors"] = collect($approval_groups[$group_index]["actors"])
            ->filter(fn($_, $key) => $key != $actor_id)
            ->values();
        $this->emit("loader", false);
    }

}
