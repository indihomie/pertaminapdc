<?php

namespace App\Http\Livewire\AppMaster\General;

use App\Const\State;
use App\Models\AppMaster;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithPagination;

class Master extends Component
{
    use WithApp,
        WithPagination,
        WithSorting;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;
    public $master_parent_id;

    public $master_category;

    public $state;
    public $master;

    public function mount()
    {
        $this->create();
    }

    public function render()
    {
        $master_category = $this->master_category;

        $parents = $master_category->category
                ?->masters()
                ->select(["id", "name", "order"])
                ->get() ?? collect();

        return view("livewire.master.master-general", [
            "master_parents" => $parents,
            "masters" => $master_category->masters()
                ->with([
                    "subParent:id,name"
                ])
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("id", "like", "{$this->search}%");
                        $query->orWhere("name", "like", "%{$this->search}%");
                    });
                })
                ->when($this->master_parent_id, function ($query) {
                    $query->where("master_id", $this->master_parent_id);
                })
                ->orderBy($this->sortBy ?: "order", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $master_category = $this->master_category;

        $master_last = $master_category->masters()
            ->orderBy("id", "desc")
            ->first();
        $order = $master_last ? Str::replace($master_category->id, "", $master_last->id) : 0;
        $order = ((int)$order) + 1;

        $master_order = $master_category->masters()
            ->orderBy("order", "desc")
            ->first();

        $this->state = State::CREATE;
        $this->master = [
            "id" => $master_category->id . Str::padLeft($order, 4, "0"),
            "master_id" => "",
            "name" => "",
            "description" => "",
            "data" => "{}",
            "order" => $master_order->order ? ($master_order->order + 1) : 1,
            "status" => AppMaster::STATUS_ACTIVE,
        ];
    }

    public function edit(AppMaster $master)
    {
        $this->state = State::EDIT;
        $this->master = $master->toArray();
        $this->master["data"] = $master->data ? json_encode($master->data, JSON_PRETTY_PRINT) : "{}";
    }

    public function save()
    {
        $master = $this->master;

        $this->validate([
            "master.master_id" => ["sometimes", "exists:app_masters,id"],
            "master.id" => ["required", $master["id"] ? "" : "unique:app_masters,id"],
            "master.name" => ["required", "max:255"],
            "master.description" => ["nullable"],
            "master.data" => ["required", "json"],
            "master.order" => ["required", "numeric"],
            "master.status" => ["required", "boolean"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $master_category = $this->master_category;
        $master = $this->master;

        DB::beginTransaction();

        try {

            AppMaster::query()
                ->create([
                    "id" => Str::upper($master["id"]),
                    "category_id" => $master_category->id,
                    "master_id" => $master["master_id"],
                    "name" => $master["name"],
                    "description" => $master["description"],
                    "data" => json_decode($master["data"]),
                    "order" => $master["order"],
                    "status" => $master["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Master berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Master gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $master = $this->master;

        DB::beginTransaction();

        try {

            $update = AppMaster::query()->find($master["id"]);

            $update->update([
                "master_id" => $master["master_id"],
                "name" => $master["name"],
                "description" => $master["description"],
                "data" => json_decode($master["data"]),
                "order" => $master["order"],
                "status" => $master["status"],
                "updated_by" => $user->id,
            ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Master berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Master gagal diubah")
            ]);
        }

    }

    public function destroy(AppMaster $master)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $master->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Master berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Master gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
