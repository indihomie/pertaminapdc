<?php

namespace App\Http\Livewire\AppMaster\General;

use App\Const\State;
use App\Models\AppMasterCategory;
use App\Models\AppMenu;
use App\Models\AppModule;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class MasterCategory extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;
    public $module_id;

    public $modules;

    public $state;
    public $master;

    public $image;

    public function mount()
    {

        $modules = AppModule::query()
            ->orderBy("order")
            ->get()
            ->keyBy("id");

        $this->modules = $modules;

        $this->create();
    }

    public function render()
    {

        $parents = AppMasterCategory::query()
            ->select(["id", "name"])
            ->get();

        return view("livewire.master.master-general-category", [
            "master_parents" => $parents,
            "masters" => AppMasterCategory::query()
                ->with([
                    "category:id,name"
                ])
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("id", "like", "{$this->search}%");
                        $query->orWhere("name", "like", "%{$this->search}%");
                    });
                })
                ->withCount([
                    "masters"
                ])
                ->when($this->module_id, function ($query) {

                    $menu_ids = AppMenu::query()
                        ->where("module_id", $this->module_id)
                        ->where("target_type", AppMenu::MENU_TARGET_MASTER)
                        ->pluck("target");

                    $query->whereIn("id", $menu_ids);
                })
                ->orderBy($this->sortBy ?: "order", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->master = [
            "id" => "",
            "category_id" => "",
            "name" => "",
            "description" => "",
            "data" => "{}",
            "path_icon" => "",
            "order" => 1,
            "status" => AppMasterCategory::STATUS_ACTIVE,
        ];
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function edit(AppMasterCategory $master)
    {
        $this->state = State::EDIT;
        $this->master = $master->toArray();
        $this->master["data"] = $master->data ? json_encode($master->data, JSON_PRETTY_PRINT) : "{}";
        $this->image = [
            "file" => null,
            "remove" => false
        ];
    }

    public function removeImage()
    {
        $this->master["path_icon"] = null;
        $this->image = [
            "file" => null,
            "remove" => true
        ];
    }

    public function save()
    {
        $master = $this->master;

        $this->validate([
            "image.file" => ["nullable", "image", "mimes:jpeg,png,jpg,gif", "max:2048"],
            "master.category_id" => ["sometimes", "exists:app_master_categories,id"],
            "master.id" => ["required", $master["id"] ? "" : "unique:app_master_categories,id"],
            "master.name" => ["required", "max:255"],
            "master.description" => ["nullable"],
            "master.data" => ["required", "json"],
            "master.order" => ["required", "numeric"],
            "master.status" => ["required", "boolean"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $master = $this->master;

        DB::beginTransaction();

        try {

            $create = AppMasterCategory::query()
                ->create([
                    "id" => Str::upper($master["id"]),
                    "category_id" => $master["category_id"],
                    "name" => $master["name"],
                    "description" => $master["description"],
                    "data" => json_decode($master["data"]),
                    "order" => $master["order"],
                    "status" => $master["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            if ($this->image["file"]) {
                $create->uploadImage($this->image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Master Kategori berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Master Kategori gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $master = $this->master;

        DB::beginTransaction();

        try {

            $update = AppMasterCategory::query()->find($master["id"]);

            $update->update([
                "category_id" => $master["category_id"],
                "name" => $master["name"],
                "description" => $master["description"],
                "data" => json_decode($master["data"]),
                "order" => $master["order"],
                "status" => $master["status"],
                "updated_by" => $user->id,
            ]);

            if ($this->image["remove"]) {
                $update->deleteImage();
            }

            if ($this->image["file"]) {
                $update->uploadImage($this->image["file"]);
            }

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Master Kategori berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Master Kategori gagal diubah")
            ]);
        }

    }

    public function destroy(AppMasterCategory $master)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $master->deleteImage();
            $master->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Master Kategori berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Master Kategori gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
