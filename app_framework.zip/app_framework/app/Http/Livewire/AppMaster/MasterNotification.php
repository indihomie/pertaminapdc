<?php

namespace App\Http\Livewire\AppMaster;

use App\Const\State;
use App\Models\AppFormatNotification;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class MasterNotification extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $notification;

    public function mount()
    {
        $this->create();
    }

    public function render()
    {

        return view("livewire.master.master-notification", [
            "levels" => AppFormatNotification::LEVELS,
            "notifications" => AppFormatNotification::query()
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("code", "like", "{$this->search}%");
                        $query->orWhere("name", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->notification = [
            "id" => 0,
            "code" => "",
            "category" => "",
            "name" => "",
            "description" => "",
            "level" => "",
            "menu_code" => "",
            "target_application" => 1,
            "target_email" => 0,
            "target_sms" => 0,
            "content_application" => "",
            "content_email" => "",
            "content_sms" => "",
        ];
    }

    public function edit(AppFormatNotification $notification)
    {
        $this->state = State::EDIT;
        $this->notification = $notification->toArray();
    }

    public function save()
    {
        $notification = $this->notification;

        $this->validate([
            "notification.code" => ["required", "unique:app_format_notifications,code,{$notification["id"]}", "min:4"],
            "notification.category" => ["required", "max:255"],
            "notification.name" => ["required", "max:255"],
            "notification.description" => ["required"],
            "notification.level" => ["required", Rule::in(array_keys(AppFormatNotification::LEVELS))],
            "notification.menu_code" => ["sometimes"],
            "notification.target_application" => ["sometimes", "boolean"],
            "notification.target_email" => ["sometimes", "boolean"],
            "notification.target_sms" => ["sometimes", "boolean"],
            "notification.content_application" => ["sometimes"],
            "notification.content_email" => ["sometimes"],
            "notification.content_sms" => ["sometimes"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $notification = $this->notification;

        DB::beginTransaction();

        try {

            AppFormatNotification::query()
                ->create([
                    "code" => Str::upper($notification["code"]),
                    "category" => $notification["category"],
                    "name" => $notification["name"],
                    "description" => $notification["description"],
                    "level" => $notification["level"],
                    "menu_code" => $notification["menu_code"],
                    "target_application" => $notification["target_application"],
                    "target_email" => $notification["target_email"],
                    "target_sms" => $notification["target_sms"],
                    "content_application" => $notification["content_application"],
                    "content_email" => $notification["content_email"],
                    "content_sms" => $notification["content_sms"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Notifikasi berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Notifikasi gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $notification = $this->notification;

        DB::beginTransaction();

        try {

            $update = AppFormatNotification::query()->find($notification["id"]);

            $update->update([
                "code" => Str::upper($notification["code"]),
                "category" => $notification["category"],
                "name" => $notification["name"],
                "description" => $notification["description"],
                "level" => $notification["level"],
                "menu_code" => $notification["menu_code"],
                "target_application" => $notification["target_application"],
                "target_email" => $notification["target_email"],
                "target_sms" => $notification["target_sms"],
                "content_application" => $notification["content_application"],
                "content_email" => $notification["content_email"],
                "content_sms" => $notification["content_sms"],
                "updated_by" => $user->id,
            ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Notifikasi berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Notifikasi gagal diubah")
            ]);
        }

    }

    public function destroy(AppFormatNotification $notification)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $notification->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Notifikasi berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Notifikasi gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
