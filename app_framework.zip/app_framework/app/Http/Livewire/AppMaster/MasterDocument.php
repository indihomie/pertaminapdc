<?php

namespace App\Http\Livewire\AppMaster;

use App\Const\State;
use App\Models\AppFormatDocument;
use App\Models\AppMaster;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use mikehaertl\wkhtmlto\Pdf;

class MasterDocument extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $document;
    public $document_stream = "";

    public function mount()
    {
        $this->create();
    }

    public function render()
    {

        $papers = AppMaster::query()
            ->where("category_id", "SUKD")
            ->active()
            ->orderBy("order")
            ->get();

        $paper_sizes = $papers->mapWithKeys(fn($paper) => [$paper->id => $paper->data]);

        return view("livewire.master.master-document", [
            "papers" => $papers,
            "paper_sizes" => $paper_sizes,
            "documents" => AppFormatDocument::query()
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("code", "like", "{$this->search}%");
                        $query->orWhere("name", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function print(AppFormatDocument $document)
    {

        $dir_temp = sys_get_temp_dir();
        $file_name = Str::random(10) . ".pdf";

        $pdf = new Pdf([
            "no-outline",
            "margin-top" => $document->margin_top,
            "margin-right" => $document->margin_right,
            "margin-bottom" => $document->margin_bottom,
            "margin-left" => $document->margin_left,
            // Default page options
            "disable-smart-shrinking",
        ]);

        $pdf->addPage($document->content);
        $pdf->saveAs("{$dir_temp}/{$file_name}");

        dd($pdf->getCommand());

        if ($pdf->getError()) {

            $this->emit("error", $pdf->getError());
            $this->emit("dismiss", "modal_viewer");

            Log::error($pdf->getError());

            return;
        }

        $this->document = $document->toArray();
        $this->document_stream = url("/stream/" . encrypt($file_name)) . "?disk=temp";
    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->document = [
            "id" => 0,
            "code" => "",
            "name" => "",
            "paper_id" => "",
            "margin_top" => 10,
            "margin_right" => 10,
            "margin_bottom" => 10,
            "margin_left" => 10,
            "content" => "",
        ];
    }

    public function edit(AppFormatDocument $document)
    {
        $this->state = State::EDIT;
        $this->document = $document->toArray();
        $this->emit("ckeditor_resize", $document->paper_id);
    }

    public function save()
    {
        $document = $this->document;

        $this->validate([
            "document.code" => ["required", "unique:app_format_documents,code,{$document["id"]}", "min:4"],
            "document.name" => ["required", "max:255"],
            "document.paper_id" => ["required", "exists:app_masters,id"],
            "document.margin_top" => ["required"],
            "document.margin_right" => ["required"],
            "document.margin_bottom" => ["required"],
            "document.margin_left" => ["required"],
            "document.content" => ["required"],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $document = $this->document;

        DB::beginTransaction();

        try {

            AppFormatDocument::query()
                ->create([
                    "code" => Str::upper($document["code"]),
                    "name" => $document["name"],
                    "paper_id" => $document["paper_id"],
                    "margin_top" => $document["margin_top"],
                    "margin_right" => $document["margin_right"],
                    "margin_bottom" => $document["margin_bottom"],
                    "margin_left" => $document["margin_left"],
                    "content" => $document["content"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Dokumen berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Dokumen gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $document = $this->document;

        DB::beginTransaction();

        try {

            $update = AppFormatDocument::query()->find($document["id"]);

            $update->update([
                "code" => Str::upper($document["code"]),
                "name" => $document["name"],
                "paper_id" => $document["paper_id"],
                "margin_top" => $document["margin_top"],
                "margin_right" => $document["margin_right"],
                "margin_bottom" => $document["margin_bottom"],
                "margin_left" => $document["margin_left"],
                "content" => $document["content"],
                "updated_by" => $user->id,
            ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Dokumen berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Dokumen gagal diubah")
            ]);
        }

    }

    public function destroy(AppFormatDocument $document)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $document->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Dokumen berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Dokumen gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
