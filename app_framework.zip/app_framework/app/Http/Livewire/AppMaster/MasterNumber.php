<?php

namespace App\Http\Livewire\AppMaster;

use App\Const\State;
use App\Models\AppFormatNumber;
use App\Traits\WithApp;
use App\Traits\WithSorting;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class MasterNumber extends Component
{
    use WithApp,
        WithPagination,
        WithSorting,
        WithFileUploads;

    protected $paginationTheme = "bootstrap";

    public int $perPage = 10;

    public $search;

    public $state;
    public $number;

    public function mount()
    {
        $this->create();
    }

    public function render()
    {

        return view("livewire.master.master-number", [
            "delimiters" => AppFormatNumber::delimiter,
            "types" => AppFormatNumber::type,
            "type_years" => AppFormatNumber::type_year,
            "type_months" => AppFormatNumber::type_month,
            "numbers" => AppFormatNumber::query()
                ->when($this->search, function ($query) {
                    $query->where(function ($query) {
                        $query->orWhere("code", "like", "{$this->search}%");
                        $query->orWhere("name", "like", "%{$this->search}%");
                    });
                })
                ->orderBy($this->sortBy ?: "name", $this->sortAsc ? "asc" : "desc")
                ->paginate($this->perPage)
        ]);
    }

    public function updated($key)
    {

        if (in_array($key, ["number.parameter_1", "number.parameter_2", "number.parameter_3", "number.parameter_4", "number.parameter_5"])) {

            $index = Str::replace("number.parameter_", "", $key);

            $this->number["parameter_{$index}_type"] = "";
            $this->number["parameter_{$index}_value"] = "";

            return;
        }

        if (in_array($key, ["number.parameter_1_type", "number.parameter_2_type", "number.parameter_3_type", "number.parameter_4_type", "number.parameter_5_type"])) {

            $index = Str::replace(["number.parameter_", "_type"], "", $key);

            $this->number["parameter_{$index}_value"] = "";

            return;
        }

    }

    public function create()
    {
        $this->state = State::CREATE;
        $this->number = [
            "id" => 0,
            "code" => "",
            "name" => "",
            "description" => "",
            "delimiter" => AppFormatNumber::DELIMITER_SLASH,
            "parameter_1" => AppFormatNumber::TYPE_CODE,
            "parameter_2" => AppFormatNumber::TYPE_YEAR,
            "parameter_3" => AppFormatNumber::TYPE_MONTH,
            "parameter_4" => AppFormatNumber::TYPE_SEQUENCE,
            "parameter_5" => "",
            "parameter_1_type" => "",
            "parameter_2_type" => AppFormatNumber::TYPE_YEAR_4,
            "parameter_3_type" => AppFormatNumber::TYPE_MONTH_MONTH_2,
            "parameter_4_type" => 4,
            "parameter_5_type" => "",
            "parameter_1_value" => "",
            "parameter_2_value" => date("Y"),
            "parameter_3_value" => date("m"),
            "parameter_4_value" => 1,
            "parameter_5_value" => "",
        ];
    }

    public function edit(AppFormatNumber $number)
    {
        $this->state = State::EDIT;
        $this->number = $number->toArray();
    }

    public function save()
    {
        $number = $this->number;

        $this->validate([
            "number.code" => ["required", "unique:app_format_numbers,code,{$number["id"]}", "min:4"],
            "number.name" => ["required", "max:255"],
            "number.delimiter" => [Rule::in(array_keys(AppFormatNumber::delimiter))],
            "number.description" => ["sometimes"],
            "number.parameter_1" => ["required", Rule::in(array_keys(AppFormatNumber::type))],
            "number.parameter_2" => ["required", Rule::in(array_keys(AppFormatNumber::type))],
            "number.parameter_3" => ["required", Rule::in(array_keys(AppFormatNumber::type))],
            "number.parameter_4" => ["sometimes", Rule::in(array_keys(AppFormatNumber::type))],
            "number.parameter_5" => ["sometimes", Rule::in(array_keys(AppFormatNumber::type))],
            "number.parameter_1_type" => [$number["parameter_1"] ? "required" : ""],
            "number.parameter_2_type" => [$number["parameter_2"] ? "required" : ""],
            "number.parameter_3_type" => [$number["parameter_3"] ? "required" : ""],
            "number.parameter_4_type" => [$number["parameter_4"] ? "required" : ""],
            "number.parameter_5_type" => [$number["parameter_5"] ? "required" : ""],
            "number.parameter_1_value" => [$number["parameter_1"] && $number["parameter_1"] != AppFormatNumber::TYPE_CODE ? "required" : ""],
            "number.parameter_2_value" => [$number["parameter_2"] && $number["parameter_2"] != AppFormatNumber::TYPE_CODE ? "required" : ""],
            "number.parameter_3_value" => [$number["parameter_3"] && $number["parameter_3"] != AppFormatNumber::TYPE_CODE ? "required" : ""],
            "number.parameter_4_value" => [$number["parameter_4"] && $number["parameter_4"] != AppFormatNumber::TYPE_CODE ? "required" : ""],
            "number.parameter_5_value" => [$number["parameter_5"] && $number["parameter_5"] != AppFormatNumber::TYPE_CODE ? "required" : ""],
        ]);

        if ($this->state == State::EDIT) {
            $this->update();
        }

        if ($this->state == State::CREATE) {
            $this->store();
        }

    }

    private function store()
    {
        Gate::authorize("{$this->app_path}.store");

        $user = auth()->user();
        $number = $this->number;

        DB::beginTransaction();

        try {

            AppFormatNumber::query()
                ->create([
                    "code" => Str::upper($number["code"]),
                    "name" => $number["name"],
                    "delimiter" => $number["delimiter"],
                    "description" => $number["description"],
                    "parameter_1" => $number["parameter_1"],
                    "parameter_2" => $number["parameter_2"],
                    "parameter_3" => $number["parameter_3"],
                    "parameter_4" => $number["parameter_4"],
                    "parameter_5" => $number["parameter_5"],
                    "parameter_1_type" => $number["parameter_1_type"],
                    "parameter_2_type" => $number["parameter_2_type"],
                    "parameter_3_type" => $number["parameter_3_type"],
                    "parameter_4_type" => $number["parameter_4_type"],
                    "parameter_5_type" => $number["parameter_5_type"],
                    "parameter_1_value" => $number["parameter_1_value"],
                    "parameter_2_value" => $number["parameter_2_value"],
                    "parameter_3_value" => $number["parameter_3_value"],
                    "parameter_4_value" => $number["parameter_4_value"],
                    "parameter_5_value" => $number["parameter_5_value"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Penomoran berhasil ditambah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Penomoran gagal ditambah")
            ]);
        }

    }

    private function update()
    {
        Gate::authorize("{$this->app_path}.update");

        $user = auth()->user();
        $number = $this->number;

        DB::beginTransaction();

        try {

            $update = AppFormatNumber::query()->find($number["id"]);

            $update->update([
                "code" => Str::upper($number["code"]),
                "name" => $number["name"],
                "delimiter" => $number["delimiter"],
                "description" => $number["description"],
                "parameter_1" => $number["parameter_1"],
                "parameter_2" => $number["parameter_2"],
                "parameter_3" => $number["parameter_3"],
                "parameter_4" => $number["parameter_4"],
                "parameter_5" => $number["parameter_5"],
                "parameter_1_type" => $number["parameter_1_type"],
                "parameter_2_type" => $number["parameter_2_type"],
                "parameter_3_type" => $number["parameter_3_type"],
                "parameter_4_type" => $number["parameter_4_type"],
                "parameter_5_type" => $number["parameter_5_type"],
                "parameter_1_value" => $number["parameter_1_value"],
                "parameter_2_value" => $number["parameter_2_value"],
                "parameter_3_value" => $number["parameter_3_value"],
                "parameter_4_value" => $number["parameter_4_value"],
                "parameter_5_value" => $number["parameter_5_value"],
                "updated_by" => $user->id,
            ]);

            DB::commit();

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Penomoran berhasil diubah")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("dismiss", "modal_form");
            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Penomoran gagal diubah")
            ]);
        }

    }

    public function destroy(AppFormatNumber $number)
    {
        Gate::authorize("{$this->app_path}.delete");

        DB::beginTransaction();

        try {

            $number->delete();

            DB::commit();

            $this->emit("notification", [
                "type" => "success",
                "message" => __("Format Penomoran berhasil dihapus")
            ]);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            $this->emit("notification", [
                "type" => "error",
                "message" => __("Format Penomoran gagal dihapus")
            ]);

        } finally {
            $this->emit("loader", false);
        }

    }

}
