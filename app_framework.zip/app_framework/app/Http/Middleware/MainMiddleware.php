<?php

namespace App\Http\Middleware;

use App\Models\AppModule;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\View;

class MainMiddleware
{

    public function handle(Request $request, Closure $next)
    {

        list($module_path, $module_sub_path, $menu_path, $menu_sub_path) = $request->segments();

        $user = auth()->user();
        $user_role = $user->role;
        $user_permissions = $user_role->permissions;

        $path = "{$module_path}.{$module_sub_path}.{$menu_path}.{$menu_sub_path}";

        $module = AppModule::query()->firstWhere("path", $module_path);
        if (!$module) {
            return response(view("errors.404"));
        }

        $module_sub = $module->moduleSubs()->firstWhere("path", $module_sub_path);
        if (!$module_sub) {
            return response(view("errors.404"));
        }

        $menu = $module_sub->menus()->firstWhere("path", $menu_path);
        if (!$menu) {
            return response(view("errors.404"));
        }

        $menu_sub = $menu->menuSubs()->firstWhere("path", $menu_sub_path);
        if ($menu_sub_path != "_" && !$menu_sub) {
            return response(view("errors.404"));
        }

        if ($menu_sub_path == "_" && $user->cannot("{$module_path}.{$module_sub_path}.{$menu_path}._.view")) {
            return response(view("errors.403"));
        }

        if ($user->cannot("{$module_path}.{$module_sub_path}.{$menu_path}.{$menu_sub_path}.view")) {
            return response(view("errors.403"));
        }


        $user_permissions = $user_permissions
            ->map(function ($permission) {

                $extract = explode(".", $permission->name);

                // handle extract is null
                if (count($extract) == 1) {
                    return null;
                }

                return [
                    "module_path" => $extract[0],
                    "module_sub_path" => $extract[1] ?? "",
                    "menu_path" => $extract[2] ?? "",
                    "menu_sub_path" => $extract[3] ?? "",
                    "permission" => $extract[4] ?? "",
                ];
            })
            ->filter(function ($permission) use ($module_path) {
                return $permission && $permission["module_path"] == $module_path && $permission["permission"] == "view";
            });


        $module->load([
            "category:id,name",
            "moduleSubs" => function ($query) use ($user_permissions) {
                $query->whereIn("path", $user_permissions->pluck("module_sub_path")->unique()->toArray());
                $query->where("status", 1);
                $query->orderBy("order");
            }
        ]);

        $module_sub->load([
            "menus" => function ($query) use ($user_permissions) {
                $query->whereIn("path", $user_permissions->pluck("menu_path")->unique()->toArray());
                $query->where("status", 1);
                $query->orderBy("order");
            },
            "menus.menuSubs" => function ($query) use ($user_permissions) {
                $query->whereIn("path", $user_permissions->pluck("menu_sub_path")->unique()->toArray());
                $query->where("status", 1);
                $query->orderBy("order");
            },
        ]);

        $request->route()->setParameter("app", (object)[
            "module" => $module,
            "module_sub" => $module_sub,
            "menu" => $menu_sub_path == "_" ? $menu : $menu_sub,
            "permission" => $path,
        ]);

        View::share("request", $request);

        View::share("user", $user);
        View::share("user_role", $user_role);

        View::share("app_module_name", $module->name);
        View::share("app_module_sub_name", $module_sub->name);
        View::share("app_menu_name", $menu->name);
        View::share("app_menu_sub_name", $menu_sub?->name ?? "");

        View::share("app_module", $module);
        View::share("app_module_sub", $module_sub);
        View::share("app_menu", $menu_sub_path == "_" ? $menu : $menu_sub);
        View::share("app_path", $path);

        return $next($request);
    }
}
