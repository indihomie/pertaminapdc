<?php

namespace App\Http\Middleware;

use App\Models\AppLogAccess;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AccessLogMiddleware
{

    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {

        $response = $next($request);

        if (Str::contains($request->path(), "livewire")) {
            return $response;
        }

        AppLogAccess::insert([
            "user_id" => auth()->id() ?? 0,
            "ip_address" => $request->ip(),
            "path" => $request->path(),
            "method" => $request->method(),
            "status" => $response->getStatusCode(),
        ]);

        return $response;
    }

}
