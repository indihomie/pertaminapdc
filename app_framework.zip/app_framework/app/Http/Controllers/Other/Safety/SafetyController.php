<?php

namespace App\Http\Controllers\Other\Safety;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SafetyController extends Controller
{

    public function index(Request $request)
    {
        return view("other.safety.safety");
    }

}
