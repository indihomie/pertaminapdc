<?php

namespace App\Http\Controllers\App\Master;

use App\Http\Controllers\Controller;
use App\Models\AppMasterCategory;
use Illuminate\Http\Request;

class MasterGeneralController extends Controller
{

    public function indexCategory(Request $request)
    {
        return view("app-master.general.master-category");
    }

    public function indexMaster(Request $request, AppMasterCategory $app_master_categories)
    {
        return view("app-master.general.master", [
            "master_category" => $app_master_categories
        ]);
    }

    public function indexMasterByMenu(Request $request)
    {

        $master = $request->app->menu->master;

        if (!$master) {
            return view("app-master.general.master-not-found");
        }

        return view("app-master.general.master", [
            "master_category" => $master
        ]);
    }

}
