<?php

namespace App\Http\Controllers\App\Monitor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use function view;

class AccessLogController extends Controller
{

    public function index(Request $request)
    {
        return view("app-monitor.access-log");
    }

}
