<?php

namespace App\Http\Controllers\App\Setting;

use App\Http\Controllers\Controller;
use App\Models\AppManualBook;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;

class ManualBookController extends Controller
{

    public function index(Request $request)
    {

        $manual = AppManualBook::find(1);

        return view("app-setting.manual-book", compact("manual"));
    }

    public function store(Request $request)
    {
        Gate::authorize("{$request->app->permission}.update");

        $this->validate($request, [
            "name" => "required|string|max:255",
            "description" => "required|string|max:255",
            "document" => "sometimes|mimes:pdf,doc,docx|max:4096",
            "document_remove" => "nullable",
        ]);

        DB::beginTransaction();

        try {

            $update = AppManualBook::find(1);

            $update->update([
                "name" => $request->name,
                "description" => $request->description,
            ]);

            if ($request->document_remove) {
                $update->deleteDocument();
            }

            if ($request->document) {
                $update->uploadDocument($request->document);
            }

            DB::commit();
            session()->flash("success", __("Buku Manual berhasil diubah"));

        } catch (Exception $e) {

            Log::error($e);

            DB::rollBack();
            session()->flash("error", __("Buku Manual gagal diubah"));

            dd($e);
        }

        return redirect()->back();
    }

}
