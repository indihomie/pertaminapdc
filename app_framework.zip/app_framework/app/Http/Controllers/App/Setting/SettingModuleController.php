<?php

namespace App\Http\Controllers\App\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SettingModuleController extends Controller
{

    public function index(Request $request)
    {
        return view("app-setting.setting-module");
    }

}
