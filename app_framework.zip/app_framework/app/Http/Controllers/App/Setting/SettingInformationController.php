<?php

namespace App\Http\Controllers\App\Setting;

use App\Http\Controllers\Controller;
use App\Models\AppInformation;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;

class SettingInformationController extends Controller
{

    public function index(Request $request)
    {

        $information = AppInformation::query()->first();

        return view("app-setting.setting-information", compact("information"));
    }

    public function store(Request $request)
    {
        Gate::authorize("{$request->app->permission}.update");

        $this->validate($request, [
            "name" => "required|string|max:255",
            "company" => "required|string|max:255",
            "copyright" => "required|string|max:255",

            "icon" => "sometimes|image|mimes:png|max:1024",
            "logo" => "sometimes|image|mimes:png|max:1024",

            "image_mobile_logo" => "sometimes|image|mimes:png|max:1024",
            "image_mobile_login_logo" => "sometimes|image|mimes:png|max:1024",
            "image_mobile_login_background" => "sometimes|image|mimes:jpeg|max:1024",
        ]);

        DB::beginTransaction();

        try {

            $information = AppInformation::query()->first();

            $information->update([
                "name" => $request->name,
                "company" => $request->company,
                "copyright" => $request->copyright,

                "color_primary" => $request->color_primary,
                "color_primary_dark" => $request->color_primary_dark,
            ]);

            // icon
            if ($request->icon_remove) {
                $information->deleteIcon();
            }

            if ($request->hasFile("icon")) {
                $information->uploadIcon($request->file("icon"));
            }

            // logo
            if ($request->logo_remove) {
                $information->deleteLogo();
            }

            if ($request->hasFile("logo")) {
                $information->uploadLogo($request->file("logo"));
            }

            // mobile logo
            if ($request->image_mobile_logo_remove) {
                $information->deleteImageMobileLogo();
            }

            if ($request->hasFile("image_mobile_logo")) {
                $information->uploadImageMobileLogo($request->file("image_mobile_logo"));
            }

            // mobile login logo
            if ($request->image_mobile_login_logo_remove) {
                $information->deleteImageMobileLoginLogo();
            }

            if ($request->hasFile("image_mobile_login_logo")) {
                $information->uploadImageMobileLoginLogo($request->file("image_mobile_login_logo"));
            }

            // mobile login background
            if ($request->image_mobile_login_background_remove) {
                $information->deleteImageMobileLoginBackground();
            }

            if ($request->hasFile("image_mobile_login_background")) {
                $information->uploadImageMobileLoginBackground($request->file("image_mobile_login_background"));
            }

            Cache::forget("app_information");

            DB::commit();
            session()->flash("success", __("Informasi berhasil disimpan"));

        } catch (Exception $e) {

            Log::error($e);

            DB::rollBack();
            session()->flash("error", __("Informasi gagal disimpan"));

            dd($e);
        }

        return redirect()->back();
    }

}
