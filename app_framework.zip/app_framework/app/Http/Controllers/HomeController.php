<?php

namespace App\Http\Controllers;

use App\Models\AppInformationAnnouncement;
use App\Models\AppInformationNews;
use App\Models\AppManualBook;
use App\Models\AppModule;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class HomeController extends Controller
{

    public function front(Request $request)
    {

        return view("welcome");
    }

    public function index(Request $request)
    {

        $user = auth()->user();
        $user_role = $user->role;
        $user_permissions = $user_role->permissions;

        $user_access_modules = $user_permissions
            ->filter(fn($permission) => Str::contains($permission->name, "module_"))
            ->mapWithKeys(fn($permission) => [$permission->name => true]);

        $app_manual = AppManualBook::query()->with("updatedBy")->latest()->first();
        $app_announcements = AppInformationAnnouncement::query()->with("updatedBy")->latest()->limit(5)->get();
        $app_news = AppInformationNews::query()->with("updatedBy")->latest()->limit(5)->get();

        $app_modules = AppModule::query()
            ->with("category")
            ->where("status", 1)
            ->orderBy("order", "desc")
            ->get()
            ->filter(fn($module) => $user_access_modules["module_{$module->id}"] ?? false);

        $app_module_categories = $app_modules->pluck("category")
            ->unique("id")
            ->where("status", 1)
            ->values();
        $app_modules = $app_modules->groupBy("category_id");

        $notifications = $user->notifications()->orderBy("created_at", "desc")->limit(5)->get();

        return view("home",
            compact([
                "user",
                "user_role",
                "app_manual",
                "app_announcements",
                "app_news",
                "app_module_categories",
                "app_modules",
                "notifications",
            ])
        );
    }

}
