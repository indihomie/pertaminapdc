<?php

namespace App\Http\Controllers;

use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;

class AuthController extends Controller
{

    public function index(Request $request)
    {

    }

    public function login(Request $request)
    {

    }

    public function createForgotPassword(Request $request)
    {

        return view("app-auth.forgot-password");
    }

    public function storeForgotPassword(Request $request)
    {

        $request->validate([
            "email" => "required|email:rfc,dns|exists:app_users"
        ]);

        $status = Password::sendResetLink(
            $request->only("email")
        );

        if ($status == Password::RESET_LINK_SENT) {

            return redirect()->back()
                ->with("success", "Email Reset Password berhasil dikirim");
        }

        return redirect()->back()
            ->withErrors([
                "failed" => "Email Reset gagal dikirim"
            ]);
    }

    public function resetPassword(Request $request, $token)
    {

        return view("app-auth.reset-password", [
            "token" => $token
        ]);
    }

    public function updatePassword(Request $request)
    {

        $this->validate($request, [
            "token" => "required",
            "email" => "required|email:rfc,dns|exists:app_users",
            "password" => "required|min:8|confirmed",
            "password_confirmation" => "required|same:password",
        ]);

        $status = Password::reset(
            $request->only(
                "token",
                "email",
                "password",
                "password_confirmation",
            ),
            function ($user, $password) {

                $user->forceFill([
                    "password" => Hash::make($password)
                ]);

                $user->save();

                event(new PasswordReset($user));
            }
        );

        if ($status == Password::PASSWORD_RESET) {

            session()->flash("success", "Password berhasil diubah");

            return redirect()->route("password.reset", [
                "token" => $request->token,
                "email" => $request->email
            ]);
        }

        if ($status == Password::INVALID_TOKEN) {

            return redirect()
                ->route("password.reset", [
                    "token" => $request->token,
                    "email" => $request->email
                ])
                ->withErrors([
                    "failed" => "Password gagal diubah, Token reset password kadaluarsa"
                ]);
        }

        return redirect()
            ->route("password.reset", [
                "token" => $request->token,
                "email" => $request->email
            ])
            ->withErrors([
                "failed" => "Password gagal diubah, Terjadi masalah sistem!"
            ]);
    }

}
