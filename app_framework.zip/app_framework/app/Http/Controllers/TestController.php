<?php

namespace App\Http\Controllers;

use App\Classes\FormatApproval;
use App\Models\AppApproval;
use App\Models\AppApprovalStep;

class TestController extends Controller
{

    public function index()
    {

        dd(FormatApproval::generate(
            "TEST",
            "menu",
            AppApproval::class,
            1,
            [
                "dataset1" => "data1",
            ]
        ));

//        dd(FormatApproval::approve(
//            35,
//            now(),
//            1,
//            AppApprovalStep::STATUS_APPROVED,
//            "TEST",
//
//        ));

    }

}
