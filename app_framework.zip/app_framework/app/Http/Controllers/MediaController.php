<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class MediaController extends Controller
{

    public function view(Request $request, $file_path_encrypt)
    {

        try {

            $file_path = decrypt($file_path_encrypt);
            $storage = Storage::disk("public");

            if (!$storage->exists($file_path) || !$file_path) {
                throw new Exception("File tidak ditemukan");
            }

            $extension = File::extension($storage->path($file_path));

            if (in_array($extension, ["image", "jpg", "jpeg", "png", "gif", "ico"])) {

                return response()->file($storage->path($file_path));
            }

            if (in_array($extension, ["mp4", "mp3", "webm"])) {

                return response()->file($storage->path($file_path));
            }

            if ($extension == "pdf") {

                return response()->file($storage->path($file_path));
            }

            if (in_array($extension, ["doc", "docx", "xls", "xlsx", "csv"])) {

                $url = url("storage/{$file_path}");

                return view("app.view-doc", [
                    "url" => urlencode($url)
                ]);
            }

            throw new Exception("Format dokumen tidak dikenal");

        } catch (Exception $e) {
            return $e->getMessage();
        }

    }

    public function stream(Request $request, $file_path_encrypt)
    {

        try {

            $file_path = decrypt($file_path_encrypt);
            $storage = Storage::disk($request->disk ?? "public");

            if (!$storage->exists($file_path) || !$file_path) {
                throw new Exception("File tidak ditemukan");
            }

            return $storage->response($file_path);

        } catch (Exception $e) {
            return $e->getMessage();
        }

    }

    public function download(Request $request, $file_path_encrypt)
    {

        try {

            $file_path = decrypt($file_path_encrypt);
            $storage = Storage::disk("public");

            if (!$storage->exists($file_path)) {
                throw new Exception("File tidak ditemukan");
            }

            $file_name = File::basename($file_path);

            return $storage->download($file_path, $file_name);

        } catch (Exception $e) {
            return $e->getMessage();
        }

    }

    public function ckeditorUpload(Request $request)
    {

        if ($request->hasFile("upload")) {

            $file = $request->file("upload");

            $filename = $file->store("uploads", ["disk" => "public"]);

            // Render HTML output
            @header("Content-type: text/html; charset=utf-8");

            $CKEditorFuncNum = $request->input("CKEditorFuncNum");
            $url = asset("storage/" . $filename);

            echo "<script>window.parent.CKEDITOR.tools.callFunction({$CKEditorFuncNum}, '{$url}', 'Image successfully uploaded')</script>";
        }

    }

}
