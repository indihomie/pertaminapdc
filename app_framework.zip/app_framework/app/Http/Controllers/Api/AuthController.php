<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;


class AuthController extends Controller
{

    public function login(Request $request)
    {

        $validate = Validator::make($request->all(), [
            "device_id" => ["required"],
            "device_name" => ["required"],
            "username" => ["required", "min:6", "exists:app_users"],
            "password" => ["required", "min:6"],
        ]);

        if ($validate->fails()) {

            return response()->json([
                "message" => $validate->errors()->first()
            ], 202);
        }

        $credential = [
            "username" => $request->username,
            "password" => $request->password
        ];

        $result = Auth::attempt($credential);

        if (!$result) {

            return response()->json([
                "message" => "Username atau Password tidak valid",
                "result" => null
            ], 202);
        }

        $user = auth()->user();
        $user->update([
            "login_at" => now()
        ]);

        $info = [
            "device_name" => $request->device_name,
            "ip" => $request->ip()
        ];

        $result = [
            "id" => $user->id,
            "name" => $user->name,
            "email" => $user->email,
            "phone" => $user->phone,
            "image" => $user->path_photo,
            "auth" => $user->createToken(json_encode($info))
        ];

        return response()->json([
            "message" => "OK",
            "result" => $result
        ]);
    }

    public function logout()
    {

        $user = auth()->user();

        $user->update([
            "firebase_token" => ""
        ]);
        $user->token()->revoke();

        return response()->json([
            "message" => "OK"
        ]);
    }

    public function updatePassword(Request $request)
    {

        $this->validate($request, [
            "password" => ["required", "min:6", "current_password:"],
            "password_new" => ["required"],
        ]);

        $user = auth()->user();

        $user->update([
            "password" => bcrypt($request->password_new)
        ]);

        return response()->json([
            "message" => "OK",
            "result" => null
        ]);
    }

}
