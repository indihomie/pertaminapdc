<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AppVersionMobile;

class ApplicationController extends Controller
{

    public function index()
    {

        $version = AppVersionMobile::latest()->first();

        if (!$version) {

            return response()->json([
                "message" => "ZERO_RESULTS",
                "result" => null
            ], 202);
        }

        $logs = AppVersionMobile::latest()
            ->take(4)
            ->get();

        $logs->map(function ($log) {

            $log->datetime = strtotime($log->created_at);

            return $log;
        });

        $version->datetime = strtotime($version->created_at);
        $version->logs = $logs;

        return response()->json([
            "message" => "OK",
            "result" => $version
        ]);
    }

}
