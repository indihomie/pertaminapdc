<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{

    public function index(Request $request)
    {

        $user = auth()->user();

        return response()->json([
            "message" => "OK",
            "result" => [
                "id" => $user->id,
                "name" => $user->name,
                "email" => $user->email,
                "phone" => $user->phone,
                "path_photo" => $user->path_photo,
            ]
        ]);
    }

    public function updateTokenFirebase(Request $request)
    {

        $this->validate($request, [
            "token" => ["required", "min:64"],
        ]);

        $user = auth()->user();

        DB::beginTransaction();

        try {

            $user->update([
                "firebase_token" => $request->token,
            ]);

            DB::commit();

            return response()->json([
                "mesasge" => "OK",
            ], 201);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            return response()->json([
                "message" => "ERROR",
                "result" => $e->getMessage()
            ]);

        }

    }

}
