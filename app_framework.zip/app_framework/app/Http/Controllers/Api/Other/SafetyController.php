<?php

namespace App\Http\Controllers\Api\Other;

use App\Http\Controllers\Controller;
use App\Models\AppUser;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SafetyController extends Controller
{

    public function indexLocationHistorySelf(Request $request)
    {

        $user = auth()->user();

        return $this->indexLocationHistory($request, $user);
    }

    public function indexLocationHistory(Request $request, AppUser $user)
    {

        $location_histories = $user->locationHistories()
            ->latest()
            ->get()
            ->map(function ($history) {

                return [
                    "id" => $history->id,
                    "user_id" => $history->user_id,
                    "longitude" => $history->longitude,
                    "latitude" => $history->latitude,
                    "created_at" => $history->created_at->toDateTimeString(),
                    "updated_at" => $history->created_at->toDateTimeString(),
                    "created_at_timestamp" => $history->created_at->timestamp,
                    "updated_at_timestamp" => $history->updated_at->timestamp,
                ];
            });

        return response()->json([
            "message" => "OK",
            "result" => $location_histories
        ]);
    }

    public function storeLocationHistory(Request $request)
    {

        $this->validate($request, [
            "longitude" => ["required", "numeric"],
            "latitude" => ["required", "numeric"],
        ]);

        $user = auth()->user();

        DB::beginTransaction();

        try {

            $user->locationHistories()
                ->create([
                    "longitude" => $request->longitude,
                    "latitude" => $request->latitude,
                ]);

            DB::commit();

            return response()->json([
                "mesasge" => "OK",
            ], 201);

        } catch (Exception $e) {

            DB::rollBack();
            Log::error($e);

            return response()->json([
                "message" => "ERROR",
                "result" => $e->getMessage()
            ]);
        }

    }

    public function showEmergency(Request $request, AppUser $user)
    {

        return response()->json([
            "message" => "OK",
            "result" => [
                "id" => $user->id,
                "name" => $user->name,
                "phone" => $user->phone,
                "path_photo" => $user->path_photo,
            ]
        ]);
    }

    public function sendEmergency(Request $request)
    {

        $firebase_token = config("environment.TOKEN_FCM");

        $user = auth()->user();

        $user->relations
            ->each(function ($relation) use ($user, $firebase_token) {

                Http::asJson()
                    ->withHeaders([
                        "Content-Type" => "application/json",
                        "Authorization" => "key={$firebase_token}"
                    ])->post("https://fcm.googleapis.com/fcm/send", [
                        "to" => $relation->firebase_token,
                        "data" => [
                            "channel_id" => "Panic",
                            "title" => "Emergency",
                            "body" => "{$user->name} dalam bahaya, silahkan klik notifikasi untuk melihat lokasi terakhir.",
                            "id" => $user->id,
                        ],
                        "time_to_live" => 60,
                    ]);

            });

        return response()->json([
            "message" => "OK",
            "result" => null
        ]);
    }

}
