<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LegacyController extends Controller
{

    public function _(Request $request)
    {
        return view("welcome");
    }

    public function home()
    {
        return view("home");
    }

    public function index()
    {
        return view("index");
    }

    public function popup()
    {
        return view("popup");
    }

    public function void()
    {
        return view("void");
    }

}
