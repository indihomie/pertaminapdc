<?php

namespace App\Http\Controllers;

use App\Models\AppModule;
use App\Models\AppModuleSub;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RelayController extends Controller
{

    public function module(Request $request, AppModule $module)
    {

        $user = auth()->user();
        $user_role = $user->role;
        $user_permissions = $user_role->permissions;

        $access_menus = [];

        $module->load([
            "moduleSubs:id,module_id,path,name,order",
            "moduleSubs.menus:id,module_sub_id,path,name,order",
            "moduleSubs.menus.menuSubs:id,module_id,module_sub_id,id,menu_id,path,name,order",
        ]);

        $module->moduleSubs
            ->sortBy("order")
            ->each(function ($module_sub) use (&$access_menus, $module) {

                $module_sub->menus
                    ->sortBy("order")
                    ->each(function ($menu) use (&$access_menus, $module, $module_sub) {

                        if ($menu->menuSubs->isEmpty()) {

                            $access_menus[] = [
                                "key" => "{$module->path}.{$module_sub->path}.{$menu->path}._.view",
                                "module" => $module->path,
                                "module_sub" => $module_sub->path,
                                "menu" => $menu->path,
                                "menu_sub" => "_",
                            ];
                        }

                        $menu->menuSubs
                            ->sortBy("order")
                            ->each(function ($menu_sub) use (&$access_menus, $module, $module_sub, $menu) {

                                $access_menus[] = [
                                    "key" => "{$module->path}.{$module_sub->path}.{$menu->path}.{$menu_sub->path}.view",
                                    "module" => $module->path,
                                    "module_sub" => $module_sub->path,
                                    "menu" => $menu->path,
                                    "menu_sub" => $menu_sub->path,
                                ];
                            });

                    });

            });

        $access_menus = collect($access_menus)->whereIn("key", $user_permissions->pluck("name"));

        if ($access_menus->isEmpty()) {
            return view("errors.403");
        }

        $menu = $access_menus->first();

        return redirect("{$menu["module"]}/{$menu["module_sub"]}/{$menu["menu"]}/{$menu["menu_sub"]}");
    }

    public function moduleSub(Request $request, AppModule $module, AppModuleSub $module_sub)
    {

        $user = auth()->user();
        $user_role = $user->role;
        $user_permissions = $user_role->permissions;

        $access_menus = [];

        $module_sub->load([
            "menus:id,module_sub_id,path,name,order",
            "menus.menuSubs:id,module_id,module_sub_id,id,menu_id,path,name,order",
        ]);

        $module_sub->menus
            ->sortBy("order")
            ->each(function ($menu) use (&$access_menus, $module, $module_sub) {

                if ($menu->menuSubs->isEmpty()) {

                    $access_menus[] = [
                        "key" => "{$module->path}.{$module_sub->path}.{$menu->path}._.view",
                        "module" => $module->path,
                        "module_sub" => $module_sub->path,
                        "menu" => $menu->path,
                        "menu_sub" => "_",
                    ];
                }

                $menu->menuSubs
                    ->sortBy("order")
                    ->each(function ($menu_sub) use (&$access_menus, $module, $module_sub, $menu) {

                        $access_menus[] = [
                            "key" => "{$module->path}.{$module_sub->path}.{$menu->path}.{$menu_sub->path}.view",
                            "module" => $module->path,
                            "module_sub" => $module_sub->path,
                            "menu" => $menu->path,
                            "menu_sub" => $menu_sub->path,
                        ];
                    });

            });

        $access_menus = collect($access_menus)->whereIn("key", $user_permissions->pluck("name"));

        if ($access_menus->isEmpty()) {
            return view("errors.403");
        }

        $menu = $access_menus->first();

        return redirect("{$menu["module"]}/{$menu["module_sub"]}/{$menu["menu"]}/{$menu["menu_sub"]}");
    }

    public function emptyPage(Request $request)
    {

//        $accesses = [
//            "view" => "view",
//            "create" => "store",
//            "update" => "update",
//            "delete" => "delete",
//        ];
//
//        foreach (Permission::all() as $permission) {
//
//            if (Str::contains($permission->name, ".")) {
//
//                list($_module, $_module_sub, $_menu, $_menu_sub, $access) = explode(".", $permission->name);
//
//                $permission->update([
//                    "name" => "{$_module}.{$_module_sub}.{$_menu}.{$_menu_sub}.{$accesses[$access]}",
//                ]);
//            };
//
//        }

//        $permissions = array_keys(config("paramter.permissions"));
//
//        $menus = AppMenu::all();
//
//        foreach ($menus as $menu) {
//
//            $_permissions = collect(range(0, strlen($menu->access) - 1))
//                ->map(function ($index) use ($permissions, $menu) {
//
//                    if ($menu->access[$index] == "1") {
//                        return $permissions[$index];
//                    }
//
//                    return null;
//                })
//                ->filter()
//                ->values()
//                ->toArray();
//
//            $menu->update([
//                "permissions" => $_permissions
//            ]);
//        }

        return view("empty");
    }

    public function linkPage($app)
    {
        Gate::authorize("{$app->permissions}.view");
        return view("link");
    }

    public function master(Request $request)
    {
        Gate::authorize("{$request->app->permission}.view");
        return view("app-setting.setting-master-single");
    }

}
