<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DocumentationController extends Controller
{

    public function index(Request $request)
    {

        $storage = Storage::disk("sources");
        $content = $storage->get($request->path);

        return view("documentation", [
            "request" => $request->all(),
            "content" => $content
        ]);
    }

}
