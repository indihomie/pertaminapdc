<?php

namespace App\Const;

enum State
{
    const DELETE = -1;
    const CREATE = 1;
    const EDIT = 2;
}
