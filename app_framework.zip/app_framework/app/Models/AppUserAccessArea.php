<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string id
 * @property string user_id
 * @property string area_id
 * @property string created_by
 * @property string created_at
 * @property string updated_by
 * @property string updated_at
 **/
class AppUserAccessArea extends Model
{
    use HasFactory;

    protected $table = "app_user_access_areas";

    protected $guarded = [];

}
