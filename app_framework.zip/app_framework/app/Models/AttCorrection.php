<?php

namespace App\Models;

use App\Models\Employee\Employee;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string employee_id
 * @property string number
 * @property string attendance_start
 * @property string attendance_end
 * @property string attendance_duration
 * @property string correction_start
 * @property string correction_end
 * @property string correction_duration
 * @property string path_document
 * @property string description
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 * @property string deleted_at
 **/
class AttCorrection extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    const PATH_DOCUMENT = "attendances/corrections";


    protected $table = "att_corrections";

    protected $guarded = [];

    protected $casts = [
        "attendance_start" => "datetime",
        "attendance_end" => "datetime",
        "attendance_duration" => "datetime",
        "correction_start" => "datetime",
        "correction_end" => "datetime",
        "correction_duration" => "datetime",
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "employee_id",
                "number",
                "attendance_start",
                "attendance_end",
                "attendance_duration",
                "attendance_start",
                "attendance_end",
                "attendance_duration",
                "path_document",
                "description",
                "created_by",
                "updated_by",
            ]);
    }


    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }

}
