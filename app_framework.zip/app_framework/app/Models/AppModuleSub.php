<?php

namespace App\Models;

use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string             id
 * @property string             module_id
 * @property string             name
 * @property string             directory
 * @property string             path_icon
 * @property string             description
 * @property string             order
 * @property string             status
 * @property string             created_by
 * @property string             created_at
 * @property string             updated_by
 * @property string             updated_at
 * @property AppGroupAccessMenu accessMenus
 **/
class AppModuleSub extends Model
{
    use HasFactory,
        LogsActivity,
        WithStatus;

    public static $path_icon = "_/module_sub/";

    protected $table = "app_module_subs";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "module_id",
                "name",
                "directory",
                "path_icon",
                "description",
                "order",
                "status",
                "created_by",
                "created_at",
                "updated_by",
                "updated_at",
            ]);
    }


    public function menus()
    {
        return $this->hasMany(AppMenu::class, "module_sub_id", "id")->where("menu_id", 0);
    }

    public function manual()
    {
        return $this->hasOne(AppManualBook::class, "module_sub_id", "id");
    }

}
