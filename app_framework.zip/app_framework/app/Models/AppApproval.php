<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string master_id
 * @property string menu_code
 * @property string reference_type
 * @property string reference_id
 * @property string type
 * @property string dataset
 * @property string status
 * @property string position
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppApproval extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy;

    const STATUS_PENDING = "pending";
    const STATUS_PROGRESS = "progress";
    const STATUS_APPROVED = "approved";
    const STATUS_REJECTED = "rejected";
    const STATUSES = [
        self::STATUS_PENDING => "Pending",
        self::STATUS_PROGRESS => "Progress",
        self::STATUS_APPROVED => "Approved",
        self::STATUS_REJECTED => "Rejected",
    ];

    protected $table = "app_approvals";

    protected $guarded = [];

    protected $casts = [
        "dataset" => "json"
    ];

    public function getActivitylogOptions(): LogOptions
    {

        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "master_id",
                "menu_code",
                "reference_type",
                "reference_id",
                "type",
                "dataset",
                "status",
                "position",
                "created_by",
                "updated_by",
            ]);
    }


    public function reference()
    {
        return $this->morphTo("reference");
    }

    public function steps()
    {
        return $this->hasMany(AppApprovalStep::class, "approval_id");
    }

}
