<?php

namespace App\Models;

use App\Traits\CreatedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
* @property string id
* @property string user_id
* @property string ip_address
* @property string path
* @property string method
* @property string status
* @property string created_at
 **/
class AppLogAccess extends Model
{
    use HasFactory,
        CreatedBy;

    protected $table = "app_log_accesses";

    public const UPDATED_AT = null;

    protected $guarded = [];

    public function user()
    {
        return $this->hasOne(AppUser::class, "id", "user_id");
    }

}
