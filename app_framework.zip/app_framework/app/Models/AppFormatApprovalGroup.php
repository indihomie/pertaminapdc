<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string approval_id
 * @property string order
 * @property string step_prev
 * @property string step_next
 * @property string conditions
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppFormatApprovalGroup extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy;

    protected $table = "app_format_approval_groups";

    protected $guarded = [];

    protected $casts = [
        "conditions" => "json",
    ];

    public function getActivitylogOptions(): LogOptions
    {

        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "approval_id",
                "order",
                "conditions",
                "step_prev",
                "step_next",
                "created_by",
                "updated_by",
            ]);
    }

    public function actors()
    {
        return $this->hasMany(AppFormatApprovalGroupActor::class, "approval_group_id", "id");
    }

}
