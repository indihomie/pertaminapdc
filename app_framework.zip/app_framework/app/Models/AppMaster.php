<?php

namespace App\Models;

use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string category_id
 * @property string master_id
 * @property string name
 * @property string description
 * @property string data
 * @property string order
 * @property string status
 * @property string created_by
 * @property string created_at
 * @property string updated_by
 * @property string updated_at
 **/
class AppMaster extends Model
{
    use HasFactory,
        LogsActivity,
        WithStatus;

    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;
    const STATUSES = [
        self::STATUS_ACTIVE => "Aktif",
        self::STATUS_INACTIVE => "Tidak Aktif",
    ];

    protected $table = "app_masters";

    protected $keyType = "string";

    protected $guarded = [];

    protected $casts = [
        "data" => "json"
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "category_id",
                "master_id",
                "name",
                "description",
                "data",
                "order",
                "status",
                "created_by",
                "created_at",
                "updated_by",
                "updated_at",
            ]);
    }

    public function scopeActive($query)
    {
        return $query->where("status", self::STATUS_ACTIVE);
    }


    public function category()
    {
        return $this->hasOne(AppMasterCategory::class, "id", "category_id");
    }

    public function subParent()
    {
        return $this->hasOne(AppMaster::class, "id", "master_id");
    }

    public function subChilds()
    {
        return $this->hasMany(AppMaster::class, "master_id", "id");
    }


    public function appModules()
    {
        return $this->hasMany(AppModule::class, "category_id", "id");
    }

}
