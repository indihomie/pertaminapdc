<?php

namespace App\Models\Other;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SafetyRelation extends Model
{
    use HasFactory;

    protected $guarded = [];

}
