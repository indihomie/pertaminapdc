<?php

namespace App\Models\Attendance;

use App\Models\AppMaster;
use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;

/**
 * @property string id
 * @property string code
 * @property string name
 * @property string description
 * @property string quota
 * @property string valid_start
 * @property string valid_end
 * @property string valid_type_id
 * @property string valid_join_month
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 * @property string deleted_at
 **/
class AttMasterLeave extends Model
{
    use HasFactory, UpdateBy, SoftDeletes;

    protected $table = "att_master_leaves";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "code",
                "name",
                "description",
                "quota",
                "valid_start",
                "valid_end",
                "valid_type_id",
                "valid_join_month",
                "holiday",
                "created_by",
                "updated_by",
            ]);
    }


    public function type()
    {
        return $this->hasOne(AppMaster::class, "id", "valid_type_id");
    }

}
