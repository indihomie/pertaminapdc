<?php

namespace App\Models\Attendance;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string employee_id
 * @property string shift_id
 * @property string date
 * @property string type
 * @property string start
 * @property string end
 * @property string rest_start
 * @property string rest_end
 * @property string description
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 * @property string deleted_at
 **/
class AttSchedule extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    public static $TYPE_HOLIDAY = -1;
    public static $TYPE_SCHEDULE = 0;
    public static $TYPE_FLEXIBLE = 1;

    public static $types = [
        -1 => "Libur",
        0 => "Jadwal",
        1 => "Fleksibel"
    ];

    protected $table = "att_schedules";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "employee_id",
                "shift_id",
                "date",
                "type",
                "start",
                "end",
                "rest_start",
                "rest_end",
                "description",
                "created_by",
                "updated_by",
            ]);
    }

}
