<?php

namespace App\Models\Attendance;

use App\Models\AppMaster;
use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string code
 * @property string category_id
 * @property string name
 * @property string description
 * @property string start
 * @property string end
 * @property string created_by
 * @property string updated_by
 **/
class AttMasterHoliday extends Model
{
    use HasFactory, SoftDeletes, LogsActivity, UpdateBy;

    protected $table = "att_master_holidays";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "code",
                "name",
                "description",
                "quota",
                "valid_start",
                "valid_end",
                "valid_type_id",
                "valid_join_month",
                "holiday",
                "created_by",
                "updated_by",
            ]);
    }

    public function category()
    {
        return $this->hasOne(AppMaster::class, "id", "category_id");
    }

}
