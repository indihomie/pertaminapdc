<?php

namespace App\Models\Attendance;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string code
 * @property string name
 * @property string description
 * @property string start
 * @property string end
 * @property string rest_start
 * @property string rest_end
 * @property string holiday
 * @property string schedules
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 * @property string deleted_at
 **/
class AttMasterShift extends Model
{
    use HasFactory,
        SoftDeletes,
        LogsActivity,
        UpdateBy;

    public static $TYPE_HOLIDAY = -1;
    public static $TYPE_SCHEDULE = 0;
    public static $TYPE_FLEXIBLE = 1;

    public static $status_holiday = [
        1 => "Ya",
        0 => "Tidak"
    ];

    public static $types = [
        -1 => "Libur",
        0 => "Jadwal",
        1 => "Fleksibel"
    ];

    protected $table = "att_master_shifts";

    protected $casts = [
        "schedules" => "array"
    ];

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "code",
                "name",
                "description",
                "start",
                "end",
                "rest_start",
                "rest_end",
                "holiday",
                "schedules",
                "created_by",
                "updated_by",
            ]);
    }

}
