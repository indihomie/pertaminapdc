<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string id
 * @property string user_id
 * @property string category
 * @property string title
 * @property string content
 * @property string path_image
 * @property string attachments
 * @property string menu_code
 * @property string reference_type
 * @property string reference_id
 * @property string read
 * @property string created_at
 * @property string updated_at
 **/
class AppNotification extends Model
{
    use HasFactory;

    protected $table = "app_notifications";

    protected $guarded = [];

    protected $casts = [
        "attachments" => "json"
    ];

    public function reference()
    {
        return $this->morphTo();
    }

    public function menus()
    {
        return $this->hasMany(AppMenu::class, "code", "menu_code")->where("code", "!=", "");
    }

}
