<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string approval_id
 * @property string approval_group_id
 * @property string order
 * @property string reference_type
 * @property string reference_id
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppFormatApprovalGroupActor extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy;

    protected $table = "app_format_approval_group_actors";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {

        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "approval_id",
                "approval_group_id",
                "order",
                "reference_type",
                "reference_id",
                "operator",
                "created_by",
                "updated_by",
            ]);
    }

    public function attributeName()
    {
        return $this->reference->name;
    }


    public function reference()
    {
        return $this->morphTo("reference");
    }

}
