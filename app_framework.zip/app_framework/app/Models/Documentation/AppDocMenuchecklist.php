<?php

namespace App\Models\Documentation;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string name
 */
class AppDocMenuchecklist extends Model
{
    use HasFactory;

    public static $path_photo = 'documentation/menuchecklist/';

    protected $guarded = [];

}
