<?php

namespace App\Models\Documentation;

use Illuminate\Database\Eloquent\Model;

/**
 * @property string name
 */
class AppDocTeam extends Model
{

    static $path_photo = "documentation/team/";

    protected $guarded = [];

}
