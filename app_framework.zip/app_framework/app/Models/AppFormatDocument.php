<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Carbon\Traits\Timestamp;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property int       id
 * @property string    code
 * @property string    name
 * @property int       paper_id
 * @property int       margin_top
 * @property int       margin_right
 * @property int       margin_bottom
 * @property int       margin_left
 * @property string    content
 * @property int       created_by
 * @property int       updated_by
 * @property Timestamp created_at
 * @property Timestamp updated_at
 * @property Timestamp deleted_at
 **/
class AppFormatDocument extends Model
{
    use HasFactory,
        SoftDeletes,
        LogsActivity,
        UpdateBy;

    protected $table = "app_format_documents";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "code",
                "name",
                "paper_id",
                "margin_top",
                "margin_right",
                "margin_bottom",
                "margin_left",
                "content",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at",
                "deleted_at",
            ]);
    }


    public function paper()
    {
        return $this->hasOne(AppMaster::class, "id", "paper_id");
    }

}
