<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string name
 * @property string description
 * @property string copyright
 * @property string color
 * @property string path_icon
 * @property string path_logo
 * @property string path_background
 * @property string path_image_login_left
 * @property string path_image_login_right
 * @property string path_image_mobile_logo
 * @property string path_image_mobile_login_logo
 * @property string path_image_mobile_login_background
 * @property string created_by
 * @property string created_at
 * @property string updated_by
 * @property string updated_at
 **/
class AppInformation extends Model
{
    use HasFactory,
        LogsActivity;

    const path_image = "info";

    protected $table = "app_informations";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "name",
                "description",
                "copyright",
                "color",
                "path_icon",
                "path_logo",
                "path_background",
                "path_image_login_left",
                "path_image_login_right",
                "path_image_mobile_logo",
                "path_image_mobile_login_logo",
                "path_image_mobile_login_background",
                "created_by",
                "created_at",
                "updated_by",
                "updated_at",
            ]);
    }

    // method

    // icon
    public function uploadIcon(UploadedFile $file)
    {
        tap($this->path_icon, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_icon" => $file->storeAs(self::path_image, "icon.png", ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteIcon()
    {
        tap($this->path_icon, function ($previous) {

            $this
                ->forceFill([
                    "path_icon" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

    // logo
    public function uploadLogo(UploadedFile $file)
    {
        tap($this->path_logo, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_logo" => $file->storeAs(self::path_image, "logo.png", ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteLogo()
    {
        tap($this->path_logo, function ($previous) {

            $this
                ->forceFill([
                    "path_logo" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

    // mobile logo
    public function uploadImageMobileLogo(UploadedFile $file)
    {
        tap($this->path_image_mobile_logo, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_image_mobile_logo" => $file->storeAs(self::path_image, "mobile_logo.png", ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImageMobileLogo()
    {
        tap($this->path_image_mobile_logo, function ($previous) {

            $this
                ->forceFill([
                    "path_image_mobile_logo" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

    // mobile login logo
    public function uploadImageMobileLoginLogo(UploadedFile $file)
    {
        tap($this->path_image_mobile_login_logo, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_image_mobile_login_logo" => $file->storeAs(self::path_image, "mobile_login_logo.png", ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImageMobileLoginLogo()
    {
        tap($this->path_image_mobile_login_logo, function ($previous) {

            $this
                ->forceFill([
                    "path_image_mobile_login_logo" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

    // mobile login background
    public function uploadImageMobileLoginBackground(UploadedFile $file)
    {
        tap($this->path_image_mobile_login_background, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_image_mobile_login_background" => $file->storeAs(self::path_image,"mobile_login_background.png", ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImageMobileLoginBackground()
    {
        tap($this->path_image_mobile_login_background, function ($previous) {

            $this
                ->forceFill([
                    "path_image_mobile_login_background" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

}
