<?php

namespace App\Models;

use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property integer            id
 * @property string             name
 * @property string             description
 * @property integer            status
 * @property AppGroupAccessMenu accessMenus
 **/
class AppGroup extends Model
{
    use HasFactory,
        LogsActivity,
        WithStatus;

    protected $table = "app_groups";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "name",
                "description",
                "status",
            ]);
    }


    public function accessModules()
    {
        return $this->hasMany(AppGroupAccessModule::class, "group_id", "id");
    }

    public function accessMenus()
    {
        return $this->hasMany(AppGroupAccessMenu::class, "group_id", "id");
    }


    public function users()
    {
        return $this->hasMany(AppUser::class, "group_id", "id");
    }

}
