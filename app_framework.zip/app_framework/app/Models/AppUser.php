<?php

namespace App\Models;

use App\Traits\DependUserToOther;
use App\Traits\HasRole;
use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Http\UploadedFile;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Storage;
use Laravel\Passport\HasApiTokens;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Permission\Traits\HasRoles;

/**
 * @property string             id
 * @property string             type
 * @property string             group_id
 * @property string             employee_id
 * @property string             username
 * @property string             password
 * @property string             name
 * @property string             description
 * @property string             phone
 * @property string             email
 * @property string             email_verified_at
 * @property string             path_photo
 * @property string             region_id
 * @property string             region_offset
 * @property string             two_factor_secret
 * @property string             two_factor_recovery_codes
 * @property string             remember_token
 * @property string             status
 * @property string             login_at
 * @property string             created_by
 * @property string             created_at
 * @property string             updated_by
 * @property string             updated_at
 * @property string
 * @property AppGroupAccessMenu accessMenus
 **/
class AppUser extends Authenticatable
{
    use HasFactory,
        HasApiTokens,
        Notifiable,
        LogsActivity,
        HasRoles,
        WithStatus;
    use DependUserToOther;

    const path_image = "_users";

    const TYPE_DEVELOPER = 0;
    const TYPE_USER = 1;

    protected $table = "app_users";

    protected $guarded = [];

    protected $hidden = [
        "password"
    ];

    protected $casts = [
        "email_verified_at" => "datetime",
        "login_at" => "datetime",
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "type",
                "group_id",
                "employee_id",
                "username",
                "password",
                "name",
                "description",
                "phone",
                "email",
                "email_verified_at",
                "path_photo",
                "status",
                "created_by",
                "updated_by",
            ]);
    }


    public function getRoleAttribute()
    {
        return $this->roles()->first();
    }

    public function group()
    {
        return $this->hasOne(AppGroup::class, "id", "group_id");
    }

    public function notifications()
    {
        return $this->hasMany(AppNotification::class, "user_id", "id");
    }

    // method

    public function uploadImage(UploadedFile $file)
    {
        tap($this->path_photo, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_photo" => $file->store(self::path_image, ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImage()
    {
        tap($this->path_photo, function ($previous) {

            $this
                ->forceFill([
                    "path_photo" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

}
