<?php

namespace App\Models\Note;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatatanChangereq extends Model
{
    use HasFactory;

    protected $table = "catatan_changereq";
    // static $path_file = "note/change_request";

    protected $guarded = [];

}
