<?php

namespace App\Models\Note;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatatanSistem extends Model
{
    use HasFactory;

    static $path_file = "note/catatan_sistem";

    protected $guarded = [];

}
