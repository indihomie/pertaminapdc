<?php

namespace App\Models\Note;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocRencana extends Model
{
    use HasFactory;

    static $path_file = "note/rencana";

    protected $guarded = [];

}
