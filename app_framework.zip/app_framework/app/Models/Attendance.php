<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property string id
 * @property string employee_id
 * @property string reference_type
 * @property string reference_id
 * @property string schedule_type
 * @property string schedule_id
 * @property string schedule_start
 * @property string schedule_end
 * @property string start
 * @property string start_location_id
 * @property string start_document_path
 * @property string start_longitude
 * @property string start_latitude
 * @property string start_region_id
 * @property string start_region_offset
 * @property string end
 * @property string end_location_id
 * @property string end_document_path
 * @property string end_longitude
 * @property string end_latitude
 * @property string end_region_id
 * @property string end_region_offset
 * @property string description
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 * @property string deleted_at
 **/
class Attendance extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = "attendances";

    protected $guarded = [];

}
