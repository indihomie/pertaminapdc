<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Carbon\Traits\Timestamp;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;

/**
 * @property int       id
 * @property string    code
 * @property string    category
 * @property string    name
 * @property string    description
 * @property string    menu_code
 * @property int       level
 * @property int       target_application
 * @property int       target_email
 * @property int       target_sms
 * @property string    content_application
 * @property string    content_email
 * @property string    content_sms
 * @property int       created_by
 * @property int       updated_by
 * @property Timestamp created_at
 * @property Timestamp updated_at
 * @property Timestamp deleted_at
 **/
class AppFormatNotification extends Model
{
    use HasFactory,
        SoftDeletes,
        UpdateBy;

    const LEVEL_NORMAL = "normal";
    const LEVEL_IMPORTANT = "important";

    const LEVELS = [
        self::LEVEL_NORMAL => "Normal",
        self::LEVEL_IMPORTANT => "Penting",
    ];

    protected $table = "app_format_notifications";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "code",
                "category",
                "name",
                "description",
                "menu_code",
                "level",
                "target_application",
                "target_email",
                "target_sms",
                "content_application",
                "content_email",
                "content_sms",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at",
                "deleted_at",
            ]);
    }

}
