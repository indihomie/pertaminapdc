<?php

namespace App\Models;

use App\Traits\UpdateBy;
use App\Traits\WithoutTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class AppApprovalCondition extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy,
        WithoutTimestamps;

    protected $table = "app_approval_conditions";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "master_id",
                "step_id",
                "tipe",
                "kondisi",
                "nilai",
                "parameter",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at"
            ]);
    }

    protected static $submitEmptyLogs = false;
    protected static $logOnlyDirty = true;
}
