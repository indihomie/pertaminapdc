<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property string id
 * @property string group_id
 * @property string module_id
 * @property string created_by
 * @property string updated_by
 * @property string deleted_by
 * @property string created_at
 * @property string updated_at
 * @property string deleted_at
 **/
class AppGroupAccessModule extends Model
{
    use HasFactory;

    protected $table = "app_group_access_modules";

    protected $guarded = [];



}
