<?php

namespace App\Models;

use App\Traits\UpdateBy;
use App\Traits\WithoutTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string code
 * @property string name
 * @property string description
 * @property string delimiter
 * @property string parameter_1_type
 * @property string parameter_2_type
 * @property string parameter_3_type
 * @property string parameter_4_type
 * @property string parameter_5_type
 * @property string parameter_1_value
 * @property string parameter_2_value
 * @property string parameter_3_value
 * @property string parameter_4_value
 * @property string parameter_5_value
 * @property string parameter_1_increment
 * @property string parameter_2_increment
 * @property string parameter_3_increment
 * @property string parameter_4_increment
 * @property string parameter_5_increment
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 * @property string deleted_at
 **/
class AppFormatNumber extends Model
{
    use HasFactory,
        SoftDeletes,
        LogsActivity,
        UpdateBy,
        WithoutTimestamps;

    const DELIMITER_SLASH = "/";
    const DELIMITER_PIPE = "|";
    const DELIMITER_DASH = "-";
    const DELIMITER_UNDERSCORE = "_";
    const DELIMITER_EMPTY = "";

    const delimiter = [
        self::DELIMITER_SLASH => "/ Garing",
        self::DELIMITER_PIPE => "| Pipe",
        self::DELIMITER_DASH => "- Strip",
        self::DELIMITER_UNDERSCORE => "_ Underscore",
        self::DELIMITER_EMPTY => "Kosong"
    ];

    const TYPE_YEAR = "year";
    const TYPE_MONTH = "month";
    const TYPE_CODE = "code";
    const TYPE_SEQUENCE = "sequence";
    const TYPE_EMPTY = "";

    const TYPE_YEAR_4 = "year_4";
    const TYPE_YEAR_2 = "year_2";
    const TYPE_YEAR_ROMAN_4 = "roman_4";
    const TYPE_YEAR_ROMAN_2 = "roman_2";

    const TYPE_MONTH_MONTH = "month";
    const TYPE_MONTH_MONTH_2 = "month_2";
    const TYPE_MONTH_MONTH_3 = "month_3";
    const TYPE_MONTH_ROMAN = "roman";

    const type = [
        self::TYPE_YEAR => "Tahun",
        self::TYPE_MONTH => "Bulan",
        self::TYPE_CODE => "Kode",
        self::TYPE_SEQUENCE => "Sequence",
        self::TYPE_EMPTY => "Kosong"
    ];
    const type_year = [
        self::TYPE_YEAR_4 => "4 Digit",
        self::TYPE_YEAR_2 => "2 Digit",
        self::TYPE_YEAR_ROMAN_4 => "Romawi 4",
        self::TYPE_YEAR_ROMAN_2 => "Romawi 2",
    ];
    const type_month = [
        self::TYPE_MONTH_MONTH => "Bulan",
        self::TYPE_MONTH_MONTH_2 => "Angka",
        self::TYPE_MONTH_MONTH_3 => "3 Huruf",
        self::TYPE_MONTH_ROMAN => "Romawi",
    ];

    protected $table = "app_format_numbers";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "code",
                "name",
                "description",
                "delimiter",
                "parameter_1_type",
                "parameter_2_type",
                "parameter_3_type",
                "parameter_4_type",
                "parameter_5_type",
                "parameter_1_value",
                "parameter_2_value",
                "parameter_3_value",
                "parameter_4_value",
                "parameter_5_value",
                "parameter_1_increment",
                "parameter_2_increment",
                "parameter_3_increment",
                "parameter_4_increment",
                "parameter_5_increment",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at",
                "deleted_at",
            ]);
    }

}
