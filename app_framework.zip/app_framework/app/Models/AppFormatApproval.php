<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string code
 * @property string name
 * @property string description
 * @property string dataset
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppFormatApproval extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy;

    protected $table = "app_format_approvals";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "code",
                "name",
                "description",
                "dataset",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at",
            ]);
    }


    public function groups()
    {
        return $this->hasMany(AppFormatApprovalGroup::class, "approval_id", "id");
    }

    public function actors()
    {
        return $this->hasMany(AppFormatApprovalGroupActor::class, "approval_id", "id");
    }

    public function generated()
    {
        return $this->hasMany(AppApproval::class, "master_id");
    }

}
