<?php

namespace App\Models;

use App\Models\Documentation\AppDocMenuchecklist;
use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string category_id
 * @property string name
 * @property string directory
 * @property string path_icon
 * @property string type
 * @property string link
 * @property string order
 * @property string status
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppModule extends Model
{
    use HasFactory,
        LogsActivity,
        WithStatus;

    const TYPE_MODULE = "module";
    const TYPE_LINK = "link";

    const TYPES = [
        self::TYPE_MODULE => "Modul",
        self::TYPE_LINK => "Link",
    ];

    const path_icon = "_/module";

    protected $table = "app_modules";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "category_id",
                "name",
                "directory",
                "path_icon",
                "type",
                "link",
                "order",
                "status",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at"
            ]);
    }


    public function scopeActive($query)
    {
        $query->where("app_modules.status", true);
    }


    public function category()
    {
        return $this->hasOne(AppMaster::class, "id", "category_id");
    }

    public function moduleSubs()
    {
        return $this->hasMany(AppModuleSub::class, "module_id", "id");
    }

    public function menus()
    {
        return $this->hasMany(AppMenu::class, "module_id", "id");
    }


    public function menuchecklist()
    {
        return $this->hasOne(AppDocMenuchecklist::class, "module_id", "id");
    }


    // function

    public function uploadImage(UploadedFile $file)
    {
        tap($this->path_icon, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_icon" => $file->store(self::path_icon, ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImage()
    {
        tap($this->path_icon, function ($previous) {

            $this
                ->forceFill([
                    "path_icon" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

}
