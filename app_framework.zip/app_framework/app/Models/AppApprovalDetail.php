<?php

namespace App\Models;

use App\Traits\UpdateBy;
use App\Traits\WithoutTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class AppApprovalDetail extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy,
        WithoutTimestamps;

    protected $table = "app_approval_details";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "approval_id",
                "urut",
                "parameter",
                "role_type",
                "role_id",
                "level",
                "prev",
                "next",
                "user_id",
                "tanggal",
                "keterangan",
                "status",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at"
            ]);
    }


    public function role()
    {
        return $this->morphTo();
    }

    public function approval()
    {
        return $this->belongsTo(AppApproval::class);
    }

    public function user()
    {
        return $this->hasOne(AppUser::class, 'id', 'user_id');
    }

}
