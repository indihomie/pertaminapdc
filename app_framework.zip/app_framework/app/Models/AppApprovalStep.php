<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string approval_id
 * @property string order
 * @property string operator
 * @property string step_prev
 * @property string step_next
 * @property string status
 * @property string reference_type
 * @property string reference_id
 * @property string approved_at
 * @property string approved_by
 * @property string approved_message
 * @property string created_at
 * @property string updated_at
 **/
class AppApprovalStep extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy;

    const STATUS_APPROVED = 1;
    const STATUS_PENDING = 0;
    const STATUS_REJECTED = -1;

    protected $table = "app_approval_steps";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "approval_id",
                "order",
                "operator",
                "step_prev",
                "step_next",
                "status",
                "reference_type",
                "reference_id",
                "approved_at",
                "approved_by",
                "approved_message",
            ]);
    }

    public function approval()
    {
        return $this->hasOne(AppApproval::class, "id", "approval_id");
    }

}
