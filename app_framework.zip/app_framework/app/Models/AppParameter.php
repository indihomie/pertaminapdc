<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string code
 * @property string name
 * @property string value
 * @property string data
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppParameter extends Model
{
    use HasFactory,
        SoftDeletes,
        LogsActivity,
        UpdateBy;

    protected $table = "app_parameters";

    protected $keyType = "string";

    protected $guarded = [];

    protected $casts = [
        "data" => "json"
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "name",
                "value",
                "data",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at",
                "deleted_at",
            ]);
    }

}
