<?php

namespace App\Models;

use App\Traits\UpdateBy;
use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string datetime
 * @property string name
 * @property string content
 * @property string source
 * @property string path_image
 * @property string status
 * @property string created_at
 * @property string created_by
 * @property string updated_at
 * @property string updated_by
 **/
class AppInformationNews extends Model
{
    use HasFactory,
        SoftDeletes,
        LogsActivity,
        WithStatus,
        UpdateBy;

    const path_image = "_news";

    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;
    const STATUSES = [
        self::STATUS_ACTIVE => "Aktif",
        self::STATUS_INACTIVE => "Tidak Aktif",
    ];

    protected $table = "app_information_news";

    protected $guarded = [];

    protected $casts = [
        "datetime" => "datetime"
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "datetime",
                "name",
                "content",
                "source",
                "path_image",
                "status",
            ]);
    }

    // method

    public function uploadImage(UploadedFile $file)
    {
        tap($this->path_image, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_image" => $file->store(self::path_image, ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImage()
    {
        tap($this->path_image, function ($previous) {

            $this
                ->forceFill([
                    "path_image" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

}
