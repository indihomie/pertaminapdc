<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppExampleSub extends Model
{
    use HasFactory;

    static $status_label = [
        1 => "Aktif",
        0 => "Tidak aktif"
    ];

    protected $table = "app_example_subs";

    protected $guarded = [];

}
