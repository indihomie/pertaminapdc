<?php

namespace App\Models;

use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string category_id
 * @property string module_id
 * @property string menu_id
 * @property string name
 * @property string description
 * @property string data
 * @property string path_icon
 * @property string order
 * @property string status
 * @property string created_by
 * @property string created_at
 * @property string updated_by
 * @property string updated_at
 **/
class AppMasterCategory extends Model
{
    use HasFactory,
        SoftDeletes,
        LogsActivity,
        WithStatus;

    const path_icon = "_/master";

    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;
    const STATUSES = [
        self::STATUS_ACTIVE => "Aktif",
        self::STATUS_INACTIVE => "Tidak Aktif",
    ];

    protected $table = "app_master_categories";

    protected $keyType = "string";

    protected $guarded = [];

    protected $casts = [
        "data" => "json"
    ];

    protected $appends = [
        "icon"
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "category_id",
                "module_id",
                "menu_id",
                "name",
                "description",
                "data",
                "path_icon",
                "order",
                "status",
                "created_by",
                "created_at",
                "updated_by",
                "updated_at",
                "deleted_at",
            ]);
    }


    public function getIconAttribute()
    {
        return getIconExtension($this->path_icon);
    }


    public function module()
    {
        return $this->hasOne(AppModule::class, "id", "module_id");
    }

    public function category()
    {
        return $this->hasOne(AppMasterCategory::class, "id", "category_id");
    }

    public function masters()
    {
        return $this->hasMany(AppMaster::class, "category_id", "id");
    }


    // method

    public function uploadImage(UploadedFile $file)
    {
        tap($this->path_icon, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_icon" => $file->store(self::path_icon, ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImage()
    {
        tap($this->path_icon, function ($previous) {

            $this
                ->forceFill([
                    "path_icon" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

}
