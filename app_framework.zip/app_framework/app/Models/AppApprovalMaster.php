<?php

namespace App\Models;

use App\Traits\UpdateBy;
use App\Traits\WithoutTimestamps;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class AppApprovalMaster extends Model
{
    use HasFactory,
        SoftDeletes,
        LogsActivity,
        UpdateBy,
        WithoutTimestamps;

    protected $table = "app_approval_masters";

    protected $guarded = [];


    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "kode",
                "keterangan",
                "parameter",
                "status",
                "created_by",
                "updated_by",
                "deleted_by",
                "created_at",
                "updated_at",
                "deleted_at",
            ]);
    }

    protected static function boot()
    {
        parent::boot();

        static::addGlobalScope("active", function (Builder $builder) {
            $builder->whereNull("app_approval_masters.deleted_at");
        });

    }

}
