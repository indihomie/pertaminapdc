<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property integer id
 * @property integer employee_id
 * @property string  number
 * @property string  subject
 * @property date    date
 * @property string  agency
 * @property string  year
 * @property integer category_id
 * @property integer type_id
 * @property date    start_date
 * @property date    end_date
 * @property string  location
 * @property string  description
 * @property string  filename
 * @property string  created_by
 * @property string  updated_by
 **/
class EmployeeTraining extends Model
{
    use HasFactory, LogsActivity;

    static $path_image = "hrms/employee/training";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'number',
                'subject',
                'category_id',
                'type_id',
                'date',
                'agency',
                'year',
                'branch',
                'number',
                'start_date',
                'end_date',
                'location',
                'filename',
                'description',
                'created_by',
                'updated_by',
            ]);
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }

    public function category()
    {
        return $this->hasOne(AppMaster::class, "id", "category_id");
    }

    public function type()
    {
        return $this->hasOne(AppMaster::class, "id", "type_id");
    }
}
