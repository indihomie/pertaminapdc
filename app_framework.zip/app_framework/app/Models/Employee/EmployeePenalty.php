<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class EmployeePenalty extends Model
{
    use HasFactory, LogsActivity;

    static $path_image = "hrms/employee/penalty";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'number',
                'subject',
                'type_id',
                'agency',
                'year',
                'start_date',
                'end_date',
                'filename',
                'description',
                'created_by',
                'updated_by',
            ]);
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }

    public function type()
    {
        return $this->hasOne(AppMaster::class, "id", "type_id");
    }
}
