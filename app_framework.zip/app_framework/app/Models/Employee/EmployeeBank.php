<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property integer id
 * @property integer employee_id
 * @property integer bank_id
 * @property string  branch
 * @property string  number
 * @property string  name
 * @property string  description
 * @property string  filename
 * @property string  status
 * @property string  created_by
 * @property string  updated_by
 **/
class EmployeeBank extends Model
{
    use HasFactory, LogsActivity, WithStatus;

    static $path_image = "hrms/employee/bank";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'bank_id',
                'branch',
                'number',
                'name',
                'filename',
                'description',
                'status',
                'created_by',
                'updated_by',
            ]);
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }

    public function bank()
    {
        return $this->hasOne(AppMaster::class, "id", "bank_id");
    }
}
