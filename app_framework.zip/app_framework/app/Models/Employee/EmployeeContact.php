<?php

namespace App\Models\Employee;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property integer id
 * @property integer employee_id
 * @property string  name
 * @property integer relation_id
 * @property string  phone
 * @property string  address
 * @property integer province_id
 * @property integer city_id
 * @property string  fam_name
 * @property integer fam_relation_id
 * @property string  fam_phone
 * @property string  fam_address
 * @property integer fam_province_id
 * @property integer fam_city_id
 * @property string  created_by
 * @property string  updated_by
 **/
class EmployeeContact extends Model
{
    use HasFactory, LogsActivity;

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'name',
                'relation_id',
                'phone',
                'address',
                'province_id',
                'city_id',
                'fam_name',
                'fam_relation_id',
                'fam_phone',
                'fam_address',
                'fam_province_id',
                'fam_city_id',
                'created_by',
                'updated_by',
            ]);
    }

}
