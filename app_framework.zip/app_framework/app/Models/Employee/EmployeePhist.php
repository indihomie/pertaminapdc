<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use App\Traits\Attendance\EmployeePhistToAttendance;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property integer id
 * @property integer employee_id
 * @property integer position_id
 * @property string  sk_number
 * @property string  sk_subject
 * @property date    sk_date
 * @property integer directorate_id
 * @property integer division_id
 * @property integer department_id
 * @property integer unit_id
 * @property integer location_id
 * @property integer rank_id
 * @property integer grade_id
 * @property date    start_date
 * @property date    end_date
 * @property string  description
 * @property string  status
 * @property integer leader_id
 * @property integer administration_id
 * @property integer replacement_id
 * @property string  overtime
 * @property integer payroll_id
 * @property integer process_id
 * @property integer group_id
 * @property integer shift_id
 * @property string  created_by
 * @property string  updated_by
 **/
class EmployeePhist extends Model
{
    use HasFactory,
        LogsActivity,
        EmployeePhistToAttendance;

    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "employee_id",
                "position_id",
                "sk_number",
                "sk_subject",
                "sk_date",
                "directorate_id",
                "division_id",
                "department_id",
                "unit_id",
                "location_id",
                "rank_id",
                "grade_id",
                "start_date",
                "end_date",
                "description",
                "status",
                "leader_id",
                "administration_id",
                "replacement_id",
                "overtime",
                "payroll_id",
                "process_id",
                "shift_id",
                "created_by",
                "updated_by",
            ]);
    }

    public function scopeActive($query)
    {
        return $query->where("status", 1);
    }

    public function rank()
    {
        return $this->hasOne(AppMaster::class, "id", "rank_id");
    }

    public function position()
    {
        return $this->hasOne(AppMaster::class, "id", "position_id");
    }

}
