<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class EmployeeEducation extends Model
{
    use HasFactory, LogsActivity;

    static $path_image = "hrms/employee/education";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'type_id',
                'name',
                'date',
                'year',
                'city_id',
                'graduate_year',
                'faculty_id',
                'department_id',
                'essay',
                'filename',
                'description',
                'created_by',
                'updated_by',
            ]);
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }

    public function type()
    {
        return $this->hasOne(AppMaster::class, "id", "type_id");
    }

    public function city()
    {
        return $this->hasOne(AppMaster::class, "id", "city_id");
    }

    public function faculty()
    {
        return $this->hasOne(AppMaster::class, "id", "faculty_id");
    }

    public function department()
    {
        return $this->hasOne(AppMaster::class, "id", "department_id");
    }
}
