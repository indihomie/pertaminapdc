<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property integer id
 * @property integer employee_id
 * @property string  name
 * @property integer relation_id
 * @property string  gender
 * @property integer birth_place_id
 * @property date    birth_date
 * @property string  filename
 * @property string  description
 * @property string  created_by
 * @property string  updated_by
 **/
class EmployeeFamily extends Model
{
    use HasFactory, LogsActivity;

    protected $guarded = [];

    static $path_image = "hrms/employee/family";

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'name',
                'relation_id',
                'gender',
                'birth_place_id',
                'birth_date',
                'filename',
                'description',
                'created_by',
                'updated_by',
            ]);
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }

    public function relation()
    {
        return $this->hasOne(AppMaster::class, "id", "relation_id");
    }

}
