<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class EmployeeAsset extends Model
{
    use HasFactory, LogsActivity, WithStatus;

    static $path_image = "hrms/employee/asset";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'name',
                'number',
                'usage',
                'date',
                'category_id',
                'type_id',
                'start_date',
                'end_date',
                'filename',
                'description',
                'status',
                'created_by',
                'updated_by',
            ]);
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }

    public function category()
    {
        return $this->hasOne(AppMaster::class, "id", "category_id");
    }

    public function type()
    {
        return $this->hasOne(AppMaster::class, "id", "type_id");
    }

}
