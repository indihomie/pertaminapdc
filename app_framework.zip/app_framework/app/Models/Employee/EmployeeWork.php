<?php

namespace App\Models\Employee;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class EmployeeWork extends Model
{
    use HasFactory, LogsActivity;

    static $path_image = "hrms/employee/work";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'employee_id',
                'company',
                'position',
                'start_date',
                'end_date   ',
                'division',
                'department',
                'location',
                'job_desc',
                'filename',
                'description',
                'created_by',
                'updated_by',
            ]);
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, "id", "employee_id");
    }
}
