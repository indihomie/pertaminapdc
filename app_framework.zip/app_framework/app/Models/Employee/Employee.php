<?php

namespace App\Models\Employee;

use App\Models\AppMaster;
use App\Models\AppParameter;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property integer id
 * @property integer category_id
 * @property string  name
 * @property string  nickname
 * @property string  number
 * @property integer birth_place_id
 * @property date    birth_date
 * @property string  identity_number
 * @property string  family_card_number
 * @property string  identity_file
 * @property string  gender
 * @property string  identity_address
 * @property integer identity_province_id
 * @property integer identity_city_id
 * @property string  address
 * @property integer province_id
 * @property integer city_id
 * @property string  phone_number
 * @property string  cell_number
 * @property string  email
 * @property integer marital_id
 * @property integer ptkp_id
 * @property integer religion_id
 * @property string  photo
 * @property string  npwp_number
 * @property string  npwp_date
 * @property string  bpjs_tk_number
 * @property date    bpjs_tk_date
 * @property string  bpjs_ks_number
 * @property date    bpjs_ks_date
 * @property integer blood_type_id
 * @property string  blood_rhesus
 * @property string  uni_cloth
 * @property integer uni_pant
 * @property integer uni_shoe
 * @property integer status_id
 * @property date    join_date
 * @property date    leave_date
 * @property integer nation_id
 * @property string  created_by
 * @property string  updated_by
 **/
class Employee extends Model
{
    use HasFactory, LogsActivity;

    protected $guarded = [];


    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                'type',
                'group_id',
                'employee_id',
                'username',
                'password',
                'name',
                'description',
                'phone',
                'email',
                'email_verified_at',
                'path_photo',
                'status',
                'created_by',
                'updated_by',
            ]);
    }

    public function scopeActive($query)
    {
        $query->where('status_id', AppParameter::where('code', 'ESA')->value('value'));

        return $query;
    }

    public function category()
    {
        return $this->hasOne(AppMaster::class, "id", "category_id");
    }

    public function phist()
    {
        return $this->hasOne(EmployeePhist::class, "employee_id", "id")->where('status', 1);
    }

    public function contact()
    {
        return $this->hasOne(EmployeeContact::class, "employee_id", "id");
    }
}
