<?php

namespace App\Models;

use App\Traits\UpdateBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string module_sub_id
 * @property string name
 * @property string description
 * @property string path_document
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppManualBook extends Model
{
    use HasFactory,
        LogsActivity,
        UpdateBy;

    const path_document = "_manual";

    protected $table = "app_manual_books";

    protected $guarded = [];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "name",
                "description",
                "path_document",
                "created_by",
                "updated_by",
                "created_at",
                "updated_at",
            ]);
    }

    // method

    public function uploadDocument(UploadedFile $file)
    {
        tap($this->path_document, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_document" => $file->store(self::path_document, ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteDocument()
    {
        tap($this->path_document, function ($previous) {

            $this
                ->forceFill([
                    "path_document" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

}
