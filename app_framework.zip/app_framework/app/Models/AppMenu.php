<?php

namespace App\Models;

use App\Traits\WithStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property string id
 * @property string module_id
 * @property string module_sub_id
 * @property string menu_id
 * @property string level
 * @property string name
 * @property string target
 * @property string parameter
 * @property string access
 * @property string permissions
 * @property string path_icon
 * @property string file
 * @property string toolbar_side
 * @property string order
 * @property string status
 * @property string description
 * @property string path_fsd
 * @property string description_fsd
 * @property string created_by
 * @property string updated_by
 * @property string created_at
 * @property string updated_at
 **/
class AppMenu extends Model
{
    use HasFactory,
        LogsActivity,
        WithStatus;

    const path_icon = "_/menu";

    const MENU_SIDE_SHOW = 1;
    const MENU_SIDE_SMALL = 0;
    const MENU_SIDE_HIDE = -1;
    const MENU_SIDES = [
        self::MENU_SIDE_SHOW => "Tampil",
        self::MENU_SIDE_SMALL => "Kecil",
        self::MENU_SIDE_HIDE => "Sembunyikan"
    ];

    const MENU_TARGET_MENU = 0;
    const MENU_TARGET_DROPDOWN = 1;
    const MENU_TARGET_MASTER = 2;
    const MENU_TARGET_LINK = 3;
    const MENU_TARGETS = [
        self::MENU_TARGET_MENU => "Menu",
        self::MENU_TARGET_DROPDOWN => "Dropdown",
        self::MENU_TARGET_MASTER => "Master",
        self::MENU_TARGET_LINK => "Link",
    ];

    public static $path_icon = "_/menu";
    public static $path_manual = "_manual";
    public static $path_fsd = "_fsd";

    protected $table = "app_menus";

    protected $guarded = [];

    protected $appends = [
        "status_label",
        "status_image"
    ];

    protected $casts = [
        "permissions" => "json",
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->dontSubmitEmptyLogs()
            ->logOnlyDirty()
            ->logOnly([
                "id",
                "module_id",
                "module_sub_id",
                "menu_id",
                "level",
                "name",
                "name",
                "target",
                "parameter",
                "access",
                "path_icon",
                "file",
                "toolbar_side",
                "order",
                "status",
                "description",
                "path_fsd",
                "description_fsd",
                "created_by",
                "updated_by",
            ]);
    }


    public function module()
    {
        return $this->hasOne(AppModule::class, "id", "module_id");
    }

    public function moduleSub()
    {
        return $this->hasOne(AppModuleSub::class, "id", "module_sub_id");
    }

    public function menuParent()
    {
        return $this->hasOne(AppMenu::class, "id", "menu_id");
    }

    public function menuSubs()
    {
        return $this->hasMany(AppMenu::class, "menu_id", "id");
    }


    public function master()
    {
        return $this->hasOne(AppMasterCategory::class, "id", "target");
    }


    // method

    public function uploadImage(UploadedFile $file)
    {
        tap($this->path_icon, function ($previous) use ($file) {

            $this
                ->forceFill([
                    "path_icon" => $file->store(self::path_icon, ["disk" => "public"]),
                ])
                ->save();

            if ($previous) {
                Storage::disk("public")->delete($previous);
            }

        });
    }

    public function deleteImage()
    {
        tap($this->path_icon, function ($previous) {

            $this
                ->forceFill([
                    "path_icon" => "",
                ])
                ->save();

            Storage::disk("public")->delete($previous);
        });
    }

}
