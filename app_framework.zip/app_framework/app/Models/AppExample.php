<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppExample extends Model
{
    use HasFactory;

    protected $table = "app_examples";

    protected $guarded = [];

    public function subs()
    {
        return $this->hasMany(AppExampleSub::class, "app_example_id", "id");
    }

}
