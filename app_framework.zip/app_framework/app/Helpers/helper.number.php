<?php

function setAngka($nilai)
{
    $nilai = '' == $nilai ? '0' : $nilai;
    $hasil = '.' == substr($nilai, 0, 1) ? '0' . $nilai : $nilai;

    return str_replace(',', '', $hasil);
}

function getAngka($nilai = 0, $digit = 0)
{
    return number_format($nilai, $digit);
}

function ceilAngka($number, $significance = 1)
{
    return (is_numeric($number) && is_numeric($significance)) ? (ceil($number / $significance) * $significance) : false;
}

function getRomawi($val)
{
    $arr = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
    $value = intval($val);

    return $arr[$value];
}

function terbilang($x)
{
    $t = explode('.', $x);

    return $t[1] > 0 ? numToString($t[0]) . ' Koma' . numToString($t[1]) : numToString($t[0]);
}

function numToString($x)
{
    $abil = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Delapan', 'Sembilan', 'Sepuluh', 'Sebelas'];
    if ($x < 12) {
        return ' ' . $abil[$x];
    }
    if ($x < 20) {
        return numToString($x - 10) . ' Belas';
    }
    if ($x < 100) {
        return numToString($x / 10) . ' Puluh' . numToString($x % 10);
    }
    if ($x < 200) {
        return ' Seratus' . numToString($x - 100);
    }
    if ($x < 1000) {
        return numToString($x / 100) . ' Ratus' . numToString($x % 100);
    }
    if ($x < 2000) {
        return ' Seribu' . numToString($x - 1000);
    }
    if ($x < 1000000) {
        return numToString($x / 1000) . ' Ribu' . numToString($x % 1000);
    }
    if ($x < 1000000000) {
        return numToString($x / 1000000) . ' Juta' . numToString($x % 1000000);
    }
}
