<?php

function datatable($cols = 0, $nosort = [], $mode = "datas", $tabel = "table", $manual = false, $paging = true, $scroll = "", $footers = [])
{
    global $par, $page;

    ?>
    <script type="text/javascript">

        jQuery(document).ready(function () {

            let <?= "{$tabel}" ?> = jQuery('#<?= $tabel ?>').dataTable({
                'bProcessing': true,
                'bServerSide': true,
                'bFilter': false,
                'sPaginationType': 'full_numbers',
                'aLengthMenu': [[10, 25, 50, 100, 250], [10, 25, 50, 100, 250]],

                <?php if (!$paging) : ?>
                'bPaginate': false,
                'bInfo': false,
                <?php endif; ?>

                <?php if ($scroll == "hv") : ?>
                'sScrollY': '225px',
                'sScrollX': '100%',
                <?php endif; ?>

                <?php if ($scroll == "h") : ?>
                'sScrollX': '100%',
                <?php endif; ?>

                <?php if ($scroll == "v") : ?>
                'sScrollY': '300px',
                <?php endif; ?>

                <?php if ($cols) : ?>
                'aoColumns': [
                    <?php for ($i = 1; $i <= $cols; $i++) : ?>
                    <?php if (in_array($i, $nosort) || $i == 1) : ?>
                    {'bSortable': false},
                    <?php else : ?>
                    null,
                    <?php endif; ?>
                    <?php endfor; ?>
                ],
                <?php else : ?>
                'bSort': false,
                <?php endif; ?>

                'sDom': 'frtlip',
                'oLanguage': {
                    'sInfo': 'showing <span>_START_</span> to <span>_END_</span> of <span>_TOTAL_</span> entries',
                    'sInfoFiltered': '<span></span>',
                    'sProcessing': '<img src="assets/images/loader.gif" style="width: 50px; height: 50px; z-index: 1; position: absolute; left: 50%; top: 50px;"/>',
                },
                'sAjaxSource': 'void?<?= $page ? "page={$page}" : "" ?><?= getPar($par, "mode") ?>&par[mode]=<?= $mode ?>',
                'fnServerData': function (source, data, callback) {

                    data.push({'name': 'search', 'value': jQuery('#search').val() ?? ''})
                    data.push({'name': 'keyup_1', 'value': jQuery('#keyup_1').val() ?? ''})
                    data.push({'name': 'keyup_2', 'value': jQuery('#keyup_2').val() ?? ''})
                    data.push({'name': 'change_1', 'value': jQuery('#change_1').val() ?? ''})
                    data.push({'name': 'change_2', 'value': jQuery('#change_2').val() ?? ''})
                    data.push({'name': 'change_3', 'value': jQuery('#change_3').val() ?? ''})
                    data.push({'name': 'change_4', 'value': jQuery('#change_4').val() ?? ''})
                    data.push({'name': 'click_1', 'value': jQuery('#click_1').val() ?? ''})

                    jQuery.get(source, data, function (response) {

                        try {

                            let json = JSON.parse(response)

                            <?php foreach ($footers as $id => $object) : ?>
                            jQuery('#<?= $id ?>').html(json.<?= $object ?>)
                            <?php endforeach; ?>

                            callback(json)

                        } catch {
                            alert("Data gagal dimuat")
                            callback({
                                iTotalRecords: 0,
                                iTotalDisplayRecords: 0,
                                aaData: []
                            })
                        }

                    })
                },
                'fnDrawCallback': function () {
                    refreshFsLightbox()
                }
            })

            jQuery('#search')
                .attr("placeholder", "Cari...")
                .attr("style", "background: url('assets/images/filter.png') no-repeat; width: 200px; padding-left: 30px;")

            <?php if (!$manual): ?>
            jQuery('#search').keyup(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })

            jQuery('#keyup_1').change(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })

            jQuery('#keyup_2').change(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })

            jQuery('#change_1').change(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })

            jQuery('#change_2').change(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })

            jQuery('#change_3').change(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })

            jQuery('#change_5').change(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })

            jQuery('#click_1').change(function () {
                <?= "{$tabel}" ?>.fnReloadAjax()
            })
            <?php endif; ?>

        })

    </script>
    <?php
}
