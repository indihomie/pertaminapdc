<?php

use Illuminate\Support\Carbon;

function carbon($datetime): Carbon
{
    return $datetime ? Carbon::create($datetime) : Carbon::now();
}

function dateConvert($date): string
{

    if (str_contains($date, "/")) {

        list($date, $month, $year) = explode("/", $date);

        return "{$year}-{$month}-{$date}";
    }

    if (str_contains($date, "-")) {

        list($year, $month, $date) = explode("-", $date);

        return "{$date}/{$month}/{$year}";
    }

    return "";
}

function setTanggal($tanggal)
{
    $arr = explode('/', $tanggal);

    return $arr[2] . '-' . $arr[1] . '-' . $arr[0];
}

function getTanggal($tanggal, $format = '')
{
    $arr = explode('-', $tanggal);
    if ('' == $format) {
        $hasil = ('' == $tanggal or '0000-00-00' == $tanggal) ? '' : $arr[2] . '/' . $arr[1] . '/' . $arr[0];
    } else {
        $hasil = ('' == $tanggal or '0000-00-00' == $tanggal) ? '' : "{$arr[2]} " . getBulan($arr[1]) . " {$arr[0]}";
    }

    return $hasil;
}

function getBulan($bulan, $str = '')
{
    $arr = [
        '1' => 'Januari', '2' => 'Februari', '3' => 'Maret', '4' => 'April', '5' => 'Mei', '6' => 'Juni', '7' => 'Juli',
        '8' => 'Agustus', '9' => 'September', '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', '05' => 'Mei', '06' => 'Juni', '07' => 'Juli',
        '08' => 'Agustus', '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember',
    ];
    $sub = [
        '1' => 'Jan', '2' => 'Feb', '3' => 'Mar', '4' => 'Apr', '5' => 'May', '6' => 'Jun', '7' => 'Jul',
        '8' => 'Aug', '9' => 'Sep', '01' => 'Jan', '02' => 'Feb', '03' => 'Mar', '04' => 'Apr', '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Aug', '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec',
    ];

    return $str ? $sub["{$bulan}"] : $arr["{$bulan}"];
}
