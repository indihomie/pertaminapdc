<?php

function openView($path_file)
{

    if (!$path_file) {
        return "";
    }

    $array = explode(".", $path_file);
    $extension = strtolower(end($array));

    if (in_array($extension, ["png", "jpg", "jpeg", "gif", "ico"])) {

        $component = "<a href='storage/{$path_file}' data-fslightbox='gallery'>";
        $component .= getIconExtension($path_file);
        $component .= "</a>";

        return $component;
    }

    if (in_array($extension, ["pdf", "doc", "docx", "xls", "xlsx"])) {

        $encrypted = encrypt($path_file);

        $component = "<a href='#' onclick='openBox(`view/{$encrypted}`, 1000, 520)'>";
        $component .= getIconExtension($path_file);
        $component .= "</a>";

        return $component;
    }

    return "?";
}

function getIconExtension($filename): string
{

    if (!$filename)
        return "<img src='assets/images/extensions/file.png'>";

    $extension = explode(".", $filename);
    $icon = end($extension);

    if (count($extension) == 0 || strlen($icon) > 4)
        $icon = "file";

    return "<img src='assets/images/extensions/{$icon}.png'>";
}

function selectArray($name, $title, $datas, $index, $column, $select, $all = "", $java = "", $width = "200px;", $class = "")
{

    $style = $width ? "width: $width;" : "";

    $html = "<select id='$name' class='chosen-select $class' name='$name' title='$title' style='$style' $java>";

    $html .= !empty($all) ? "<option value=''>$all</option>" : "";

    foreach ($datas as $key => $data) {

        $key = $index ? $data[$index] : $key;
        $value = $column ? $data[$column] : $data;

        $selected = $key == $select ? "selected" : "";

        $html .= "<option value='$key' $selected>$value</option>";
    }

    $html .= "</select>";

    return $html;
}

function selectYear($name, $title, $select, $all = "", $range = "", $start = "", $end = "", $class = "", $width = "", $java = "")
{

    $range = $range ?: 5;

    $style = $width ? "width: $width;" : "";
    $html = "<select id='$name' class='$class' name='$name' title='$title' style='$style' $java>";

    $start = $start ?: ($select ? $select - $range : date('Y') - $range);
    $end = $end ?: ($select ? $select + $range : date('Y') + $range);

    $html .= $all != "" ? "<option value=''>$all</option>" : "";

    for ($year = $start; $year <= $end; $year++) {

        $selected = $year == $select ? "selected" : "";

        $html .= "<option value='$year' $selected>$year</option>";

    }

    $html .= "</select>";

    return $html;
}

function selectMonth($name, $title, $select, $all = "", $class = "", $width = "", $java = "")
{

    $style = $width ? "width: $width;" : "";
    $html = "<select id='$name' class='$class' name='$name' title='$title' style='$style' $java>";

    $html .= $all != "" ? "<option value=''>$all</option>" : "";

    for ($month = 0; $month <= 12; $month++) {

        $selected = $month == $select ? "selected" : "";

        $html .= "<option value='$month' $selected>" . getBulan($month) . "</option>";
    }

    $html .= "</select>";

    return $html;
}

function setValidation($param, $nm_obj, $message = '', $rg_awal = '0', $rg_akhir = '0')
{
    global $rule;

    switch ($param) {
        case 'is_null':
            $rule .= "t10_checkisi(document.getElementById('{$nm_obj}'),\"{$message}\");\n";

            break;

        case 'is_mail':
            $rule .= "t10_checkmail(document.getElementById('{$nm_obj}'),\"{$message}\");\n";

            break;

        case 'is_date':
            $rule .= "t10_checkvaliddate(document.getElementById('{$nm_obj[0]}'),document.getElementById('{$nm_obj[1]}'),document.getElementById('{$nm_obj[2]}'));\n";

            break;

        case 'is_num':
            $rule .= "t10_checknum(document.getElementById('{$nm_obj}'),\"{$message}\");\n";

            break;

        case 'is_range':
            $rule .= "t10_checkrange(document.getElementById('{$nm_obj}'),\"{$message}\",{$rg_awal},{$rg_akhir});\n";

            break;
    }
}

function getValidation()
{
    global $rule;

    $text = '
    <script type="javascript" src="assets/js/validation.js"></script>
    <script>
        let valid;
        function validation(var_nama_form) {

            let nm_form = var_nama_form;

            valid = true;

            ' . $rule . '

        return valid;
    }
    </script>';

    return $text;
}
