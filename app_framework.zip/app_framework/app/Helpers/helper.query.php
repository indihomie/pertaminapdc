<?php

function ddSql(&$query)
{
    $addSlashes = str_replace('?', "'?'", $query->toSql());
    dd(vsprintf(str_replace('?', '%s', $addSlashes), $query->getBindings()));
}

function getField($sql)
{
    return reset(DB::select($sql)[0]);
}

function getLastId($table, $key)
{
    return getField("select $key from $table order by $key desc limit 1") + 1;
}

function getRow($sql)
{

    $res = db($sql);
    return $res ? mysql_fetch_assoc($res) : false;
}

function getRows($sql, $key = "")
{

    $res = db($sql);
    $index = -1;
    $result = [];

    while ($row = mysql_fetch_assoc($res)) {
        $index++;
        $result[!empty($key) ? $row[$key] : $index] = $row;
    }

    return $result;
}
