<?php

function getPar($par, $remove = '')
{
    global $c, $p, $m, $s, $_p, $_l;

    $var = '';

    if (strlen($c)) {
        $var .= "&c={$c}";
    }

    if (strlen($p)) {
        $var .= "&p={$p}";
    }

    if (strlen($m)) {
        $var .= "&m={$m}";
    }

    if (strlen($s)) {
        $var .= "&s={$s}";
    }

    if (strlen($_p)) {
        $var .= "&_p={$_p}";
    }

    if (strlen($_l)) {
        $var .= "&_l={$_l}";
    }

    if (is_array($par)) {

        $remove = explode(",", str_replace(" ", "", $remove));

        foreach ($par as $key => $value) {

            if (in_array($key, $remove)) continue;

            $var .= "&par[$key]=$value";
        }

    }

    return $var;
}
