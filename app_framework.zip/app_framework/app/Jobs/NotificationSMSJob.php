<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;

class NotificationSMSJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $user_phone;
    public string $category;
    public string $title;
    public string $content;
    public string $path_image;
    public array $attachments;
    public string $menu;
    public string $reference_type;
    public int $reference_id;

    public function __construct($user_phone, $category, $title, $content, $path_image, $attachments, $menu, $reference_type, $reference_id)
    {
        $this->user_phone = $user_phone;
        $this->category = $category;
        $this->title = $title;
        $this->content = $content;
        $this->path_image = $path_image;
        $this->attachments = $attachments;
        $this->menu = $menu;
        $this->reference_type = $reference_type;
        $this->reference_id = $reference_id;
    }

    public function handle()
    {
        $host = config("environment.SMS_HOST");
        $username = config("environment.SMS_USERNAME");
        $password = config("environment.SMS_PASSWORD");

        $phone = $this->user_phone;

        $title = $this->title;
        $content = $this->content;

        $response = Http::post("{$host}/reguler/api/sendsms/", [
            "userkey" => $username,
            "passkey" => $password,
            "to" => $phone,
            "message" => "{$title}\n{$content}"
        ]);

        dd($response->body());

    }
}
