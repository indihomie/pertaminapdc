<?php

namespace App\Jobs;

use App\Mail\TemplateMail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class NotificationEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public string $user_email;
    public string $category;
    public string $title;
    public string $content;
    public string $path_image;
    public array $attachments;
    public string $menu;
    public string $reference_type;
    public int $reference_id;

    public function __construct($user_email, $category, $title, $content, $path_image, $attachments, $menu, $reference_type, $reference_id)
    {
        $this->user_email = $user_email;
        $this->category = $category;
        $this->title = $title;
        $this->content = $content;
        $this->path_image = $path_image;
        $this->attachments = $attachments;
        $this->menu = $menu;
        $this->reference_type = $reference_type;
        $this->reference_id = $reference_id;
    }

    public function handle()
    {
        $email = $this->user_email;
        $title = $this->title;
        $content = $this->content;
        $path_image = $this->path_image;
        $attachments = $this->attachments;

        Mail::to($email)
            ->send(new TemplateMail($title, $content, $path_image, $attachments));

    }
}
