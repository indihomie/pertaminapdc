<?php

namespace App\Jobs;

use App\Models\AppNotification;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class NotificationApplicationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $user_id;
    public string $category;
    public string $title;
    public string $content;
    public string $path_image;
    public array $attachments;
    public string $menu;
    public string $reference_type;
    public int $reference_id;

    public function __construct($user_id, $category, $title, $content, $path_image, $attachments, $menu, $reference_type, $reference_id)
    {
        $this->user_id = $user_id;
        $this->category = $category;
        $this->title = $title;
        $this->content = $content;
        $this->path_image = $path_image;
        $this->attachments = $attachments;
        $this->menu = $menu;
        $this->reference_type = $reference_type;
        $this->reference_id = $reference_id;
    }

    public function handle()
    {
        AppNotification::create([
            "user_id" => $this->user_id,
            "category" => $this->category,
            "title" => $this->title,
            "content" => $this->content,
            "path_image" => $this->path_image,
            "attachments" => $this->attachments,
            "menu_code" => $this->menu,
            "reference_type" => $this->reference_type,
            "reference_id" => $this->reference_id,
        ]);
    }

}
