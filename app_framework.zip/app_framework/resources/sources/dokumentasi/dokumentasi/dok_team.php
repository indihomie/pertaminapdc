<?php

use App\Models\Documentation\AppDocTeam;
use App\View\Components\Form;
use App\View\Components\Layout;

function getContent($par)
{
    global $_submit, $access;

    switch ($par['mode']) {
        case 'datas':
            echo lData();

        break;

        case 'delete':
            if ($access['delete']) {
                destroy();
            } else {
                echo 'Tidak ada akses';
            }

            break;

        case 'add':
            if ($access['add']) {
                $_submit ? store() : form();
            } else {
                echo 'Tidak ada akses';
            }

        break;

        case 'edit':
            if ($access['edit']) {
                $_submit ? update() : form();
            } else {
                echo 'Tidak ada akses';
            }

        break;

        default:
            index();

        break;
    }
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {
        $delete = AppDocTeam::find($par['id']);

        $storage = Storage::disk('storages');

        if ($storage->exists($delete->path_photo)) {
            $storage->delete($delete->path_photo);
        }

        $delete->delete();

        DB::commit();

        echo "<script>alert('Data berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal dihapus')</script>";
    }

    echo '<script>closeBox()</script>';
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {
        $update = AppDocTeam::find($par['id']);

        $update->update([
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
            'division' => $request->division,
            'position' => $request->position,
            'description' => $request->description,
            'updated_by' => $user->id,
        ]);

        if ($request->file('photo') || $request->photo_status) {
            $storage = Storage::disk('storages');

            if ($storage->exists($update->path_photo)) {
                $storage->delete($update->path_photo);
            }

            $update->update([
                'path_photo' => '',
            ]);
        }

        if ($request->file('photo')) {
            $update->update([
                'path_photo' => $request->file('photo')->store(AppDocTeam::$path_photo, ['disk' => 'storages']),
            ]);
        }

        DB::commit();

        echo "<script>alert('Data berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal diubah')</script>";
    }

    echo '<script>closeBox()</script>';
}

function store()
{
    global $user, $request;

    DB::beginTransaction();

    try {
        AppDocTeam::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'email' => $request->email,
            'division' => $request->division,
            'position' => $request->position,
            'path_photo' => $request->file('photo') ? $request->file('photo')->store(AppDocTeam::$path_photo, ['disk' => 'storages']) : '',
            'description' => $request['description'],
            'created_by' => $user->id,
            'updated_by' => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Data berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal disimpan')</script>";
    }

    echo '<script>closeBox()</script>';
}

function index()
{
    global $par, $access;

    datatable(7, ['2', '7']);
    Layout::title(); ?>

<div id="contentwrapper" class="contentwrapper">
    <form method="post" id="form" class="stdform" onsubmit="return false;">
        <div class="filter_container">
            <div class="filter_left">
                <p>
                    <input type="text" id="search" name="search" />
                </p>
            </div>
            <div class="filter_right">
                <?php if (isset($access['add'])) { ?>
                <a href="#Add" class="stdbtn"
                    onclick="openBox('popup.php?par[mode]=add<?php echo getPar($par, 'mode, id'); ?> ', 725, 400);"><i
                        class="fa fa-plus"></i>&emsp;TAMBAH</a>
                <?php } ?>
                &nbsp;
                <a href="?par[mode]=xls<?php echo getPar($par, 'mode'); ?>" class="stdbtn"><i
                        class="fas fa-file-export"></i></i>&emsp;EXPORT</a>
            </div>
        </div>
    </form>
    <table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="table">
        <thead>
            <tr>
                <th width="20">No.</th>
                <th width="80">Foto</th>
                <th width="*">Nama</th>
                <th width="100">No. HP</th>
                <th width="150">Bagian</th>
                <th width="150">Jabatan</th>
                <th width="50">Kontrol</th>
        </thead>
        <tbody></tbody>
    </table>
</div>
<?php
}

function lData()
{
    global $par, $access;

    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $arr_order = [
        'name',
        '',
        'name',
        'phone',
        'division',
        'position',
        '',
    ];

    $q_order = $arr_order[$iSortCol_0];
    $q_sort = $iSortCol_0 > 0 ? $sSortDir_0 : 'desc';

    $q_filter = '1 = 1';
    $q_filter .= $search ? " AND (name LIKE '%{$search}%' OR phone LIKE '%{$search}%' OR division LIKE '%{$search}%' OR position LIKE '%{$search}%')" : '';

    $teams = AppDocTeam::whereRaw($q_filter);

    $count = $teams->count();

    $teams = $teams->orderBy($q_order, $q_sort);

    if ($iDisplayLength > 0) {
        $teams->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $teams = $teams->get();
    $json = [
        'iTotalRecords' => $teams->count(),
        'iTotalDisplayRecords' => $count,
        'aaData' => [],
    ];

    $no = intval($iDisplayStart);
    foreach ($teams as $team) {
        ++$no;

        $photo = "<a href = \"#\" onclick=\"openBox('view.php?doc=fotoTeam&par[id]={$team['id']}".getPar($par, 'mode, id')."', 725, 500);\"><img src= \"".$team['path_file'].'" height="50"></a>';

        $control = '';
        if (isset($access['edit'])) {
            $control .= "<a onclick=\"openBox('popup?par[mode]=edit&par[id]={$team['id']}".getPar($par, 'mode, id')."', 825, 500);\"  href=\"#\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";

            $control .= "<a href=\"?par[mode]=del&par[id]={$team['id']}".getPar($par, 'mode, id')."\" onclick=\"return confirm('are you sure to delete data ?');\" title=\"Delete Data\" class=\"delete\"><span>Delete</span></a>";
        }

        $data = [
            '<div align="center">'.$no.'.</div>',
            '<div align="center">'.$photo.'</div>',
            "<div align=\"left\">{$team['name']}</div>",
            "<div align=\"center\">{$team['phone']}</div>",
            "<div align=\"left\">{$team['division']}</div>",
            "<div align=\"left\">{$team['position']}</div>",
            "<div align=\"center\">{$control}</div>",
        ];

        $json['aaData'][] = $data;
    }

    return json_encode($json);
}

function form()
{
    global $par;

    $doc_team = AppDocTeam::find($par['id']);

    setValidation('is_null', 'inp[name]', 'you must fill name');
    setValidation('is_null', 'inp[phone]', 'you must fill phone');
    setValidation('is_null', 'inp[email]', 'you must fill email');
    setValidation('is_null', 'inp[division]', 'you must fill division');
    setValidation('is_null', 'inp[position]', 'you must fill position');
    echo getValidation(); ?>
<div class="centercontent contentpopup">
    <?php
        Layout::title(true); ?>
    <div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?php echo getPar($par); ?>"
            onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
            autocomplete="off">
            <?php echo Layout::formBtnSubmit('true'); ?>
            <?php echo Form::CSRF(); ?>
            <fieldset>
                <?php

    Form::inputLabelText('Nama', 'name', $doc_team['name'], 't');
    Form::inputLabelText('No. HP', 'phone', $doc_team['phone'], 't');
    Form::inputLabelText('Email', 'email', $doc_team['email'], 't');
    Form::inputLabelText('Bagian', 'division', $doc_team['division'], 't');
    Form::inputLabelText('Jabatan', 'position', $doc_team['position'], 't');
    Form::inputLabelDocument('Foto', 'photo', $doc_team['path_photo'], false, 'l-input-small', '*');
    Form::inputLabelTextArea('Keterangan', 'description', $doc_team['description']); ?>
            </fieldset>
        </form>
    </div>
</div>
<?php
}

function xls()
{
    global $db,$par,$arrTitle,$arrIcon,$cName,$access,$fExport;

    require_once 'plugins/PHPExcel.php';
    $sekarang = date('Y-m-d');

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator($cName)
        ->setLastModifiedBy($cName)
        ->setTitle($arrTitle[''.$_GET[p].''])
    ;
    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(40);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);

    $objPHPExcel->getActiveSheet()->mergeCells('A1:F1');
    $objPHPExcel->getActiveSheet()->mergeCells('A2:F2');
    $objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->setCellValue('A1', 'REKAP TEAM');
    $objPHPExcel->getActiveSheet()->setCellValue('A2', 'TANGGAL : '.date('Y-m-d H:i:s'));

    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->setCellValue('A4', 'No.');
    $objPHPExcel->getActiveSheet()->setCellValue('B4', 'NAMA');
    $objPHPExcel->getActiveSheet()->setCellValue('C4', 'NO HP');
    $objPHPExcel->getActiveSheet()->setCellValue('D4', 'EMAIL');
    $objPHPExcel->getActiveSheet()->setCellValue('E4', 'BAGIAN');
    $objPHPExcel->getActiveSheet()->setCellValue('F4', 'JABATAN');

    $rows = 5;

    $sql = ' SELECT * FROM doc_team';

    $res = db($sql);
    while ($r = mysql_fetch_array($res)) {
        ++$no;

        $objPHPExcel->getActiveSheet()->getStyle('A'.$rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $objPHPExcel->getActiveSheet()->getStyle('A'.$rows.':F'.$rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

        $objPHPExcel->getActiveSheet()->setCellValue('A'.$rows, $no);
        $objPHPExcel->getActiveSheet()->setCellValue('B'.$rows, $r[nama]);
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$rows, $r[hp]);
        $objPHPExcel->getActiveSheet()->setCellValue('D'.$rows, $r[email]);
        $objPHPExcel->getActiveSheet()->setCellValue('E'.$rows, $r[bagian]);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$rows, $r[jabatan]);

        ++$rows;
    }
    --$rows;
    $objPHPExcel->getActiveSheet()->getStyle('A'.$rows.':F'.$rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:A'.$rows)->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:A'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:B'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('C4:C'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('D4:D'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('E4:E'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F4:F'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A1:F'.$rows)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->getStyle('A4:F'.$rows)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_FOLIO);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(3, 4);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setTop(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setLeft(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setRight(0.2);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setBottom(0.3);

    $objPHPExcel->getActiveSheet()->setTitle('DATA TEAM');
    $objPHPExcel->setActiveSheetIndex(0);

    // Save Excel file
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save($fExport.'DATA TEAM '.$sekarang.'.xls');
}
?>