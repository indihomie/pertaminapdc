<?php

use App\Models\AppMaster;
use App\Models\AppModule;
use App\View\Components\Layout;

function getContent($par)
{
    global $par;

    switch ($par['mode']) {
        case 'combo_moduls':
            echo comboModuls();

            break;

        default:
            index();

            break;
    }
}

function comboModuls()
{
    global $par;

    $moduls = AppModule::select(['id', 'name'])
        ->where('category_id', $_SESSION['filter_category_id'])
        ->where('name', '!=', 'Setting')
        ->orderBy('order')->get();

    return json_encode($moduls);
}

function index()
{
    global $par, $access;

    $module_categories = AppMaster::select(['id', 'name'])->where('category_id', 'S001')->orderBy('order')->get();
    $modules = AppModule::select(['id', 'name'])->where('category_id', $_SESSION['filter_category_id'])->orderBy('order')->get();

    Layout::title(); ?>
<div id="contentwrapper" class="contentwrapper">
    <form method="post" id="form" class="stdform" onsubmit="return false;">
        <div class="filter_container">
            <div class="filter_left">
                <p>
                    <?php echo selectArray('par[filter_category_id]', '', $module_categories, 'id', 'name', $_SESSION['filter_category_id'], '- Pilih Kategori -', 'onchange="getSub(\'' . getPar($par, 'mode, category_id') . '\')"') . '&nbsp;' . selectArray('par[filter_module_id]', '', $modules, 'id', 'name', $_SESSION['filter_module_id'], '- Pilih Modul - '); ?>
                    <input type="submit" value="Cari" class="btn btn_search btn-small" />
                </p>
            </div>
            <div class="filter_right">
                <a href="?par[mode]=xls<?php echo getPar($par, 'mode'); ?>" class="stdbtn"><i
                        class="fas fa-file-export"></i></i>&emsp;EXPORT</a>
            </div>
        </div>
    </form>
    <table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="">
        <thead>
            <tr>
                <th width="20">No.</th>
                <th>Nama</th>
                <th width="50">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php

                $modules = AppModule::whereNotNull('id')
                    ->where('name', '!=', 'Setting')
                    ->with(['moduleSubs' => function ($query) {
                        $query->where('name', '!=', 'Setting');
                    }], 'moduleSubs.menus')
                    ->when($par['filter_category_id'], function ($query, $category_id) {
                        $query->where('category_id', $category_id);
                    })
                    ->when($par['filter_module_id'], function ($query, $module_id) {
                        $query->where('module_id', $module_id);
                    })
                    ->when($par['search'], function ($query, $search) {
                        $query->where('name', 'LIKE', "%{$search}%");
                    })
                    ->orderBy('order', 'ASC')->get();

                $no = 0;
                foreach ($modules as $module) {
                    ++$no;
                    $module->status = $module->status ? '<img src="assets/images/t.png" title="Active">' : '<img src="assets/images/f.png" title="Not Active">'; ?>
            <tr>
                <td><?php echo $no; ?>.</td>
                <td><?php echo strtoupper($module['name']); ?></td>
                <td align="center"><?php echo $module['status']; ?></td>
            </tr>

            <?php
                    $sub_no = 0;
                    $module_subs = $module->moduleSubs()->orderBy('order', 'ASC')->get();
                    foreach ($module_subs as $module_sub) {
                        ++$sub_no;

                        $module_sub->status = $module_sub->status ? '<img src="assets/images/t.png" title="Active">' : '<img src="assets/images/f.png" title="Not Active">'; ?>
            <tr>
                <td></td>
                <td style="padding-left:40px;"><?php echo $sub_no . '. ' . $module_sub->name; ?></td>
                <td align="center"><?php echo $module_sub->status; ?></td>
            </tr>
            <?php
                        $menu_no = 0;
                        $menus = $module_sub->load('menus')->menus()->where('menu_id', 0)->orderBy('order', 'ASC')->get();
                        foreach ($menus as $menu) {
                            ++$menu_no;
                            $menu->status = $menu->status ? '<img src="assets/images/t.png" title="Active">' : '<img src="assets/images/f.png" title="Not Active">'; ?>
            <tr>
                <td></td>
                <td style="padding-left:60px;"><?php echo $menu->name; ?></td>
                <td align="center"><?php echo $menu->status; ?></td>
            </tr>
            <?php
                            $menu_child_no = 0;
                            $menus_childs = $menu->load('menuChilds')->menuChilds()->orderBy('order', 'ASC')->get();
                            foreach ($menus_childs as $menu_child) {
                                ++$menu_child_no;
                                $menu_child->status = $menu_child->status ? '<img src="assets/images/t.png" title="Active">' : '<img src="assets/images/f.png" title="Not Active">'; ?>
            <tr>
                <td></td>
                <td style="padding-left:60px;"><?php echo $menu_child->name; ?></td>
                <td align="center"><?php echo $menu_child->status; ?></td>
            </tr>

            <?php
                            }
                        }
                    }
                } ?>
        </tbody>
    </table>
</div>

<?php
}

function xls()
{
    global $db, $par, $arrTitle, $arrIcon, $cName, $menuAccess, $fExport, $cUsername, $s, $cID;

    require_once 'plugins/PHPExcel.php';

    $sekarang = date('Y-m-d');

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator($cName)
        ->setLastModifiedBy($cName)
        ->setTitle($arrTitle['' . $_GET[p] . '']);

    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(5);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);

    $objPHPExcel->getActiveSheet()->mergeCells('B1:F1');
    $objPHPExcel->getActiveSheet()->mergeCells('B2:F2');
    $objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('B1:B2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setSize(15);
    $objPHPExcel->getActiveSheet()->setCellValue('B1', 'DATA SITEMAP');

    $objPHPExcel->getActiveSheet()->getStyle('B4:F4')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('B4:F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('B4:F4')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('B4:F4')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:F4')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->setCellValue('B4', 'NO.');
    $objPHPExcel->getActiveSheet()->setCellValue('C4', 'MODUL');
    $objPHPExcel->getActiveSheet()->setCellValue('D4', 'SUB MODUL');
    $objPHPExcel->getActiveSheet()->setCellValue('E4', 'MENU');
    $objPHPExcel->getActiveSheet()->setCellValue('F4', 'SUB MENU');

    $objPHPExcel->getActiveSheet()->getStyle('B4:F4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('CCCCFFFF');

    $rows = 5;

    $filter = "where name !='Setting'";

    if (!empty($par[category_id])) {
        $filter .= "and category_id = '{$par['category_id']}'";
    }

    if (!empty($par[wew])) {
        $filter .= " AND module_id = '{$par['wew']}'";
    }

    $sql = "
    SELECT *
    FROM app_modules {$filter} order by order

    ";

    $res = db($sql);
    $no = 0;
    while ($r = mysql_fetch_assoc($res)) {
        $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

        ++$no;
        $r[tanggalKonseling] = getTanggal($r[tanggalKonseling]);

        $objPHPExcel->getActiveSheet()->getStyle('B' . $rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);

        $objPHPExcel->getActiveSheet()->getStyle('A' . $rows . ':E' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

        $objPHPExcel->getActiveSheet()->setCellValue('B' . $rows, $no . '.');
        $objPHPExcel->getActiveSheet()->setCellValue('C' . $rows, strtoupper($r[name]));

        $sql_ = "select * from app_module_subs where module_id = '{$r['module_id']}' AND namaSite != 'Setting' order by
    urutanSite";
        $res_ = db($sql_);
        while ($r_ = mysql_fetch_array($res_)) {
            $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
            $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

            ++$no;
            ++$rows;
            $objPHPExcel->getActiveSheet()->getStyle('B' . $rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            $objPHPExcel->getActiveSheet()->setCellValue('B' . $rows, $no . '.');
            $objPHPExcel->getActiveSheet()->setCellValue('D' . $rows, strtoupper($r_[namaSite]));
            $sql__ = "select * from app_menus where module_id = '{$r['module_id']}' AND module_sub_id = '{$r_['module_sub_id']}'
    order by urutanMenu";
            $res__ = db($sql__);
            while ($r__ = mysql_fetch_array($res__)) {
                $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
                $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

                ++$no;
                ++$rows;
                $objPHPExcel->getActiveSheet()->getStyle('B' . $rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                $objPHPExcel->getActiveSheet()->setCellValue('B' . $rows, $no . '.');
                $objPHPExcel->getActiveSheet()->setCellValue('E' . $rows, $r__[namaMenu]);
                $sql___ = "select * from app_menus where module_id = '{$r['module_id']}' AND module_sub_id = '{$r_['module_sub_id']}'
    AND kodeInduk = '{$r__['kodeMenu']}' order by urutanMenu";
                $res___ = db($sql___);
                while ($r___ = mysql_fetch_array($res___)) {
                    $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
                    $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

                    ++$no;
                    ++$rows;
                    $objPHPExcel->getActiveSheet()->getStyle('B' . $rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                    $objPHPExcel->getActiveSheet()->setCellValue('B' . $rows, $no . '.');

                    $objPHPExcel->getActiveSheet()->setCellValue('F' . $rows, $r___[namaMenu]);
                }
            }
        }

        // $sql_ = "
        // SELECT *,coalesce((select count(id) from emp_tupoksi where parent_id=kodeData),0) statusData
        // FROM app_masters
        // WHERE kodeCategory = 'X05' and kodeInduk = '$r[kodeData]'
        // ORDER BY kodeData
        // ";

        // $res_ = db($sql_);
        // $no_anakan=0;
        // while ($r_ = mysql_fetch_assoc($res_)) {
        // $r_[statusData] = $r_[statusData] > 0 ? "Active" : "Not Active";
        // $no_anakan++;
        // $objPHPExcel->getActiveSheet()->setCellValue('A'.($rows+$no_anakan), " ".$no_anakan.". ".$r_[namaData]);
        // $objPHPExcel->getActiveSheet()->setCellValue('C'.($rows+$no_anakan), $r_[statusData]);
        // $sql__ = "SELECT *,coalesce((select count(id) from emp_tupoksi where parent_id=kodeData),0) statusData FROM app_masters
        // WHERE kodeInduk = '$r_[kodeData]'
        // ORDER BY kodeData";
        // $res__ = db($sql__);
        // $no__anakan=0;
        // $urut_huruf=0;
        // // $no__anakan=0;
        // while ($r__ = mysql_fetch_assoc($res__)) {
        // $r__[statusData] = $r__[statusData] > 0 ? "Active" : "Not Active";
        // $no__anakan++;
        // $urut_huruf++;
        // $objPHPExcel->getActiveSheet()->setCellValue('B'.($rows+$no_anakan+$no__anakan), numToAlpha($urut_huruf).". ".$r__[namaData]);
        // $objPHPExcel->getActiveSheet()->setCellValue('C'.($rows+$no_anakan+$no__anakan), $r__[statusData]);

        // $sql___ = "SELECT *,coalesce((select count(id) from emp_tupoksi where parent_id=kodeData),0) statusData FROM app_masters where kodeInduk = '$r__[kodeData]' order by kodeData";
        // $res___ = db($sql___);
        // $no___anakan = 0;
        // while($r___ = mysql_fetch_assoc($res___)){
        // $r___[statusData] = $r___[statusData] > 0 ? "Active" : "Not Active";
        // $no__anakan++;
        // $no___anakan++;
        // $objPHPExcel->getActiveSheet()->setCellValue('B'.($rows+$no_anakan+$no__anakan), " ".strtolower(numToAlpha($no___anakan)).". ".$r___[namaData]);
        // $objPHPExcel->getActiveSheet()->setCellValue('C'.($rows+$no_anakan+$no__anakan), $r___[statusData]);
        // }

        // }
        // }
        // // $rows = $rows + $no___anakan;
        // $rows = $rows + $no__anakan;
        // $rows = $rows + $no_anakan;

        // ++$rows;
    }

    --$rows;
    $objPHPExcel->getActiveSheet()->getStyle('B' . $rows . ':F' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:B' . $rows)->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:B' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('C4:C' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('D4:D' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('E4:E' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F4:F' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->getStyle('B1:F' . $rows)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->getStyle('B4:F' . $rows)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_FOLIO);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(3, 4);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setTop(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setLeft(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setRight(0.2);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setBottom(0.3);

    $objPHPExcel->getActiveSheet()->setTitle('SITEMAP');
    $objPHPExcel->setActiveSheetIndex(0);

    // Save Excel file

    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save($fExport . 'SITEMAP.' . time() . '.xls');
}