function getComboModuls(elem, getPar){
    let category_id = elem.value;
    let module_id = document.getElementById('par[filter_module_id]');

    if (category_id != '') {
        jQuery.get(`void?par[mode]=combo_moduls&par[filter_category_id]=${category_id}${getPar}`).done(function (result) {
            let data = JSON.parse(result);
            for(var i=module_id.options.length-1; i>=0; i--){
                module_id.remove(i);
            }

            if(data){
                let opt = document.createElement("OPTION");
                opt.value = "";
                opt.text = "";
                module_id.options.add(opt);

                for(let i=0; i < data.length; i++){
                    let opt = document.createElement("OPTION");
                    opt.value = data[i].id;
                    opt.text = data[i].name;
                    if(opt.value) module_id.options.add(opt);
                    jQuery("#par\\[filter_module_id\\]").trigger("chosen:updated");
                }
            }
        });
    }

    return false;
}
