<?php

use App\Models\AppMaster;
use App\Models\AppMenu;
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\AppModule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

function getContent($par)
{
    global $_submit, $access;

    switch ($par['mode']) {
        case "combo_moduls":
            echo comboModuls();
            break;

        case "edit":
            if ($access["edit"])
                $_submit ? update() : form();
            else
                echo "Tidak ada akses";
            break;

        default:
            index();
            break;
    }
}

function comboModuls()
{
    global $par;

    $moduls = AppModule::select(['id', 'name'])
        ->where('category_id', $par['filter_category_id'])
        ->where('name', '!=', 'Pengaturan')
        ->orderBy('order', 'ASC')->get();

    return json_encode($moduls);
}

function update()
{
    global $par, $request;

    $validator = Validator::make($request->all(), [
        "path_fsd" => "required|mimes:doc,docx,pdf",
    ]);

    if ($validator->fails()) {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?" . getPar($par) . "'</script>";
        return;
    }

    DB::beginTransaction();

    try {
        $update = AppMenu::find($par["id"]);

        $update->update([
            'description_fsd' => $request->description_fsd,
            "path_icon" => $request->file("path_fsd") ? $request->file("path_fsd")->store(AppMenu::$path_fsd, ["disk" => "public"]) : "",
        ]);

        DB::commit();

        echo "<script>alert('Data berhasil diubah')</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal diubah')</script>";
    }

    echo "<script>window.location='?" . getPar($par, "mode, id") . "';</script>";
}

function form()
{
    global $par;

    $menu = AppMenu::with('module', 'module_sub')->find($par['id']);
?>
<div class="centercontent contentpopup">
    <?= Layout::title(true); ?>
    <div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
            onsubmit="toggleLoader();" enctype="multipart/form-data" autocomplete="off">
            <?= Form::CSRF() ?>
            <?= Layout::formBtnSubmit('true') ?>
            <div id="general" class="subcontent">
                <p>
                    <label class="l-input-small">Modul</label>
                    <span class="field"><?= $menu->module->name ?>&nbsp;</span>
                </p>
                <p>
                    <label class="l-input-small">Sub Modul</label>
                    <span class="field"><?= $menu->module_sub->name ?>&nbsp;</span>
                </p>
                <p>
                    <label class="l-input-small">Menu</label>
                    <span class="field"><?= $menu->name ?>&nbsp;</span>
                </p>
                <?= Form::inputLabelDocument('File FSD', 'path_fsd', $menu->path_fsd, true, "l-input-small", ".pdf,.doc,.docx"); ?>
                <?= Form::inputLabelTextArea('Keterangan', 'description_fsd', $menu->description_fsd); ?>
            </div>
        </form>
    </div>
</div>
<?php
}

function index()
{
    global $par, $access;

    $_SESSION["filter_category_id"] = $par['filter_category_id'];
    $_SESSION["filter_module_id"] = $par['filter_module_id'];

    $module_categories = AppMaster::where('category_id', 'S001')->orderBy('name')->get();
    $module = AppModule::when($_SESSION["filter_category_id"], function ($query, $category_id) {
        $query->where('category_id', $category_id);
    })->where('name', '!=', 'Pengaturan')->orderBy('order')->get();

    Layout::title();
?>
<div id="contentwrapper" class="contentwrapper">
    <form id="form" name="form" method="POST" class="stdform" action="?<?php echo getPar($par); ?>"
        onsubmit="toggleLoader();" autocomplete="off">
        <?php echo Form::CSRF(); ?>
        <div class="filter_container">
            <div class="filter_left">
                <p>
                    <input type="text" id="search" name="search" placeholder="Cari..."
                        style="background: url('assets/images/filter.png') no-repeat; width: 200px; padding-left: 30px;" />
                    <?= Form::selectArray("Filter Kategori Modul", "par[filter_category_id]", $module_categories, "id", "name", $_SESSION["filter_category_id"], "- Semua Modul -", "onchange=\"getComboModuls(this, '" . getPar($par, "mode, filter_category_id") . "');\"", "200px") . '&nbsp;' .  Form::selectArray("Filter Modul", "par[filter_module_id]", $module, "id", "name", $_SESSION["filter_module_id"], "- Semua Modul -",); ?>
                    <input type="submit" value="Cari" class="btn btn_search btn-small" />
                </p>
            </div>
            <div class="filter_right">
                <a href="?par[mode]=xls<?= getPar($par, 'mode') ?>" class="stdbtn"><i
                        class="fas fa-file-export"></i></i>&emsp;EXPORT</a>
            </div>
        </div>
    </form>
    <table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="">
        <thead>
            <tr>
                <th width=" 20">No.</th>
                <th width="*">Sub Modul</th>
                <th width="50">D/L</th>
                <th width="50">View</th>
                <th width="80">SIZE</th>
                <th width="50">Kontrol</th>
            </tr>
        </thead>
        <tbody>
            <?

                $modules = AppModule::where('name', '!=', 'Pengaturan')
                    ->with(['moduleSubs' => function ($query) {
                        $query->where('name', '!=', 'Pengaturan');
                    }])
                    ->when($_SESSION["filter_category_id"], function ($query, $category_id) {
                        $query->where('category_id', $category_id);
                    })
                    ->when($_SESSION["filter_module_id"], function ($query, $module_id) {
                        $query->where('id', $module_id);
                    })
                    ->when($par['search'], function ($query, $search) {
                        $query->where('name', 'LIKE', "%{$search}%");
                    })
                    ->orderBy('order', 'ASC')->get();

                $no = 0;
                foreach ($modules as $module) {
                    $no++;
                ?>
            <tr>
                <td style="background-color:#e9e9e9"><?= $no ?>.</td>
                <td style="background-color:#e9e9e9" colspan="5"><?= strtoupper($module['name']) ?></td>
            </tr>
            <?php

                    $sub_no = 0;
                    foreach ($module->moduleSubs as $module_subs) {
                        $module_subs = $module_subs->load('menus');
                        $menus_parent = $module_subs->menus()->where('menu_id', 0)->get();
                        $sub_no++;
                    ?>
            <tr>
                <td></td>
                <td colspan="5" style="padding-left:40px;"><?= $sub_no . '. ' . $module_subs['name'] ?></td>
            </tr>
            <?php
                        foreach ($menus_parent as $menu) {
                            if (empty($menu['path_fsd'])) {
                                $menu['download'] = ' - ';
                                $menu['view'] = ' - ';
                                $menu['size'] = ' - ';
                            } else {
                                $menu['download'] = '<a href="download/' . encrypt($menu->path_fsd) . '" target="_blank">' . getIconExtension($menu->path_fsd) . '</a>';

                                $menu['view'] = $menu->path_fsd ? openView($menu->path_fsd) : '-';
                                $menu['size'] = getFileSize($menu->path_fsd);
                            }

                            $menu['status'] = 't' == $menu['status'] ? '<img src="styles/images/t.png" title="Active">' : '<img src="styles/images/f.png" title="Not Active">'; ?>
            <tr>
                <td></td>
                <td style="padding-left:60px;"><?php echo $menu['name']; ?></td>
                <td align="center"><?php echo $menu['download']; ?></td>
                <td align="center"><?php echo $menu['view']; ?></td>
                <td align="center"><?php echo $menu['size']; ?></td>
                <td align="center">
                    <?php if (isset($access['edit'])) { ?>
                    <a href="#edit" title="Edit Data" class="edit"
                        onclick="openBox('popup?par[mode]=edit&par[id]=<?php echo $menu['id'] . getPar($par, 'mode, id'); ?>', 750, 370);"><span>Edit</span></a>
                    <?php } ?>
                </td>
            </tr>
            <?php

                            $menus_childs = AppMenu::where('menu_id', $menu->id)->orderBy('order', 'ASC')->get();

                            foreach ($menus_childs as $menu_child) {
                                if (empty($menu_child['path_fsd'])) {
                                    $menu_child['download'] = ' - ';
                                    $menu_child['view'] = ' - ';
                                    $menu_child['size'] = ' - ';
                                } else {
                                    $menu_child['download'] = '<a     href="download/' . encrypt($menu_child->path_fsd) . '" target="_blank">' . getIconExtension($menu_child->path_fsd) . '</a>';
                                    $menu_child['view'] = $menu_child->path_fsd ? openView($menu_child->path_fsd) : '-';
                                    $menu_child['size'] = getFileSize($menu_child->path_fsd);
                                } ?>
            <tr>
                <td></td>
                <td style="padding-left:80px;"><?php echo $menu_child->name; ?></td>
                <td align="center"><?php echo $menu_child['download']; ?></td>
                <td align="center"><?php echo $menu_child['view']; ?></td>
                <td align="center"><?php echo $menu_child['size']; ?></td>

                <td align="center">
                    <?php if (isset($access['edit'])) { ?>
                    <a href="#edit" title="Edit Data" class="edit"
                        onclick="openBox('popup.php?par[mode]=edit&par[id]=<?php echo $menu_child['id'] . getPar($par, 'mode, id'); ?>', 750, 370);"><span>Edit</span></a>
                    <?php } ?>
                </td>
            </tr>
            <?php
                            }
                        }
                    }
                }
                ?>
        </tbody>
    </table>
</div>
<?php
}

function xls()
{
    global $fExport;
    require_once 'plugins/PHPExcel.php';
    $sekarang = date('Y-m-d');

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator($cName)
        ->setLastModifiedBy($cName)
        ->setTitle($arrTitle["" . $_GET[p] . ""]);
    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(40);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);

    $objPHPExcel->getActiveSheet()->mergeCells('A1:F1');
    $objPHPExcel->getActiveSheet()->mergeCells('A2:F2');
    $objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->setCellValue('A1', "REKAP FSD");
    $objPHPExcel->getActiveSheet()->setCellValue('A2', "TANGGAL : " . date('Y-m-d H:i:s'));

    $objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);

    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->setCellValue('A4', 'No.');
    $objPHPExcel->getActiveSheet()->setCellValue('B4', "MENU");
    $objPHPExcel->getActiveSheet()->setCellValue('C4', "SUB MODUL");
    $objPHPExcel->getActiveSheet()->setCellValue('D4', "UPDATE");
    $objPHPExcel->getActiveSheet()->setCellValue('E4', "PIC");
    $objPHPExcel->getActiveSheet()->setCellValue('F4', "DOC");

    $rows = 5;

    $sql = " SELECT * FROM app_menus t1 join app_module_subs t2 on t1.module_sub_id = t2.module_sub_id where t2.namaSite !=
    'Pengaturan' order by t2.namasite,t1.namaMenu";

    $res = db($sql);
    while ($r = mysql_fetch_array($res)) {
        $no++;
        $status = $r[status] == "t" ? "Aktif" : "Tidak Aktif";
        $r[gender] = $r[gender] == "p" ? "Wanita" : "Pria";
        $komunitas = getField("SELECT GROUP_CONCAT(komunitas) FROM komunitas_relasi t1 JOIN komunitas_data t2 ON
    t1.`idKomunitas` = t2.`id` WHERE t1.`idAnggota` = '$r[id]' ");







        $objPHPExcel->getActiveSheet()->getStyle('A' . $rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);


        $objPHPExcel->getActiveSheet()->getStyle('A' . $rows . ':F' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
        $r[status] = empty($r[fileFsd]) ? "Belum" : "Sudah";
        if (!empty($r[fileFsd])) {
            $objPHPExcel->getActiveSheet()->getStyle('F' . $rows)->applyFromArray(
                array(
                    'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => '016f00')
                    )
                )
            );
        }
        $objPHPExcel->getActiveSheet()->setCellValue('A' . $rows, $no);
        $objPHPExcel->getActiveSheet()->setCellValue('B' . $rows, $r['namaMenu']);
        $objPHPExcel->getActiveSheet()->setCellValue('C' . $rows, $r['namaSite']);
        $objPHPExcel->getActiveSheet()->setCellValue('D' . $rows, $r['updated_at']);
        $objPHPExcel->getActiveSheet()->setCellValue('E' . $rows, $r['updated_by']);
        $objPHPExcel->getActiveSheet()->setCellValue('F' . $rows, $r['status']);

        $rows++;
    }
    $rows--;
    $objPHPExcel->getActiveSheet()->getStyle('A' . $rows . ':F' . $rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->getStyle('A4:A' . $rows)->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:A' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->getStyle('B4:B' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('C4:C' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('D4:D' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F4:F' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('E4:E' . $rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A1:E' . $rows)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->getStyle('A4:F' . $rows)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_FOLIO);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(3, 4);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setTop(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setLeft(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setRight(0.2);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setBottom(0.3);

    $objPHPExcel->getActiveSheet()->setTitle("DATA FSD");
    $objPHPExcel->setActiveSheetIndex(0);

    // Save Excel file
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save($fExport . "DATA FSD " . $sekarang . ".xls");
}