<?php
// if(!isset($access["view"])) echo "<script>logout();</script>";
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\Note\CatatanSistem;
use App\Models\Note\CatatanChangereq;
use App\Models\AppMasterCategory;

$fExport = "files/export/";
$fRencana = "files/dokumentasi/rencana/";

function getContent($par){
	global $s,$_submit,$access;
	switch($par[mode]){
		case "datas":
			echo lData();
		break;

		case "cetak":
		$text = pdf();
		break;

		case "approve":
		if(isset($access["add"])) $text = empty($_submit) ? formApprove() : approve(); else $text = lihat();
		break;

		case "del":
			if(isset($access["delete"])) $text = hapus(); else $text = lihat();
			break;

		case "edit":
			if ($access["edit"])
				$_submit ? ubah() : form();
			else
				echo "Tidak ada akses";
			break;

		default:
			$text = lihat();
			break;
	}
	return $text;
}

function pdf(){
	global $db,$s,$inp,$par,$fFile,$arrTitle,$arrParam;
	require_once('plugins/TCPDF/tcpdf.php');

	// create new PDF document
	//$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		$pdf = new TCPDF ('P', 'mm', 'A4', true, 'UTF-8', false);

		$pdf->setPrintHeader(false);
		$pdf->setPrintFooter(false);

	//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetMargins(5, 5, 5);

	// set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, 1);

	// add a page
		$pdf->AddPage();

	// set font
		$pdf->SetFont('helvetica', '', 12);

		$sql = db("select * from catatan_sistem as a
			left join catatan_changereq as b on(a.idCatatan = b.id_temuan)
			where a.idCatatan = '$par[id]'");
		$r = mysql_fetch_assoc($sql);

		$content  = "";
		$content .= "
		<table border=\"1\">
			<tr>
				<th align=\"left\" width=\"200\"><b> PROJECT</b></th>
				<th align=\"center\" rowspan=\"4\" width=\"180\"><h2>CHANGES REQUEST</h2></th>
				<th align=\"center\" rowspan=\"2\"><b>CODE</b></th>
				<th align=\"center\" width=\"40\" rowspan=\"4\"><b>SCS 09</b></th>
			</tr>
			<tr>
				<th align=\"left\"><h2> $r[proyek]</h2></th>
			</tr>
			<tr>
				<th align=\"left\"><b> APPLICATION MODUL</b></th>
				<th align=\"center\" rowspan=\"2\"><b>CR</b></th>
			</tr>
			<tr>
				<th align=\"left\" rowspan=\"2\"><h2> $r[modul]</h2></th>
			</tr>
			<tr>
				<th align=\"center\">DATE  : 24-04-2019</th>
				<th align=\"center\" colspan=\"2\">NO :  $r[nomor]</th>
			</tr>
		</table>
		<br><br>
		<table border=\"1\">
			<tr>
				<td colspan=\"4\"><b> PERMINTAAN PERUBAHAN – PERMINTAAN BARU</b></td>
			</tr>
			<tr>
				<td> Nama<br> $r[user]<br></td>
				<td> ttd</td>
				<td> Jabatan - Unit<br> $r[user_jabatan]<br></td>
				<td> Tanggal</td>
			</tr>
			<tr>
				<td colspan=\"4\"><b> PERSETUJUAN ATASAN / PROJECT MANAGER</b></td>
			</tr>
			<tr>
				<td> Nama<br> $r[atasan]<br></td>
				<td> ttd</td>
				<td> Jabatan - Unit<br> $r[atasan_jabatan]<br></td>
				<td> Tanggal</td>
			</tr>
			<tr>
				<td colspan=\"4\"><b> DISKRIPSI PERMINTAAN</b></td>
			</tr>
			<tr>
				<td colspan=\"4\"> \t$r[uraian]<br></td>
			</tr>
			<tr>
				<td colspan=\"4\"> Detail Penjelasan<br> $r[penjelasan]<br></td>
			</tr>
			<tr>
				<td colspan=\"4\"> Letak Perubahan<br><br>";
					$sql = db("select kodeData, namaData From app_masters where kodeCategory = 'KLP'");
					while($r = mysql_fetch_assoc($sql)){
						$content.=" [&nbsp;&nbsp;] $r[namaData] &nbsp;&nbsp;&nbsp;&nbsp;";
					}
					$content .= "
					<br>
				</td>
			</tr>
			<tr>
				<td colspan=\"4\"> Tipe Permintaan<br><br>";
					$sql2 = db("select kodeData, namaData From app_masters where kodeCategory = 'KTP'");
					while($r2 = mysql_fetch_assoc($sql2)){
						$content.=" [&nbsp;&nbsp;] $r2[namaData] &nbsp;&nbsp;&nbsp;&nbsp;";
					}
					$content .= "
					<br>
				</td>
			</tr>
			<tr>
				<td colspan=\"4\"> Prioritas<br><br>";
					$sql3 = db("select kodeData, namaData From app_masters where kodeCategory = 'KP'");
					while($r3 = mysql_fetch_assoc($sql3)){
						$content.=" [&nbsp;&nbsp;] $r3[namaData] &nbsp;&nbsp;&nbsp;&nbsp;";
					}
					$content .= "
					<br>
				</td>
			</tr>
			<tr>
				<td colspan=\"4\"> Penjelasan Tambahan<br><br>";
					$sql4 = db("select kodeData, namaData From app_masters where kodeCategory = 'KPT'");
					while($r4 = mysql_fetch_assoc($sql4)){
						$content.=" [&nbsp;&nbsp;] $r4[namaData] &nbsp;&nbsp;&nbsp;&nbsp;";
					}
					$content .= "
					<br>
				</td>
			</tr>
			<tr>
				<td colspan=\"4\"> Rekomendasi / Catatan<br></td>
			</tr>
			<tr>
				<td colspan=\"2\" rowspan=\"2\"> Permintaan Tanggal Implementasi<br> ".getTanggal($r[target])."</td>
				<td colspan=\"2\"> Pembiayaan Baru</td>
			</tr>
			<tr>
				<td> ADA</td>
				<td> TIDAK ADA</td>
			</tr>
		</table>";

	// output the HTML content
		$pdf->writeHTML($content, true, true, true, true, '');

	// reset pointer to the last page
		$pdf->lastPage();
	// ---------------------------------------------------------
		ob_end_clean();
	//Close and output PDF document
		$pdf->Output();
}

/*function pdf(){
	global $db,$s,$inp,$par,$fFile,$arrTitle,$arrParam;
	require_once 'plugins/PHPPdf.php';



	$pdf = new PDF('P','mm','A4');
	$pdf->AddPage();
	$pdf->SetLeftMargin(15);

	$sql = db("select * from catatan_sistem as a
		left join catatan_changereq as b on(a.idCatatan = b.id_temuan)
		where a.idCatatan = '$par[id]'");
	$r = mysql_fetch_assoc($sql);

	$pdf->SetLeftMargin(15);
	$pdf->SetFont('Arial','',10);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("PROJECT\tb"));

	$pdf->SetFont('Arial','',14);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("".$r[proyek]."\tb"));

	$pdf->SetFont('Arial','',10);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("APPLICATION MODUL\tb"));

	$pdf->SetFont('Arial','',15);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("".$r[modul]."\tb"));
	$pdf->Ln(10);

	$pdf->SetLeftMargin(15);
	$pdf->SetFont('Arial','',10);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("PERMINTAAN PERUBAHAN PERMINTAAN BARU\tb"));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(45,45,45,45));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Nama\n".$r[user]."","ttd\n","Jabatan - Unit\n".$r[user_jabatan]."","Tanggal\n"));

	$pdf->SetFont('Arial','',10);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("PERSETUJUAN ATASAN / PROJECT MANAGER\tb"));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(45,45,45,45));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Nama\n".$r[atasan]."","ttd\n","Jabatan - Unit\n".$r[atasan_jabatan]."","Tanggal\n"));

	$pdf->SetFont('Arial','',10);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("DISKRIPSI PERMINTAAN\tb"));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("".$r[proyek]." ".$r[modul].":\n".$r[uraian].""));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Detail Penjelasan:\n".$r[penjelasan].""));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Letak Perubahan\n\n"));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Tipe Permintaan\n\n"));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Prioritas\n\n"));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Penjelasan Tambahan\n\n"));

	$pdf->SetFont('Arial','',8);
	$pdf->SetWidths(array(180));
	$pdf->SetAligns(array('L'));
	$pdf->Row(array("Rekomendasi Catatan\n\n"));
	ob_end_clean();
	$pdf->Output();
}*/

function formApprove(){
	global $db,$s,$inp,$par,$arrTitle,$arrParameter,$menuAccess, $arrParam, $cUsername;

	$sql="SELECT * from nonpayroll_thr_setting where id = '$par[idt]'";
	$res=db($sql);
	$r=mysql_fetch_array($res);

	$false =  $r["approve"] == "f" ? "checked=\"checked\"" : "";
	$true =  empty($false) ? "checked=\"checked\"" : "";

	$r["approveBy"] = empty($r["approveBy"]) ? $cUsername : $r["approveBy"];

	$text = getValidation();

	$text.="

	<div class=\"centercontent contentpopup\">
		<div class=\"pageheader\">
			<h1 class=\"pagetitle\">".$arrTitle[$s]."</h1>
			".getBread(ucwords($par[mode]." data"))."
		</div>
		<div id=\"contentwrapper\" class=\"contentwrapper\">
			<form id=\"form\" name=\"form\" method=\"post\" class=\"stdform\" action=\"?_submit=1".getPar($par)."\" onsubmit=\"return validation(document.form);\" enctype=\"multipart/form-data\">
				<div id=\"general\" class=\"subcontent\">
					<p>
						<label class=\"l-input-small\">Approve By</label>
						<div class=\"field\">

							<input type=\"text\" id=\"inp[approveBy]\" name=\"inp[approveBy]\"  value=\"".$r["approveBy"]."\" class=\"mediuminput\" style=\"width:100px;\" readonly/>
						</div>
					</p>
					<p>
						<label class=\"l-input-small\">Tanggal</label>
						<div class=\"field\">
							<input type=\"text\" id=\"approveDate\" name=\"inp[approveDate]\" size=\"10\" maxlength=\"10\" value=\"".getTanggal($r["approveDate"])."\" class=\"vsmallinput hasDatePicker\"/>
						</div>
					</p>
					<p>
						<label class=\"l-input-small\">Status</label>
						<div class=\"fradio\">
							<input type=\"radio\" id=\"true\" name=\"inp[approve]\" value=\"t\" $true /> <span class=\"sradio\">Disetujui</span>
							<input type=\"radio\" id=\"false\" name=\"inp[approve]\" value=\"f\" $false /> <span class=\"sradio\">Ditolak</span>
						</div>
					</p>
					<p>
						<label class=\"l-input-small\">Keterangan</label>
						<div class=\"field\">
							<textarea id=\"inp[approveKet]\" name=\"inp[approveKet]\" rows=\"3\" cols=\"50\" class=\"longinput\" style=\"height:50px; width:300px;\">".$r["approveKet"]."</textarea>
						</div>
					</p>


				</div>


				<p style=\"position:absolute;top:5px;right:10px;\">

					<input type=\"submit\" class=\"submit radius2\" name=\"btnSimpan\" value=\"Submit\"/>
					<input type=\"button\" class=\"cancel radius2\" value=\"Batal\" onclick=\"closeBox();\"/>

				</p>

			</form>
		</div>";
		return $text;
}

function approve(){
	global $db,$s,$inp,$par,$cUsername, $arrParam;

	$sql = "update catatan_sistem set approve = '".$inp["approve"]."', approveBy = '".$inp["approveBy"]."', approveKet = '".$inp["approveKet"]."', approveDate = '".setTanggal($inp["approveDate"])."' where idCatatan = '$par[idCatatan]' ";
	db($sql);
	echo "<script>closeBox();alert('DATA BERHASIL DIAPPROVE');reloadPage();</script>";
}

function ubah_old(){
	global $s, $inp, $par, $cUsername, $arrParam, $db, $cID;
	$id = getField("SELECT id from catatan_changereq where id_temuan = '$par[id]'");
	$lastID = getField("SELECT id from catatan_changereq order by id desc limit 1")+1;
	$perubahan = "$inp[perubahan0],$inp[perubahan1],$inp[perubahan2],$inp[perubahan3]";
	$tipe = "$inp[tipe0],$inp[tipe1],$inp[tipe2],$inp[tipe3]";
	$prioritas = "$inp[prioritas0],$inp[prioritas1],$inp[prioritas2]";
	$tambahan = "$inp[tambahan0],$inp[tambahan1],$inp[tambahan2],$inp[tambahan3]";
	if(empty($id)){
		// insert
		$sql = "INSERT INTO `catatan_changereq` (`id`, `id_temuan`, `proyek`, `modul`, `uraian`, `user`, `user_jabatan`, `atasan`, `atasan_jabatan`, `penjelasan`, `perubahan`, `tipe`, `prioritas`, `tambahan`, `catatan`, `target`, `biaya`, `created_date`, `created_by`) VALUES ('$lastID', '$par[id]', '$inp[proyek]', '$inp[modul]', '$inp[uraian]', '$inp[user]', '$inp[user_jabatan]', '$inp[atasan]', '$inp[atasan_jabatan]', '$inp[penjelasan]', '$perubahan', '$tipe', '$prioritas', '$tambahan', '$catatan', '".setTanggal($inp[target])."', '$inp[biaya]', now(), '$cID')";
	}else{
		// update
		$sql = "UPDATE `catatan_changereq` SET `id` = '$par[idcr]', `id_temuan` = '$par[id]', `proyek` = '$inp[proyek]', `modul` = '$inp[modul]', `uraian` = '$inp[uraian]', `user` = '$inp[user]', `user_jabatan` = '$inp[user_jabatan]', `atasan` = '$inp[atasan]', `atasan_jabatan` = '$inp[atasan_jabatan]', `penjelasan` = '$inp[penjelasan]', `perubahan` = '$perubahan', `tipe` = '$tipe', `prioritas` = '$prioritas', `tambahan` = '$tambahan', `catatan` = '$catatan', `target` = '".setTanggal($inp[target])."', `biaya` = '$inp[biaya]', `updated_date` = now(), `updated_by` = '$cID' WHERE `catatan_changereq`.`id` = $par[idcr]";
	}

	/*var_dump($sql);
	die();*/

	dd($sql);

	// echo "<script>alert('Data Berhasil Disimpan')</script>";
	// echo "<script>window.location='?par[mode]=edit" . getPar($par, "mode") . "';</script>";
}

function ubah(){
	global $user, $request, $par;

    DB::beginTransaction();
	// DB::enableQueryLog();

    try {
		if (empty($par['idcr'])) {
			CatatanChangereq::create([
				'id_temuan' => $par['id'],
				'nomor' => $request->nomor,
				'proyek' => $request->proyek,
				'modul' => $request->modul,
				'uraian' => $request->uraian,
				'user_pengusul' => $request->user_pengusul,
				'user_jabatan' => $request->user_jabatan,
				'atasan' => $request->atasan,
				'atasan_jabatan' => $request->atasan_jabatan,
				'penjelasan' => $request->penjelasan,
				'perubahan' => $request->perubahan,
				'catatan' => $request->catatan,
				'target' => setTanggal($request->target),
				'biaya' => $request->biaya
			]);
	
			DB::commit();
		} else {
			$update = CatatanChangereq::find($par["idcr"]);
			$update->update([
				'id_temuan' => $par['id'],
				'nomor' => $request->nomor,
				'proyek' => $request->proyek,
				'modul' => $request->modul,
				'uraian' => $request->uraian,
				'user_pengusul' => $request->user_pengusul,
				'user_jabatan' => $request->user_jabatan,
				'atasan' => $request->atasan,
				'atasan_jabatan' => $request->atasan_jabatan,
				'penjelasan' => $request->penjelasan,
				'perubahan' => $request->perubahan,
				'catatan' => $request->catatan,
				'target' => setTanggal($request->target),
				'biaya' => $request->biaya
			]);
			DB::commit();
		}

		// dd($order->getQueryLog());

		
        echo "<script>alert('Data berhasil disimpan')</script>";
		echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

		dd($e);
        echo "<script>alert('Data gagal disimpan')</script>";
    }

	echo "<script>closeBox()</script>";
}

function lihat(){
	global $par,$access;

	if (isset($access["edit"]) || isset($access["delete"])) {
		datatable(7, array(6, 7));
	} else {
		datatable(6, array(6, 7));
	}

	$app_master_category = AppMasterCategory::query()->select(["id", "name"])->where("category_id", "=", "KP")->orderBy("order")->get()->toArray();
	// comboData("SELECT * FROM app_masters WHERE kodeCategory = 'KP' AND statusData ='t' order by namaData","kodeData","namaData","bSearch","All Prioritas",$bSearch,"","210px;","chosen-select")

	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">

		<form action="" method="post" id = "form" class="stdform" onsubmit="return false;">
			<div id="pos_l" style="float:left;">
				<p>
					<input type="text" id="fSearch" name="fSearch" value="<?= $par[filterData] ?>" style="width:200px;"/>

                    <?= Form::selectArray("Filter Prioritas", "change_1", $app_master_category, "id", "name", $bSearch, "- Semua Prioritas -"); ?>
				</p>
			</div>
			<div id="pos_r" style="float:right;">
				<a href="#" class="btn btn1 btn_inboxi" style="margin-left:5px;"><span>Export Data</span></a>
			</div>
		</form>
		<br clear="all" />
		<table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="table">
			<thead>
				<tr>
					<th  width="20">No.</th>
					<th width="100">Tanggal</th>
					<th width="100">Nomor</th>
					<th  width="*">Judul</th>
					<th width="100">User</th>
					<th width="100">Atasan</th>
					<?php
					if(isset($access["edit"]) || isset($access["delete"])) 
						echo "<th  width=\"50\">Detail</th>";
					?>
				</tr>
			</thead>

			<tbody></tbody>
		</table>

	</div>
	<?php
	$sekarang = date('Y-m-d');
	if($par['mode'] == "xls"){
		xls();
		echo "<iframe src=\"download.php?d=exp&f=CHANGES REQUEST".$sekarang.".xls\" frameborder=\"0\" width=\"0\" height=\"0\"></iframe>";
	}
}



function lData(){
	global $par, $access,$user;
	global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

	// DB::enableQueryLog();

	$arr_order = [
        "t1.id",
        "t1.tanggal",
        "t1.nomor",
        "t1.temuan",
        "t2.username",
    ];

    $q_order = $arr_order[$iSortCol_0];
    $q_sort = $iSortCol_0 > 0 ? $sSortDir_0 : 'desc';

	$q_filter = "1 = 1";
    $q_filter .= $search ? " AND (t1.temuan LIKE '%{$search}%' OR t3.prioritas LIKE '%{$search}%')" : "";


	// $query = "SELECT * from catatan_sistems t1 inner join app_users t2 on t1.created_by = t2.id left join catatan_changereq t3 on t1.id = t3.id_temuan $sWhere order by $orderBy $sLimit";

	$query = DB::table('catatan_sistems as t1')
	->select('*', 't1.id AS id_catatan', 't3.id AS id_cr')
	->join('app_users as t2', 't1.created_by', 't2.id')
	->leftJoin('catatan_changereq as t3', 't1.id','t3.id_temuan')
	->whereNotNull('t1.id');

	$count = clone $query;

	$query = $query->orderBy($q_order, $q_sort);

	if ($iDisplayLength > 0) {
        $query->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $cr = $query->get();

	$json = array(
		// "iTotalRecords" => mysql_num_rows($res),
		"iTotalDisplayRecords" => $count->count(),
		"aaData" => array(),
	);

	// dd(DB::getQueryLog());
	$no=intval($iDisplayStart);
    foreach($cr as $r) {
		$no++;
		if($r->approve == 't'){
			$approve = "<img src=\"styles/images/t.png\" title=\"Selesai\">";
		}else{
			$approve = "<img src=\"styles/images/p.png\" title=\"Pending\">";
		}

		$print = "<a href=\"#\" class=\"print\"></a>";
		// $idcr=getField("select id from catatan_changereq where id_temuan = $r[idCatatan]");

		$data=array(
			"<div align=\"center\">".$no.".</div>",
			"<div align=\"center\">".getTanggal($r->tanggal)."</div>",
			"<div align=\"left\">".$r->nomor."</div>",
			"<div align=\"left\">".$r->temuan."</div>",
			"<div align=\"left\">".$r->username."</div>",
			"<div align=\"left\">".$r->atasan."</div>",
			"<div align=\"center\"><a href=\"?par[mode]=edit&par[id]=$r->id_catatan&par[idcr]=$r->id_cr".getPar($par,"mode,id,idcr")."\" class=\"edit\"></a></div>"
		);
		$json['aaData'][]=$data;
	}
	return json_encode($json);
}

function form(){
	global $par,$access,$user;

	$catatan_sistem = CatatanSistem::find($par['id']);
	$change_request = CatatanChangereq::find($par['idcr']);
	
	if($$change_request->biaya == '0'){
		$true_y = 'checked';
	}
	if($change_request->biaya == '1'){
		$true_n = 'checked';
	}

	if (empty($change_request->biaya)) {
		$default = 'checked';
	}

	echo getValidation();
	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">
		<form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
            onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
            autocomplete="off">		
			
			<input type="hidden" name="_token" value="<?= csrf_token() ?>">

			<p style="position:absolute;right:5px;top:5px;">
            	<?= Layout::formBtnSubmit() ?>
			</p>
			<fieldset>
				<legend> REQUEST </legend>
				<?=
					Form::inputLabelText('Nomor', 'nomor', $change_request->nomor);
					Form::inputLabelDatePicker('Tanggal', 'tanggal', $catatan_sistem->tanggal);
					Form::inputLabelText('Project', 'proyek', $change_request->proyek);
					Form::inputLabelText('Modul', 'modul', $change_request->modul);
					Form::inputLabelText('Judul', 'judul', $catatan_sistem->temuan, "", "", "", "","", "readonly");
					Form::inputLabelTextArea('Uraian', 'uraian', $change_request->uraian);	
				?>
				<table style="width:100%">
					<tr>
						<td style="width:50%">
							<p>
								<label class="l-input-small2">User Pengusul</label>
								<input type="text" id="user_pengusul" name="user_pengusul" value="<?= $change_request->user_pengusul; ?>" style="width:250px;"/>
							</p>
						</td>
						<td>
							<p>
								<label class="l-input-small">Jabatan</label>
								<input type="text" id="user_jabatan" name="user_jabatan" value="<?= $change_request->user_jabatan;?>" style="width:250px;"/>
							</p>
						</td>
					</tr>
					<tr>
						<td style="width:50%">
							<p>
								<label class="l-input-small2">Project Manager</label>
								<input type="text" id="atasan" name="atasan"  value="<?= $change_request->atasan ?>" style="width:250px;"/>
							</p>
						</td>
						<td>
							<p>
								<label class="l-input-small">Jabatan</label>
								<input type="text" id="atasan_jabatan" name="atasan_jabatan"  value="<?= $change_request->atasan_jabatan; ?>" style="width:250px;"/>
							</p>
						</td>
					</tr>
				</table>
			</fieldset>

			<fieldset>
				<legend> ANALISA </legend>
				<?php
					Form::inputLabelTextArea('Detail Penjelasan', 'penjelasan', $change_request->penjelasan);	
				?>
			</fieldset>

			<fieldset>
				<legend> Perubahan </legend>
				<?php
					Form::inputLabelTextArea('Detail Perubahan', 'perubahan', $change_request->perubahan);	
				?>
			</fieldset>

			<fieldset>
				<legend> Catatan </legend>
				<?php
					Form::inputLabelTextArea('Catatan', 'catatan', $change_request->catatan);	
				?>
			</fieldset>

			<fieldset>
				<legend> REKOMENDASI </legend>
				<table style="width:100%">
					<tr>
						<td style="width:50%">
							<p>
								<label class="l-input-small2">Rencana Implementasi</label>
								<div class="field">
									<input type="text" id="target" name="target"  value="<?= getTanggal($change_request->target);?>" class="hasDatePicker"/>
								</div>
							</p>
						</td>
						<td>
						<label class="l-input-small" style="width:40%">Biaya</label>
							<div class="field">
								<div class="sradio" style="padding-top:5px;padding-left:8px;">
									<input type="radio" name="biaya" value="0" <?= $true_y." ".$default ?>> <span style="padding-right:10px;">Tidak</span>
									<input type="radio" name="biaya" value="1" <?= $true_n ?>> <span style="padding-right:10px;">Ya</span>
								</div>
							</div>
						</td>
					</tr>

				</table>
			</fieldset>
		</form>
	</div>
	<?php
}

function hapus(){
	global $s,$inp,$par,$fRencana,$cUsername;
	$foto_file = getField("select file from doc_file where idRencana='$par[id]'");
	if(file_exists($fRencana.$foto_file) and $foto_file!="")unlink($fRencana.$foto_file);

	$sql="delete from doc_rencana where id='$par[id]'";
	db($sql);
	echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
}
?>
