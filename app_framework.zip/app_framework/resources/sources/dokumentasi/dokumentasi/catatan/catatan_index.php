<?php
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\Note\DocRencana;
use App\Models\Note\DocFile;
use App\Models\Note\CatatanSistem;

global $s,$access,$par;
$fFoto = "files/catatan/catatan/";
$fRencana = "files/dokumentasi/rencana/";

switch($par['mode']){
	case "add":
		if(isset($access['add']))
			include 'catatan_edit.php';		
		else
			include "catatan_list.php";
		break;

	case 'del':
		if (isset($access["delete"]))
			deleteData();
		else
			include 'catatan_list.php';
		break;

	case 'delDok':
		if (isset($access["delete"]))
			hapusDoc();
		else
			include 'catatan_list.php';
		break;

	case "delFoto":
		if(isset($access['delete']))
			hapusFoto();
		else
			include 'catatan_list.php';		
		break;

	case "tambahFile":
		if(isset($access["add"])) empty($_submit) ? formFile() : tambahFile(); else include "catatan_list.php";
		break;

	case "editDoc":
		if(isset($access["edit"])) empty($_submit) ? formFile() : ubahFile(); else include "catatan_list.php";
		break;


	case "edit":
		if(isset($access['edit']))
			include 'catatan_edit.php';		
		else
			include "catatan_list.php";
		break;

	default:
		include 'catatan_list.php';
		break;
}



function deleteData(){
	global $par;

    DB::beginTransaction();

    try {

        $delete = CatatanSistem::find($par["idCatatan"]);

        $storage = Storage::disk("storages");

        if ($storage->exists($delete->file)) {
            $storage->delete($delete->file);
        }

        $delete->delete();

        DB::commit();

        echo "<script>alert('Catatan berhasil dihapus')</script>";
		echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,idCatatan")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Catatan gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}



function hapusFoto() {
	global $s, $inp, $par, $dFile, $cUsername, $fFoto;
	$file = getField("SELECT File FROM catatan_sistem WHERE idCatatan='$par[idCatatan]'");
	if (file_exists($fFoto . $file) and $file != "")
		unlink($fFoto . $file);
	$sql = "UPDATE catatan_sistem SET File = '' WHERE idCatatan='$par[idCatatan]'";
	db($sql);
	echo "
	<script>
		window.parent.location = 'index.php?par[mode]=edit&par[idCatatan]=$par[idCatatan]".getPar('idCatatan')."';
	</script>";		
}


function formFile(){
	global $par;

    $doc_files = DocFile::find($par['idDoc']);
	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">
		<form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
            onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
            autocomplete="off">					
			<p style="position:absolute;right:5px;top:5px;">
				<?= Layout::formBtnSubmit(true) ?>
			</p>
			<div id="general" class="subcontent">
				<?php
					Form::inputLabelText('Nama File', 'nama_file', $doc_files->nama_file);
					Form::inputLabelDocument("File", "file", $doc_files->file, false, "l-input-small", "*");
					Form::inputLabelText('Keterangan', 'keterangan', $doc_files->keterangan);
				?>
			</div>
		</form>
	</div>
	<?php
}

function tambahFile(){
	global $par, $user, $request;

    DB::beginTransaction();
	// DB::enableQueryLog();
    try {
        DocFile::create([
            'id_rencana' => $par['idCatatan'],
            'nama_file' => $request->nama_file,
			'file' => $request->file("file") ? $request->file("file")->store(DocFile::$path_file, ["disk" => "storages"]) : "",
            'keterangan' => $request->keterangan,
            'created_by' => $user->id,
            'updated_by' => $user->id,
        ]);

		//dd($order->getQueryLog())
        DB::commit();

	
        echo "<script>alert('Data File berhasil disimpan')</script>";
		echo "<script>closeBox()</script>";
		// echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

		// dd($e);
        // echo "<script>alert('Data gagal disimpan')</script>";
    }

	echo "<script>closeBox()</script>";
}

function ubahFile(){
	global $s, $inp, $par, $cUsername, $arrParam;
	$inp[file] = uploadDok($par[idDoc]);
	$sql = "update doc_file set namaFile = '$inp[namaFile]', file = '$inp[file]', keterangan = '$inp[keterangan]', updated_by = '$cUsername', updateDate = '".date('Y-m-d H:i:s')."' where id = '$par[idDoc]'";
	db($sql);
	
	echo "<script>alert('UPDATE DATA BERHASIL');closeBox();reloadPage();</script>";
}

function uploadDok($id) {
	global $s, $inp, $par, $fRencana;
	$fileUpload = $_FILES["file"]["tmp_name"];
	$fileUpload_name = $_FILES["file"]["name"];
	if (($fileUpload != "") and ( $fileUpload != "none")) {
		fileUpload($fileUpload, $fileUpload_name, $fRencana);
		$foto_file = "rencana_dok-" . time() . "." . getExtension($fileUpload_name);
		fileRename($fRencana, $fileUpload_name, $foto_file);
	}
	if (empty($foto_file))
		$foto_file = getField("select file from doc_file where id ='$id'");

	return $foto_file;
}

function hapusDok() {
	global $s, $inp, $par, $fRencana, $cUsername;

	$foto_file = getField("select file from doc_file where id='$par[idDoc]'");
	if (file_exists($fRencana . $foto_file) and $foto_file != "")
		unlink($fRencana . $foto_file);

	$sql = "delete from doc_file where id='$par[idDoc]'";
	db($sql);

	echo "<script>window.location='?par[mode]=editDoc" . getPar($par, "mode,idDoc") . "';</script>";
}

function uploadFile($id) {
	global $s, $inp, $par, $fRencana;
	$fileUpload = $_FILES["file"]["tmp_name"];
	$fileUpload_name = $_FILES["file"]["name"];
	if (($fileUpload != "") and ( $fileUpload != "none")) {
		fileUpload($fileUpload, $fileUpload_name, $fRencana);
		$foto_file = "rencana-" . time() . "." . getExtension($fileUpload_name);
		fileRename($fRencana, $fileUpload_name, $foto_file);
	}
	if (empty($foto_file))
		$foto_file = getField("select file from doc_rencana where id ='$id'");

	return $foto_file;
}

function hapusFile() {
	global $s, $inp, $par, $fRencana, $cUsername;

	$foto_file = getField("select file from doc_rencana where id='$par[id]'");
	if (file_exists($fRencana . $foto_file) and $foto_file != "")
		unlink($fRencana . $foto_file);

	$sql = "update doc_rencana set file='' where id='$par[id]'";
	db($sql);

	echo "<script>window.location='?par[mode]=edit" . getPar($par, "mode") . "';</script>";
}

function hapusDoc(){
	global $s,$inp,$par,$fRencana,$cUsername;
	$foto_file = getField("select file from doc_file where id='$par[idDoc]'");
	if(file_exists($fRencana.$foto_file) and $foto_file!="")unlink($fRencana.$foto_file);

	$sql="delete from doc_file where id='$par[idDoc]'";
	db($sql);
	echo "<script>window.location='?par[mode]=edit&par[idCatatan]=$par[idCatatan]" . getPar($par, "mode,idDoc,id") . "';</script>";
}

?>