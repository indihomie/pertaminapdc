<?php
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\Note\DocRencana;
use App\Models\Note\DocFile;
use App\Models\Note\CatatanSistem;
use App\Models\AppUser;
use App\Models\AppMasterCategory;


global $s, $par, $arrTitle, $arrParameter, $accesss, $cUsername,$cNama,$cNickname;
	if (isset($_POST["btnSimpan"])) {
		switch ($par[mode]) {
			case "add":
				save('insert');
				die();
			break;

			case "edit":
				save('update');
				die();
			break;
		}
	}

	// $arrNama = arrayQuery("select username, nickName from app_users");
	$catatan_sistem = CatatanSistem::find($par['idCatatan']);
	$app_master_category = AppMasterCategory::query()->select(["id", "name"])->where("module_id", "=", "19")->orderBy("order")->get()->toArray();


	// $sql = "SELECT * FROM catatan_sistem WHERE idCatatan = '$par[idCatatan]'";
	// // echo $sql;
	// $res = db($sql);
	// $r = mysql_fetch_array($res);

	//$fil = empty($r[propinsiToko]) ? "" : "and kodeInduk = '$r[propinsiToko]'";

	// $true_y = $catatan_sistem->testing == '0' ? "checked" : "";
	if($catatan_sistem->testing == '0'){
		$true_y = 'checked';
	}
	if($catatan_sistem->testing == '1'){
		$true_n = 'checked';
	}

	if (empty($catatan_sistem->testing)) {
		$default = 'checked';
	}

	if ($catatan_sistem->status == '0') {
		$e_true = 'checked';
	}
	if ($catatan_sistem->status == '1') {
		$f_true = 'checked';
	}
	if ($catatan_sistem->status == '2') {
		$g_true = 'checked';
	}
	if (empty($catatan_sistem->status)) {
		$default_status = 'checked';
	}

	if (empty($catatan_sistem->tanggal_mulai)) {
		$catatan_sistem->tanggal_mulai = date("d/m/Y");
	} else {
		$catatan_sistem->tanggal_mulai = getTanggal($catatan_sistem->tanggal_mulai);
	}

	if (empty($catatan_sistem->tanggal_selesai)) {
		$catatan_sistem->tanggal_selesai = date('d/m/Y');
	} else {
		$catatan_sistem->tanggal_selesai = getTanggal($catatan_sistem->tanggal_selesai);
	}

	if (empty($catatan_sistem->tanggal_test)) {
		$catatan_sistem->tanggal_test = date('d/m/Y');
	} else {
		$catatan_sistem->tanggal_test = getTanggal($catatan_sistem->tanggal_test);
	}

	if (empty($catatan_sistem->tanggal)) {
		$catatan_sistem->tanggal = date('d/m/Y');
	} else {
		$catatan_sistem->tanggal = $catatan_sistem->tanggal;
	}
	setValidation("is_null", "Temuan", "Anda belum mengisi Temuan");
	setValidation("is_null", "Penjelasan", "Anda belum mengisi Penjelasan");
	setValidation("is_null", "tanggal_mulai", "Anda belum memilih Tanggal Mulai");
	setValidation("is_null", "tanggal_selesai", "Anda belum memilih Tanggal Selesai");

	setValidation("is_null", "tanggal_test", "Anda belum memilih Tanggal Test");
	echo getValidation();

	$r[created_by] = empty($r[created_by]) ? $cUsername : $r[created_by];
	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">
	<form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
            onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
            autocomplete="off">

			<input type="hidden" name="_token" value="<?= csrf_token() ?>">
				
			<p style="position:absolute;right:5px;top:5px;">
            	<?= Layout::formBtnSubmit() ?>
			</p>
			<ul class="hornav">
				<li class="current"><a href="#tabCatatan">CATATAN</a></li>
				<li><a href="#tabDokumen">DOKUMEN</a></li>
			</ul>
			<div id="tabCatatan" class="subcontent" style="display: block;">
				<?php 
					Form::inputLabelDatePicker('Tanggal', 'tanggal', $catatan_sistem->tanggal);
					// Form::inputLabelText('Nama', 'created_by', $catatan_sistem->created_by, false, "l-input-small","mediuminput","","","readonly");
					Form::inputLabelText('Judul', 'temuan', $catatan_sistem->temuan);
					Form::inputLabelText('Penjelasan', 'penjelasan', $catatan_sistem->penjelasan);

					$queryKategori = "SELECT * from app_masters where kodeCategory='KC' and statusData='t' order by `order`";
					Form::inputLabelSelectArray("Kategori", "id_kategori", $app_master_category, "id", "name", $catatan_sistem->kategori_catatan);
					// Form::inputLabelSelect('Kategori', $queryKategori, "kodeData", "namaData", "kategori_catatan", $catatan_sistem->kategori_catatan);
					Form::inputLabelDocument("File", "file", $catatan_sistem->file, false, "l-input-small", "*");

				?>
			</div>

			<div id="tabDokumen" class="subcontent" style="display: none;">
				<div class="title" >
					<p style="float:right;">
					<?php
					if(empty($par['idCatatan'])){
					?>
						<a onclick="alert('Silahkan klik tombol SIMPAN terlebih dahulu');" href="#" class="btn btn1 btn_document"><span>Tambah Data</span></a>
					<?php
					}else{
					?>
						<a onclick="openBox('popup?par[mode]=tambahFile<?= getPar($par,'mode')?>',725,300);" href="#" class="btn btn1 btn_document"><span>Tambah Data</span></a>
					<?php
					}
					?>
					</p>
				</div>
				<br clear="all"/>
				<table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="dyntables">
					<thead>
						<tr>
							<th width="20">No.</th>
							<th width="*">Dokumen</th>
							<th width="50">View</th>
							<th width="50">DL</th>
							<th width="100">Upload</th>
							<th width="100">User</th>
							<th width="80">Size</th>
							<th width="50">Kontrol</th>
						</tr>
					</thead>
					<tbody>
					<?php
							$files_rencana = DocFile::where('id_rencana', $par['idCatatan'])->get();
							$no=0;
							foreach ($files_rencana as $r) {
								$no++;
									$controlIcon = "<a href=\"#\" onclick=\"openBox('view?doc=fileDoc&par[idDoc]=$r->id".getPar($par,"mode")."',725,500);\" class=\"detail\"><span>Detail</span></a>";
									$controlKebutuhan = "";
									if (isset($access["edit"])) {
										$controlKebutuhan .= "<a onclick=\"openBox('popup?par[mode]=editDoc&par[idDoc]=$r->id".getPar($par,"mode, idDoc")."',725,300);\" href=\"#\" title=\"Edit Data\" class=\"edit\"><span>Edit</span></a>";
									}
									if(isset($access["delete"])){
										$controlKebutuhan.= "<a href=\"?par[mode]=delDok&par[idDoc]=$r->id".getPar($par,"mode,idDoc")."\" onclick=\"return confirm('are you sure to DELETE data ?');\" title=\"delete Data\" class=\"delete\"><span>DELETE</span></a></td>";
									} ?>
									<tr>
										<td><?= $no; ?></td>
										<td><?= $r->nama_file; ?></td>
										<td><?= $controlIcon; ?></td>
										<td><?= $controlIcon; ?></td>
										<td><?= getTanggal($r->tanggal); ?></td>
										<td><?= $r->created_by; ?></td>
										<td><?= getFileSize($r->file); ?></td>
										<td><?= $controlKebutuhan; ?></td>
									</tr>									
							<?php }
						?>
						</tbody>
					</table>
			</div>
			<br>
			<fieldset>
				<legend>PENYELESAIAN</legend>
				<p>
					<table style="width:100%">
						<tr>
							<td width="50%">
								<label class="l-input-small" style="width:40%">Tanggal Mulai</label>
								<div class="field">
									<input type="text" id="tanggal_mulai" name="tanggal_mulai" class="smallinput hasDatePicker" value="<?= $catatan_sistem->tanggal_mulai ?>"/>
								</div>
							</td>

							<td width="50%">
								<label>Target Selesai</label>
								<div class="field">
									<input type="text" id="tanggal_selesai" name="tanggal_selesai" class="smallinput hasDatePicker" value="<?= $catatan_sistem->tanggal_selesai ?>"/>
								</div>
							</td>
						</tr>
					</table>
				</p>
				<p>
					<table style="width:100%">
						<tr>
							<td width="50%">
								<label class="l-input-small" style="width:40%">PIC</label>
								<div class="field">
									<input type="text" id="pic" name="pic" class="smallinput" value="<?= $catatan_sistem->pic ?>"/>
								</div>
							</td>

							<td width="50%">
								<label>Target Aktual</label>
								<div class="field">
									<input type="text" id="tanggal_aktual" name="tanggal_aktual" class="smallinput hasDatePicker" value="<?= getTanggal($catatan_sistem->tanggal_aktual) ?>"/>
								</div>
							</td>
						</tr>
					</table>
				</p>
				<?php
						Form::inputLabelTextArea('Keterangan', 'keterangan', $doc_rencanas->keterangan);			
				?>
				<p>
					<table style="width:100%">
						<tr>
							<td width="50%">
								<label class="l-input-small" style="width:40%">Testing</label>
								<div class="field">
									<div class="sradio" style="padding-top:5px;padding-left:8px;">
										<input type="radio" name="testing" value="0" <?= $true_y." ".$default ?>> <span style="padding-right:10px;">Belum</span>
										<input type="radio" name="testing" value="1" <?= $true_n ?>> <span style="padding-right:10px;">Sudah</span>
									</div>
								</div>
							</td>
							<td width="50%">
								<label>Tanggal Test</label>
								<div class="field">
									<input type="text" id="tanggal_test" name="tanggal_test" class="smallinput hasDatePicker" value="<?= $catatan_sistem->tanggal_test ?>"/>
								</div>
							</td>
						</tr>
					</table>
				</p>
				<p>
					<label class="l-input-small">Status</label>
					<div class="field">
						<div class="sradio" style="padding-top:5px;padding-left:8px;">
							<input type="radio" name="status" value="0" <?= $e_true." ".$default_status ?>> <span style="padding-right:10px;">Belum</span>
							<input type="radio" name="status" value="1" <?= $f_true ?>> <span style="padding-right:10px;">Selesai</span>
							<input type="radio" name="status" value="2" <?= $g_true ?>> <span style="padding-right:10px;">Pending</span>
						</div>
					</div>
				</p>
			</fieldset>
			<br>
			<?php if ($par[mode] != "add") { ?>
			<fieldset>

				<legend>HISTORY</legend>

				<table style="width: 100%">
					<tr>
						<td width="50%">
							<label class="l-input-small" style="width:50%">Input Date</label>
							<span class="field"><?= $catatan_sistem->created_at ?> &nbsp;</span>
						</td>
						<td width="50%">
							<label class="l-input-small">Input By</label>
							<?php
								$user_create = AppUser::find($catatan_sistem->created_by);
							?>
							<span class="field"><?= $user_create->name; ?> &nbsp;</span>
						</td>
					</tr>
				</table>

				<table style="width: 100%">
					<tr>
						<td width="50%">
							<label class="l-input-small" style="width:50%">Update Date</label>
							<span class="field"><?= $catatan_sistem->updated_at ?> &nbsp;</span>
						</td>
						<td width="50%">
							<label class="l-input-small">Update By</label>
							<?php
								$user_update = AppUser::find($catatan_sistem->updated_by);
							?>
							<span class="field"><?= $user_update->name; ?> &nbsp;</span>
						</td>
					</tr>
				</table>

			</fieldset>
			<?php } ?>
		</form>
	</div>
<?php



function save($params = ""){
	global $par, $user, $request;

	if ($params == "insert") {
		DB::beginTransaction();
		// DB::enableQueryLog();
		try {
			CatatanSistem::create([
				'kategori_catatan' => $request->kategori_catatan ?? "",
				'nomor' => $request->nomor ?? "",
				'tanggal' => setTanggal($request->tanggal),
				'temuan' => $request->temuan,
				'penjelasan' => $request->penjelasan,
				'tanggal_mulai' => setTanggal($request->tanggal_mulai),
				'tanggal_selesai' => setTanggal($request->tanggal_selesai),
				'tanggal_aktual' => setTanggal($request->tanggal_aktual),
				'pic' => $request->pic,
				'keterangan' => $request->keterangan,
				'testing' => $request->testing,
				'tanggal_test' => setTanggal($request->tanggal_test),
				'status' => $request->status,
				'file' => $request->file("file") ? $request->file("file")->store(CatatanSistem::$path_file, ["disk" => "storages"]) : "",
				'approve' => $request->approve ?? "",
				'approve_ket' => $request->approve_ket ?? "",
				'created_by' => $user->id,
				'updated_by' => $user->id,
				'approve_by' => $user->id,
			]);

			//dd($order->getQueryLog())
			DB::commit();

		
			echo "<script>alert('Data berhasil disimpan')</script>";
			echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
			// echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
		} catch (Exception $e) {

			DB::rollBack();
			Log::error($e);

			// dd($e);
			echo "<script>alert('Data gagal disimpan')</script>";
    	}
		echo "<script>closeBox()</script>";
	}else{
		DB::beginTransaction();
		try {
			$update = CatatanSistem::find($par['idCatatan']);
			$update->update([
				'kategori_catatan' => $request->kategori_catatan ?? "",
				'nomor' => $request->nomor ?? "",
				'tanggal' => setTanggal($request->tanggal),
				'temuan' => $request->temuan,
				'penjelasan' => $request->penjelasan,
				'tanggal_mulai' => setTanggal($request->tanggal_mulai),
				'tanggal_selesai' => setTanggal($request->tanggal_selesai),
				'tanggal_aktual' => setTanggal($request->tanggal_aktual),
				'pic' => $request->pic,
				'keterangan' => $request->keterangan,
				'testing' => $request->testing,
				'tanggal_test' => setTanggal($request->tanggal_test),
				'status' => $request->status,
				'file' => $request->file("file") ? $request->file("file")->store(CatatanSistem::$path_file, ["disk" => "storages"]) : "",
				'approve' => $request->approve ?? "",
				'approve_ket' => $request->approve_ket ?? "",
				'updated_by' => $user->id,
				'approve_by' => $user->id,
			]);

			if ($request->file("file") || $request->file) {

				$storage = Storage::disk("storages");

				if ($storage->exists($update->file)) {
					$storage->delete($update->file);
				}

				$update->update([
					"file" => ""
				]);
			}

			if ($request->file("file")) {
				$update->update([
					"file" => $request->file("file")->store(CatatanSistem::$path_file, ["disk" => "storages"])
				]);
			}

			DB::commit();
			echo "<script>alert('Data berhasil diubah')</script>";
			echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
			// echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

		} catch (Exception $e) {

			DB::rollBack();
			Log::error($e);

			echo "<script>alert('Data gagal diubah')</script>";
		}
    echo "<script>closeBox()</script>";
	}
}
?>
