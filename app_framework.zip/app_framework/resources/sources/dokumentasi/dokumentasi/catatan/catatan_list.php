<?php
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\Note\DocRencana;
use App\Models\Note\DocFile;
use App\Models\Note\CatatanSistem;

function hapus(){
	global $par;

    DB::beginTransaction();

    try {

        $delete = CatatanSistem::find($par["idCatatan"]);

        $storage = Storage::disk("storages");

        if ($storage->exists($delete->file)) {
            $storage->delete($delete->file);
        }

        $delete->delete();

        DB::commit();

        echo "<script>alert('Catatan berhasil dihapus')</script>";
		echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,idCatatan")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Catatan gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}	

function lihat(){
	global $par,$access;		

	if(isset($access["edit"]) || isset($access["delete"])) {
		datatable(9, array(6, 7));
	} else{
		datatable(8, array(6, 7));
	}
	
	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">
		<form action="" method="post" class="stdform" onsubmit="return false;">
			<div id="pos_l" style="float:left">
				<input type="text" id="fSearch" name="fSearch" value="<?= $par['filterData'] ?>" style="width:200px;"/></td>
			</div>
			<div id="pos_r">		
				<?php		
				if(isset($access["add"])) 
					echo "<a href=\"?par[mode]=add".getPar($par,"mode")."\" class=\"btn btn1 btn_document\" ><span>Tambah Data</span></a>";
				?>
			</div>

			</form>
			<br clear="all" />
			<table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="table">
				<thead>
					<tr>
						<th width="20">No.</th>
						<th width="100">Tanggal</th>
						<th width="*">Catatan</th>
						<th width="100">User</th>
						<th width="100">PIC</th>
						<th width="100">RENCANA</th>
						<th width="100">SELESAI</th>
						<th width="50">STATUS</th>
						<?php
							if(isset($access["edit"]) || isset($access["delete"])) {						
								echo "<th width=\"75\">Control</th>";
							}
						?>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
			</div>
	<?php	
}

function datas(){
	global $par,$access;
	global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

	// DB::enableQueryLog();

	$arr_order = array(
		"id",
		"tanggal",
		"temuan",
		"created_by",
		"pic",	
		"tanggal_mulai",
		"tanggal_selesai",
		"status"
	);


	$q_order = $arr_order[$iSortCol_0];
    $q_sort = $iSortCol_0 > 0 ? $sSortDir_0 : 'desc';

	$q_filter = "1 = 1";
    $q_filter .= $search ? " AND (temuan LIKE '%{$search}%' OR penjelasan LIKE '%{$search}%')" : "";

	$catatan_sistem = CatatanSistem::selectRaw("*")
	->whereRaw($q_filter);

	$count = $catatan_sistem->count();

	$catatan_sistem = $catatan_sistem->orderBy($q_order, $q_sort);

    if ($iDisplayLength > 0) {
        $catatan_sistem->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $catatan_sistem = $catatan_sistem->get();

    $json = array(
			"iTotalRecords" => $catatan_sistem->count(),
			"iTotalDisplayRecords" => $count,
			"aaData" => array(),
    );

	// dd(DB::getQueryLog());
	$no=intval($iDisplayStart);
	foreach($catatan_sistem as $catatan) {
		$no++;
		switch ($catatan['status']) {
			case '1':
				$status = "<img src=\"styles/images/t.png\" title=\"Selesai\">";
				break;
			
			case '2':
				$status = "<img src=\"styles/images/o.png\" title=\"Pending\">";
				break;
			
			default:
				$status = "<img src=\"styles/images/f.png\" title=\"Belum\">";
				break;
		}

		$controlEmp="";

		if(isset($access["edit"]))
			$controlEmp.="<a href=\"?par[mode]=edit&par[idCatatan]=$catatan->id".getPar($par,"mode,idCatatan")."\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";				
		if(isset($access["delete"]))
			$controlEmp.="<a href=\"?par[mode]=del&par[idCatatan]=$catatan->id".getPar($par,"mode,idCatatan")."\" onclick=\"return confirm('are you sure to delete data ?');\" title=\"Delete Data\" class=\"delete\" ><span>Delete</span></a>";				

		$data=array(
			"<div align=\"center\">".$no.".</div>",				
			"<div align=\"left\">".getTanggal($catatan['tanggal'])."</div>",
			"<div align=\"left\">".$catatan['temuan']."</div>",
			"<div align=\"left\"> - </div>",
			"<div align=\"left\">".$catatan['pic']."</div>",
			"<div align=\"center\">".getTanggal($catatan['tanggal_mulai'])."</div>",
			"<div align=\"center\">".getTanggal($catatan['tanggal_selesai'])."</div>",
			"<div align=\"center\">".$status."</div>",
			"<div align=\"center\">".$controlEmp."</div>",
		);

		$json['aaData'][]=$data;
	}
	return json_encode($json);
}

function getContent($par){
	global $s,$_submit,$access;
	switch($par['mode']){
		case "datas":
			echo datas();
			break;

		case "del":
			hapus();
			break;

		default:
			echo lihat();
			break;
	}
}	
?>