<?php

use App\Models\AppMaster;
use App\Models\AppModule;
use App\View\Components\Layout;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

function getContent($par)
{
    global $s, $_submit, $access;

    switch ($par['mode']) {
        case 'edit':
            if ($access['edit']) {
                $_submit ? update() : form();
            } else {
                echo 'Tidak ada akses';
            }

        break;

        case 'export_menuchecklist':
            exportMenuchecklist();

            break;

        default:
            index();

        break;
    }
}

function index()
{
    global $par, $access;

    $module_categories = AppMaster::select(['id', 'name'])->where('category_id', 'S001')->orderBy('order')->get();

    Layout::title(); ?>
<div id="contentwrapper" class="contentwrapper">
    <form method="post" id="form" class="stdform" onsubmit="return false;">
        <div class="filter_container">
            <div class="filter_left">
                <p>
                    <?php echo selectArray('par[filter_category_id]', '', $module_categories, 'id', 'name', $_SESSION['filter_category_id'], '- Pilih Kategori -'); ?>
                    <input type="submit" value="Cari" class="btn btn_search btn-small" />
                </p>
            </div>
            <div class="filter_right">
                <a href="?par[mode]=xls<?php echo getPar($par, 'mode'); ?>" class="stdbtn"><i
                        class="fas fa-file-export"></i></i>&emsp;EXPORT</a>
            </div>
        </div>
    </form>
    <table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="">
        <thead>
            <tr>
                <th rowspan="2" style="vertical-align:middle" width="20">No.</th>
                <th rowspan="2" style="vertical-align:middle" width="*">Modul</th>
                <th rowspan="2" style="vertical-align:middle" width="100">Jumlah Menu</th>
                <th rowspan="2" style="vertical-align:middle" width="50">Doc</th>
                <th colspan="2" width="100">Pelaksanaan</th>
                <th rowspan="2" style="vertical-align:middle" width="90">SIZE</th>
                <th rowspan="2" style="vertical-align:middle" width="150">Update</th>
                <th rowspan="2" style="vertical-align:middle" width="50">Kontrol</th>
            </tr>
            <tr>
                <th width="50">View</th>
                <th width="50">D/L</th>
            </tr>
        </thead>
        <tbody>
            <?php

        $modules = AppModule::whereNotNull('id')
            ->where('name', '!=', 'Setting')
            ->with('category')
            ->with(
                ['moduleSubs' => function ($query) {
                    $query->where('name', '!=', 'Setting');
                }]
            )
            ->withCount(['menus' => function ($query) {
                $query->where('target', 'NOT LIKE', '%setting%')->where('target', '!=', '');
            }])
            ->with(['menuchecklist'])
            ->when($par['filter_category_id'], function ($query, $category_id) {
                $query->where('category_id', $category_id);
            })
            ->when($par['search'], function ($query, $search) {
                $query->where('name', 'LIKE', "%{$search}%");
            })
            ->orderBy('order')->get();

    $no = 0;
    foreach ($modules as $module) {
        $count_category = AppModule::where('category_id', $module['category_id'])->count();
        ++$no;
        if (1 == $no) {
            if (!empty($module['category'])) {
                ?>
            <tr>
                <td style="background-color:#e9e9e9"></td>
                <td colspan="8" style="background-color:#e9e9e9">
                    <?php echo strtoupper($module['category']['name']); ?>
                </td>
            </tr>
            <?php
            }
        } elseif ($no == $count_category + 1) {
            if (!empty($module['category'])) {
                ?>
            <tr>
                <td style="background-color:#e9e9e9"></td>
                <td colspan="8" style="background-color:#e9e9e9">
                    <?php echo strtoupper($module['category']['namaData']); ?>
                </td>
            </tr>
            <?php
            }

            $count_category += $count_category;
        }

        if (isset($access['edit'])) {
            $control = "<a onclick=\"openBox('popup.php?par[mode]=edit&par[module_id]={$module['module_id']}&par[id]={$module['id']}".getPar($par, 'mode, id')."',825,400);\" href=\"#\" title=\"Edit Data\" class=\"edit\"><span>Edit</span></a>";
        }

        if (empty($module['path_file'])) {
            $module['download'] = '-';
            $module['view'] = '-';
            $module['size'] = '-';
        } else {
            $module['download'] = "<a href=\"download.php?d=fileChecklist&f={$module['id']}\"><img src=\"".getIconExtension($module['path_file']).'" align="center"
                    style="padding-right:5px; padding-bottom:5px; max-width:20px; max-height:20px;"></a>';
            $module['view'] = "<a href=\"#\"
                onclick=\"openBox('view.php?doc=fileChecklist&par[id]={$module['id']}".getPar($par, 'mode')."',725,500);\"
                class=\"detail\"><span>Detail</span></a>";
            $module['size'] = getSizeFile($module['path_file']);
        } ?>
            <tr>
                <td align="center"><?php echo $no; ?></td>
                <td><?php echo $module['name']; ?></td>
                <td align="center"><?php echo $module['menus_count']; ?></td>
                <td align="center"><a href="#" onclick="export_menuchecklist('<?php echo $module['id']; ?>');"><img
                            src="assets/images/extensions/xls.png" align="center"
                            style="padding-right:5px; padding-bottom:5px; max-width:20px; max-height:20px;"></a></td>
                <td align="center"><?php echo $module['view']; ?></td>
                <td align="center"><?php echo $module['download']; ?></td>
                <td align="center"><?php echo $module['size']; ?></td>
                <td align="center"><?php echo $module['size']; ?></td>
                <td align="center"><?php echo $control; ?></td>
            </tr>
            <?php
    } ?>
        </tbody>
    </table>
</div>
<script>
jQuery("#btnExport").live('click', function(e) {
    e.preventDefault();
    window.location.href = "?par[mode]=xls2" + "<?php echo getPar($par, 'mode, id'); ?>" +
        "&par[id]=<?php echo $par['modul']; ?>";
});
</script>
<script>
function export_menuchecklist(module_id) {
    taskBackground(
        `<?php echo getPar($par, 'mode, module_id'); ?>&par[mode]=export_menuchecklist&module_id=${module_id}`)
}

function exports() {

    let search = jQuery("#search").val()
    let module_id = jQuery("#change_1").val()

    taskBackground(`<?php echo getPar($par, 'mode'); ?>&par[mode]=export&change_id=${module_id}&search=${search}`)
}
</script>
<?php
    $sekarang = date('Y-m-d');
    if ('xls' == $par['mode']) {
        xls();
        echo '<iframe src="download.php?d=exp&f=DATA CHECKLIST '.$sekarang.'.xls" frameborder="0" width="0" height="0"></iframe>';
    }

    if ('xls2' == $par['mode']) {
        xls2();
        echo '<iframe src="download.php?d=exp&f=XLS CHECKLIST '.$sekarang.'.xls" frameborder="0" width="0" height="0"></iframe>';
    }
}

function xls()
{
    global $db,$par,$arrTitle,$arrIcon,$cName,$menuAccess,$fExport,$cUsername,$s,$cID,$areaCheck;

    require_once 'plugins/PHPExcel.php';
    $sekarang = date('Y-m-d');

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator($cName)
        ->setLastModifiedBy($cName)
        ->setTitle($arrTitle[''.$_GET[p].''])
;
    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);

    $objPHPExcel->getActiveSheet()->mergeCells('A1:F1');
    $objPHPExcel->getActiveSheet()->mergeCells('A2:F2');
    $objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
    $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->setCellValue('A1', 'REKAP CHECKLIST');
    $objPHPExcel->getActiveSheet()->setCellValue('A2', 'TANGGAL : '.date('Y-m-d H:i:s'));

    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:F4')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->setCellValue('A4', 'No.');
    $objPHPExcel->getActiveSheet()->setCellValue('B4', 'MODUL');
    $objPHPExcel->getActiveSheet()->setCellValue('C4', 'JML MENU');
    $objPHPExcel->getActiveSheet()->setCellValue('D4', 'UPLOAD');
    $objPHPExcel->getActiveSheet()->setCellValue('E4', 'USER');
    $objPHPExcel->getActiveSheet()->setCellValue('F4', 'STATUS');

    $rows = 5;

    $sql = " SELECT t1.*,t2.id,t2.file FROM app_modules t1 left join doc_menuchecklist t2 on t1.module_id = t2.module_id
where t1.name !='Setting' order by order asc";

    $res = db($sql);
    $arrNama = arrayQuery('select username, nickName from app_users');

    while ($r = mysql_fetch_array($res)) {
        ++$no;
        $tanggalCreate = getField("SELECT createDate from doc_menuchecklist where module_id = '{$r['module_id']}'");

        $r[jumlahMenu] = getField("select count(kodeMenu) from app_menus where module_id = '{$r['module_id']}'");

        $objPHPExcel->getActiveSheet()->getStyle('A'.$rows)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('C'.$rows)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$rows)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('E'.$rows)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('F'.$rows)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $objPHPExcel->getActiveSheet()->getStyle('A'.$rows.':F'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
        $r[status] = empty($r[file]) ? 'Belum' : 'Sudah';
        if (!empty($r[file])) {
            $objPHPExcel->getActiveSheet()->getStyle('F'.$rows)->applyFromArray(
                [
                    'fill' => [
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => ['rgb' => '016f00'],
                    ],
                ]
            );
        } else {
            $objPHPExcel->getActiveSheet()->getStyle('F'.$rows)->applyFromArray(
                [
                    'fill' => [
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => ['rgb' => 'ff0000'],
                    ],
                ]
            );
        }
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$rows, $no);
        $objPHPExcel->getActiveSheet()->setCellValue('B'.$rows, $r[name]);
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$rows, $r[jumlahMenu]);
        $objPHPExcel->getActiveSheet()->setCellValue('D'.$rows, $tanggalCreate);
        $objPHPExcel->getActiveSheet()->setCellValue('E'.$rows, $arrNama[$r[created_by]]);
        $objPHPExcel->getActiveSheet()->setCellValue('F'.$rows, $r[status]);

        ++$rows;
    }
    --$rows;
    $objPHPExcel->getActiveSheet()->getStyle('A'.$rows.':F'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:A'.$rows)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('A4:A'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:B'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('C4:C'.$rows)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('C4:C'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('D4:D'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('E4:E'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F4:F'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->getStyle('A1:F'.$rows)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->getStyle('A4:F'.$rows)->getAlignment()->setWrapText(true);

    $objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE)->setFitToWidth(1)
        ->setFitToHeight(1)
;
    $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(3, 4);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setTop(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setLeft(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setRight(0.2);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setBottom(0.3);

    $objPHPExcel->getActiveSheet()->setTitle('DATA CHECKLIST');
    $objPHPExcel->setActiveSheetIndex(0);

    // Save Excel file
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save($fExport.'DATA CHECKLIST '.$sekarang.'.xls');
}

function xls2()
{
    global $db,$par,$arrTitle,$arrIcon,$cName,$menuAccess,$fExport,$cUsername,$s,$cID,$areaCheck;

    require_once 'plugins/PHPExcel.php';

    $sekarang = date('Y-m-d');

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()->setCreator($cName)
        ->setLastModifiedBy($cName)
        ->setTitle($arrTitle[''.$_GET[p].''])
;
    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(5);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(35);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(8);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);
    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(8);
    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(45);

    $objPHPExcel->getActiveSheet()->mergeCells('B1:H1');
    $objPHPExcel->getActiveSheet()->mergeCells('B2:H2');
    $objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setSize(16);

    $objPHPExcel->getActiveSheet()->getStyle('B2')->getFont()->setBold(true);

    $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->setCellValue('B1', 'CHECKLIST MENU');
    $objPHPExcel->getActiveSheet()->setCellValue('B2', 'MODUL : '.getField("select name from app_modules where module_id
='{$par['module_id']}'"));

    $objPHPExcel->getActiveSheet()->getStyle('B4:H4')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('D5:G5')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('B4:H5')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('B4:H5')->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('B4:H5')->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:H5')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:H5')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('D4:G4')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->getStyle('C5:F5')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);

    // $objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);

    // $objPHPExcel->getActiveSheet()->mergeCells('A4:A5');
    $objPHPExcel->getActiveSheet()->mergeCells('B4:B5');
    $objPHPExcel->getActiveSheet()->mergeCells('C4:C5');
    $objPHPExcel->getActiveSheet()->mergeCells('H4:H5');
    $objPHPExcel->getActiveSheet()->mergeCells('D4:G4');

    $objPHPExcel->getActiveSheet()->setCellValue('B4', 'No.');
    $objPHPExcel->getActiveSheet()->setCellValue('C4', 'MENU');
    $objPHPExcel->getActiveSheet()->setCellValue('D4', 'CHECKLIST');
    $objPHPExcel->getActiveSheet()->setCellValue('D5', 'VIEW');
    $objPHPExcel->getActiveSheet()->setCellValue('E5', 'INPUT');
    $objPHPExcel->getActiveSheet()->setCellValue('F5', 'EDIT');
    $objPHPExcel->getActiveSheet()->setCellValue('G5', 'HAPUS');
    $objPHPExcel->getActiveSheet()->setCellValue('H4', 'KETERANGAN');

    $rows = 6;

    $sql = " SELECT * from app_module_subs where module_id = '{$par['module_id']}' and namaSite != 'Setting' order by
urutanSite";

    $res = db($sql);
    while ($r = mysql_fetch_array($res)) {
        ++$no;
        $objPHPExcel->getActiveSheet()->setCellValue('C'.($rows), $r[namaSite]);
        $objPHPExcel->getActiveSheet()->setCellValue('B'.($rows), $no);

        $sql_ = "
SELECT * from app_menus where module_sub_id = '{$r['module_sub_id']}' order by kodeMenu asc
";

        $res_ = db($sql_);
        $no_anakan = 0;

        while ($r_ = mysql_fetch_assoc($res_)) {
            $r_[statusData] = $r_[statusData] > 0 ? 'Active' : 'Not Active';
            ++$no_anakan;
            $objPHPExcel->getActiveSheet()->setCellValue('C'.($rows + $no_anakan), ' '.$r_[namaMenu]);
        }
        $rows = $rows + $no_anakan;

        $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
        $objPHPExcel->getActiveSheet()->getStyle('B'.$rows)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        ++$rows;
    }
    --$rows;
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:B'.$rows)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->getStyle('A4:A'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B4:B'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('C4:C'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('D4:D'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('E4:E'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F4:F'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('G4:G'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('H4:H'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->getStyle('A1:H'.$rows)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

    $objPHPExcel->getActiveSheet()->getStyle('A4:H'.$rows)->getAlignment()->setWrapText(true);

    $rows = $rows + 2;
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('E'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->mergeCells('B'.$rows.':E'.$rows);
    $objPHPExcel->getActiveSheet()->mergeCells('F'.$rows.':H'.$rows);
    $objPHPExcel->getActiveSheet()->setCellValue('B'.$rows, 'VENDOR');
    $objPHPExcel->getActiveSheet()->setCellValue('F'.$rows, 'CLIENT');

    ++$rows;
    $rowsmax = $rows + 6;

    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':B'.$rowsmax)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':B'.$rowsmax)->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows.':E'.$rowsmax)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F'.$rowsmax)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F'.$rows.':H'.$rowsmax)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('H'.$rows.':H'.$rowsmax)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $objPHPExcel->getActiveSheet()->getStyle('F'.$rows.':F'.$rowsmax)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);

    $objPHPExcel->getActiveSheet()->mergeCells('B'.$rows.':E'.$rowsmax);
    $objPHPExcel->getActiveSheet()->mergeCells('F'.$rows.':H'.$rowsmax);

    $objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setScale(100);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_FOLIO);
    $objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(3, 4);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setTop(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setLeft(0.3);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setRight(0.2);
    $objPHPExcel->getActiveSheet()->getPageMargins()->setBottom(0.3);

    $objPHPExcel->getActiveSheet()->setTitle('DATA CHECKLIST');
    $objPHPExcel->setActiveSheetIndex(0);

    // Save Excel file
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
    $objWriter->save($fExport.'XLS CHECKLIST '.$sekarang.'.xls');
}

function form()
{
    global $s,$inp,$par,$menuAccess,$fChecklist,$cUsername,$arrTitle;

    // file_get_contents
    echo "<script>
window.parent.update('".getPar($par, 'mode')."');
</script>";
    $sql = "SELECT * FROM doc_menuchecklist t1 join app_modules t2 where t1.module_id = '{$par['module_id']}'";
    // echo $sql;
    $res = db($sql);
    $r = mysql_fetch_array($res);

    $r[name] = empty($r[name]) ? getField("select name from app_modules where module_id = '{$par['module_id']}'") :
$r[name];

    // $r[appr_div_by] = empty($r[appr_div_by]) ? $cUsername : $r[appr_div_by];

    $text .= '<div class="centercontent contentpopup">
    <div class="pageheader">
        <h1 class="pagetitle">'.$arrTitle[$s].'</h1>
        '.getBread(ucwords($par[mode].' data')).'
    </div>
    <div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1'.getPar($par)." \"
            onsubmit=\"return validation(document.form);\" enctype=\"multipart/form-data\">
            <p style=\"position:absolute;right:5px;top:5px;\">
                <input type=\"submit\" class=\"submit radius2\" name=\"btnSimpan\" value=\"Save\" onclick=\"return
                    pas();\" />
                <input type=\"button\" class=\"cancel radius2\" value=\"Cancel\" onclick=\"closeBox();\" />
            </p>
            <div id=\"general\" class=\"subcontent\">


                <p>
                    <label class=\"l-input-small\">Modul</label>
                    <span class=\"field\">{$r['name']}&nbsp;</span>
                </p>

                <p>
                    <label class=\"l-input-small\">File</label>
                <div class=\"field\">";
    $text .= empty($r[file]) ?
                    '<input type="text" id="fotoTemp" name="fotoTemp" class="input" style="width:300px;"
                        maxlength="100" />
                    <div class="fakeupload" style="width:360px;">
                        <input type="file" id="file" name="file" class="realupload" size="50"
                            onchange="this.form.fotoTemp.value = this.value;" />
                    </div>' :
                    '<img src="'.getIconExtension($r[file]).'" align="left" height="25"
                        style="padding-right:5px; padding-bottom:5px;">
                    <a href="?par[mode]=delFile'.getPar($par, 'mode')." \" onclick=\"return confirm('are you sure to
                        delete image ?')\" class=\"action delete\"><span>Delete</span></a>
                    <br clear=\"all\">";
    $text .= "
                </div>
                </p>
                <p>
                    <label class=\"l-input-small\">Keterangan</label>
                    <span class=\"fieldB\">
                        <textarea style=\"width:350px;height:50px;\" id=\"inp[keterangan]\"
                            name=\"inp[keterangan]\">{$r['keterangan']}</textarea>
                    </span>
                </p>
                <p>
                    <label class=\"l-input-small\">PIC</label>
                <div class=\"field\">
                    <input type=\"text\" id=\"inp[pic]\" name=\"inp[pic]\" value=\"{$r['pic']}\"
                        class=\"mediuminput\" />
                </div>
                </p>
            </div>



        </form>
    </div>";

    return $text;
}

function exportMenuchecklist()
{
    global $user, $request;

    $module = AppModule::with(['moduleSubs' => function ($query) {
        $query->where('name', '!=', 'Setting')->orderBy('order')->with(['menus' => function ($query) {
            $query->where('menu_id', 0)->orderBy('order')->with(['menuChilds' => function ($query) {
                $query->orderBy('order');
            }]);
        }]);
    }])->find($request['module_id']);

    $time = now()->format('Ymd His');
    $path = '_exports';
    $filename = "CHECKLIST {$module['name']} {$time}.xlsx";
    $title = "CHECKLIST {$module['name']}";
    $creator = $user->name ?? config('environment.APP_NAME');

    $spreadsheet = new Spreadsheet();

    $spreadsheet->getProperties()
        ->setCreator($creator)
        ->setTitle($title)
        ->setSubject($title)
        ->setDescription($title)
    ;

    $spreadsheet->setActiveSheetIndex(0);
    $spreadsheet->getActiveSheet()->setTitle($title);

    $spreadsheet->getActiveSheet()->getSheetView()->setZoomScale(90);
    $spreadsheet->getActiveSheet()->getPageSetup()->setScale(70);
    $spreadsheet->getActiveSheet()->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
    $spreadsheet->getActiveSheet()->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);
    $spreadsheet->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(3, 4);
    $spreadsheet->getActiveSheet()->getPageMargins()->setTop(0.3);
    $spreadsheet->getActiveSheet()->getPageMargins()->setLeft(0.3);
    $spreadsheet->getActiveSheet()->getPageMargins()->setRight(0.2);
    $spreadsheet->getActiveSheet()->getPageMargins()->setBottom(0.3);

    $spreadsheet->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $spreadsheet->getActiveSheet()->getColumnDimension('B')->setWidth(5);
    $spreadsheet->getActiveSheet()->getColumnDimension('C')->setWidth(35);
    $spreadsheet->getActiveSheet()->getColumnDimension('D')->setWidth(8);
    $spreadsheet->getActiveSheet()->getColumnDimension('E')->setWidth(8);
    $spreadsheet->getActiveSheet()->getColumnDimension('F')->setWidth(8);
    $spreadsheet->getActiveSheet()->getColumnDimension('G')->setWidth(8);
    $spreadsheet->getActiveSheet()->getColumnDimension('H')->setWidth(45);

    $spreadsheet->getActiveSheet()->mergeCells('B1:H1');
    $spreadsheet->getActiveSheet()->mergeCells('B2:C2');
    $spreadsheet->getActiveSheet()->mergeCells('B3:C3');
    $spreadsheet->getActiveSheet()->mergeCells('D2:H2');
    $spreadsheet->getActiveSheet()->mergeCells('D3:H3');
    $spreadsheet->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle('B1')->getFont()->setSize(16);

    //$spreadsheet->getActiveSheet()->getStyle('B2')->getFont()->setBold(true);
    // $spreadsheet->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);

    $spreadsheet->getActiveSheet()->setCellValue('B1', 'CHECKLIST MENU');
    $spreadsheet->getActiveSheet()->setCellValue('B2', 'MODUL          :  '.strtoupper($module['name']));
    $spreadsheet->getActiveSheet()->setCellValue('B3', 'PESERTA        : ');
    $spreadsheet->getActiveSheet()->setCellValue('D2', 'TGL.PELAKSANAAN       : ');
    $spreadsheet->getActiveSheet()->setCellValue('D3', 'LOKASI                            : ');

    $spreadsheet->getActiveSheet()->getStyle('B5:H5')->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle('D6:G6')->getFont()->setBold(true);
    $spreadsheet->getActiveSheet()->getStyle('B5:H6')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $spreadsheet->getActiveSheet()->getStyle('B5:H6')->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    $spreadsheet->getActiveSheet()->getStyle('B5:H6')->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B5:H6')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B5:H6')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('D5:G5')->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);

    $spreadsheet->getActiveSheet()->mergeCells('B5:B6');
    $spreadsheet->getActiveSheet()->mergeCells('C5:C6');
    $spreadsheet->getActiveSheet()->mergeCells('H5:H6');
    $spreadsheet->getActiveSheet()->mergeCells('D5:G5');

    $spreadsheet->getActiveSheet()->setCellValue('B5', 'NO');
    $spreadsheet->getActiveSheet()->setCellValue('C5', 'MENU');
    $spreadsheet->getActiveSheet()->setCellValue('D5', 'CHECKLIST');
    $spreadsheet->getActiveSheet()->setCellValue('D6', 'VIEW');
    $spreadsheet->getActiveSheet()->setCellValue('E6', 'INPUT');
    $spreadsheet->getActiveSheet()->setCellValue('F6', 'EDIT');
    $spreadsheet->getActiveSheet()->setCellValue('G6', 'HAPUS');
    $spreadsheet->getActiveSheet()->setCellValue('H5', 'KETERANGAN');

    $rows = 7;
    $no = 0;
    foreach ($module->moduleSubs as $module_subs) {
        ++$no;
        $spreadsheet->getActiveSheet()->setCellValue('B'.($rows), $no);
        $spreadsheet->getActiveSheet()->setCellValue('C'.($rows), $module_subs['name']);

        $spreadsheet->getActiveSheet()->getStyle('B'.($rows))->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $no_menu = 0;
        foreach ($module_subs->menus as $menu) {
            ++$rows;
            ++$no_menu;
            $menu['status'] = $menu['status'] > 0 ? 'Active' : 'Not Active';

            $spreadsheet->getActiveSheet()->setCellValue('C'.($rows), '       '.numToAlpha($no_menu).'. '.$menu['name']);

            $no_menu_child = 0;
            foreach ($menu->menuChilds as $menu_child) {
                ++$no_menu_child;
                ++$rows;
                $spreadsheet->getActiveSheet()->setCellValue('C'.($rows), '              '.numToAlpha($no_menu).".{$no_menu_child} ".$menu_child['name']);
            }
        }
        $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
        $spreadsheet->getActiveSheet()->getStyle('B'.$rows)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        ++$rows;
    }
    --$rows;
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B5:B'.$rows)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B5:B'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('C5:C'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('D5:D'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('E5:E'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('F5:F'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('G5:G'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('H5:H'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

    $spreadsheet->getActiveSheet()->getStyle('A1:H'.$rows)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
    $spreadsheet->getActiveSheet()->getStyle('A5:H'.$rows)->getAlignment()->setWrapText(true);

    $rows = $rows + 2;
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':H'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('E'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

    $spreadsheet->getActiveSheet()->mergeCells('B'.$rows.':E'.$rows);
    $spreadsheet->getActiveSheet()->mergeCells('F'.$rows.':H'.$rows);
    $spreadsheet->getActiveSheet()->setCellValue('B'.$rows, 'VENDOR');
    $spreadsheet->getActiveSheet()->setCellValue('F'.$rows, 'CLIENT');

    ++$rows;
    $rowsmax = $rows + 6;

    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':B'.$rowsmax)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':B'.$rowsmax)->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows.':E'.$rowsmax)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('B'.$rows)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('F'.$rowsmax)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('F'.$rows.':H'.$rowsmax)->getBorders()->getBottom()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('H'.$rows.':H'.$rowsmax)->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    $spreadsheet->getActiveSheet()->getStyle('F'.$rows.':F'.$rowsmax)->getBorders()->getLeft()->setBorderStyle(Border::BORDER_THIN);

    $spreadsheet->getActiveSheet()->mergeCells('B'.$rows.':E'.$rowsmax);
    $spreadsheet->getActiveSheet()->mergeCells('F'.$rows.':H'.$rowsmax);

    // Save Excel file
    $writer = new Xlsx($spreadsheet);
    $writer->save(base_path("storages/{$path}/{$filename}"));

    $file_path = encrypt("{$path}/{$filename}");

    echo '<script>parent.toggleLoader(false)</script>';
    echo "<script>window.location='public/download/{$file_path}'</script>";
}