<?php


//if(!isset($access[$s]["view"])) echo "<script>logout();</script>";
use Carbon\Carbon;
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\Note\DocRencana;
use App\Models\Note\DocFile;
use App\Models\AppMasterCategory;


$fExport = "files/export/";
$fRencana = "files/dokumentasi/rencana/";

function getContent($par){
	global $s,$_submit,$access, $par;
	switch($par[mode]){
		case "datas":
			echo lData();
		break;
		
		case "lihat":
			lihat();
		break;

		case "child_data":
			echo datasChild();
		break;

		case "view":
			echo _view();
		break;

		case "delDok":
			echo hapusDok();
		break;
	//AWAL CRUD RENCANA
		case "del":
			if ($access["delete"])
				destroy();
			else
				echo "Tidak ada akses";
			break;

		case "edit":
			if ($access["edit"])
				$_submit ? update() : form();
			else
				echo "Tidak ada akses";
			break;

		case "add":
			if ($access["add"])
				$_submit ? store() : form();
			else
				echo "Tidak ada akses";
			break;
	//AKHIR CRUD RENCANA
	//AWAL CRUD FILE RENCANA
		case "tambahFile":
			if ($access["add"])
				$_submit ? storeFile() : formFile();
			else
				echo "Tidak ada akses";
			break;
		case "editDoc":
			if ($access["edit"])
				$_submit ? updateFile() : formFile();
			else
				echo "Tidak ada akses";
			break;
		case "delDoc":
			if ($access["delete"])
				destroyFile();
			else
				echo "Tidak ada akses";
			break;
	//AKHIR CRUD FILE RENCANA
		default:
			_view();
			break;
	}
}

function lihat()
{
	global $par,$access;

	// $modul = getField("SELECT module_id from app_modules order by order asc limit 1");
	$par[modul] = empty($par[modul]) ? $modul : $par[modul];
	$par[divisi] = isset($par["divisi"]) ? $par["divisi"] : "";

	if(isset($access["edit"]) || isset($access["delete"])) {
		datatable(7, array(6, 7));
	} else{
		datatable(6, array(6, 7));
	}

	$app_master_category = AppMasterCategory::query()->select(["id", "name"])->where("category_id", "=", "KRK")->orderBy("order")->get()->toArray();


	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">
		<form action="" method="post" id = "form" class="stdform" onsubmit="return false;">
			<div id="pos_l" style="float:left;">
				<p>
					<input type="text" id="search" name="search" />
                    <?= Form::selectArray("Filter Prioritas", "change_1", $app_master_category, "id", "name", $bSearch, "- Semua Prioritas -"); ?>
				</p>
			</div>
			<div id="pos_r" style="float:right;">
			<a href="?par[mode]=xls<?= getPar($par, "mode,kodeAktifitas")?>" class="btn btn1 btn_inboxi" style="margin-left:5px;"><span>Export Data</span></a>
				<?php if(isset($access["add"])) : ?>
					<a href="?par[mode]=add<?= getPar($par,"mode")?>" class="btn btn1 btn_document"><span>Tambah Data</span></a>
				<?php endif; ?>
			</div>
		</form>
		<br clear="all" />
		<table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="table">
			<thead>
				<tr>
					<th rowspan="2" style="vertical-align:middle" width="20">No.</th>
					<th rowspan="2" style="vertical-align:middle" width="*">Aktifitas</th>
					<th colspan="2" width="100">Rencana</th>
					<th rowspan="2" style="vertical-align:middle" width="100">Aktual</th>
					<th rowspan="2" style="vertical-align:middle" width="100">Gap</th>
					<?php if(isset($access["edit"]) || isset($access["delete"])) : ?>
						<th rowspan="2" style="vertical-align:middle" width="50">Kontrol</th>
					<?php endif; ?>
				</tr>
				<tr>
					<th width="50">Mulai</th>
					<th width="50">Selesai</th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>

	<?php
	$sekarang = date('Y-m-d');
	if($par[mode] == "xls"){
		xls();
		echo"<iframe src=\"download.php?d=exp&f=DATA UAT ".$sekarang.".xls\" frameborder=\"0\" width=\"0\" height=\"0\"></iframe>";
	}
	return $text;
}

function lData(){

	global $par,$access;
	global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

	// DB::enableQueryLog();

	$arr_order = array(
		"id",
		"aktifitas",
		"tgl_mulai",
		"tgl_selesai",
		"tgl_pelaksanaan",
		"",
		""
	);

    $q_order = $arr_order[$iSortCol_0];
    $q_sort = $iSortCol_0 > 0 ? $sSortDir_0 : 'desc';


	$q_filter = "1 = 1";
    $q_filter .= $search ? " AND (aktifitas LIKE '%{$search}%' OR ket_aktifitas LIKE '%{$search}%')" : "";

    $rencanas = DocRencana::selectRaw("*")
        ->whereRaw($q_filter);

	$count = $rencanas->count();

    $rencanas = $rencanas->orderBy($q_order, $q_sort);

    if ($iDisplayLength > 0) {
        $rencanas->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $rencanas = $rencanas->get();

    $json = array(
        "iTotalRecords" => $rencanas->count(),
        "iTotalDisplayRecords" => $count,
        "aaData" => array(),
        );
		// dd(DB::getQueryLog());

	$no=intval($iDisplayStart);
	foreach($rencanas as $rencana) {
		$no++;
		$dateNow = date_create(date("Y-m-d"));
		$dateasal = date_create($rencana->tgl_pelaksanaan);
		$day = date_diff($dateNow, $dateasal);

		if($rencana->tgl_pelaksanaan == "0000-00-00"){
			$sisa = "-";
		}else{
			$sisa = $day->format("%R%a hari");
		}

		$controlKebutuhan = "";
		if (isset($access["edit"])) {
			$controlKebutuhan .= "<a href=\"?par[mode]=edit&par[id]=$rencana->id". getPar($par, 'mode, id, idDoc') . "\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";
		}
		if(isset($access["delete"])){
			$controlKebutuhan.= "<a href=\"?par[mode]=del&par[id]=$rencana->id".getPar($par,"mode,id ,idDoc")."\" onclick=\"return confirm('anda yakin akan menghapus data ini ?')\" title=\"DELETE Data\" class=\"delete\"><span>delete</span></a>";
		}

        $data=array(
			"<div align=\"center\">".$no.".</div>",
			"<div align=\"left\">$rencana[aktifitas]</div>",
			"<div align=\"left\">".getTanggal($rencana['tgl_mulai'])."</div>",
			"<div align=\"left\">".getTanggal($rencana['tgl_selesai'])."</div>",
			"<div align=\"center\">".getTanggal($rencana['tgl_pelaksanaan'])."</div>",
			"<div align=\"left\">&nbsp;".$sisa."</div>",
			"<div align=\"center\">$controlKebutuhan</div>",
		);

        $json['aaData'][]=$data;
	}

	// if($par[mode] == "xls"){
	// 	xls();
	// 	$text.="<iframe src=\"download.php?d=exp&f=DATA CHECKLIST ".$sekarang.".xls\" frameborder=\"0\" width=\"0\" height=\"0\"></iframe>";
	// }
	return json_encode($json);
}

function datasChild()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search, $change_1;


    $arr_order = [
        "",
        "nama_file",
        "file",
        "",
        "created_by",
        "",
        "",
    ];

	$doc_files = DocFile::query()
			->where("id_rencana", $par["id"]);

    $count = clone $doc_files;
	$json = array(
        "iTotalRecords" => $doc_files->count(),
        "iTotalDisplayRecords" => $count,
        "aaData" => array(),
        );

    $doc_files->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $doc_files->limit($iDisplayLength)->offset($iDisplayStart);
    }
	$no=0;
    foreach($doc_files as $doc_file) {
			$no++;

			$controlIcon = "<a href=\"#\" onclick=\"openBox('view.php?doc=fileDoc&par[idDoc]=$doc_file->id".getPar($par,"mode")."',725,500);\" class=\"detail\"><span>Detail</span></a>";
			$controlKebutuhan = "";
			if (isset($access["edit"])) {
				$controlKebutuhan .= "<a onclick=\"openBox('popup.php?par[mode]=editDoc&par[idDoc]=$doc_file->id".getPar($par,"mode, idDoc")."',725,300);\" href=\"#\" title=\"Edit Data\" class=\"edit\"><span>Edit</span></a>";
			}
			if(isset($access["delete"])){
				$controlKebutuhan.= "<a href=\"?par[mode]=delDoc&par[idDoc]=$doc_file->id".getPar($par,"mode,idDoc")."\" onclick=\"return confirm('are you sure to DELETE data ?');\" title=\"delete Data\" class=\"delete\"><span>DELETE</span></a></td>";
			}

        $data=array(
			"<div align=\"center\">".$no.".</div>",
			"<div align=\"center\">".$doc_file->nama_file."</div>",
			"<div align=\"center\">".$controlIcon."</div>",
			"<div align=\"center\">".$controlIcon."</div>",
			"<div align=\"center\">".getTanggal($doc_file->tanggal)."</div>",
			"<div align=\"center\">".$doc_file->created_by."</div>",
			"<div align=\"center\">".getFileSize($doc_file->file)."</div>",
			"<div align=\"center\">".$controlKebutuhan.".</div>",
		);
		$json['aaData'][]=$data;
	}
	return json_encode($json);
}

function form(){
	global $par;

    $doc_rencanas = DocRencana::find($par['id']);
	$app_master_category = AppMasterCategory::query()->select(["id", "name"])->where("module_id", "=", "19")->orderBy("order")->get()->toArray();

    echo getValidation();

	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
            onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
            autocomplete="off">

			<input type="hidden" name="_token" value="<?= csrf_token() ?>">

			<p style="position:absolute;right:5px;top:5px;">
            	<?= Layout::formBtnSubmit() ?>
			</p>
			<fieldset>
				<legend> RENCANA </legend>
				<?php
					Form::inputLabelText('Aktifitas', 'aktifitas', $doc_rencanas->aktifitas);
					Form::inputLabelTextArea('Keterangan Aktifitas', 'ket_aktifitas', $doc_rencanas->ket_aktifitas);
					Form::inputLabelDateTimePicker('Mulai', 'tgl_mulai', 'jam_mulai', $doc_rencanas->tgl_mulai, $doc_rencanas->jam_mulai);
					Form::inputLabelDateTimePicker('Selesai', 'tgl_selesai', 'jam_selesai', $doc_rencanas->tgl_selesai, $doc_rencanas->jam_selesai);
					
					// $queryKategori = "SELECT kodeData, namaData from app_masters where status='t' and category_id='APMC' order by `order`";
					// Form::inputLabelSelect('Kategori', $queryKategori, "kodeData", "namaData", "id_kategori", $doc_rencanas->id_kategori);
					Form::inputLabelSelectArray("Kategori", "id_kategori", $app_master_category, "id", "name", $doc_rencanas->id_kategori);
					Form::inputLabelText('PIC', 'pic', $doc_rencanas->pic);
					Form::inputLabelDocument("File", "file", $doc_rencanas->file, false, "l-input-small", "*");
				?>
			</fieldset>
			<fieldset>
				<legend> PELAKSANAAN </legend>
					<?php
						FORM::inputLabelDatePicker('Tanggal', 'tgl_pelaksanaan', $doc_rencanas->tgl_pelaksanaan);
						Form::inputLabelText('Pelaksana', 'pelaksana', $doc_rencanas->pelaksana);
						Form::inputLabelTextArea('Keterangan Pelaksanaan', 'ket_pelaksanaan', $doc_rencanas->ket_pelaksanaan);	
					?>
			</fieldset>
			<br clear="all"/>
			<div class="widgetbox">
				<div class="title" >
					<h3 style="margin-bottom: -36px;">Dokumen</h3>
					<p style="position: relative; left: 966px; bottom:-6px;">
						<?php
							if(empty($par['id'])){
								echo "<a onclick=\"alert('Silahkan klik tombol SAVE terlebih dahulu');\" href=\"#\" class=\"btn btn1 btn_document\"><span>Tambah Data</span></a>";
							}else{
								echo "<a onclick=\"openBox('popup?par[mode]=tambahFile".getPar($par,"mode")."',725,300);\" href=\"#\" class=\"btn btn1 btn_document\"><span>Tambah Data</span></a>";
							}
						?>
					</p>
				</div>



				<br clear="all"/>
				<table class="stdtable stdtablequick">
					<thead>
						<tr>
							<th width="20">No.</th>
							<th width="*">Dokumen</th>
							<th width="50">View</th>
							<th width="50">DL</th>
							<th width="100">Upload</th>
							<th width="100">User</th>
							<th width="80">Size</th>
							<th width="50">Kontrol</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$files_rencana = DocFile::where('id_rencana', $par['id'])->get();
							$no=0;
							foreach ($files_rencana as $r) {
								$no++;
									$controlIcon = "<a href=\"#\" onclick=\"openBox('view?doc=fileDoc&par[idDoc]=$r->id".getPar($par,"mode")."',725,500);\" class=\"detail\"><span>Detail</span></a>";
									$controlKebutuhan = "";
										$controlKebutuhan .= "<a onclick=\"openBox('popup?par[mode]=editDoc&par[idDoc]=$r->id".getPar($par,"mode, idDoc")."',725,300);\" href=\"#\" title=\"Edit Data\" class=\"edit\"><span>Edit</span></a>";
									
										$controlKebutuhan.= "<a href=\"?par[mode]=delDoc&par[idDoc]=$r->id".getPar($par,"mode,idDoc")."\" onclick=\"return confirm('are you sure to DELETE data ?');\" title=\"delete Data\" class=\"delete\"><span>DELETE</span></a></td>";
									?>

									<tr>
										<td><?= $no; ?></td>
										<td><?= $r->nama_file; ?></td>
										<td><?= $controlIcon; ?></td>
										<td><?= $controlIcon; ?></td>
										<td><?= getTanggal($r->tanggal); ?></td>
										<td><?= $r->created_by; ?></td>
										<td><?= getFileSize($r->file); ?></td>
										<td><?= $controlKebutuhan; ?></td>
									</tr>									
							<?php }
						?>
					</tbody>
				</table>
				<?php datatable(8, [3, 4, 8], "child_data"); ?>
			</form>
		</div>
	<?php
}


function formFile(){
	global $par;

    $doc_files = DocFile::find($par['idDoc']);
	Layout::title();
	?>
	<div id="contentwrapper" class="contentwrapper">
		<form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
            onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
            autocomplete="off">
			<input type="hidden" name="_token" value="<?= csrf_token() ?>">
			<p style="position:absolute;right:5px;top:5px;">
				<?= Layout::formBtnSubmit(true) ?>
			</p>
			<div id="general" class="subcontent">
				<?php
					Form::inputLabelText('Nama File', 'nama_file', $doc_files->nama_file);
					Form::inputLabelDocument("File", "file", $doc_files->file, false, "l-input-small", "*");
					Form::inputLabelText('Keterangan', 'keterangan', $doc_files->keterangan);
				?>
			</div>
		</form>
	</div>
	<?php
}

function store()
{
	global $user, $request;

    DB::beginTransaction();
	// DB::enableQueryLog();
    try {
        DocRencana::create([
            'aktifitas' => $request->aktifitas,
            'ket_aktifitas' => $request->ket_aktifitas,
            'tgl_mulai' => setTanggal($request->tgl_mulai),
            'tgl_selesai' => setTanggal($request->tgl_selesai),
			'jam_mulai' => $request->jam_mulai,
            'jam_selesai' => $request->jam_selesai,
            'id_kategori' => $request->id_kategori,
            'pic' => $request->pic,
			'file' => $request->file("file") ? $request->file("file")->store(DocRencana::$path_file, ["disk" => "storages"]) : "",
            'tgl_pelaksanaan' => setTanggal($request->tgl_pelaksanaan),
            'pelaksana' => $request->pelaksana,
            'ket_pelaksanaan' => $request->ket_pelaksanaan,
            'created_by' => $user->id,
            'updated_by' => $user->id,
        ]);

		//dd($order->getQueryLog())
        DB::commit();

	
        echo "<script>alert('Data berhasil disimpan')</script>";
		echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

		//dd($e);
        echo "<script>alert('Data gagal disimpan')</script>";
    }

	echo "<script>closeBox()</script>";
}

function storeFile()
{
	global $par, $user, $request;

    DB::beginTransaction();
	// DB::enableQueryLog();
    try {
        DocFile::create([
            'id_rencana' => $par["id"],
            'nama_file' => $request->nama_file,
			'file' => $request->file("file") ? $request->file("file")->store(DocRencana::$path_file, ["disk" => "storages"]) : "",
            'keterangan' => $request->keterangan,
            'created_by' => $user->id,
            'updated_by' => $user->id,
        ]);

		//dd($order->getQueryLog())
        DB::commit();

	
        echo "<script>alert('Data File berhasil disimpan')</script>";
		echo "<script>closeBox()</script>";
		// echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

		// dd($e);
        // echo "<script>alert('Data gagal disimpan')</script>";
    }

	echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {
        $update = DocRencana::find($par["id"]);
        $update->update([
            'aktifitas' => $request->aktifitas,
            'ket_aktifitas' => $request->ket_aktifitas,
            'tgl_mulai' => setTanggal($request->tgl_mulai),
            'tgl_selesai' => setTanggal($request->tgl_selesai),
			'jam_mulai' => $request->jam_mulai,
            'jam_selesai' => $request->jam_selesai,
            'id_kategori' => $request->id_kategori,
            'pic' => $request->pic,
			'file' => $request->file("file") ? $request->file("file")->store(DocRencana::$path_file, ["disk" => "storages"]) : "",
            'tgl_pelaksanaan' => setTanggal($request->tgl_pelaksanaan),
            'pelaksana' => $request->pelaksana,
            'ket_pelaksanaan' => $request['ket_pelaksanaan'],
            'updated_by' => $user->id,
        ]);

        if ($request->file("file") || $request->file) {

            $storage = Storage::disk("storages");

            if ($storage->exists($update->file)) {
                $storage->delete($update->file);
            }

            $update->update([
                "file" => ""
            ]);
        }

        if ($request->file("file")) {
            $update->update([
                "file" => $request->file("file")->store(DocRencana::$path_file, ["disk" => "storages"])
            ]);
        }

        DB::commit();

        echo "<script>alert('Data berhasil diubah')</script>";
		echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function updateFile()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {
        $update = DocFile::find($par["idDoc"]);
        $update->update([
            'id_rencana' => $par["id"],
            'nama_file' => $request->nama_file,
			'file' => $request->file("file") ? $request->file("file")->store(DocFile::$path_file, ["disk" => "storages"]) : "",
            'keterangan' => $request->keterangan,
            'updated_by' => $user->id,
        ]);

        if ($request->file("file") || $request->file) {

            $storage = Storage::disk("storages");

            if ($storage->exists($update->file)) {
                $storage->delete($update->file);
            }

            $update->update([
                "file" => ""
            ]);
        }

        if ($request->file("file")) {
            $update->update([
                "file" => $request->file("file")->store(DocFile::$path_file, ["disk" => "storages"])
            ]);
        }

        DB::commit();

		echo "<script>alert('Data File berhasil di Ubah')</script>";
		echo "<script>closeBox()</script>";
		// echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = DocRencana::find($par["id"]);

        $storage = Storage::disk("storages");

        if ($storage->exists($delete->file)) {
            $storage->delete($delete->file);
        }

        $delete->delete();

        DB::commit();

        echo "<script>alert('Rencana berhasil dihapus')</script>";
		echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Rencana gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}

function destroyFile()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = DocFile::find($par["idDoc"]);

        $storage = Storage::disk("storages");

        if ($storage->exists($delete->file)) {
            $storage->delete($delete->file);
        }

        $delete->delete();

        DB::commit();

        echo "<script>alert('File Rencana berhasil dihapus')</script>";
		echo "<script>window.location='?par[mode]=lihat".getPar($par,"mode,id")."';</script>";
        // echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('File Rencana gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}

function xls(){
	global $db,$par,$arrTitle,$arrIcon,$cName,$access,$fExport,$cUsername,$s,$cID,$areaCheck;
	require_once 'plugins/PHPExcel.php';

	// $par[module_id] = '19';
	$sekarang = date('Y-m-d');



	$objPHPExcel = new PHPExcel();
	$objPHPExcel->getProperties()->setCreator($cName)
	->setLastModifiedBy($cName)
	->setTitle($arrTitle["".$_GET[p].""]);
	$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
	$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(5);
	$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(35);
	$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(8);
	$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8);
	$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(8);

	$objPHPExcel->getActiveSheet()->mergeCells('B1:F1');
	$objPHPExcel->getActiveSheet()->mergeCells('B2:F2');
	$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setSize(16);

	$objPHPExcel->getActiveSheet()->getStyle('B2')->getFont()->setBold(true);
	// $objPHPExcel->getActiveSheet()->getStyle('A1:A2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

	$objPHPExcel->getActiveSheet()->setCellValue('B1', "JADWAL RENCANA KERJA");


	$objPHPExcel->getActiveSheet()->getStyle('B4:F4')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('D5:F5')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('B4:F5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	$objPHPExcel->getActiveSheet()->getStyle('B4:F5')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
	$objPHPExcel->getActiveSheet()->getStyle('B4:F5')->getBorders()->getTop()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('B4:F5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('B4:F5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('D4:F4')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	// $objPHPExcel->getActiveSheet()->getStyle('C5:F5')->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

	// $objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);

	// $objPHPExcel->getActiveSheet()->mergeCells('A4:A5');
	$objPHPExcel->getActiveSheet()->mergeCells('B4:B5');
	$objPHPExcel->getActiveSheet()->mergeCells('C4:C5');
	$objPHPExcel->getActiveSheet()->mergeCells('D4:E4');

	$objPHPExcel->getActiveSheet()->setCellValue('B4', 'No.');
	$objPHPExcel->getActiveSheet()->setCellValue('C4', "Aktifitas");
	$objPHPExcel->getActiveSheet()->setCellValue('D4', "Rencana");
	$objPHPExcel->getActiveSheet()->setCellValue('D5', "Mulai");
	$objPHPExcel->getActiveSheet()->setCellValue('E5', "Selesai");
	$objPHPExcel->getActiveSheet()->setCellValue('F5', "PIC KLIEN");

	$rows=6;

	$sql = " SELECT * from doc_rencanas";

	$res=db($sql);
	while($r=mysql_fetch_array($res)){
		$no++;
		$tanggalCreate = getField("SELECT createDate from doc_menuchecklist where module_id = '$r[module_id]'");

		$r[jumlahMenu] = getField("SELECT count(kodeMenu) from app_menus where module_id = '$r[module_id]'");

		$objPHPExcel->getActiveSheet()->getStyle('A'.$rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$objPHPExcel->getActiveSheet()->getStyle('C'.$rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$objPHPExcel->getActiveSheet()->getStyle('D'.$rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$objPHPExcel->getActiveSheet()->getStyle('E'.$rows)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);



		$objPHPExcel->getActiveSheet()->setCellValue('B'.$rows, $no);
		$objPHPExcel->getActiveSheet()->setCellValue('C'.$rows, $r[name]);
		$objPHPExcel->getActiveSheet()->setCellValue('D'.$rows, $r[tgl_mulai]);
		$objPHPExcel->getActiveSheet()->setCellValue('E'.$rows, $r[tgl_selesai]);
		$objPHPExcel->getActiveSheet()->setCellValue('F'.$rows, $r[pelaksana]);



		$rows++;
	}
	$rows--;
	$objPHPExcel->getActiveSheet()->getStyle('A'.$rows.':F'.$rows)->getBorders()->getBottom()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('A4:A'.$rows)->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('A4:A'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('B4:B'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('C4:C'.$rows)->getBorders()->getLeft()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('C4:C'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('D4:D'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('E4:E'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);
	$objPHPExcel->getActiveSheet()->getStyle('F4:F'.$rows)->getBorders()->getRight()->setBorderStyle(PHPExcel_Style_Border::BORDER_THIN);

	$objPHPExcel->getActiveSheet()->getStyle('A1:F'.$rows)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

	$objPHPExcel->getActiveSheet()->getStyle('A4:F'.$rows)->getAlignment()->setWrapText(true);

	$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
	$objPHPExcel->getActiveSheet()->getPageSetup()->setScale(100);
	$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE)->setFitToWidth(1)->setFitToHeight(1);
	$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
	$objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(3, 4);
	$objPHPExcel->getActiveSheet()->getPageMargins()->setTop(0.3);
	$objPHPExcel->getActiveSheet()->getPageMargins()->setLeft(0.3);
	$objPHPExcel->getActiveSheet()->getPageMargins()->setRight(0.2);
	$objPHPExcel->getActiveSheet()->getPageMargins()->setBottom(0.3);

	$objPHPExcel->getActiveSheet()->setTitle("DATA CHECKLIST");
	$objPHPExcel->setActiveSheetIndex(0);

	// Save Excel file
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
	$objWriter->save($fExport."DATA CHECKLIST ".$sekarang.".xls");
}

function _view()
{
			global $s,$inp,$par,$title,$arrParameter,$access;
			$par['bulanRencana'] = date('m');
			$par['tahunRencana'] = date('Y');

			Layout::title();
			?>
			<div id="contentwrapper" class="contentwrapper">
				<div class="one_half last dashboard_left">
				<?php
					$arrData = DocRencana::query()
												->select('*')
												->whereMonth("tgl_mulai", "=", "$par[bulanRencana]")
												->whereYear("tgl_mulai", "=", "$par[tahunRencana]")
												->orderBy("id")
												->get()->toArray();
					// dd($arrData);
				?>
					<script type="text/javascript" src="scripts/calendar.js"></script>
					<script type="text/javascript">
						jQuery(function () {
							jQuery('#calendar').fullCalendar({
								month: <?= $par['bulanRencana'] ?>,
								year: <?= $par['tahunRencana'] ?>,

								buttonText: {
									prev: '&laquo;',
									next: '&raquo;',
									prevYear: '&nbsp;&lt;&lt;&nbsp;',
									nextYear: '&nbsp;&gt;&gt;&nbsp;',
									today: 'today',
									month: 'month',
									week: 'week',
									day: 'day'
								},

								header: {
									left: 'title',
									right: 'prev,next',
								},

								events: {
									url: '$url',
									cache: true
								},

								eventMouseover: function(calEvent, jsEvent) {
									var tooltip = '<div class="tooltipevent" style="padding:0 5px; position:absolute; z-index:10000; font-size:10px; background:#fff; color:#666; border:solid 1px #ccc; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px;">' + calEvent.data.namaAktifitas +'</div>';

									jQuery("body").append(tooltip);
									jQuery(this).mouseover(function(e) {
										jQuery(this).css('z-index', 10000);
										jQuery('.tooltipevent').fadeIn('500');
										jQuery('.tooltipevent').fadeTo('10', 1.9);
									}).mousemove(function(e) {
										jQuery('.tooltipevent').css('top', e.pageY + 10);
										jQuery('.tooltipevent').css('left', e.pageX + 20);
									});
								},

								eventMouseout: function(calEvent, jsEvent) {
									jQuery(this).css('z-index', 8);
									jQuery('.tooltipevent').remove();
								},

								eventClick: function (calEvent, jsEvent, view) {
									window.location = '?par[id]=' + calEvent.id + '".getPar($par,"id")."';
								},
							});

							jQuery('.fc-button-prev span').click(function(){
								document.getElementById('daftarLibur').style.display = 'none';
								var date = jQuery('#calendar').fullCalendar('getDate');
								var bulanRencana = date.getMonth() == 0 ? 11 : date.getMonth()-1;
								var tahunRencana = date.getMonth() == 0 ? date.getFullYear()-1 : date.getFullYear();
								window.location = '?par[bulanRencana]=' + bulanRencana + '&par[tahunRencana]=' + tahunRencana + '".getPar($par,"bulanRencana,tahunRencana,idLibur")."';
							});

							jQuery('.fc-button-next span').click(function(){
								document.getElementById('daftarLibur').style.display = 'none';
								var date = jQuery('#calendar').fullCalendar('getDate');
								var bulanRencana = date.getMonth() == 12 ? 0 : date.getMonth()+1;
								var tahunRencana = date.getMonth() == 12 ? date.getFullYear()+1 : date.getFullYear();
								window.location = '?par[bulanRencana]=' + bulanRencana + '&par[tahunRencana]=' + tahunRencana + '".getPar($par,"bulanRencana,tahunRencana,idLibur")."';
							});
						});
					</script>

					<div id="calendar"></div>
					<div class="widgetbox">
						<div class="title" style="margin-top:30px; margin-bottom:5px;">
							<span style="float:left;"><h3>Daftar Rencana Kerja</h3></span>
							<input type="button" class="cancel radius2" value="VIEW ALL" onclick="window.location='?par[mode]=lihat<?= getPar($par,'mode,idLibur')?>';"  style="float:right; margin-top:-15px;"/>
						</div>
						<div id="daftarLibur" class="widgetcontent userlistwidget nopadding">
							<ul>
							<?php
								$no=1;
								if(is_array($arrData)){
									while(list($i, $r)=each($arrData)){
										list($tgl_mulai) = explode(" ", $r['tgl_mulai']);
										list($tgl_selesai) = explode(" ", $r['tgl_selesai']);
										?>
										<li>
											<div style="width:10px; height:10px; background:<?=$r[color]?>; margin-top:4px; margin-right:5px; float:left;">&nbsp;</div>
											<a href="?par[mode]=edit&par[id]=<?= $r[id].getPar($par,"id")?>"> <?= $r['aktifitas']?></a>
											<div style="font-size:10px; color:#888;"><?= getTanggal($tgl_mulai)?> s.d <?= getTanggal($tgl_selesai)?></div>
										</li>
									<?php
								}
							}?>
							</ul>
						</div>
					</div>
				</div>
				<div class="one_half last dashboard_right\" style="margin-left:20px;">
					<div class="widgetbox">
						<div class="title" style="margin-top:10px; margin-bottom:5px;"><h3>Keterangan</h3></div>
						<?php
						if(isset($access["add"])) : ?>
							<a href="?par[mode]=add<?=getPar($par,"mode,id")?>" class="btn btn1 btn_document"  style="position:absolute; right:0; top:0; margin-top:0px;"><span>Tambah Data</span></a>
						<?php endif;
						// if(empty($par[id])) $par[id] = getField("SELECT id from doc_rencanas where ".$par[tahunRencana].($par[bulanRencana]+1)." between concat(year(tgl_mulai),month(tgl_mulai)) and concat(year(tgl_selesai),month(tgl_selesai)) order by tgl_mulai limit 1");

						$date=Carbon::now()->startOfMonth()->subMonth(3);
						$date2=Carbon::now()->startOfMonth();					
						$r=DocRencana::query()
							->whereBetween('tgl_mulai',[$date, $date2])
							->first();
							// dd($r);
						$r['download'] = "<a href=\"download.php?d=fileRencana&f=$par[id]\"><img src=\"".getIconExtension($r[file])."\" align=\"center\" style=\"padding-right:5px; padding-bottom:5px; max-width:20px; max-height:20px;\"></a>";
						$tanggalLibur = $r['tgl_mulai'] == $r['tgl_selesai'] ? getTanggal($r['tgl_mulai']) : getTanggal($r['tgl_mulai'])." s.d ".getTanggal($r['tgl_selesai']);
						?>
						<form id="form" name="form" method="post" class="stdform">
						<p>
							<label class="l-input-small" style="text-align:left; padding-left:10px;">Judul</label>
							<span class="field" style="margin-left:140px;"><?= $r['aktifitas'] ?>&nbsp;</span>
						</p>
						<p>
							<label class="l-input-small" style="text-align:left; padding-left:10px;">Kategori</label>
							<span class="field" style="margin-left:140px;"><?= $r['namaData'] ?>&nbsp;</span>
						</p>
						<p>
							<label class="l-input-small" style="text-align:left; padding-left:10px;">Tanggal</label>
							<span class="field" style="margin-left:140px;"><?= $tanggalLibur ?>&nbsp;</span>
						</p>
						<p>
							<label class="l-input-small" style="text-align:left; padding-left:10px;">Keterangan</label>
							<span class="field" style="margin-left:140px;"><?= nl2br($r['ket_aktifitas'])?>&nbsp;</span>
						</p>
						<p>
						<label class="l-input-small" style="text-align:left; padding-left:10px;">PIC</label>
							<span class="field" style="margin-left:140px;"><?= $r['pic'] ?>&nbsp;</span>
						</p>
						<p>
						<label class="l-input-small" style="text-align:left; padding-left:10px;">File</label>
							<span class="field" style="margin-left:140px;"><?= $r['download']?> &nbsp;</span>
						</p>
					</form>
				</div>
				<div class="widgetbox">
						<div class="title" style="margin-top:10px; margin-bottom:5px;"><h3>Pelaksanaan</h3></div>
						<?php
						if(isset($access["add"])) : ?>
							<a href="?par[mode]=add<?= getPar($par,"mode,id")?>" class="btn btn1 btn_document"  style="position:absolute; right:0; top:0; margin-top:0px;\"><span>Tambah Data</span></a>
						<?php endif;

						// if(empty($par[id])) 
						// 	$par[id] = getField("SELECT id from doc_rencanas where ".$par['tahunRencana'].($par['bulanRencana']+1)." between concat(year(tgl_mulai),month(tgl_mulai)) and concat(year(tgl_selesai),month(tgl_selesai)) order by tgl_mulai limit 1");

						$r=DocRencana::query()
						->whereBetween('tgl_mulai',[$date, $date2])
						->first();
						?>

						<form id="form" name="form" method="post" class="stdform">
						<p>
							<label class="l-input-small" style="text-align:left; padding-left:10px;">Tanggal</label>
							<span class="field" style="margin-left:140px;"><?= getTanggal($r['tgl_pelaksanaan']) ?></span>
						</p>
						<p>
						<label class="l-input-small" style="text-align:left; padding-left:10px;">Pelaksana</label>
							<span class="field" style="margin-left:140px;"><?= $r['pelaksana'] ?></span>
						</p>
						<p>
							<label class="l-input-small" style="text-align:left; padding-left:10px;">Keterangan</label>
							<span class="field" style="margin-left:140px;"><?= nl2br($r['ket_pelaksanaan'])?>&nbsp;</span>
						</p>
					</form>
				</div>
			</div>
		</div>

		<?php
}
?>
