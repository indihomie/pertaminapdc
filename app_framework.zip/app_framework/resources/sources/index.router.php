<?php

use App\Models\AppLogAccess;
use App\Models\AppMaster;
use App\Models\AppMenu;
use App\Models\AppModule;
use App\Models\AppModuleSub;
use Illuminate\Support\Facades\Cache;


$access_view = [];
$accesses = [];
$datas = [];


$user_group = $user->group;

$user_accesses = Cache::rememberForever("app_group_access_menus-{$user_group->id}", function () use ($user_group) {
    return $user_group->accessMenus;
});

foreach ($user_accesses as $key => $value) {

    if ($value->permission == 'view')
        $access_view[] = $value->menu_id;

    $accesses[$value->menu_id][$value->permission] = $value->permission;
}


$module_categories = Cache::rememberForever("app_module_categories", function () {
    return AppMaster::where("category_id", "S001")->where("status", 1)->orderBy("order", "asc")->get()->keyBy("id")->toArray();
});

$modules = Cache::rememberForever("app_modules", function () {
    return AppModule::where("status", 1)->orderBy("order", "asc")->get()->keyBy("id")->toArray();
});

$module_subs = Cache::rememberForever("app_module_sub-{$module_id}", function () use ($module_id) {
    return AppModuleSub::where("module_id", $module_id)->where("status", 1)->orderBy("order")->get()->keyBy("id")->toArray();
});


$menus = Cache::rememberForever("app_menu-{$module_id}", function () use ($module_id) {
    return AppMenu::where("module_id", $module_id)->where("menu_id", 0)->where("status", 1)->orderBy("order")->get()->keyBy("id")->toArray();
});

$menu_subs = Cache::rememberForever("app_menu_sub-{$module_id}", function () use ($module_id) {
    return AppMenu::where("module_id", $module_id)->where("menu_id", "<>", 0)->where("status", 1)->orderBy("order")->get()->keyBy("id")->toArray();
});

Cache::forget("app_menu-{$module_id}");

foreach ($module_subs as $key => $value) {

    $datas[$key] = $value;

    foreach ($menus as $_key => $_value) {

        if ($_value['module_sub_id'] != $key)
            continue;

        $datas[$key]['menus'][$_key] = $_value;

        foreach ($menu_subs as $__key => $__value) {

            if ($_key != $__value['menu_id'])
                continue;

            if (in_array($__key, $access_view))
                $datas[$key]['menus'][$_key]['subs'][$__key] = $__value;

        }

        if (count($datas[$key]['menus'][$_key]['subs'] ?? []) == 0 && !in_array($_key, $access_view))
            unset($datas[$key]['menus'][$_key]);

    }

    if (count($datas[$key]['menus'] ?? []) == 0)
        unset($datas[$key]);

}

if (empty($module_sub_id)) {

    $module_sub = reset($datas);

    $module_sub_id = $module_sub['id'];
}

if (empty($menu_id)) {

    $menus = $datas[$module_sub_id];
    $menus["menus"] = $menus["menus"] ?? [];

    $menu = reset($menus['menus']);

    $menu_id = $menu['id'];
}

if (empty($menu_sub_id)) {

    $menu = $datas[$module_sub_id]['menus'][$menu_id];
    $menu["subs"] = $menu["subs"] ?? [];

    $menu_subs = reset($menu['subs']);

    $menu_sub_id = !empty($menu['target']) ? $menu['id'] : $menu_subs['id'];
}

$module = $modules[$module_id];

// don't remove, im declaring global and redeclare for information
$menu = !empty(($datas[$module_sub_id]['menus'][$menu_id]['target'])) || empty($datas[$module_sub_id]['menus'][$menu_id]['subs']) ? $datas[$module_sub_id]['menus'][$menu_id] : $datas[$module_sub_id]['menus'][$menu_id]['subs'][$menu_sub_id];

if (!$menu) {
    header("location: home", false);
    exit;
}

$access = $accesses[$menu['id']];

//AppLogAccess::query()
//    ->create([
//        "ip_address" => $request->ip(),
//        "module_id" => $module_id ?? 0,
//        "module_sub_id" => $module_sub_id ?? 0,
//        "menu_id" => $menu_id ?? 0,
//        "menu_sub_id" => $menu_sub_id ?? 0,
//        "method" => $request->method(),
//        "mode" => $par["mode"] ?? "-",
//        "parameter" => $request->except([
//            "c", "p", "m", "s", "par",
//            "sEcho", "iColumns", "sColumns", "iDisplayStart", "iDisplayLength",
//            "mDataProp_0", "mDataProp_1", "mDataProp_2", "mDataProp_3", "mDataProp_4", "mDataProp_5", "mDataProp_6", "mDataProp_7", "mDataProp_8", "mDataProp_9", "mDataProp_10",
//            "iSortCol_0", "sSortDir_0", "iSortingCols",
//            "bSortable_0", "bSortable_1", "bSortable_2", "bSortable_3", "bSortable_4", "bSortable_5", "bSortable_6", "bSortable_7", "bSortable_8", "bSortable_9", "bSortable_10"
//        ]),
//        "created_by" => $user->id
//    ]);
