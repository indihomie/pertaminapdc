<?php

use App\Models\AppParameter;

error_reporting(-100000000000);

ini_set('display_errors', 1);

ini_set('memory_limit', '256M');
ini_set('max_execution_time', 7200);

ini_set('post_max_size', '20M');
ini_set('upload_max_filesize', '20M');

ini_set('precision', '15');


define('DS', DIRECTORY_SEPARATOR);
define('APP_URL', config("environment.APP_URL"));

global $request, $sessions, $old, $errors;

global $app_version, $arr_parameter;
global $user, $module, $module_sub, $menu, $access, $par, $inp, $c, $p, $m, $s;
global $module_id, $module_sub_id, $menu_id;
global $search, $change_1, $change_2, $change_3, $change_4, $click_1;

global $TOKEN_API_MAP,
       $arr_day,
       $arr_month,
       $arr_color,
       $arrParameter,
       $arr_permission;

$app_version = config("environment.APP_VERSION");

$db['host'] = config('environment.DB_HOST') . ":" . config('environment.DB_PORT');
$db['name'] = config('environment.DB_DATABASE');
$db['user'] = config('environment.DB_USERNAME');
$db['pass'] = config('environment.DB_PASSWORD');

$TOKEN_API_MAP = config('environment.TOKEN_MAP_JS');

$arr_day = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu"];
$arr_month = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

$arr_color = ["#ba8b26", "#0020e0", "#e00020", "#5fe000", "#128a92", "#851712", "#394a67", "#a41899"];

$arrParameter = Cache::rememberForever("app_parameters", fn() => AppParameter::query()->pluck("value", "code"));
$arr_parameter = $arrParameter;

$arr_permission = [
    "view" => "Lihat",
    "add" => "Tambah",
    "edit" => "Ubah",
    "delete" => "Hapus",
    "privileged_1" => "Akses 1",
    "privileged_2" => "Akses 2",
    "privileged_3" => "Akses 3",
];


foreach (request()->all() as $key => $value) {
    global $$key;
    $$key = $value;
}

$user = auth()->user();
$request = request();
$sessions = session();
$old = $sessions->get("old");
$errors = $sessions->get("errors");

$module_id = $c;
$module_sub_id = $p;
$menu_id = $m;
$menu_sub_id = $s;
