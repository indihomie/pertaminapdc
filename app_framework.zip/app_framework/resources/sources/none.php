<?php

use App\View\Components\Layout;

Layout::title();
