<?php

if (!$user) {
    echo "Unauthorized";
    exit;
}

// by pass page not in module
if ($page) {

    include resource_path("sources/_popup/{$page}.php");

    if (function_exists('controller')) {
        controller();
    }

    exit;
}

include resource_path("sources/index.router.php");

$directory = $menu['target'];
$dirs = explode("/", $directory);
$file = end($dirs);

if (file_exists(resource_path("sources/{$directory}.php"))) {

    include resource_path("sources/{$directory}.php");

} else {

    include resource_path("sources/none.php");

}

if (function_exists('controller')) {
    echo controller();
}

if (function_exists('getContent')) {
    echo getContent($par);
}
