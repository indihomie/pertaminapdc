<?php
global $par;

use App\Classes\ClassFinder;
use App\View\Components\Form;
use App\View\Components\Layout;
use Illuminate\Support\Carbon;
use Spatie\Activitylog\Models\Activity;

switch ($par['mode']) {

    case "datas":
        echo datas();
        break;

    case "detail":
        detail();
        break;

    default:
        index();
        break;

}

function index()
{

    $date_start = now()->format("Y-m-01");
    $date_end = now()->format("Y-m-d");

    $class_finder = new ClassFinder();
    $models = $class_finder->getClassesByNamespace("\App\Models");
    $models = collect($models)->mapWithKeys(fn($model) => [Str::substr($model, 1) => Str::replace("\App\Models\\", "", $model)])->toArray();

    $types = [
        "created" => "created",
        "updated" => "updated",
        "deleted" => "deleted"
    ];
    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <?= Form::selectArray("Model", "change_1", $models, "", "", "", "- Semua Model -", "", "300px"); ?>
                    <?= Form::selectArray("Tipe", "change_2", $types, "", "", "", "- Semua Tipe -"); ?>
                    <?= Form::inputDate("Tanggal Mulai", "change_3", $date_start); ?>
                    <?= Form::inputDate("Tanggal Selesai", "change_4", $date_end); ?>

                </div>
                <div class="filter_right">

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="120">Waktu</th>
                <th width="80">Lokasi</th>
                <th width="100">Aktifitas</th>
                <th width="*">Model</th>
                <th width="100">Model Isi</th>
                <th width="100">User</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(8, [1, 3, 4, 5, 6, 7, 8]); ?>

    <?php
}

function datas()
{
    global $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search, $change_1, $change_2, $change_3, $change_4;

    $parameter = getPar($par, "mode, id");

    $date_start = Carbon::createFromFormat("d/m/Y", $change_3)->startOfDay()->format("Y-m-d H:i:s");
    $date_end = Carbon::createFromFormat("d/m/Y", $change_4)->endOfDay()->format("Y-m-d H:i:s");

    $arr_order = [
        "created_at",
        "created_at",
    ];

    $activity_logs = Activity::query()
        ->with([
            "subject",
            "causer"
        ])
        ->whereBetween("created_at", [$date_start, $date_end])
        ->when($change_1, function ($query, $subject_type) {
            $query->where("subject_type", $subject_type);
        })
        ->when($change_2, function ($query, $description) {
            $query->where("description", $description);
        })
        ->when($search, function ($query, $search) {
            $query->where(function ($query) use ($search) {
                $query->orWhere("subject_type", "like", "%{$search}%");
                $query->orWhere("subject_id", "like", "%{$search}%");
            });
        });
    $count = clone $activity_logs;

    $activity_logs->orderBy($arr_order[$iSortCol_0], $iSortCol_0 > 0 ? $sSortDir_0 : "desc");

    if ($iDisplayLength > 0) {
        $activity_logs->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $activity_logs
        ->get()
        ->map(function ($log, $key) use ($iDisplayStart, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $subject = $log->subject->name ?? '-';
            $causer = $log->causer->name ?? '-';

            $control = "<a title='Lihat Data' class='detail' href='#' onclick='openBox(`popup?{$parameter}&par[mode]=detail&par[id]={$log->id}`, 600, 520)'></a>";

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$log->created_at->format("d.m.Y H:i:s")}</div>",
                "<div align='left'>{$log->log_name}</div>",
                "<div align='left'>{$log->description}</div>",
                "<div align='left'>{$log->subject_type}</div>",
                "<div align='left'>{$subject}</div>",
                "<div align='left'>{$causer}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function detail()
{
    global $par;

    $log = Activity::query()->find($par["id"]);
    $changes = $log->changes();

    ?>
    <form id="form"
          class="stdform px-1"
          name="form">

        <fieldset class="rounded">

            <?php Form::spanLabel("Lokasi", $log->log_name); ?>
            <?php Form::spanLabel("Tipe", $log->description); ?>
            <?php Form::spanLabel("Waktu", $log->created_at->format("d F Y H:i:s")); ?>
            <?php Form::spanLabel("User", $log->subject->name ?? "??"); ?>

        </fieldset>

        <div class="mt-4 mb-1">
            Before
        </div>

        <pre class="p-2 bg-gray-200 rounded box-border w-full overflow-y-auto"><?= e(json_encode($changes["old"], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre>

        <div class="mt-4 mb-1">
            After
        </div>

        <pre class="p-2 bg-gray-200 rounded box-border w-full overflow-y-auto"><?= e(json_encode($changes["attributes"], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre>

    </form>
    <?php
}
