<?php
global $access, $par, $_submit;

use App\Models\AppLogAccess;
use App\Models\AppModule;
use App\View\Components\Form;
use App\View\Components\Layout;
use Carbon\Carbon;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "detail":
        detail();
        break;

    default:
        index();
        break;

}

function index()
{
    global $module_id;

    $module = AppModule::query()->where("status", 1)->get();

    $date_start = now()->format("Y-m-d");
    $date_end = now()->format("Y-m-d");

    $is_global = in_array($module_id, [12, 20]);

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">
                    &nbsp;
                    <?= Form::selectArray("Filter Modul", "change_1", $module, "id", "name", $is_global ? "" : $module_id, "- Semua Modul -", $is_global ? "" : "disabled"); ?>
                    &nbsp;
                    <?= Form::inputDate("Tanggal Mulai", "change_2", $date_start); ?>
                    <?= Form::inputDate("Tanggal Selesai", "change_3", $date_end); ?>

                </div>
                <div class="filter_right">


                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="120">Waktu</th>
                <th width="80">IP</th>
                <th width="120">Modul</th>
                <th width="120">Sub Modul</th>
                <th width="*">Menu</th>
                <th width="20">Metode</th>
                <th width="20">Mode</th>
                <th width="120">User</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(10, range(3, 10)); ?>

    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search, $change_1, $change_2, $change_3;

    $parameter = getPar($par, "mode");
    $number = $iDisplayStart;

    $arr_order = [
        "created_at",
        "created_at",
        "ip_address",
        "module_id",
        "module_sub_id",
        "menu_id",
        "method",
        "mode",
        "created_by",
    ];

    $date_start = Carbon::createFromFormat("d/m/Y", $change_2)->startOfDay();
    $date_end = Carbon::createFromFormat("d/m/Y", $change_3)->endOfDay();

    $access_log = AppLogAccess::query()
        ->join("app_users", "app_users.id", "=", "app_log_accesses.created_by")
        ->whereBetween("app_log_accesses.created_at", [$date_start->format("Y-m-d H:i:s"), $date_end->format("Y-m-d H:i:s")])
        ->when($search, function ($query, $search) {
            $query->where(function ($query) use ($search) {
                $query->orWhere("app_users.name", "like", "{$search}%");
                $query->orWhere("app_log_accesses.ip_address", "like", "{$search}%");
            });
        })
        ->when($change_1, function ($query, $module_id) {
            $query->where("module_id", $module_id);
        });
    $count = clone $access_log;

    $access_log->orderBy($arr_order[$iSortCol_0], $iSortCol_0 > 0 ? $sSortDir_0 : "desc");

    if ($iDisplayLength > 0) {
        $access_log->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $access_log
        ->select(["app_log_accesses.*", "app_users.name"])
        ->with([
            "module" => function ($query) {
                $query->select(["id", "name"]);
            },
            "moduleSub" => function ($query) {
                $query->select(["id", "name"]);
            },
            "menu" => function ($query) {
                $query->select(["id", "name"]);
            },
            "menuSub" => function ($query) {
                $query->select(["id", "name"]);
            }
        ])
        ->get()
        ->map(function ($access_log) use (&$number, $access, $par, $parameter) {

            $number++;

            $control = "";
            $control .= "<a title='Detail Data' class='detail' href='#Detail' onclick='openBox(`popup?{$parameter}&par[mode]=detail&par[id]={$access_log->id}`, 800, 520)'></a>";

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$access_log->created_at->format("d.m.Y H:i:s")}</div>",
                "<div align='left'>{$access_log->ip_address}</div>",
                "<div align='left'>{$access_log->module->name}</div>",
                "<div align='left'>{$access_log->moduleSub->name}</div>",
                "<div align='left'>{$access_log->menu->name} - {$access_log->menuSub->name}</div>",
                "<div align='center'>{$access_log->method}</div>",
                "<div align='left'>{$access_log->mode}</div>",
                "<div align='left'>{$access_log->name}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function detail()
{
    global $par;

    $log_access = AppLogAccess::query()->find($par["id"]);

    ?>
    <form id="form"
          class="stdform px-1"
          name="form">

        <fieldset class="rounded">

            <?php Form::spanLabel("Waktu", $log_access->created_at->format("d F Y H:i:s")); ?>
            <?php Form::spanLabel("IP", $log_access->ip_address); ?>
            <?php Form::spanLabel("Modul", $log_access->module->name); ?>
            <?php Form::spanLabel("Sub Modul", $log_access->moduleSub->name); ?>
            <?php Form::spanLabel("Menu", $log_access->menu->name); ?>
            <?php Form::spanLabel("Sub Menu", $log_access->menuSub->name); ?>

            <div class="h-1"></div>

            <?php Form::spanLabel("Metode", $log_access->method); ?>
            <?php Form::spanLabel("Mode", $log_access->mode); ?>

            <div class="h-1"></div>

            <?php Form::spanLabel("User", $log_access->createdBy->name); ?>

        </fieldset>

        <div class="mt-4 mb-1">
            Parameter
        </div>

        <pre class="p-2 bg-gray-200 rounded box-border w-full overflow-y-auto"><?= e(json_encode($log_access->parameter, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre>

    </form>
    <?php
}
