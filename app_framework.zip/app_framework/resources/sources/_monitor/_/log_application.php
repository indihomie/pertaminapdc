<?php
global $par;

use App\View\Components\Form;
use App\View\Components\Layout;
use Jackiedo\LogReader\Exceptions\UnableToRetrieveLogFilesException;

switch ($par['mode']) {

    case "datas":
        echo datas();
        break;

    case "detail":
        detail();
        break;

    default:
        index();
        break;

}

function index()
{

    $files = Storage::disk("log")->files("/");
    $files = collect($files)
        ->filter(fn($file) => !Str::contains($file, ".gitignore"))
        ->mapWithKeys(function ($file) {
            return [$file => $file];
        })
        ->reverse();

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <?= Form::selectArray("Log File", "change_1", $files, "", "", $_SESSION["filter_log"], ""); ?>

                </div>
                <div class="filter_right">

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="150">Waktu</th>
                <th width="100">Level</th>
                <th width="100">Enviroment</th>
                <th width="*">Konten</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(6, range(1, 6)); ?>

    <?php
}

function datas()
{
    global $par;
    global $iDisplayStart, $iDisplayLength, $change_1;

    $_SESSION["filter_log"] = $change_1;

    $parameter = getPar($par, "mode");

    $reader = LogReader::filename($change_1);
    $logs = collect();

    try {

        $logs = $reader
            ->get()
            ->merge($logs);
        $count = $logs->count();

        $limit = $iDisplayLength ?: 10;
        $start = $iDisplayStart ?: 0;
        $page = $start == 0 ? 1 : ($start / $limit + 1);

        $logs = $logs
            ->map(function ($a) {
                return (collect($a))->only(['id', 'date', 'environment', 'level', 'file_path', 'context']);
            })
            ->values();

        $datas = [];

        foreach ($logs->forPage($page, $limit)->toArray() as $key => $log) {

            $no = $key + 1;

            $context = $log["context"];

            $datas[] = [
                "<div align='center'>{$no}.</div>",
                "<div align='center'>{$log["date"]->format("d/m/Y H:i:s")}</div>",
                "<div align='left'>{$log["level"]}</div>",
                "<div align='left'>{$log["environment"]}</div>",
                "<div align='left'>{$context->message}</div>",
                "<div align='center'>
                    <a title='Lihat Data' class='detail' href='#' onclick='openBox(`popup?{$parameter}&par[mode]=detail&par[file]={$change_1}&par[id]={$log["id"]}`, 800, 520)'></a>
                </div>",
            ];
        }

        return json_encode([
            "iTotalDisplayRecords" => $count,
            "iTotalRecords" => $iDisplayLength,
            "aaData" => $datas
        ]);

    } catch (UnableToRetrieveLogFilesException $exception) {

        return json_encode([
            "iTotalDisplayRecords" => 0,
            "iTotalRecords" => 0,
            "aaData" => []
        ]);
    }
}

function detail()
{
    global $par;

    $reader = LogReader::filename($par["file"])->find($par["id"]);

    ?>
    <form id="form"
          class="stdform px-1"
          name="form">

        <fieldset class="rounded">

            <?php Form::spanLabel("Environment", $reader->environment); ?>
            <?php Form::spanLabel("Waktu", $reader->date->format("d F Y H:i:s")); ?>
            <?php Form::spanLabel("Level", $reader->level); ?>

        </fieldset>

        <div class="mt-4 mb-1">
            Error
        </div>

        <pre class="p-2 bg-gray-200 rounded box-border w-full overflow-y-auto"><?= e(json_encode($reader->context, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre>

        <div class="mt-4 mb-1">
            Stack Trace
        </div>

        <pre class="p-2 bg-gray-200 rounded box-border w-full overflow-y-auto"><?= e(json_encode($reader->stack_traces, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre>

    </form>
    <?php
}
