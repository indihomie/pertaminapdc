<?php
global $access, $par, $_submit, $code;

use App\Classes\FormatDocument;
use App\Models\AppFormatDocument;
use App\Models\AppMaster;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "print":
        FormatDocument::generateView($code, []);
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;

    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add`, 1140, 700);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="50">Kode</th>
                <th width="*">Nama</th>
                <th width="200">Ukuran Kertas</th>
                <th width="120">Diubah</th>
                <th width="120">Diubah Oleh</th>
                <th width="50">Cetak</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(8, [1, 6, 7, 8]); ?>
    <script>

        function print(code) {
            taskBackground(`<?= $parameter ?>&par[mode]=print&code=${code}`)
        }

    </script>
    <?php
}

function form()
{
    global $access, $par;

    $papers = AppMaster::query()->select(["id", "name", "data"])->where("category_id", "SUKD")->orderBy("order")->get();
    $paper_sizes = $papers->mapWithKeys(fn($paper) => [$paper->id => $paper->data]);

    $document = AppFormatDocument::query()->find($par["id"]);

    if ($par["mode"] == "add") {
        $document->paper_id = "SUKD0005";
        $document->margin_top = 0;
        $document->margin_right = 0;
        $document->margin_bottom = 0;
        $document->margin_left = 0;
    }

    echo getValidation();

    ?>
    <div>

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="toggleLoader()"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <?php Form::inputLabelText("kode", "code", $document->code, false, "l-input-small", "vsmallinput text-transform-uppercase", "", "", "minlength='8' maxlength='8'"); ?>
                <?php Form::inputLabelText("nama", "name", $document->name, false); ?>
                <?php Form::inputLabelSelectArray("Kertas", "paper_id", $papers->toArray(), "id", "name", $document->paper_id, false, "", "l-input-small", "", "onchange='updatePaper(this.value)'", "21.5%") ?>

                <div class="flex">
                    <div class="flex-1">
                        <?php Form::inputLabelNumber("Margin Atas", "margin_top", $document->margin_top, false, "l-input-small2", "w-16"); ?>
                    </div>
                    <div class="flex-1">
                        <?php Form::inputLabelNumber("Margin Bawah", "margin_bottom", $document->margin_bottom, false, "l-input-small2", "w-16"); ?>
                    </div>
                </div>

                <div class="flex">
                    <div class="flex-1">
                        <?php Form::inputLabelNumber("Margin Kanan", "margin_right", $document->margin_right, false, "l-input-small2", "w-16"); ?>
                    </div>
                    <div class="flex-1">
                        <?php Form::inputLabelNumber("Margin Kiri", "margin_left", $document->margin_left, false, "l-input-small2", "w-16"); ?>
                    </div>
                </div>

            </fieldset>

            <br>

            <div id="editor_toolbar"></div>
            <textarea name="content"
                      id="editor" class="border border border-solid border-gray-300 cke_source cke_reset cke_enable_context_menu"><?= $document->content ?></textarea>

        </form>

    </div>
    <script>

        const editor = document.getElementById('editor')
        const editor_toolbar = document.getElementById('editor_toolbar')
        const papers = <?= $paper_sizes->toJson() ?>

        let paper = papers['<?= $document->paper_id ?>']

        ckeditor = CKEDITOR.replace(editor, {
            filebrowserUploadUrl: "<?= route("ckeditor-upload", ["_token" => csrf_token()]) ?>",
            filebrowserUploadMethod: 'form',
            width: `${paper.width}mm`,
            height: `${paper.height}mm`,
        })

        function updatePaper(paper_id) {
            paper = papers[paper_id]
            ckeditor.resize(`${paper.width}mm`, `${paper.height}mm`)
        }

    </script>
    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "id",
        "code",
        "name",
        "paper_id",
        "updated_at"
    ];

    $documents = AppFormatDocument::query()
        ->with(["paper", "updatedBy:id,name"])
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        });
    $count = clone $documents;

    $documents->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $documents->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $documents
        ->get()
        ->map(function ($document, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$document->id}`, 1140, 700);'></a>";
            }
            if ($access["delete"]) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus master dokumen ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$document->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$document->code}</div>",
                "<div align='left'>{$document->name}</div>",
                "<div align='left'>{$document->paper->name}</div>",
                "<div align='center'>{$document->updated_at->format("d.m.Y H:i:s")}</div>",
                "<div align='left'>{$document->updatedBy->name}</div>",
                "<div align='center'><a title='Cetak' class='print' href='#Print' onclick='print(`$document->code`)'></a></div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $user, $request;

    DB::beginTransaction();

    try {

        AppFormatDocument::create([
            "code" => Str::upper($request->code),
            "name" => $request->name,
            "paper_id" => $request->paper_id,
            "margin_top" => $request->margin_top,
            "margin_right" => $request->margin_right,
            "margin_bottom" => $request->margin_bottom,
            "margin_left" => $request->margin_left,
            "content" => $request->content ?? "",
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Dokumen berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Dokumen gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $update = AppFormatDocument::find($par["id"]);

        $update->update([
            "code" => Str::upper($request->code),
            "name" => $request->name,
            "paper_id" => $request->paper_id,
            "margin_top" => $request->margin_top,
            "margin_right" => $request->margin_right,
            "margin_bottom" => $request->margin_bottom,
            "margin_left" => $request->margin_left,
            "content" => $request->content ?? "",
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Dokumen berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Dokumen gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = AppFormatDocument::find($par["id"]);

        $delete->delete();

        DB::commit();

        echo "<script>alert('Dokumen berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Dokumen gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}
