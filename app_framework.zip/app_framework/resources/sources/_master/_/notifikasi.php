<?php
global $access, $par, $_submit;

use App\Classes\NotificationSend;
use App\Models\AppFormatNotification;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;

    case "send":
        NotificationSend::send(
            "KODE0001",
            [
                "{{application_name}}" => "Developer"
            ],
            1,
            "Developer",
            "",
            "",
            0,
            "_/info/background.png",
            [
                "_pdf/xfJNUzBw3ZNU6EOcs3lglGzvSneVuEqj.pdf"
            ]
        );
        break;

    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add`, 1140, 700);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="50">Kode</th>
                <th width="*">Nama</th>
                <th width="120">Diubah</th>
                <th width="120">Diubah Oleh</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(6, [1, 6]); ?>
    <?php
}

function form()
{
    global $access, $par;

    $levels = AppFormatNotification::levels;
    $notification = AppFormatNotification::query()->find($par["id"]);

    $checkboxes = [
        ["name" => "target_application", "value" => 1, "title" => "Aplikasi"],
        ["name" => "target_email", "value" => 1, "title" => "Email"],
        ["name" => "target_sms", "value" => 1, "title" => "SMS"],
    ];

    $checks = $notification ? $notification->only(["target_application", "target_email", "target_sms"]) : [];

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <?php Form::inputLabelText("kode", "code", $notification->code, true, "l-input-small", "vsmallinput text-transform-uppercase", "", "", "minlength='8' maxlength='8'"); ?>
                <?php Form::inputLabelText("Kategori", "category", $notification->category, false, "l-input-small", "vsmallinput"); ?>
                <?php Form::inputLabelText("Nama", "name", $notification->name, true); ?>
                <?php Form::inputLabelTextArea("Deskripsi", "description", $notification->description, false); ?>
                <?php Form::inputLabelText("Kode Menu", "menu_code", $notification->menu_code, false, "l-input-small", "vsmallinput text-transform-uppercase", "", "", ""); ?>
                <?php Form::inputLabelSelectArray("Level", "level", $levels, "", "", $notification->level, true, "", "l-input-small", "vsmallinput", "", "21.3%"); ?>
                <?php Form::inputLabelCheckBoxes("Notifikasi", "notification", $checkboxes, "name", "value", "title", $checks, true); ?>

            </fieldset>

            <br>

            <fieldset class="rounded">
                <?php Form::inputLabelText("Judul", "title", $notification->title, false); ?>
            </fieldset>

            <div class="h-2"></div>

            <ul class="hornav mx-0">
                <li class="current">
                    <a href="#content_application">Aplikasi</a>
                </li>
                <li class="">
                    <a href="#content_email">Email</a>
                </li>
                <li class="">
                    <a href="#content_sms">SMS</a>
                </li>
            </ul>


            <div id="content_application" class="subcontent m-0 px-0 border-none" style="display: block;">
                <textarea name="content_application"
                          id="editor_application" class="w-full max-w-full h-40 box-border border border border-solid border-gray-300"><?= $notification->content_application ?></textarea>
            </div>
            <div id="content_email" class="subcontent m-0 px-0 border-none" style="display: none;">

                <textarea name="content_email"
                          id="editor_email" class="box-border border border border-solid border-gray-300"><?= $notification->content_email ?></textarea>

            </div>
            <div id="content_sms" class="subcontent m-0 px-0 border-none" style="display: none;">
                <textarea name="content_sms"
                          id="editor_sms" class="w-full max-w-full h-40 box-border border border border-solid border-gray-300"><?= $notification->content_sms ?></textarea>
            </div>

        </form>

    </div>
    <script>

        const editor_application = document.getElementById('editor_application')
        const editor_email = document.getElementById('editor_email')
        const editor_sms = document.getElementById('editor_sms')

        CKEDITOR.replace(editor_email)

    </script>
    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "id",
        "code",
        "name",
        "updated_at"
    ];

    $notifications = AppFormatNotification::query()
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        });
    $count = clone $notifications;

    $notifications->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $notifications->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $notifications
        ->get()
        ->map(function ($document, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$document->id}`, 1140, 700);'></a>";
            }
            if ($access["delete"]) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus master notifikasi ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$document->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$document->code}</div>",
                "<div align='left'>{$document->name}</div>",
                "<div align='center'>{$document->updated_at->format("d.m.Y H:i:s")}</div>",
                "<div align='left'>{$document->updatedBy->name}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $user, $request;

    DB::beginTransaction();

    try {

        AppFormatNotification::create([
            "code" => Str::upper($request->code),
            "category" => $request->category ?? "",
            "name" => $request->name,
            "description" => $request->description ?? "",
            "title" => $request->title ?? "",
            "menu_code" => $request->menu_code ?? "",
            "level" => $request->level,
            "target_application" => $request->target_application ?? 0,
            "target_email" => $request->target_email ?? 0,
            "target_sms" => $request->target_sms ?? 0,
            "content_application" => $request->content_application ?? "",
            "content_email" => $request->content_email ?? "",
            "content_sms" => $request->content_sms ?? "",
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Notifikasi berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Notifikasi gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $update = AppFormatNotification::find($par["id"]);

        $update->update([
            "code" => Str::upper($request->code),
            "category" => $request->category ?? "",
            "name" => $request->name,
            "description" => $request->description ?? "",
            "title" => $request->title ?? "",
            "menu_code" => $request->menu_code ?? "",
            "level" => $request->level,
            "target_application" => $request->target_application ?? 0,
            "target_email" => $request->target_email ?? 0,
            "target_sms" => $request->target_sms ?? 0,
            "content_application" => $request->content_application ?? "",
            "content_email" => $request->content_email ?? "",
            "content_sms" => $request->content_sms ?? "",
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Notifikasi berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Notifikasi gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = AppFormatNotification::find($par["id"]);

        $delete->delete();

        DB::commit();

        echo "<script>alert('Notifikasi berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Notifikasi gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}
