<?php

use App\Classes\Approval;
use App\Models\AppApproval;
use App\Models\AppApprovalDetail;
use App\Models\AppApprovalMaster;
use App\View\Components\Form;
use App\View\Components\Layout;
use Illuminate\Support\Facades\DB;

function getContent()
{
    global $access, $par, $_submit;

    switch ($par["mode"])
    {
        default:
            index();
        break;

        case "datas":
            echo datas();
        break;

        case "add":
            add();
        break;

        case "approvalPage":
            approvalPage();
        break;

        case "formApproval":
            if ($access["edit"]) $_submit ? simpanApproval() : Approval::form();
            else index();
        break;
    }
}

function simpanApproval()
{
    global $par;

    $approve = Approval::save();

    if ($approve['success'] == true)
    {
        DB::statement("update approval_test set approval_status = '".$approve['status']."', approval_date = '".date("Y-m-d")."' where id = '".$par['id']."'");
    }

    echo "<script>closeBox()</script>";
    echo "<script>alert('Data berhasil disimpan')</script>";
    echo "<script>reloadPage()</script>";
}

function approvalPage()
{
    global $par;

    Layout::title();

    $data =  DB::table('approval_test')->where('id', $par['id'])->first();

    ?>

    <div class="contentwrapper stdform">

        <fieldset class="rounded">
            <legend class="px-2">Informasi</legend>
            <?= Form::spanLabel("Nama", $data->nama) ?>
        </fieldset>

        <br/>

        <?= Approval::view("TEST_APPR", $par['id']); ?>

    </div>
    <?php
}

function add()
{
    $kodeApproval = "TEST_APPR";
    $kodeMasterMenu = "TEST_APPR";
    $id = 1;
    $dataSet = ["par1" => 1, "par2" => 1, "par3" => 0, "par4" => 1];

    Approval::create($kodeApproval, $kodeMasterMenu, $id, $dataSet);

    echo "<script>window.location='?".getPar($par)."'</script>";
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "id",
        "nama",
    ];

    $getData = DB::table("approval_test")
        ->when($search, function ($query, $search) {
            $query->where(function ($query){
                $query->where("nama", "like", "%{$search}%");
            });
        });
    $count = clone $getData;

    $getData->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $getData->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $getData
        ->get()
        ->map(function ($result, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + ($key + 1);

            return [
                "<div align='center'>{$number}</div>",
                "<div align='center'>{$result->nama}</div>",
                "<div align='center'><a href='?par[mode]=approvalPage&par[id]={$result->id}".$parameter."'>{$result->approval_status}</a></div>"
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function index()
{
    global $par;

    datatable(3, [1, 2, 3]);

    Layout::title();

    ?>

    <div class="contentwrapper">
        <form action="" class="stdform">
            <div class="filter_container">
                <div class="filter_left">
                    <input type="text" id="search">
                </div>
                <div class="filter_right">
                    <a class="stdbtn" href="?par[mode]=add<?= getPar($par, "mode, id") ?>"><i class="fa fa-plus"></i> TAMBAH</a>
                </div>
            </div>
        </form>
        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">No</th>
                <th width="*">Nama</th>
                <th width="120">Status</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <?php
}



?>
