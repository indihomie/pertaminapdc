<?php
global $access, $par, $_submit;

use App\Classes\FormatNumber;
use App\Models\AppFormatNumber;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;

    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add`, 1200, 500);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="50">Kode</th>
                <th width="*">Nama</th>
                <th width="120">Diubah</th>
                <th width="120">Diubah Oleh</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(6, [1, 6]); ?>
    <?php
}

function form()
{
    global $access, $par;

    $delimiters = AppFormatNumber::delimiter;
    $types = AppFormatNumber::type;
    $types_non_empty = collect($types)->filter(fn($value, $key) => $key)->toArray();

    $type_year = [
        "year_4" => "4 Digit",
        "year_2" => "2 Digit",
        "roman_4" => "Romawi 4",
        "roman_2" => "Romawi 2",
    ];
    $type_month = [
        "month" => "Bulan",
        "month_2" => "Angka",
        "month_3" => "3 Huruf",
        "roman" => "Romawi"
    ];

    $format_number = AppFormatNumber::query()->find($par["id"]);

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <div class="grid grid-cols-3 gap-4">
                    <div class="grid">

                        <?php Form::inputLabelText("kode", "code", $format_number->code, true, "l-input-small2", "smallinput text-transform-uppercase", "", "", "minlength='6' maxlength='8'"); ?>
                        <?php Form::inputLabelText("Nama", "name", $format_number->name, true, "l-input-small2"); ?>
                        <?php Form::inputLabelTextArea("Deskripsi", "description", $format_number->description, false, "l-input-small2"); ?>

                    </div>
                </div>

            </fieldset>

            <div class="my-3"></div>

            <fieldset class="rounded">

                <legend>&nbsp; Seting &nbsp;</legend>

                <div class="grid grid-cols-3 gap-4">
                    <div class="grid">
                        <?php Form::inputLabelSelectArray("Delimiter", "delimiter", $delimiters, "", "", $format_number->delimiter, true, "", "l-input-small2", "mediuminput"); ?>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <div class="grid">
                        <?php Form::inputLabelSelectArray("Parameter 1", "parameter_1", $types_non_empty, "", "", $format_number->parameter_1, false, "", "l-input-small2", "mediuminput", "onchange='showField(1)'", ""); ?>
                    </div>
                    <div class="grid">
                        <div id="type_1_year" class="type_1" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_1_type_year", $type_year, "", "", $format_number->parameter_1_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_1_month" class="type_1" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_1_type_month", $type_month, "", "", $format_number->parameter_1_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_1_code" class="type_1" style="display: none;">
                            <?php Form::inputLabelText("Kode", "parameter_1_type_code", $format_number->parameter_1_type, false, "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_1_sequence" class="type_1" style="display: none;">
                            <?php Form::inputLabelNumber("Panjang", "parameter_1_type_sequence", $format_number->parameter_1_type, false, "l-input-small2", "vsmallinput"); ?>
                        </div>
                    </div>
                    <div class="grid">
                        <div id="value_1" style="display: none;">
                            <?php Form::inputLabelText("Nilai", "parameter_1_value", $format_number->parameter_1_value, false, "l-input-small2", "smallinput"); ?>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <div class="grid">
                        <?php Form::inputLabelSelectArray("Parameter 2", "parameter_2", $types_non_empty, "", "", $format_number->parameter_2, false, "", "l-input-small2", "mediuminput", "onchange='showField(2)'", ""); ?>
                    </div>
                    <div class="grid">
                        <div id="type_2_year" class="type_2" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_2_type_year", $type_year, "", "", $format_number->parameter_2_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_2_month" class="type_2" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_2_type_month", $type_month, "", "", $format_number->parameter_2_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_2_code" class="type_2" style="display: none;">
                            <?php Form::inputLabelText("Kode", "parameter_2_type_code", $format_number->parameter_2_type, false, "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_2_sequence" class="type_2" style="display: none;">
                            <?php Form::inputLabelNumber("Panjang", "parameter_2_type_sequence", $format_number->parameter_2_type, false, "l-input-small2", "vsmallinput"); ?>
                        </div>
                    </div>
                    <div class="grid">
                        <div id="value_2" style="display: none;">
                            <?php Form::inputLabelText("Nilai", "parameter_2_value", $format_number->parameter_2_value, false, "l-input-small2", "smallinput"); ?>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <div class="grid">
                        <?php Form::inputLabelSelectArray("Parameter 3", "parameter_3", $types, "", "", $format_number->parameter_3, false, "", "l-input-small2", "mediuminput", "onchange='showField(3)'", ""); ?>
                    </div>
                    <div class="grid">
                        <div id="type_3_year" class="type_3" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_3_type_year", $type_year, "", "", $format_number->parameter_3_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_3_month" class="type_3" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_3_type_month", $type_month, "", "", $format_number->parameter_3_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_3_code" class="type_3" style="display: none;">
                            <?php Form::inputLabelText("Kode", "parameter_3_type_code", $format_number->parameter_3_type, false, "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_3_sequence" class="type_3" style="display: none;">
                            <?php Form::inputLabelNumber("Panjang", "parameter_3_type_sequence", $format_number->parameter_3_type, false, "l-input-small2", "vsmallinput"); ?>
                        </div>
                    </div>
                    <div class="grid">
                        <div id="value_3" style="display: none;">
                            <?php Form::inputLabelText("Nilai", "parameter_3_value", $format_number->parameter_3_value, false, "l-input-small2", "smallinput"); ?>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <div class="grid">
                        <?php Form::inputLabelSelectArray("Parameter 4", "parameter_4", $types, "", "", $format_number->parameter_4, false, "", "l-input-small2", "mediuminput", "onchange='showField(4)'", ""); ?>
                    </div>
                    <div class="grid">
                        <div id="type_4_year" class="type_4" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_4_type_year", $type_year, "", "", $format_number->parameter_4_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_4_month" class="type_4" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_4_type_month", $type_month, "", "", $format_number->parameter_4_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_4_code" class="type_4" style="display: none;">
                            <?php Form::inputLabelText("Kode", "parameter_4_type_code", $format_number->parameter_4_type, false, "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_4_sequence" class="type_4" style="display: none;">
                            <?php Form::inputLabelNumber("Panjang", "parameter_4_type_sequence", $format_number->parameter_4_type, false, "l-input-small2", "vsmallinput"); ?>
                        </div>
                    </div>
                    <div class="grid">
                        <div id="value_4" style="display: none;">
                            <?php Form::inputLabelText("Nilai", "parameter_4_value", $format_number->parameter_4_value, false, "l-input-small2", "smallinput"); ?>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <div class="grid">
                        <?php Form::inputLabelSelectArray("Parameter 5", "parameter_5", $types, "", "", $format_number->parameter_5, false, "", "l-input-small2", "mediuminput", "onchange='showField(5)'", ""); ?>
                    </div>
                    <div class="grid">
                        <div id="type_5_year" class="type_5" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_5_type_year", $type_year, "", "", $format_number->parameter_5_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_5_month" class="type_5" style="display: none;">
                            <?php Form::inputLabelSelectArray("Tipe", "parameter_5_type_month", $type_month, "", "", $format_number->parameter_5_type, false, "", "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_5_code" class="type_5" style="display: none;">
                            <?php Form::inputLabelText("Kode", "parameter_5_type_code", $format_number->parameter_5_type, false, "l-input-small2", "mediuminput"); ?>
                        </div>
                        <div id="type_5_sequence" class="type_5" style="display: none;">
                            <?php Form::inputLabelNumber("Panjang", "parameter_5_type_sequence", $format_number->parameter_5_type, false, "l-input-small2", "vsmallinput"); ?>
                        </div>
                    </div>
                    <div class="grid">
                        <div id="value_5" style="display: none;">
                            <?php Form::inputLabelText("Nilai", "parameter_5_value", old("parameter_5_value", $format_number->parameter_5_value), false, "l-input-small2", "smallinput"); ?>
                        </div>
                    </div>
                </div>

            </fieldset>

        </form>

    </div>
    <script>

        function showField(index) {

            let field_parameter = jQuery(`#parameter_${index}`)

            let type = field_parameter.val()

            jQuery(`.type_${index}`).hide()
            jQuery(`#type_${index}_${type}`).show()

            jQuery(`#value_${index}`).toggle(!["", "code"].includes(type))

        }

        for (let n = 1; n <= 5; n++) {
            showField(n)
        }

    </script>
    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "id",
        "code",
        "name",
        "updated_at"
    ];

    $notifications = AppFormatNumber::query()
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        });
    $count = clone $notifications;

    $notifications->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $notifications->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $notifications
        ->get()
        ->map(function ($document, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$document->id}`, 1200, 500);'></a>";
            }
            if ($access["delete"]) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus master notifikasi ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$document->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$document->code}</div>",
                "<div align='left'>{$document->name}</div>",
                "<div align='center'>{$document->updated_at->format("d.m.Y H:i:s")}</div>",
                "<div align='left'>{$document->updatedBy->name}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $user, $request, $par;

    $parameter = getPar($par);

    $request->mergeIfMissing([
        "parameter_1_type" => $request["parameter_1_type_{$request->parameter_1}"] ?? "",
        "parameter_2_type" => $request["parameter_2_type_{$request->parameter_2}"] ?? "",
        "parameter_3_type" => $request["parameter_3_type_{$request->parameter_3}"] ?? "",
        "parameter_4_type" => $request["parameter_4_type_{$request->parameter_4}"] ?? "",
        "parameter_5_type" => $request["parameter_5_type_{$request->parameter_5}"] ?? "",
    ]);

    $validator = Validator::make($request->all(), [
        "code" => "required|min:3",
        "name" => "required|min:4",
        "description" => "sometimes",
        "delimiter" => "sometimes",

        "parameter_1" => "required",
        "parameter_2" => "required",
        "parameter_3" => "sometimes",
        "parameter_4" => "sometimes",
        "parameter_5" => "sometimes",

        "parameter_1_type" => "required",
        "parameter_2_type" => "required",
        "parameter_3_type" => "sometimes",
        "parameter_4_type" => "sometimes",
        "parameter_5_type" => "sometimes",

        "parameter_1_value" => "sometimes",
        "parameter_2_value" => "sometimes",
        "parameter_3_value" => "sometimes",
        "parameter_4_value" => "sometimes",
        "parameter_5_value" => "sometimes",
    ]);

    if ($validator->fails()) {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?{$parameter}'</script>";
        return;
    }

    DB::beginTransaction();

    try {

        AppFormatNumber::create([
            "code" => Str::upper($request->code),
            "name" => $request->name,
            "description" => $request->description ?? "",
            "delimiter" => $request->delimiter ?? "",

            "parameter_1" => $request->parameter_1,
            "parameter_2" => $request->parameter_2,
            "parameter_3" => $request->parameter_3 ?? "",
            "parameter_4" => $request->parameter_4 ?? "",
            "parameter_5" => $request->parameter_5 ?? "",

            "parameter_1_type" => $request->parameter_1_type,
            "parameter_2_type" => $request->parameter_2_type,
            "parameter_3_type" => $request->parameter_3_type ?? "",
            "parameter_4_type" => $request->parameter_4_type ?? "",
            "parameter_5_type" => $request->parameter_5_type ?? "",

            "parameter_1_value" => $request->parameter_1_value ?? "",
            "parameter_2_value" => $request->parameter_2_value ?? "",
            "parameter_3_value" => $request->parameter_3_value ?? "",
            "parameter_4_value" => $request->parameter_4_value ?? "",
            "parameter_5_value" => $request->parameter_5_value ?? "",

            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Penomoran berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Penomoran gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    $parameter = getPar($par);

    $request->mergeIfMissing([
        "parameter_1_type" => $request["parameter_1_type_{$request->parameter_1}"] ?? "",
        "parameter_2_type" => $request["parameter_2_type_{$request->parameter_2}"] ?? "",
        "parameter_3_type" => $request["parameter_3_type_{$request->parameter_3}"] ?? "",
        "parameter_4_type" => $request["parameter_4_type_{$request->parameter_4}"] ?? "",
        "parameter_5_type" => $request["parameter_5_type_{$request->parameter_5}"] ?? "",
    ]);

    $validator = Validator::make($request->all(), [
        "code" => "required|min:3",
        "name" => "required|min:4",
        "description" => "sometimes",
        "delimiter" => "sometimes",

        "parameter_1" => "required",
        "parameter_2" => "required",
        "parameter_3" => "sometimes",
        "parameter_4" => "sometimes",
        "parameter_5" => "sometimes",

        "parameter_1_type" => "required",
        "parameter_2_type" => "required",
        "parameter_3_type" => "sometimes",
        "parameter_4_type" => "sometimes",
        "parameter_5_type" => "sometimes",

        "parameter_1_value" => "sometimes",
        "parameter_2_value" => "sometimes",
        "parameter_3_value" => "sometimes",
        "parameter_4_value" => "sometimes",
        "parameter_5_value" => "sometimes",
    ]);

    if ($validator->fails()) {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?{$parameter}'</script>";
        return;
    }

    DB::beginTransaction();

    try {

        $update = AppFormatNumber::find($par["id"]);

        $update->update([
            "code" => Str::upper($request->code),
            "name" => $request->name,
            "description" => $request->description ?? "",
            "delimiter" => $request->delimiter ?? "",

            "parameter_1" => $request->parameter_1,
            "parameter_2" => $request->parameter_2,
            "parameter_3" => $request->parameter_3 ?? "",
            "parameter_4" => $request->parameter_4 ?? "",
            "parameter_5" => $request->parameter_5 ?? "",

            "parameter_1_type" => $request->parameter_1_type,
            "parameter_2_type" => $request->parameter_2_type,
            "parameter_3_type" => $request->parameter_3_type ?? "",
            "parameter_4_type" => $request->parameter_4_type ?? "",
            "parameter_5_type" => $request->parameter_5_type ?? "",

            "parameter_1_value" => $request->parameter_1_value ?? "",
            "parameter_2_value" => $request->parameter_2_value ?? "",
            "parameter_3_value" => $request->parameter_3_value ?? "",
            "parameter_4_value" => $request->parameter_4_value ?? "",
            "parameter_5_value" => $request->parameter_5_value ?? "",

            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Penomoran berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Penomoran gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = AppFormatNumber::find($par["id"]);

        $delete->delete();

        DB::commit();

        echo "<script>alert('Penomoran berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Penomoran gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}
