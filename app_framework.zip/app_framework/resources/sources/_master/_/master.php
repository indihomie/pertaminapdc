<?php
global $access, $par, $_submit;

use App\Classes\ExportExcel;
use App\Models\AppMaster;
use App\Models\AppMasterCategory;
use App\Models\AppModule;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;

    case "export":
        exportExcel();
        break;


    case "child_index":
        indexChild();
        break;

    case "child_data":
        echo datasChild();
        break;

    case "child_add":
        if ($access["add"])
            $_submit ? storeChild() : formChild();
        else
            echo "Tidak ada akses";
        break;

    case "child_edit":
        if ($access["edit"])
            $_submit ? updateChild() : formChild();
        else
            echo "Tidak ada akses";
        break;

    case "child_delete":
        if ($access["delete"])
            destroyChild();
        else
            echo "Tidak ada akses";
        break;


    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    $modules = AppModule::query()->select(["id", "name"])->orderBy("order")->get();

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">
                    &nbsp;
                    <?= Form::selectArray("Filter Modul", "change_1", $modules, "id", "name", session("filter_module", ""), "- Semua Modul -"); ?>

                </div>
                <div class="filter_right">

                    <?php if ($access["add"] || $access["edit"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="exports()"
                        ><i class="fas fa-file-excel"></i> EKSPOR</a>
                        &nbsp;
                    <?php endif; ?>

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add`, 650, 520);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="50">Kode</th>
                <th width="30">Ikon</th>
                <th width="100">Modul</th>
                <th width="*">Nama</th>
                <th width="20">Urut</th>
                <th width="50">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(8, [2, 3, 7, 8]); ?>

    <script>

        function exports() {

            let search = jQuery("#search").val()
            let module_id = jQuery("#change_1").val()

            taskBackground(`<?= $parameter ?>&par[mode]=export&change_id=${module_id}&search=${search}`)
        }

    </script>
    <?php
}

function indexChild()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    $category = AppMasterCategory::find($par["category_id"]);
    $category_parent = $category->category;

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="">

            <div style="position: absolute; top: 1rem; right: 1.2rem;">
                <a class="stdbtn" href="index?<?= getPar($par, "mode, category_id") ?>">Kembali</a>
            </div>

        </form>

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">
                    &nbsp;
                    <?php if ($category_parent) : ?>
                        <?= Form::selectArray("Induk", "change_1", $category_parent->masters, "id", "name", session("filter_category", ""), "- Pilih Induk -", "", "200px;") ?>
                        &nbsp;
                    <?php endif; ?>
                    <strong>Kategori: <?= $category->name ?></strong>

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=child_add`, 650, 450);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="50">Kode</th>
                <th width="150">Kategori</th>
                <th width="150">Induk Ke</th>
                <th width="*">Nama</th>
                <th width="20">Urut</th>
                <th width="50">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(8, [3, 4, 8], "child_data"); ?>
    <?php
}

function form()
{
    global $access, $par;

    $modules = AppModule::query()->select(["id", "name"])->orderBy("order")->get()->toArray();
    $parents = AppMasterCategory::query()->select(["id", "name"])->where("id", "!=", $par["id"])->orderBy("order")->get()->toArray();
    $statuses = config("paramter.status_label");

    $category = AppMasterCategory::find($par["id"]);

    $category_order = $category->order ?? AppMasterCategory::query()->select("order")->orderBy("order", "desc")->first()->order + 1;

    $readonly = $par["mode"] == "edit" ? "readonly" : "";

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <?php Form::inputLabelSelectArray("Modul", "module_id", $modules, "id", "name", $category->module_id, false, "- Pilih Modul -", "l-input-small", "mediuminput", "", "63%") ?>
                <?php Form::inputLabelSelectArray("Induk", "category_id", $parents, "id", "name", $category->category_id, false, "- Pilih Induk -", "l-input-small", "mediuminput", "", "63%") ?>
                <?php Form::inputLabelText("Kode", "id", $category->id, true, "l-input-small", "vsmallinput text-transform-uppercase", "", "", "minlength='4' maxlength='4' $readonly"); ?>
                <?php Form::inputLabelText("Nama", "name", $category->name, true); ?>
                <?php Form::inputLabelTextArea("Deskripsi", "description", $category->description, false); ?>
                <?php Form::inputLabelTextArea("Data", "data", json_encode($category->data ?? []), false, "l-input-small", "mediuminput", "style='height: 5rem;'"); ?>
                <?php Form::inputLabelNumber("Urut", "order", $category_order); ?>
                <?php Form::inputLabelDocument("Ikon", "icon", $category->path_icon, false, "l-input-small", ".png", false); ?>
                <?php Form::inputLabelRadio("Status", "status", $statuses, $category->status ?? 1); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function formChild()
{
    global $access, $par;

    $category = AppMasterCategory::find($par["category_id"]);
    $category_parent = $category->category;
    $statuses = config("paramter.status_label");

    $last_id = "";

    $master = AppMaster::find($par["id"]);

    if ($par["mode"] == "child_add") {

        $last_id = $category->masters()->select("id")->orderBy("id", "desc")->first()->id ?? "";
        $last_id = Str::replace($category->id, "", $last_id);
        $last_id = (int)$last_id + 1;
        $last_id = $category->id . Str::padLeft($last_id, 4, '0');

        $master_order = $master->order ?? $category->masters()->select("order")->orderBy("order", "desc")->first()->order + 1;
    }

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <?php Form::spanLabel("Kategori", $category->name); ?>
                <?php if ($category_parent) : ?>
                    <?php Form::inputLabelSelectArray($category_parent->name, "master_id", $category_parent->masters, "id", "name", $master->master_id, false, "- Pilih Induk -", "l-input-small", "mediuminput", "", "63%") ?>
                <?php endif; ?>
                <?php Form::inputLabelText("kode", "id", $master->id ?? $last_id, true, "l-input-small", "vsmallinput text-transform-uppercase", "", "", "minlength='8' maxlength='8' readonly"); ?>
                <?php Form::inputLabelText("Nama", "name", $master->name, true); ?>
                <?php Form::inputLabelTextArea("Description", "description", $master->description, false); ?>
                <?php Form::inputLabelTextArea("Data", "data", json_encode($master->data ?? []), false); ?>
                <?php Form::inputLabelNumber("Urut", "order", $master_order); ?>
                <?php Form::inputLabelRadio("Status", "status", $statuses, $master->status ?? 1); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search, $change_1;

    session()->put("filter_module", $change_1);

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "order",
        "id",
        "icon",
        "module_id",
        "name",
        "order",
        "status",
    ];

    $master_categories = AppMasterCategory::query()
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        })
        ->when($change_1, function ($query, $module_id) {
            $query->where("module_id", $module_id);
        });
    $count = clone $master_categories;

    $master_categories->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $master_categories->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $master_categories
        ->with("module:id,name")
        ->withCount("masters")
        ->get()
        ->map(function ($category, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $image_viewer = $category->path_icon ? openView($category->path_icon) : "-";

            $control = "";

            $control .= "<a title='Lihat Data' class='detail' href='index?{$parameter}&par[mode]=child_index&par[category_id]={$category->id}'></a>";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$category->id}`, 650, 520);'></a>";
            }
            if ($access["delete"] && $category->masters_count == 0) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus kategori ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$category->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$category->id}</div>",
                "<div align='center'>{$image_viewer}</div>",
                "<div align='left'>{$category->module->name}</div>",
                "<div align='left'>{$category->name}</div>",
                "<div align='right'>{$category->order}</div>",
                "<div align='center'>{$category->status_image}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function datasChild()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search, $change_1;

    session()->put("filter_category", $change_1);

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "order",
        "id",
        "category_id",
        "master_id",
        "name",
        "order",
        "status",
    ];

    $masters = AppMaster::query()
        ->with(["category", "subParent"])
        ->where("category_id", $par["category_id"])
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        })
        ->when($change_1, function ($query, $master_id) {
            $query->where("master_id", $master_id);
        });
    $count = clone $masters;

    $masters->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $masters->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $masters
        ->with("category:id,name")
        ->withCount("subChilds")
        ->get()
        ->map(function ($master, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=child_edit&par[id]={$master->id}`, 650, 450);'></a>";
            }
            if ($access["delete"] && $master->sub_childs_count == 0) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus master ini?`) ? openBox(`void?{$parameter}&par[mode]=child_delete&par[id]={$master->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$master->id}</div>",
                "<div align='left'>{$master->category->name}</div>",
                "<div align='left'>{$master->subParent->name}</div>",
                "<div align='left'>{$master->name}</div>",
                "<div align='right'>{$master->order}</div>",
                "<div align='center'>{$master->status_image}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $user, $request;

    DB::beginTransaction();

    try {

        AppMasterCategory::create([
            "module_id" => $request->module_id ?? "",
            "category_id" => $request->category_id ?? "",
            "id" => $request->id,
            "name" => $request->name,
            "description" => $request->description ?? "",
            "data" => json_decode($request->data),
            "order" => $request->order,
            "status" => $request->status,
            "path_icon" => $request->file("icon") ? $request->file("icon")->store(AppMasterCategory::$path_image, ["disk" => "public"]) : "",
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Kategori berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Kategori gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function storeChild()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $category = AppMasterCategory::find($par["category_id"]);

        $category->masters()
            ->create([
                "master_id" => $request->master_id ?? "",
                "id" => $request->id,
                "name" => $request->name,
                "description" => $request->description ?? "",
                "data" => json_decode($request->data),
                "order" => $request->order,
                "status" => $request->status,
                "created_by" => $user->id,
                "updated_by" => $user->id,
            ]);

        DB::commit();

        echo "<script>alert('Master berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Master gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $update = AppMasterCategory::find($par["id"]);

        $update->update([
            "module_id" => $request->module_id ?? "",
            "category_id" => $request->category_id ?? "",
            "name" => $request->name,
            "description" => $request->description,
            "data" => json_decode($request->data),
            "order" => $request->order,
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        if ($request->file("icon") || $request->icon_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($update->path_icon)) {
                $storage->delete($update->path_icon);
            }

            $update->update([
                "path_icon" => ""
            ]);
        }

        if ($request->file("icon")) {
            $update->update([
                "path_icon" => $request->file("icon")->store(AppMasterCategory::$path_image, ["disk" => "public"])
            ]);
        }

        DB::commit();

        echo "<script>alert('Kategori berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Kategori gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function updateChild()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $category = AppMasterCategory::find($par["category_id"]);
        $update = $category->masters()->find($par["id"]);

        $update->update([
            "master_id" => $request->master_id ?? "",
            "name" => $request->name,
            "description" => $request->description,
            "data" => json_decode($request->data),
            "order" => $request->order,
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Master berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Master gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = AppMasterCategory::find($par["id"]);

        $storage = Storage::disk("public");

        if ($storage->exists($delete->path_icon)) {
            $storage->delete($delete->path_icon);
        }

        $delete->delete();

        DB::commit();

        echo "<script>alert('Kategori berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Kategori gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}

function destroyChild()
{
    global $par;

    DB::beginTransaction();

    try {

        $category = AppMasterCategory::find($par["category_id"]);
        $delete = $category->masters()->find($par["id"]);

        $delete->delete();

        DB::commit();

        echo "<script>alert('Master berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Master gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}

function exportExcel()
{
    global $module_sub, $menu;
    global $change_id, $search;

    $time = now()->format("Ymd His");
    $path = "_exports";
    $filename = "{$module_sub["name"]} {$menu["name"]} {$time}.xlsx";

    $master_categories_with_masters = AppMasterCategory::query()
        ->select(["id", "name"])
        ->with([
            "masters",
            "masters.subParent:id,name"
        ])
        ->when($change_id, function ($query, $module_id) {
            $query->where("module_id", $module_id);
        })
        ->when($search, function ($query, $search) {
            $query->where("name", "%{$search}%");
        })
        ->orderBy("order")
        ->get();

    $masters = [];

    foreach ($master_categories_with_masters as $category_with_masters) {

        $masters[] = $category_with_masters->name;

        foreach ($category_with_masters->masters as $index => $master) {

            $masters[] = [
                $index + 1,
                $master->id,
                $master->subParent->name ?? "-",
                $master->name,
                $master->order,
                $master->status_label
            ];
        }

    }

    ExportExcel::simple(
        "Ekspor {$menu["name"]}",
        $filename,
        $path,
        ["#", "Kode", "Induk Ke", "Nama", "Urut", "Status"],
        [8, 15, 20, 40, 8, 10],
        $masters,
        ["right", "center", "left", "left"]
    );

    $file_path = encrypt("{$path}/{$filename}");

    echo "<script>parent.toggleLoader(false)</script>";
    echo "<script>window.location='public/download/{$file_path}'</script>";
}
