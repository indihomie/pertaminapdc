<?php
global $access, $par, $_submit, $code;

use App\Classes\FormatDocument;
use App\Models\AppParameter;
use App\View\Components\Form;
use App\View\Components\Layout;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;

    default:
        index();
        break;
}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

?>

<?php Layout::title(); ?>

<div class="contentwrapper">

    <form action="" class="stdform">

        <div class="filter_container">
            <div class="filter_left">

                <input type="text" id="search">

            </div>
            <div class="filter_right">

                <?php if ($access["add"]) : ?>
                <a class="stdbtn" href="#" onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add`, 600, 300);"><i
                        class="fa fa-plus"></i> TAMBAH</a>
                <?php endif; ?>

            </div>
        </div>

    </form>

    <table id="table" class="stdtable stdtablequick">
        <thead>
            <tr>
                <th width="20">#</th>
                <th width="100">Kode</th>
                <th width="*">Nama</th>
                <th width="200">Value</th>
                <th width="120">Diubah</th>
                <th width="120">Diubah Oleh</th>
                <th width="50">Kontrol</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>

</div>

<?php datatable(7, [1, 8]); ?>
<script>
function print(code) {
    taskBackground(`<?= $parameter ?>&par[mode]=print&code=${code}`)
}
</script>
<?php
}

function form()
{
    global $access, $par;

    $parameter = AppParameter::query()->find($par["id"]);

?>
<div>

    <?php Layout::title(true); ?>

    <form method="post" action="?<?= getPar($par) ?>&_submit=1" id="form" class="stdform" name="form"
        onsubmit="toggleLoader();" autocomplete="off" enctype="multipart/form-data">

        <?php Form::CSRF(); ?>

        <?php if ($access["add"] || $access["edit"]) : ?>
        <div style="position: absolute; top: 1rem; right: .3rem;">
            <input type="submit" class="submit radius2" value="Simpan" />
        </div>
        <?php endif; ?>

        <fieldset class="rounded">

            <?php Form::inputLabelText("Kode", "code", $parameter->code, true, "l-input-small", "vsmallinput text-transform-uppercase", "", "", "minlength='3' maxlength='8'"); ?>
            <?php Form::inputLabelText("Nama", "name", $parameter->name, true); ?>
            <?php Form::inputLabelTextArea("Value", "value", $parameter->value, true); ?>

        </fieldset>
    </form>

</div>
<?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $arr_order = [
        "id",
        "code",
        "name",
        "updated_at",
        "updated_by",
    ];

    $parameters = AppParameter::query()
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        });

    $count = $parameters->count();

    $parameters->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $parameters->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $parameters
        ->get()
        ->map(function ($parameter, $key) use ($iDisplayStart, $access, $par) {
            $par = getPar($par, "mode, id");

            $number = $iDisplayStart + ($key + 1);

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$par}&par[mode]=edit&par[id]={$parameter->id}`, 600, 300);'></a>";
            }
            if ($access["delete"]) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus master parameter ini?`) ? openBox(`void?{$par}&par[mode]=delete&par[id]={$parameter->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$parameter->code}</div>",
                "<div align='left'>{$parameter->name}</div>",
                "<div align='left'>{$parameter->value}</div>",
                "<div align='center'>{$parameter->updated_at->format("d.m.Y H:i:s")}</div>",
                "<div align='left'>{$parameter->updatedBy->name}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count,
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $user, $request;

    DB::beginTransaction();

    try {

        AppParameter::create([
            "code" => Str::upper($request->code),
            "name" => $request->name,
            "value" => $request->value,
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Parameter berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Parameter gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $update = AppParameter::find($par["id"]);

        $update->update([
            "code" => Str::upper($request->code),
            "name" => $request->name,
            "value" => $request->value,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Parameter berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Parameter gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = AppParameter::find($par["id"]);

        $delete->delete();

        DB::commit();

        echo "<script>alert('Parameter berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Parameter gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}