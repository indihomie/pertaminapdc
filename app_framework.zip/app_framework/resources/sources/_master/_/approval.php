<?php

use App\Models\AppApprovalMaster;
use App\Models\AppApprovalAktor;
use App\Models\AppApprovalStep;
use App\Models\AppApprovalCondition;
use App\Models\AppGroup;
use App\View\Components\Form;
use App\View\Components\Layout;

function getContent()
{
    global $access, $par, $_submit;

    switch ($par["mode"])
    {
        default:
            index();
        break;

        case "datas":
            echo datas();
        break;

        case "add":
            if ($access["add"]) $_submit ? store() : form();
            else echo "Tidak ada akses";
        break;

        case "edit":
            if ($access["edit"]) $_submit ? update() : form();
            else echo "Tidak ada akses";
        break;

        case "delete":
            if ($access["delete"]) destroy();
            else echo "Tidak ada akses";
        break;

        case "formAktor":
            if ($access["add"]) $_submit ? storeAktor() : formAktor();
            else echo "Tidak ada akses";
        break;

        case "deleteAktor":
            if ($access["delete"]) destroyAktor();
            else echo "Tidak ada akses";
        break;

        case "deleteStep":
            if ($access["delete"]) destroyStep();
            else echo "Tidak ada akses";
            break;

        case "formStep":
            if ($access["add"]) $_submit ? storeStep() : formStep();
            else echo "Tidak ada akses";
        break;

        case "formCondition":
            if ($access["add"]) $_submit ? storeCondition() : formCondition();
            else echo "Tidak ada akses";
        break;

        case "deleteCondition":
            if ($access["delete"]) destroyCondition();
            else echo "Tidak ada akses";
        break;
    }
}

function destroyCondition()
{
    global $par;

    DB::beginTransaction();

    try
    {
        $data = AppApprovalCondition::find($par['idCondition']);
        $data->delete();

        DB::commit();

        echo "<script>alert('Data berhasil dihapus')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal dihapus')</script>";
    }

    echo "<script>window.location='?par[mode]=edit" . getPar($par, "mode, idCondition") . "'</script>";
}

function storeCondition()
{
    global $par, $user, $request;

    echo "<script>closeBox()</script>";

    DB::beginTransaction();

    try
    {
        $arrSetData = [
            'master_id' => $par['id'],
            'step_id' => $par['idStep'],
            'tipe' => $request->tipe,
            'kondisi' => $request->kondisi,
            'nilai' => $request->nilai,
            'parameter' => $request->parameter,
            'updated_by' => $user->id,
        ];

        $aktor = AppApprovalCondition::firstOrCreate(['id' => $par['idCondition']], ['created_by' => $user->id]);
        $aktor->update($arrSetData);

        DB::commit();

        echo "<script>alert('Data berhasil disimpan')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal disimpan')</script>";
    }

    echo "<script>reloadPage()</script>";
}

function formCondition()
{
    global $par;

    $data = AppApprovalCondition::find($par['idCondition']);

    $getField = AppApprovalMaster::find($par['id']);
    $field = Collect(explode(",", $getField->parameter))->mapWithKeys(fn($param) => [$param => $param]);
    $kondisi = Collect(["==", "!=", "<", "<=", ">", "=>"])->mapWithKeys(fn($param) => [$param => $param]);

    Layout::title(true, "Kondisi");

    ?>
    <div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
              onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
              autocomplete="off">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <p style="position:absolute;right:5px;top:5px;">
                <?= Layout::formBtnSubmit(true) ?>
            </p>
            <div id="general" class="subcontent">
                <?php
                Form::inputLabelSelectArray('Tipe', 'tipe', $field, '', '', $data->tipe, '', '', '', 'kosong', '', '150px');
                Form::inputLabelSelectArray('Kondisi', 'kondisi', $kondisi, '', '', $data->kondisi, '', '', '', 'kosong', '', '150px');
                Form::inputLabelText('Nilai', 'nilai', $data->nilai, '', '', '', "", '', "style=\"width:140px !important;\"");
                Form::inputLabelText('Parameter', 'parameter', $data->parameter, '', '', '', "", '', "style=\"width:140px !important;\"");
                ?>
            </div>
        </form>
    </div>
    <?php
}

function destroyStep()
{
    global $par;

    DB::beginTransaction();

    try
    {
        $data = AppApprovalStep::find($par["idStep"]);
        $data->delete();

        DB::commit();

        echo "<script>alert('Data berhasil dihapus')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal dihapus')</script>";
    }

    echo "<script>window.location='?par[mode]=edit" . getPar($par, "mode, idStep") . "'</script>";
}

function storeStep()
{
    global $par, $user, $request;

    echo "<script>closeBox()</script>";

    DB::beginTransaction();

    try
    {
        $arrSetData = [
            'master_id' => $par['id'],
            'group' => $request->group,
            'urut' => $request->urut,
            'next' => $request->next,
            'prev' => $request->prev,
            'updated_by' => $user->id,
        ];

        $aktor = AppApprovalStep::firstOrCreate(['id' => $par['idStep']], ['created_by' => $user->id]);
        $aktor->update($arrSetData);

        DB::commit();

        echo "<script>alert('Data berhasil disimpan')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal disimpan')</script>";
    }

    echo "<script>reloadPage()</script>";
}

function formStep()
{
    global $par;

    $data = AppApprovalStep::find($par['idStep']);
    $grupAktor = AppApprovalAktor::query()->where("master_id", $par['id'])->groupBy("group")->orderBy("group", "asc")->get();

    Layout::title(true, "Step");

    ?>
    <div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
              onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
              autocomplete="off">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <p style="position:absolute;right:5px;top:5px;">
                <?= Layout::formBtnSubmit(true) ?>
            </p>
            <div id="general" class="subcontent">
                <?php
                Form::inputLabelText('Urut', 'urut', $data->urut, '', '', '', "onkeyup=\"cekAngka(this)\"", '', "style=\"width:70px !important;\"");
                Form::inputLabelSelectArray('Grup', 'group', $grupAktor, 'group', 'group', $data->group, '', '', '', 'kosong', '', '82px');
                Form::inputLabelText('Prev', 'prev', $data->prev, '', '', '', "onkeyup=\"cekAngka(this)\"", '', "style=\"width:70px !important;\"");
                Form::inputLabelText('Next', 'next', $data->next, '', '', '', "onkeyup=\"cekAngka(this)\"", '', "style=\"width:70px !important;\"");
                ?>
                <br>
                <div class="notibar announcement">
                    <a class="close"></a>
                    &nbsp;&nbsp;Prev diisi 0 untuk Rejected, Next diisi 99 untuk Approved.
                </div>
            </div>
        </form>
    </div>
    <?php
}

function destroyAktor()
{
    global $par;

    DB::beginTransaction();

    try
    {
        $data = AppApprovalAktor::find($par["idAktor"]);
        $data->delete();

        DB::commit();

        echo "<script>alert('Data berhasil dihapus')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal dihapus')</script>";
    }

    echo "<script>window.location='?par[mode]=edit" . getPar($par, "mode, idAktor") . "'</script>";
}

function destroy()
{
    global $par, $user;

    DB::beginTransaction();

    try
    {
        $data = AppApprovalMaster::find($par["id"]);
        $data->delete();
        $data->update(["deleted_by" => $user->id]);

        DB::commit();

        echo "<script>alert('Data berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}

function storeAktor()
{
    global $par, $user, $request;

    echo "<script>closeBox()</script>";

    DB::beginTransaction();

    try
    {
        $arrSetData = [
            'master_id' => $par['id'],
            'group' => $request->group,
            'parameter' => $request->parameter,
            'aktor' => $request->aktor,
            'updated_by' => $user->id,
        ];

        $aktor = AppApprovalAktor::firstOrCreate(['id' => $par['idAktor']], ['created_by' => $user->id]);
        $aktor->update($arrSetData);

        DB::commit();

        echo "<script>alert('Data berhasil disimpan')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal disimpan')</script>";
    }

    echo "<script>reloadPage()</script>";
}

function formAktor()
{
    global $par;

    $data = AppApprovalAktor::find($par['idAktor']);
    $groupUser = AppGroup::where('id', '!=', '-1')->get();

    Layout::title(true, "Aktor");

    ?>
    <div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>"
              onsubmit="return validation(document.form) ? toggleLoader() : false;" enctype="multipart/form-data"
              autocomplete="off">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <p style="position:absolute;right:5px;top:5px;">
                <?= Layout::formBtnSubmit(true) ?>
            </p>
            <div id="general" class="subcontent">
                <?php
                Form::inputLabelText('Grup', 'group', $data->group, '', '', '', "onkeyup=\"cekAngka(this)\"", '', "style=\"width:70px !important;\"");
                Form::inputLabelText('Parameter', 'parameter', $data->parameter);
                Form::inputLabelSelectArray('Aktor', 'aktor', $groupUser, 'id', 'name', $data->aktor, '', '', '', 'kosong', '', '263px');
                ?>
            </div>
        </form>
    </div>
    <?php
}

function update()
{
    global $user, $request, $par;

    $validator = Validator::make($request->all(), [
        "kode" => "required|min:3"
    ]);

    if ($validator->fails())
    {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?".getPar($par)."'</script>";
        return;
    }

    DB::beginTransaction();

    try
    {
        $data = AppApprovalMaster::find($par['id']);
        $data->update([
            "kode" => $request->kode,
            "parameter" => $request->parameter,
            "keterangan" => $request->keterangan,
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Data berhasil disimpan')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal disimpan')</script>";
    }

    echo "<script>window.location='?par[mode]=edit&par[id]={$par['id']}".getPar($par)."'</script>";
}

function store()
{
    global $user, $request;

    $validator = Validator::make($request->all(), [
        "kode" => "required|min:3"
    ]);

    if ($validator->fails())
    {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?".getPar($par)."'</script>";
        return;
    }

    DB::beginTransaction();

    try
    {
        $data = AppApprovalMaster::create([
            "kode" => $request->kode,
            "keterangan" => $request->keterangan,
            "parameter" => $request->parameter,
            "status" => $request->status,
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Data berhasil disimpan')</script>";
    }
    catch (Exception $e)
    {
        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal disimpan')</script>";
    }

    echo "<script>window.location='?par[mode]=edit&par[id]={$data->id}".getPar($par)."'</script>";
}

function form()
{
    global $access, $par;

    $data = AppApprovalMaster::find($par['id']);

    Layout::title();

    ?>
    <div class="contentwrapper">

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <div style="position: absolute; top: 1rem; right: 1.25rem;">
                <a class="stdbtn" href="index?<?= getPar($par, "mode, id") ?>">KEMBALI</a>
                <?php if ($access['add'] or $access['edit']) : ?>
                    <input type="submit" class="submit radius2" value="SIMPAN"/>
                <?php endif; ?>
            </div>

            <fieldset class="rounded">
                <legend class="px-2">Informasi</legend>
                <?php
                Form::inputLabelText("Kode", "kode", $data->kode, true, "l-input-small", "vsmallinput");
                Form::inputLabelTextArea("Keterangan", "keterangan", $data->keterangan, false, "l-input-small");
                Form::inputLabelTags('Parameter', 'parameter', $data->parameter);
                Form::inputLabelRadio("Status", "status", config("paramter.status_label"), $data->status ?? 1);
                ?>
            </fieldset>

            <br clear="all"/>

            <div class="widgetbox" style="margin-bottom: 2px;">
                <div class="title">
                    <h3 style="position: relative; clear:both; float:left; margin-top: 20px ">Aktor</h3>
                    <div style="position: relative; float: right; margin-right: -25px">
                        <?php
                        if (empty($par['id'])) echo "<a onclick=\"alert('Simpan form terlebih dahulu');\" href=\"#\" class=\"btn btn1 btn_document\"><span>Tambah Data</span></a>";
                        else echo "<a onclick=\"openBox('popup?par[mode]=formAktor".getPar($par,"mode, idAktor")."', 600, 250);\" href=\"#\" class=\"btn btn1 btn_document\"><span>Tambah Data</span></a>";
                        ?>
                    </div>
                </div>
            </div>

            <table class="stdtable stdtablequick">
                <thead>
                    <tr>
                        <th width="20">No</th>
                        <th width="*">Aktor</th>
                        <th width="50">Grup</th>
                        <th width="50">Parameter</th>
                        <th width="50">Kontrol</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $aktor = AppApprovalAktor::query()->where("master_id", $par['id'])->orderBy("group", "asc")->get();
                if ($aktor->isNotEmpty())
                {
                    $no = 0;
                    $parameter = getPar($par, "mode, idAktor");

                    foreach ($aktor as $act)
                    {
                        $no++;

                        $control = "";
                        if ($access["edit"]) $control .= "<a  href=\"#\" onclick=\"openBox('popup?par[mode]=formAktor&par[idAktor]={$act->id}".$parameter."', 600, 250);\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";
                        if ($access["delete"]) $control .= "<a href=\"?par[mode]=deleteAktor&par[idAktor]={$act->id}{$parameter}\" title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus aktor?`)'></a>";

                        ?>
                        <tr>
                            <td align="center"><?= $no ?></td>
                            <td align="left"><?= $act->reference->name ?></td>
                            <td align="center"><?= $act->group ?></td>
                            <td align="center"><?= $act->parameter ?></td>
                            <td align="center"><?= $control ?></td>
                        </tr>
                        <?php
                    }
                }
                else
                {
                    ?>
                    <tr>
                        <td align="center" colspan="5">- Data kosong -</td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>

            <br clear="all"/>

            <div class="widgetbox" style="margin-bottom: 2px;">
                <div class="title">
                    <h3 style="position: relative; clear:both; float:left; margin-top: 20px ">Step</h3>
                    <div style="position: relative; float: right; margin-right: -25px">
                        <?php
                        if (empty($par['id'])) echo "<a onclick=\"alert('Simpan form terlebih dahulu');\" href=\"#\" class=\"btn btn1 btn_document\"><span>Tambah Data</span></a>";
                        else echo "<a onclick=\"openBox('popup?par[mode]=formStep".getPar($par,"mode, idStep")."', 600, 350);\" href=\"#\" class=\"btn btn1 btn_document\"><span>Tambah Data</span></a>";
                        ?>
                    </div>
                </div>
            </div>

            <table class="stdtable stdtablequick">
                <thead>
                    <tr>
                        <th width="20">No</th>
                        <th width="20">Urut</th>
                        <th width="100">Grup</th>
                        <th width="100">Prev Step</th>
                        <th width="100">Next Step</th>
                        <th width="50">Kontrol</th>
                    </tr>
                </thead>
                <tbody>
                <?php

                $step = AppApprovalStep::query()->where("master_id", $par['id'])->orderBy("urut", "asc")->get();

                if ($step->isNotEmpty())
                {
                    $no = 0;
                    $parameter = getPar($par, "mode, idStep");

                    foreach ($step as $st)
                    {
                        $no++;

                        $control = "";
                        if ($access["add"]) $control .= "<a  href=\"#\" onclick=\"openBox('popup?par[mode]=formCondition&par[idStep]={$st->id}".$parameter."', 600, 300);\" title=\"Add Data\" class=\"add\" ><span>Add</span></a>";
                        if ($access["edit"]) $control .= "<a  href=\"#\" onclick=\"openBox('popup?par[mode]=formStep&par[idStep]={$st->id}".$parameter."', 600, 350);\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";
                        if ($access["delete"]) $control .= "<a href=\"?par[mode]=deleteStep&par[idStep]={$st->id}{$parameter}\" title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus Step?`)'></a>";

                        ?>
                        <tr>
                            <td align="center"><?= $no ?></td>
                            <td align="center"><?= $st->urut ?></td>
                            <td align="center"><?= $st->group ?></td>
                            <td align="center"><?= $st->prev ?></td>
                            <td align="center"><?= $st->next ?></td>
                            <td align="center"><?= $control ?></td>
                        </tr>
                        <?php
                        $condition = AppApprovalCondition::query()->where(["master_id" => $par['id'], "step_id" => $st->id])->orderBy("id", "asc")->get();
                        if ($condition->isNotEmpty())
                        {
                            ?>
                            <tr style="background-color: #E5E5E5;">
                                <td align="center" colspan="3"></td>
                                <td align="center"><strong>Kondisi</strong></td>
                                <td align="center"><strong>Parameter</strong></td>
                                <td align="center"></td>
                            </tr>
                            <?php
                            foreach ($condition as $cd)
                            {
                                $parameter = getPar($par, "mode, idStep, idCondition");

                                $control = "";
                                if ($access["edit"]) $control .= "<a  href=\"#\" onclick=\"openBox('popup?par[mode]=formCondition&par[idStep]={$st->id}&par[idCondition]={$cd->id}{$parameter}', 600, 300);\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";
                                if ($access["delete"]) $control .= "<a href=\"?par[mode]=deleteCondition&par[idCondition]={$cd->id}{$parameter}\" title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus Kondisi?`)'></a>";

                                ?>
                                <tr>
                                    <td align="center" colspan="3"></td>
                                    <td align="center"><?= $cd->tipe ?>&nbsp;&nbsp;&nbsp;<strong><?= $cd->kondisi ?></strong>&nbsp;&nbsp;&nbsp;<?= $cd->nilai ?></td>
                                    <td align="center"><?= $cd->parameter ?></td>
                                    <td align="center"><?= $control ?></td>
                                </tr>
                                <?php
                            }
                        }
                    }
                }
                else
                {
                    ?>
                    <tr>
                        <td align="center" colspan="7">- Data kosong -</td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>

        </form>
    </div>
    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "id",
        "kode",
        "keterangan",
        "updated_at"
    ];

    $getData = AppApprovalMaster::query()
        ->when($search, function ($query, $search) {
            $query->where(function ($query){
                $query->where("kode", "like", "%{$search}%");
                $query->orWhere("keterangan", "like", "%{$search}%");
            });
        });
    $count = clone $getData;

    $getData->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $getData->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $getData
             ->get()
             ->map(function ($result, $key) use ($iDisplayStart, $access, $par, $parameter) {

                 $number = $iDisplayStart + ($key + 1);

                 $control = "";
                 if ($access["edit"]) $control .= "<a href=\"?par[mode]=edit&par[id]={$result->id}". $parameter . "\" title=\"Edit Data\" class=\"edit\" ><span>Edit</span></a>";
                 if ($access["delete"]) $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus master approval ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$result->id}`, 50, 50, false) : ``'></a>";

                 return [
                     "<div align='center'>{$number}</div>",
                     "<div align='center'>{$result->kode}</div>",
                     "<div align='left'>{$result->keterangan}</div>",
                     "<div align='center'>{$result->updated_at->format("d.m.Y H:i:s")}</div>",
                     "<div align='center'>{$result->updatedBy->name}</div>",
                     "<div align='center'>{$control}</div>",
                 ];
             });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function index()
{
    global $access, $par;

    datatable(6, [1, 6]);

    Layout::title();

    ?>

    <div class="contentwrapper">
        <form action="" class="stdform">
            <div class="filter_container">
                <div class="filter_left">
                    <input type="text" id="search">
                </div>
                <div class="filter_right">
                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn" href="?par[mode]=add<?= getPar($par, "mode, id") ?>"><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">No</th>
                <th width="50">Kode</th>
                <th width="*">Nama</th>
                <th width="120">Diubah</th>
                <th width="120">Diubah Oleh</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
    <?php
}

?>
