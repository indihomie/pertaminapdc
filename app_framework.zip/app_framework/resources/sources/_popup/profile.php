<?php
global $access, $par, $_submit;

use App\Models\AppUser;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "edit":
        update();
        break;

    default:
        form();
        break;

}

function form()
{
    global $user;

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true, "Profil"); ?>

        <form method="post" action="?page=profile&par[mode]=edit"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <div style="position: absolute; top: 1rem; right: .3rem;">
                <input type="submit" class="submit radius2" value="Simpan"/>
            </div>

            <fieldset>

                <?php Form::inputLabelText("Nama", "name", $user->name, true); ?>
                <?php Form::spanLabel("Grup User", $user->group->name); ?>
                <?php Form::inputLabelText("Username", "username", $user->username, true); ?>
                <?php Form::inputLabelText("Telepon", "phone", $user->phone, false); ?>
                <?php Form::inputLabelEmail("Email", "email", $user->email, true); ?>
                <?php Form::spanLabel("Verifikasi Email", $user->email_verified_at ? $user->email_verified_at->format("d F Y H:i") : "-"); ?>
                <?php Form::inputLabelTextArea("Catatan", "description", $user->description, false); ?>
                <?php Form::inputLabelDocument("Foto", "photo", $user->path_photo, false, "l-input-small", ".png, .jpg, .jpeg", false); ?>

            </fieldset>

        </form>

    </div>
    <?php

}

function update()
{
    global $user, $request, $par;

    $parameter = getPar($par, "mode");

    $validator = Validator::make($request->all(), [
        "name" => "required|min:3",
        "username" => "required|unique:app_users,username,{$user->id}",
        "phone" => "sometimes|min:10",
        "email" => "required|unique:app_users,email,{$user->id}",
        "description" => "sometimes|string",
    ]);

    if ($validator->fails()) {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?{$parameter}page=profile'</script>";
        return;
    }

    DB::beginTransaction();

    try {

        if ($user->email != $request->email) {
            $user->update([
                "email_verified_at" => null
            ]);
        }

        $user->update([
            "name" => $request->name,
            "username" => $request->username,
            "phone" => $request->phone,
            "email" => $request->email,
            "description" => $request->description,
            "updated_by" => $user->id,
        ]);

        if ($request->file("photo") || $request->photo_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($user->path_photo)) {
                $storage->delete($user->path_photo);
            }

            $user->update([
                "path_photo" => ""
            ]);
        }

        if ($request->file("photo")) {
            $user->update([
                "path_photo" => $request->file("photo")->store(AppUser::$path_image, ["disk" => "public"])
            ]);
        }

        DB::commit();

        echo "<script>alert('User berhasil diubah')</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('User gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
    echo "<script>parent.toggleLoader(true)</script>";
    echo "<script>parent.window.location.reload()</script>";
}
