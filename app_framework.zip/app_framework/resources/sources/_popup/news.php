<?php
global $menu;

use App\Models\AppInformationNews;

switch ($menu) {

    case "detail":
        detail();
        break;

    default:
        index();
        break;

}

function index()
{

    $newss = AppInformationNews::query()->where("status", 1)->orderBy("datetime", "desc")->limit(10)->get();

    ?>
    <div class="widgetcontent userlistwidget nopadding">
        <ul>
            <?php foreach ($newss as $news) : ?>
                <li>
                    <a href="popup?page=news&menu=detail&id=<?= $news->id ?>">
                        <div class="info">
                            <?= $news->title ?>
                            <br>
                            <small><?= $news->datetime->format("d F Y H:i") ?> | <?= $news->source ?></small>
                            <div style="height: .4rem"></div>
                            <b><?= $news->content ?></b>
                        </div>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php

}

function detail()
{
    global $id;

    $news = AppInformationNews::find($id);

    ?>
    <a href="popup?page=news"
       class="absolute top-2 left-2 bg-white p-2 w-6 h-6 rounded rounded-full text-gray-700 hover:bg-gray-300">
        <i class="fa fa-2x fa-arrow-left"></i>
    </a>
    <div
        style="width: 100%; height: 20rem; background-color: rgba(0, 0, 0, .1); background-image: url('storage/<?= $news->path_image ?>'); background-repeat: no-repeat; background-size: cover;"></div>
    <br>
    <h5><?= $news->title ?></h5>
    <small><?= $news->datetime->format("d F Y H:i") ?> | <?= $news->source ?></small>
    <br>
    <br>
    <p><?= $news->content ?></p>
    <hr>
    unduh file : <a href="<?= $news->path_image ?>" target="_blank" style="color: blue;"><?= $news->path_image ?></a>
    <?php
}
