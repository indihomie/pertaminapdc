<?php
global $access, $par, $_submit;

use App\Models\AppMenu;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "edit":
        $_submit ? update() : form();
        break;

    default:
        index();
        break;

}

function index()
{
    global $id, $user;

    $menu = AppMenu::find($id);

    ?>
    <div>

        <?php if ($menu->path_manual) : ?>
            <iframe class="m-0 w-full" style="height: 510px" src="https://view.officeapps.live.com/op/embed.aspx?src=<?= url("storage/{$menu->path_manual}") ?>"></iframe>
        <?php else: ?>
            <div class="notibar msginfo">
                <p>Dokumen belum tersedia.</p>
            </div>
        <?php endif; ?>

        <div class="p-1"
             style="position: fixed; bottom: .4rem; left: 50%; transform: translateX(-50%);">

            <?php if ($user->type == 0) : ?>
                <a href="?page=manual&id=<?= $id ?>&par[mode]=edit" class="stdbtn py-1.5">Ubah</a>
            <?php endif; ?>

            <?php if ($menu->path_manual_pdf) : ?>
                <a href="public/download/<?= encrypt($menu->path_manual) ?>" target="_blank" class="stdbtn py-1.5">Unduh manual</a>
            <?php endif; ?>

        </div>

    </div>
    <script>
        parent.toggleLoader(false)
    </script>
    <?
}

function form()
{
    global $user, $id;

    $menu = AppMenu::find($id);

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true, "Profil"); ?>

        <form method="post" action="?page=manual&id=<?= $id ?>&par[mode]=edit"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? parent.toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($user->type == 0) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <a href="?page=manual&id=<?= $id ?>" class="stdbtn">Kembali</a>
                    <input type="submit" name="_submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <?php Form::spanLabel("Modul", $menu->module->name); ?>
                <?php Form::spanLabel("Sub Modul", $menu->module_sub->name); ?>
                <?php Form::spanLabel("Menu", $menu->name); ?>
                <?php Form::inputLabelDocument("Manual", "manual", $menu->path_manual, false, "l-input-small", ".doc, .docx", false, false, true); ?>
                <?php Form::inputLabelTextArea("Deskripsi", "description", $menu->description, false); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function update()
{
    global $user, $request, $id;

    $menu = AppMenu::find($id);

    DB::beginTransaction();

    try {

        $menu->update([
            "description" => $request->description,
            "updated_by" => $user->id,
        ]);

        if ($request->file("manual") || $request->manual_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($menu->path_manual)) {
                $storage->delete($menu->path_manual);
            }

            if ($storage->exists($menu->path_manual_pdf)) {
                $storage->delete($menu->path_manual_pdf);
            }

            $menu->update([
                "path_manual" => "",
                "path_manual_pdf" => ""
            ]);
        }

        DB::commit();

        if ($request->file("manual")) {

            $path_manual_book = $request->file("manual")->store(AppMenu::$path_manual, ["disk" => "public"]);
//            $path_manual_book_pdf = Str::replace(["docx", "doc"], "pdf", $path_manual_book);

            $menu->update([
                "path_manual" => $path_manual_book,
                "path_manual_pdf" => "",
            ]);

//            $converter = new OfficeConverter(base_path("storages/{$path_manual_book}"), null, "libreoffice7.2");
//            $converter->convertTo($path_manual_book_pdf);
        }

        echo "<script>alert('Manual berhasil diubah')</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Manual gagal diubah')</script>";
    }

    echo "<script>window.location='?page=manual&id={$id}'</script>";
}
