<?php
global $storage;

use App\Models\AppModule;use App\View\Components\Layout;

$storage = Storage::disk("sources");

switch ($mode) {

    default:
        index();
        break;

}

function index()
{
    global $storage, $id;

    $module = AppModule::query()->find($id);

    $files = $storage->allFiles($module->directory);

    $files = collect($files)
        ->filter(fn($file) => Str::contains($file, ".md"))
        ->mapWithKeys(fn($file) => [$file => Str::replace(["/"], " - ", $file)]);

    ?>
    <div class="contentpopup">

    <?= Layout::title(true, "Dokumentasi"); ?>

    <fieldset class="rounded">

        <div class="p-4">
            <ul class="list-decimal list-outside pl-4">
                <?php foreach ($files as $path => $file) : ?>
                    <li><a href="documentation?id=<?= $id ?>&path=<?= $path ?>" class="hover:text-blue-600"><?= $file ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>

    </fieldset>

    <?
}
