<?php
global $menu;

use App\Models\AppInformationAnnouncement;

switch ($menu) {

    case "detail":
        detail();
        break;

    default:
        index();
        break;

}

function index()
{

    $announcements = AppInformationAnnouncement::query()->where("status", 1)->orderBy("datetime", "desc")->limit(10)->get();

    ?>
    <div class="widgetcontent userlistwidget nopadding">
        <ul>
            <?php foreach ($announcements as $announcement) : ?>
                <li>
                    <a href="popup?page=announcement&menu=detail&id=<?= $announcement->id ?>">
                        <div class="info">
                            <?= $announcement->title ?>
                            <br>
                            <small><?= $announcement->datetime->format("d F Y H:i") ?> | <?= $announcement->source ?></small>
                            <div style="height: .4rem"></div>
                            <b><?= $announcement->content ?></b>
                        </div>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php

}

function detail()
{
    global $id;

    $announcement = AppInformationAnnouncement::find($id);

    ?>
    <a href="popup?page=announcement"
       class="absolute top-2 left-2 bg-white p-2 w-6 h-6 rounded rounded-full text-gray-700 hover:bg-gray-300">
        <i class="fa fa-2x fa-arrow-left"></i>
    </a>
    <div style="width: 100%; height: 20rem; background-color: rgba(0, 0, 0, .1); background-image: url('storage/<?= $announcement->path_image ?>'); background-repeat: no-repeat; background-size: cover;"></div>
    <br>
    <h5><?= $announcement->title ?></h5>
    <small><?= $announcement->datetime->format("d F Y H:i") ?> | oleh. <?= $announcement->source ?></small>
    <br>
    <br>
    <p><?= $announcement->content ?></p>
    <hr >
    unduh file : <a href="<?= $announcement->path_image ?>" target="_blank" style="color: blue;"><?= $announcement->path_image ?></a>
    <?php
}
