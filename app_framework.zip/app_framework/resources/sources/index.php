<?php

use App\Models\AppInformation;
use App\Models\AppMasterCategory;

if (!$module_id) {
    header('location: home');
    exit;
}

include resource_path("sources/index.router.php");

if (empty($access['view'])) {
    header('location: home');
    exit;
}

$app_information = Cache::rememberForever("app_information", fn() => AppInformation::find(1));

$module = $modules[$module_id];
$module_sub = $module_subs[$module_sub_id];

$menu_parent = $menus[$menu_id];
$menu_selected = $menu;

$hide_logo = $menu_selected['viewMenu'] == "t" ? "" : "page-sidebar-closed";
$hide_menu = $menu_selected['viewMenu'] == "t" ? "" : "page-sidebar-menu-closed";

?>
<!DOCTYPE html>
<html lang="id">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="csrf-token" content="<?= csrf_token() ?>">

    <link rel="shortcut icon" href="storage/<?= $app_information["path_icon"] ?>?<?= $app_version ?>"/>

    <title><?= $app_information["description"]; ?></title>

    <link rel="stylesheet" type="text/css" href="assets/css/webpack.build.css?<?= $app_version ?>"/>
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css?<?= $app_version ?>"/>
    <link rel="stylesheet" type="text/css" href="assets/css/app.css?<?= $app_version ?>"/>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>

    <link rel="stylesheet" type="text/css" href="assets/plugins/orgchart/jquery.orgchart.css?<?= $app_version ?>"/>
    <link rel="stylesheet" type="text/css" href="assets/plugins/amcharts/plugins/export/export.css?<?= $app_version ?>"/>

    <script type="text/javascript" src="assets/js/jquery.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/custom.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/data.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/datatablesExt.fnReloadAjax.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/uniform.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/chosen.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/time.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/color.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/tinybox.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/autoNumeric.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/jquery.tagsinput.min.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/jquery.chained.min.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/jquery.validate.min.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/general.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/plugins/ckeditor/ckeditor.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/plugins/orgchart/jquery.orgchart.min.js?<?= $app_version ?>"></script>

    <!--<script type="text/javascript" src="assets/plugins/amcharts/pie.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/serial.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/amcharts.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/themes/light.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/plugins/export/export.min.js?<?= $app_version ?>"></script>-->

    <script type="text/javascript" src="assets/plugins/charts/theme.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/plugins/charts/helper.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/plugins/charts/FusionCharts.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/plugins/charts/maplist-core-pack.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/webpack.build.js?<?= $app_version ?>" defer></script>
    <script type="text/javascript" src="assets/js/app.helper.js?<?= $app_version ?>"></script>

</head>
<body class="font-sans <?= $module_sub["name"] != "laporan" ? "withvernav" : "" ?>" style="overflow-y: scroll;">

<div class="topheader pl-2"
     style="
         display: flex;
         align-items: center;
         background-image: url('storage/<?= $app_information["path_backdrop"] ?>');
         ">

    <div style="
        width: 223px;
        height: 68px;
        margin-top: .6rem;
        margin-bottom: .6rem;
        background-image: url('storage/<?= $app_information["path_logo"] ?>');
        background-size: auto;
        background-repeat: no-repeat;
        "></div>
    <div style="width: 1rem;"></div>
    <div style="flex: 1; color: #ffffff">
        <h4 class="font-sans font-medium"><?= $module["name"] ?></h4>
        <p><?= $app_information["description"]; ?> - V<?= $app_version ?></p>
    </div>

    <ul class="headermenu m-0">

        <?php
        foreach ($datas as $key => $value) :
            $_menu = $value['menus'][key($value['menus'])];
            $url = ($value['name'] != "laporan" && $value['status'] != 0) ? "&m=$_menu[id]" : "";
            ?>
            <li class="<?= $value["id"] == $module_sub_id ? "current" : "" ?>">
                <a href="index?c=<?= $module_id ?>&p=<?= $value["id"] ?><?= $url ?>">
                            <span style="
                                height: 32px;
                                display: block;
                                background: url('storage/<?= $value["path_icon"] ?: "_/module_sub/_blank.png" ?>') no-repeat center center;
                                background-size: 32px 32px;
                                "></span>
                    <?= $value["name"] ?>
                </a>
            </li>

        <?php
        endforeach;
        ?>

    </ul>

</div>

<div style="position: relative;">
    <div style="display: flex; align-items: center; padding: .25rem 1rem .25rem .5rem;">
        <div style="flex: 1">
            <strong style="color: #fff;">
                <?= $arr_day[now()->format("w")] . ", " . now()->format("d F Y") ?>
            </strong>
        </div>
        <div style="flex: 1; display: flex; justify-content: end; color: #fff">
            <a href="#" class="menu" onclick="openBox(`notifications`, 1000, 520)">
                <strong>NOTIFIKASI</strong>
            </a>
            <?php if ($user->id == 1) : ?>
                &emsp;
                <strong>|</strong>
                &emsp;
                <a href="#" class="menu" onclick="openBox('popup?page=documentation&id=<?= $module_id ?>', 1000, 520);">
                    <strong>DOKUMENTASI DEVELOPER</strong>
                </a>
            <?php endif; ?>
            &emsp;
            <strong>|</strong>
            &emsp;
            <a href="#" class="menu" onclick="openBox('popup?page=manual&id=<?= $menu_sub_id ?>', 1000, 520);">
                <strong>BUKU MANUAL</strong>
            </a>
            &emsp;
            <strong>|</strong>
            &emsp;
            <div style="
                width: 20px;
                height: 20px;
                background-color: #fff;
                background-image: url('<?= $user->path_photo ? "storage/{$user->path_photo}" : "assets/images/photo.png" ?>');
                background-size: cover;
                background-position: center;
                "></div>
            <div style="width: .3rem;"></div>
            <a class="menu"
               style="
               cursor: pointer;
               "
               onclick="openBox(`popup?page=profile`, 700, 450);">
                <?= $user->name ?>
            </a>
            &emsp;
            <strong>|</strong>
            &emsp;
            <a href="home" class="menu"><strong>BERANDA</strong></a>
            &emsp;
            <strong>|</strong>
            &emsp;
            <a class="menu"
               href="logout"
               onclick="return confirm('Konfirmasi keluar aplikasi?')">
                <strong>KELUAR</strong>
            </a>
        </div>
    </div>
    <div class="header" style="position: absolute; top: 0; width: 100%; z-index: -1;">
    </div>
</div>

<div class="bodywrapper">

    <div class="vernav2 iconmenu">
        <ul>
            <?php foreach ($datas[$module_sub_id]["menus"] as $key => $value) : ?>
                <?php
                if ($value["name"] == "Data Master") {
                    $menu_id_in_master_category = AppMasterCategory::query()->select("menu_id")->get()->pluck("menu_id");
                }
                ?>
                <?php if (count($value["subs"] ?? []) == 0) : ?>
                    <li class="<?= $value["id"] == $menu_id ? "current" : "" ?>">
                        <a title="<?= $value["name"] ?>"
                           href="index?c=<?= $module_id ?>&p=<?= $module_sub_id ?>&m=<?= $value["id"] ?>&s=<?= $value["id"] ?>">
                            <img src="storage/<?= $value["path_icon"] ? "{$value["path_icon"]}" : "_/menu/_blank.png" ?>" style="float: left; margin-right: .5rem;" width="20" height="20">
                            <span><?= strlen($value["name"]) >= 40 ? substr($value["name"], 0, 40) . "..." : $value["name"] ?></span>
                        </a>
                    </li>
                <?php else : ?>
                    <?php
                    $url = empty($value["target"]) ? "#" : "index?c={$module_id}&p={$module_sub_id}&m={$value["id"]}";
                    ?>
                    <li class="<?= $value["id"] == $menu_id ? "current" : "" ?>">
                        <a href="#menu_<?= $value["id"] ?>">
                            <img src="storage/<?= $value["path_icon"] ? "{$value["path_icon"]}" : "_/menu/_blank.png" ?>" style="float: left; margin-right: .5rem;" width="20" height="20">
                            <span><?= strlen($value['name']) >= 40 ? substr($value['name'], 0, 40) . "..." : $value['name'] ?></span>
                        </a>
                        <span class="arrow"></span>
                        <ul id="menu_<?= $value["id"] ?>">
                            <?php foreach ($value['subs'] as $_key => $_value) : ?>
                                <?php $url_master_data = $value['name'] == "Data Master" ? "&par[mode]=master&par[master]=" . in_array($_value['id'], $menu_id_in_master_category) : ""; ?>
                                <li class="<?= $_value['id'] == $menu_sub_id ? "current" : "" ?>">
                                    <a title="<?= $_value["name"] ?>"
                                       href="index?c=<?= $module_id ?>&p=<?= $module_sub_id ?>&m=<?= $value['id'] ?>&s=<?= $_value['id'] ?><?= $url_master_data ?>">
                                        <?= strlen($_value['name']) >= 40 ? substr($_value['name'], 0, 40) . "..." : $_value['name'] ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endforeach; ?>
            <a class="togglemenu"></a>
            <br/>
        </ul>
    </div>

    <div class="centercontent">
        <?php

        $directory = $menu_selected['target'];
        $dirs = explode("/", $directory);
        $file = end($dirs);

        // remove filename
        array_pop($dirs);

        $is_link = strpos($directory, "http") === 0;

        $file_js = implode("/", $dirs) . "/js/{$file}.js";

        if (!$is_link && file_exists(resource_path("sources/{$file_js}"))) {
            echo "<script type='text/javascript'>";
            echo include resource_path("sources/{$file_js}");
            echo "</script>";
        }

        if ($is_link) {

            include resource_path("sources/frame.php");

        } else if (file_exists(resource_path("sources/{$directory}.php"))) {

            include resource_path("sources/{$directory}.php");

        } else {

            include resource_path("sources/none.php");

        }

        if (function_exists("controller")) {
            echo controller();
        }

        if (function_exists("getContent")) {
            echo getContent($par);
        }

        ?>
    </div>

    <br clear="all"/>

</div>

<div id="loader" style="position: fixed; top: 0; right: 0; bottom: 0; left: 0; z-index: 70000; background-color: rgba(255, 255, 255, 0.6); display: none;">
    <div style="height: 100vh; display: flex; justify-content: center; align-items: center;">
        <img src="assets/images/preload.gif">
    </div>
</div>

</body>
</html>
