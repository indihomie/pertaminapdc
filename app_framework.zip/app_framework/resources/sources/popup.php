<?php

global $page, $c;

if ($page || !$c) {
} else {
    include "index.router.php";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <title></title>

    <link rel="stylesheet" type="text/css" href="assets/css/webpack.build.css?<?= $app_version ?>"/>
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css?<?= $app_version ?>"/>
    <link rel="stylesheet" type="text/css" href="assets/css/app.css?<?= $app_version ?>"/>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>

    <link rel="stylesheet" type="text/css" href="assets/plugins/orgchart/jquery.orgchart.css?<?= $app_version ?>"/>
    <link rel="stylesheet" type="text/css" href="assets/plugins/amcharts/plugins/export/export.css?<?= $app_version ?>"/>

    <script type="text/javascript" src="assets/js/jquery.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/custom.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/data.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/datatablesExt.fnReloadAjax.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/uniform.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/chosen.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/time.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/color.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/tinybox.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/autoNumeric.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/jquery.tagsinput.min.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/jquery.chained.min.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/js/jquery.validate.min.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/general.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/plugins/ckeditor/ckeditor.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/plugins/orgchart/jquery.orgchart.min.js?<?= $app_version ?>"></script>

    <!--<script type="text/javascript" src="assets/plugins/amcharts/pie.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/serial.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/amcharts.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/themes/light.js?<?= $app_version ?>"></script>-->
    <!--<script type="text/javascript" src="assets/plugins/amcharts/plugins/export/export.min.js?<?= $app_version ?>"></script>-->

    <script type="text/javascript" src="assets/plugins/charts/theme.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/plugins/charts/helper.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/plugins/charts/FusionCharts.js?<?= $app_version ?>"></script>
    <script type="text/javascript" src="assets/plugins/charts/maplist-core-pack.js?<?= $app_version ?>"></script>

    <script type="text/javascript" src="assets/js/webpack.build.js?<?= $app_version ?>" defer></script>
    <script type="text/javascript" src="assets/js/app.helper.js?<?= $app_version ?>"></script>

</head>
<body class="withvernav-nobg">
<div class="bodywrapper">

    <?php

    if ($page) {

        $file_js = "sources/_pages/js/{$page}.js";

        if (file_exists($file_js))
            echo "<script type='text/javascript' src='{$file_js}'></script>";

        include resource_path("sources/_popup/{$page}.php");

    } else if (!$c) {

        include resource_path("sources/none.php");

    } else {

        $directory = $menu['target'];
        $dirs = explode("/", $directory);
        $file = end($dirs);

        // remove filename
        array_pop($dirs);

        if (empty($access['view'])) {
            echo "<script>window.location='home';</script>";
            exit;
        }

        $file_js = "sources/" . implode("/", $dirs) . "/js/{$file}.js";

        if (file_exists($file_js)) {
            echo "<script src='{$file_js}' type='text/javascript'></script>";
        }

        if (file_exists(resource_path("sources/{$directory}.php"))) {

            include resource_path("sources/{$directory}.php");

        } else {

            include resource_path("sources/none.php");

        }

    }

    if (function_exists("controller")) {
        echo controller();
    }

    if (function_exists("getContent")) {
        echo getContent($par);
    }

    ?>

</div>

<div id="loader" style="position: fixed; top: 0; right: 0; bottom: 0; left: 0; z-index: 70000; background-color: rgba(255, 255, 255, 0.6); display: none;">
    <div style="height: 100vh; display: flex; justify-content: center; align-items: center;">
        <img src="assets/images/preload.gif">
    </div>
</div>

</body>
</html>
