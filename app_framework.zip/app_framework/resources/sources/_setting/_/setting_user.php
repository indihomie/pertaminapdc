<?php

use App\Models\AppMaster;
use App\Models\AppUserAccessArea;
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\AppUser;
use App\Models\AppGroup;
use App\Models\Employee\Employee;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

$fFile = "storages/images/user/";

function getContent($par)
{
    global $_submit, $access;

    switch ($par["mode"]) {
        case "cek":
            $text = cek();
            break;
        case "datas":
            $text = lData();
            break;
        case "employees":
            $text = empData();
            break;

        case "get":
            $text = gPegawai();
            break;
        case "peg":
            $text = pegawai();
            break;
        case "pas":
            if (isset($access["edit"])) $text = empty($_submit) ? formPassword() : updatePassword(); else $text = lihat();
            break;
        case "del":
            if (isset($access["delete"])) $text = destroy(); else $text = lihat();
            break;
        case "edit":
            if (isset($access["edit"])) $text = empty($_submit) ? form() : update(); else $text = lihat();
            break;
        case "add":
            if (isset($access["add"])) $text = empty($_submit) ? form() : store(); else $text = lihat();
            break;
        default:
            $text = index();
            break;
    }
    return $text;
}

function cek()
{
    global $inp, $par;
    if (getField("select username from app_users where username='$inp[username]' and username!='$par[username]'"))
        return "sorry, username \" $inp[username] \" already exist";
}

function gPegawai()
{

    $sql = "select * from employees where emp_number='" . $_GET[nikPegawai] . "'";
    $res = db($sql);
    $r = mysql_fetch_array($res);

    $data["idPegawai"] = $r[id];
    $data["nikPegawai"] = $r[emp_number];
    $data["namaPegawai"] = strtoupper($r[name]);

    return json_encode($data);
}

function store()
{
    global $user, $request;

    DB::beginTransaction();

    try {

        AppUser::create([
            'type' => 0,
            'employee_id' => $request->employee_id,
            'username' => $request->username,
            'password' => \Illuminate\Support\Facades\Hash::make($request->password),
            'group_id' => $request->group_id,
            'name' => $request->name,
            'description' => $request->description,
            'path_photo' => $request->file("path_photo") ? $request->file("path_photo")->store(AppUser::$path_image, ["disk" => "storages"]) : "",
            'status' => $request->status,
            'created_by' => $user->id,
            'updated_by' => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('User Akses berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('User Akses gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $update = AppUser::find($par["id"]);

        //GET EXIST PATH PHOTO
        $path_photo = $request->photo_path_status == 0 ? $update->path_photo : '';
        //IF EXIST AND FILE REQUEST EMPTY
        if($update->path_photo && $path_photo == '')
            Storage::disk('storages')->delete($update->$path_photo);

        //IF FILE REQUEST NOT EMPTY THEN DELETE DATA BEFORE, REPLACE WITH FILE REQUEST
        if($request->file('path_photo')){
            Storage::disk('storages')->delete($update->$path_photo);
            $path_photo = $request->file("path_photo")->store(AppUser::$path_image, ["disk" => "storages"]);
        }

        $update->update([
            'employee_id' => $request->employee_id,
            'username' => $request->username,
            'group_id' => $request->group_id,
            'name' => $request->name,
            'description' => $request->description,
            'status' => $request->status,
            'path_photo' => $path_photo,
            'updated_by' => $user->id,
        ]);

        //DELETE EXISTING ACCESS BEFORE UPDATE
        AppUserAccessArea::where('user_id', $update->id)->delete();

        //UPDATE ACCESS WITH SELECTED AREAS
        foreach ($request->det as $key => $value){
            AppUserAccessArea::create([
                'user_id' => $update->id,
                'area_id' => $value,
                'created_by' => $user->id,
                'updated_by' => $user->id,
            ]);
        }

        DB::commit();

        echo "<script>alert('User berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('User gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = AppUser::find($par["id"]);

        $storage = Storage::disk("storages");

        if ($storage->exists($delete->path_photo)) {
            $storage->delete($delete->path_photo);
        }

        $delete->delete();

        DB::commit();

        echo "<script>alert('User berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('User gagal dihapus')</script>";
    }

    echo "<script>window.location='?".getPar($par,"mode, id")."';</script>";
}


function updatePassword()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $update = AppUser::find($par["id"]);

        $update->update([
            'password' => \Illuminate\Support\Facades\Hash::make($request->password),
            'updated_by' => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Password berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Password gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function formPassword()
{
    global $par;

    setValidation("is_null", "inp[password]", "you must fill password");
    setValidation("is_null", "inp[repassword]", "you must fill re-type password");
    echo getValidation();

    ?>
    <div class="centercontent contentpopup">
        <?php
        Layout::title(true, 'Reset Password');
        ?>
        <div id="contentwrapper" class="contentwrapper">
            <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>">
                <?php
                    Form::inputLabelPassword("Password", "password", "t", "l-input-small2");
                    Form::inputLabelPassword("Konfirmasi Password", "repassword", "t", "l-input-small2");
                    Layout::formBtnSubmit();
                ?>
            </form>
        </div>
    </div>
    <?php
}

function form()
{
    global $par, $user;

    //GET QUERY FROM SELECTED VALUE
    $userData = AppUser::find($par['id']);

    //QUERY SELECT SECTION
    $datas = AppGroup::select('name as description', 'id');

    //SET FILTER GROUP IF USER IS NOT SUPERUSER
    if($user->id != 1)
        $datas->where('id', '>', '2');

    $groupDatas = $datas->get();

    setValidation("is_null", "inp[username]", "you must fill username");
    if ($par[mode] == "add") {
        setValidation("is_null", "inp[password]", "you must fill password");
        setValidation("is_null", "inp[repassword]", "you must fill re-type password");
    }
    setValidation("is_null", "inp[namaUser]", "you must fill real name");
    setValidation("is_null", "inp[group_id]", "you must fill group");
    echo getValidation();
    ?>
    <div class="centercontent contentpopup">
        <?php
        Layout::title(true);
        ?>
        <div id="contentwrapper" class="contentwrapper">
            <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>" onsubmit="return validation(document.form);" autocomplete="off" enctype="multipart/form-data">
                <ul class="hornav" style="margin: 0; margin-top: 10px;">
                    <li class="current"><a href="#general">General</a></li>
                    <li><a href="#area_akses">Area Akses</a></li>
                </ul>
                <div id="general" class="subcontent" style="display:block;">
                    <input type="hidden" name="_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="employee_id" id="employee_id" value="<?= $userData->employee_id ?>">
                    <?php
                    Form::inputLabelText('Username', 'username', $userData->username, 't');

                    if($par[mode] == "add") {
                        Form::inputLabelPassword('Password', 'password', 't');
                        Form::inputLabelPassword('Konfirmasi Password', 'repassword', 't');
                    }

                    Form::inputLabelText('NIK', 'nikPegawai', $userData->employee->emp_number, 't', '',
                        '',
                        "",
                        "",
                        "style=\"width:100px;\"",
                        "<input type=\"button\" class=\"cancel radius2\" value=\"...\" onclick=\"openBox('popup?par[mode]=peg" . getPar($par, "mode,filter") . "',800,425);\"/>");

                    Form::inputLabelText('Nama', 'name', $userData->name);
                    Form::inputLabelSelectArray('Group', 'group_id', $groupDatas, "id", "description",  $userData->group_id, "t");
                    Form::inputLabelTextArea('Keterangan', 'description', $userData->description);
                    Form::inputLabelDocument('Foto','path_photo', $userData->path_photo);
                    Form::inputLabelRadio("Status", "status", array('1' => 'Aktif', '0' => 'Tidak Aktif'), $userData->status ?? 1);
                    ?>
                    <p>
                        <?php if ($par[mode] == "edit") : ?>
                            <a href="#Reset" style="position: absolute; bottom: 10px; right: 10px" class="btn btn1 btn_refresh" onclick="openBox('popup?par[mode]=pas<?= getPar($par, "mode") ?>',650,250);"><span>Reset Password</span></a>
                        <?php endif; ?>
                    </p>
                </div>
                <div id="area_akses" class="subcontent" style="display:none;">
                    <p>
                        <label class="l-input-small">Akses Area</label>
                        <div class="field" style="margin-left:175px;">
                            <?php
                            //GET DATAS FROM DATABASE
                            $datas = AppUserAccessArea::select('area_id', 'user_id')->pluck('area_id', 'area_id')
                                ->toArray();

                            //GET DATAS FROM MASTERS
                            $areas = AppMaster::select('name', 'id')->where('status', '1')
                                ->where('category_id', 'S002')
                                ->get()
                                ->toArray();

                            Form::inputCheckboxes('det', $areas, $datas, 'id','id', 'name');
                            ?>
                        </div>
                    </p>
                </div>
                <?= Layout::formBtnSubmit('true') ?>
            </form>
        </div>
    </div>
    <?php
}


function index()
{
    global $par, $access;

    //QUERY COMBO DATA
    $queryGroup = AppGroup::query()->select('id', 'name')->get();

    //GENERATE DATA TABLE
    datatable(8, array(1, 2, 7, 8));

    Layout::title();
    ?>
    <div id="contentwrapper" class="contentwrapper">
        <form method="post" id="form" class="stdform" onsubmit="return false;">
            <div class="filter_container">
                <div class="filter_left">
                    <p>
                        <input type="text" id="search" name="search"/>
                        <?= selectArray('change_1', '', $queryGroup, "id", "name", $_SESSION['filter_groupId'], "- Pilih Group -"); ?>
                    </p>
                </div>
                <div class="filter_right">
                    <?php if (isset($access["add"])) : ?>
                        <a href="#Add" class="stdbtn" onclick="openBox('popup?par[mode]=add<?= getPar($par, "mode, username") ?> ',925,550);"><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
        <table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="table">
            <thead>
            <tr>
                <th width="20">No.</th>
                <th width="50">Foto</th>
                <th width="*">Nama</th>
                <th width="150">Username</th>
                <th width="250">Grup</th>
                <th width="125">Login Terakhir</th>
                <th width="50">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
    <?php
}

function lData()
{
    global $par, $access, $user, $c;

    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    //SET SESSION FOR FILTER
    $_SESSION['filter_groupId'] = $_GET['change_1'];

    $arr_order = [
        "t1.id",
        "",
        "t1.name",
        "t1.username",
        "t2.name",
        "t1.last_login",
        "t1.status",
    ];

    $q_order = $arr_order[$iSortCol_0];
    $q_sort = $iSortCol_0 > 0 ? $sSortDir_0 : 'desc';

    $query = DB::table('app_users as t1')->select('t1.id', 't1.path_photo', 't1.name', 't1.username', 't1.login_at', 't1.status', 't2.name as namaGroup')
        ->join('app_groups as t2', 't1.group_id', 't2.id')
        ->whereNotNull('t1.id');

    //SET FILTER WHEN NOT EMPTY
    if (!empty($search)){
        $query->where(function ($query) use ($search) {
            $query->orWhere('t1.username', 'like', "%$search%");
            $query->orWhere('t1.name', 'like', "%$search%");
            $query->orWhere('t2.name', 'like', "%$search%");
        });
    }

    if (!empty($_GET['change_1']))
        $query->where('group_id', $_GET[change_1]);
    //WHEN LOGIN USER IS NOT SUPERUSER, THEN DONT SHOW SUPERUSER
    if ($user->id != 1)
        $query->where('and t1.username', '!=', 'hambaallah');

    $count = clone $query;

    $query = $query->orderBy($q_order, $q_sort);

    if ($iDisplayLength > 0) {
        $query->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $users = $query->get();

    $json = array(
//        "iTotalRecords" => $query->count(),
        "iTotalDisplayRecords" => $count->count(),
        "aaData" => array(),
    );

    $no=intval($iDisplayStart);
    foreach($users as $r) {
        $no++;

        $statusUser = $r->status == 1 ? "<img src=\"assets/images/t.png\" title='Active'>" : "<img src=\"assets/images/f.png\" title='Not Active'>";

        if ($r->login_at == "0000-00-00 00:00:00") $r->login_at = "";
        list($tanggalLogin, $waktuLogin) = explode(" ", $r->login_at);
        $spacing = empty($r->login_at) ? "-" : "@";

        $controlDokumen = "";

        $foto = !empty($r->path_photo) ? "<img src=\"storages/" . $r->path_photo . "\" height=\"25\" style=\"padding-right:5px; padding-bottom:5px;\"> " : "";

        if (isset($access["edit"]))
            $controlDokumen .= "<a href=\"#Edit\" title=\"Edit Data\" class=\"edit\"  onclick=\"openBox('popup?par[mode]=edit&par[id]=$r->id" . getPar($par, "mode,username") . "',825,500);\"><span>Edit</span></a>";
        if (isset($access["delete"]))
            $controlDokumen .= "<a href=\"?par[mode]=del&par[id]=$r->id" . getPar($par, "mode,id") . "\" onclick=\"return confirm('anda yakin akan menghapus data ini ?')\" title=\"Delete Data\" class=\"delete\"><span>Delete</span></a>";

        $data = array(
            "<div align=\"center\">" . $no . ".</div>",
            "<div align=\"center\">$foto</div>",
            "<div align=\"left\">$r->name</div>",
            "<div align=\"left\">$r->username</div>",
            "<div align=\"left\">$r->namaGroup</div>",
            "<div align=\"center\">" . getTanggal($tanggalLogin) . " " . $spacing . " " . substr($waktuLogin, 0, 5) . "</div>",
            "<div align=\"center\">" . $statusUser . "</div>",
            "<div align=\"center\">" . $controlDokumen . "</div>",
        );

        $json['aaData'][] = $data;
    }

    return json_encode($json);
}

function pegawai()
{
    global $par;

    datatable(4, array(3),'employees','employeeTable','', 'true');
    ?>
    <div class="centercontent contentpopup">
        <?php
        Layout::title(true);
        ?>
        <div id="contentwrapper" class="contentwrapper">
            <form action="" method="post" class="stdform">
                <div class="filter_container">
                    <div class="filter_left">
                        <p>
                            <input type="text" id="search" name="search"/>
                        </p>
                    </div>
                </div>
            </form>
            <table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="employeeTable">
                <thead>
                <tr>
                    <th width="20">No.</th>
                    <th style="min-width:100px;">NIK</th>
                    <th style="min-width:400px;">Nama</th>
                    <th style="max-width:50px;">Kontrol</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

function empData()
{
    global $par, $arrParameter;

    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $arr_order = [
        "name",
        "emp_number",
        "name",
    ];

    $q_order = $arr_order[$iSortCol_0];
    $q_sort = $iSortCol_0 > 0 ? $sSortDir_0 : 'asc';

    $query = Employee::select('id', 'name', 'emp_number')->where('status_id', $arrParameter['ESA']);

    //SET FILTER WHEN NOT EMPTY
    if (!empty($search)){
        $query->where(function ($query) use ($search) {
            $query->orWhere('name', 'like', "%$search%");
            $query->orWhere('emp_number', 'like', "%$search%");
        });
    }
    $count = clone $query;

    $query = $query->orderBy($q_order, $q_sort);

    if ($iDisplayLength > 0) {
        $query->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $employees = $query->get();

    $json = array(
        "iTotalDisplayRecords" => $count->count(),
        "aaData" => array(),
    );

    $no=intval($iDisplayStart);

    foreach($employees as $r) {
        $no++;

        $data = array(
            "<div align=\"center\">" . $no . ".</div>",
            "<div align=\"left\">$r[emp_number]</div>",
            "<div align=\"left\">$r[name]</div>",
            "<div align=\"center\"><a href=\"#\" title=\"Pilih Data\" class=\"check\" onclick=\"getPegawai('" . $r[emp_number] . "', '" . getPar($par, "mode, nikPegawai") . "')\"><span>Detail</span></a></div>",
        );

        $json['aaData'][] = $data;
    }

    return json_encode($json);
}
?>
