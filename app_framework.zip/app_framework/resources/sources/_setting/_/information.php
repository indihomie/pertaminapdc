<?php
global $access, $par, $_submit;

use App\Models\AppInformation;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    default:
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

}

function form()
{
    global $access, $par;

    $info = AppInformation::find(1);

    echo getValidation();

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: 1.25rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset>

                <?php Form::inputLabelText("Aplikasi", "name", $info->name, true); ?>
                <?php Form::inputLabelText("Deskripsi", "description", $info->description, true); ?>
                <?php Form::inputLabelText("Copyright", "copyright", $info->copyright, true); ?>

            </fieldset>

            <br>

            <fieldset>

                <legend>&nbsp;WEB&nbsp;</legend>

                <?php Form::inputLabelDocument("Icon", "icon", $info->path_icon, false, "l-input-small", ".ico"); ?>
                <?php Form::inputLabelDocument("Logo", "logo", $info->path_logo, false, "l-input-small", ".png"); ?>
                <?php Form::inputLabelDocument("Backdrop", "backdrop", $info->path_backdrop, false, "l-input-small", ".png"); ?>

                <br>

                <?php Form::inputLabelDocument("Login Background", "image_login_background", $info->path_image_login_background, false, "l-input-small", ".png"); ?>
                <?php Form::inputLabelDocument("Login Kiri", "image_login_left", $info->path_image_login_left, false, "l-input-small", ".png"); ?>
                <?php Form::inputLabelDocument("Login Kanan", "image_login_right", $info->path_image_login_right, false, "l-input-small", ".png"); ?>

            </fieldset>

            <br>

            <fieldset>

                <legend>&nbsp;MOBILE&nbsp;</legend>

                <?php Form::inputLabelDocument("Logo", "image_mobile_logo", $info->path_image_mobile_logo, false, "l-input-small", ".png"); ?>

                <br>

                <?php Form::inputLabelDocument("Login Logo", "image_mobile_login_logo", $info->path_image_mobile_login_logo, false, "l-input-small", ".png"); ?>
                <?php Form::inputLabelDocument("Login Background", "image_mobile_login_background", $info->path_image_mobile_login_background, false, "l-input-small", ".png"); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function update()
{
    global $par, $user, $request;

    $parameter = getPar($par, "mode");

    $storage = Storage::disk("public");

    DB::beginTransaction();

    try {

        $update = AppInformation::find(1);

        $update->update([
            "name" => $request->name,
            "description" => $request->description,
            "copyright" => $request->copyright,

            "updated_by" => $user->id,
        ]);

        // WEB
        if ($request->file("icon") || $request->icon_delete) {

            if ($storage->exists($update->path_icon)) {
                $storage->delete($update->path_icon);
            }

            $update->update([
                "path_icon" => ""
            ]);
        }

        if ($request->file("logo") || $request->logo_delete) {

            if ($storage->exists($update->path_logo)) {
                $storage->delete($update->path_logo);
            }

            $update->update([
                "path_logo" => ""
            ]);
        }

        if ($request->file("backdrop") || $request->backdrop_delete) {

            if ($storage->exists($update->path_backdrop)) {
                $storage->delete($update->path_backdrop);
            }

            $update->update([
                "path_backdrop" => ""
            ]);
        }

        if ($request->file("image_login_background") || $request->image_login_background_delete) {

            if ($storage->exists($update->path_image_login_background)) {
                $storage->delete($update->path_image_login_background);
            }

            $update->update([
                "path_image_login_background" => ""
            ]);
        }

        if ($request->file("image_login_left") || $request->image_login_left_delete) {

            if ($storage->exists($update->path_image_login_left)) {
                $storage->delete($update->path_image_login_left);
            }

            $update->update([
                "path_image_login_left" => ""
            ]);
        }

        if ($request->file("image_login_right") || $request->image_login_right_delete) {

            if ($storage->exists($update->path_image_login_right)) {
                $storage->delete($update->path_image_login_right);
            }

            $update->update([
                "path_image_login_right" => ""
            ]);
        }

        if ($request->file("icon")) {
            $update->update([
                "path_icon" => $request->file("icon")->storeAs(AppInformation::path_image, "favicon.ico", ["disk" => "public"])
            ]);
        }

        if ($request->file("logo")) {
            $update->update([
                "path_logo" => $request->file("logo")->storeAs(AppInformation::path_image, "logo.png", ["disk" => "public"])
            ]);
        }

        if ($request->file("backdrop")) {
            $update->update([
                "path_backdrop" => $request->file("backdrop")->storeAs(AppInformation::path_image, "backdrop.png", ["disk" => "public"])
            ]);
        }

        if ($request->file("image_login_background")) {
            $update->update([
                "path_image_login_background" => $request->file("background")->storeAs(AppInformation::path_image, "login_background.png", ["disk" => "public"])
            ]);
        }

        if ($request->file("image_login_left")) {
            $update->update([
                "path_image_login_left" => $request->file("image_login_left")->storeAs(AppInformation::path_image, "login_left.png", ["disk" => "public"])
            ]);
        }

        if ($request->file("image_login_right")) {
            $update->update([
                "path_image_login_right" => $request->file("image_login_right")->storeAs(AppInformation::path_image, "login_right.png", ["disk" => "public"])
            ]);
        }

        // MOBILE
        if ($request->file("image_mobile_logo") || $request->image_mobile_logo_delete) {

            if ($storage->exists($update->path_image_mobile_logo)) {
                $storage->delete($update->path_image_mobile_logo);
            }

            $update->update([
                "path_image_mobile_logo" => ""
            ]);
        }

        if ($request->file("image_mobile_login_logo") || $request->image_mobile_login_logo_delete) {

            if ($storage->exists($update->path_image_mobile_login_logo)) {
                $storage->delete($update->path_image_mobile_login_logo);
            }

            $update->update([
                "path_image_mobile_login_logo" => ""
            ]);
        }

        if ($request->file("image_mobile_login_background") || $request->image_mobile_login_background_delete) {

            if ($storage->exists($update->path_image_mobile_login_background)) {
                $storage->delete($update->path_image_mobile_login_background);
            }

            $update->update([
                "path_image_mobile_login_background" => ""
            ]);
        }


        if ($request->file("image_mobile_logo")) {
            $update->update([
                "path_image_mobile_logo" => $request->file("image_mobile_logo")->storeAs(AppInformation::path_image, "mobile_logo.png", ["disk" => "public"])
            ]);
        }

        if ($request->file("image_mobile_login_logo")) {
            $update->update([
                "path_image_mobile_login_logo" => $request->file("image_mobile_login_logo")->storeAs(AppInformation::path_image, "mobile_login_logo.png", ["disk" => "public"])
            ]);
        }

        if ($request->file("image_mobile_login_background")) {
            $update->update([
                "path_image_mobile_login_background" => $request->file("image_mobile_login_background")->storeAs(AppInformation::path_image, "mobile_login_background.png", ["disk" => "public"])
            ]);
        }

        Cache::forget("app_information");

        DB::commit();
        echo "<script>alert('Informasi berhasil diubah')</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Informasi gagal diubah')</script>";
    }

    echo "<script>window.location='?{$parameter}'</script>";
}
