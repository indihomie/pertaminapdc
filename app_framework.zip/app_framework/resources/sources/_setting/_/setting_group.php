<?php

use App\Models\AppGroupAccessMenu;
use App\Models\AppGroupAccessModule;
use App\Models\AppModule;
use App\View\Components\Layout;
use App\View\Components\Form;
use App\Models\AppUser;
use App\Models\AppGroup;
use App\Models\AppMaster;

function getContent($par)
{
    global $_submit, $access;

    switch ($par["mode"]) {

        case "datas":
            $text = datas();
        break;

        case "chk":
            $text = chk();
        break;

        case "delete":
            if (isset($access["delete"]))
                $text = destroy();
            else
                $text = index();
        break;

        case "edit":
            if (isset($access["edit"]))
                $text = empty($_submit) ? form() : store();
            else
                $text = index();
        break;

        case "add":
            if (isset($access["add"]))
                $text = empty($_submit) ? form() : store();
            else
                $text = index();
        break;

        default:
            $text = index();
        break;

    }

    return $text;
}

function datas()
{
    global $par, $access;

    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $arr_order = ["id", "name"];

    $q_order = $arr_order[$iSortCol_0];
    $q_sort  = $iSortCol_0 > 0 ? $sSortDir_0 : 'DESC';

    $query = AppGroup::whereNull("deleted_at");

    if (!empty($search)) {
        $query->where(function ($query) use ($search) {
            $query->orWhere('name', 'like', "%$search%");
        });
    }

    $count = clone $query;

    $query = $query->orderBy($q_order, $q_sort);

    if ($iDisplayLength > 0) {
        $query->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $groups = $query->get();

    $json = [
        "iTotalDisplayRecords" => $count->count(),
        "aaData" => [],
    ];

    $no = $iDisplayStart;

    foreach ($groups as $r) {

        $no++;

        $r['status'] = $r['status'] == '1' ? "<img src=\"assets/images/t.png\" title='Active'>" : "<img src=\"assets/images/f.png\" title='Not Active'>";

        $controlDokumen = "";

        if (isset($access["edit"]))   $controlDokumen .= "<a href=\"#Edit\" title=\"Edit Data\" class=\"edit\" onclick=\"openBox('popup?par[mode]=edit&par[group_id]=$r[id]" . getPar($par, "mode, group_id") . "',800,500);\"><span>Edit</span></a>";
        if (isset($access["delete"])) $controlDokumen .= "<a href=\"?par[mode]=delete&par[group_id]=$r[id]" . getPar($par, "mode, group_id") . "\" onclick=\"return confirm('anda yakin akan menghapus data ini ?')\" title=\"Delete Data\" class=\"delete\"><span>Delete</span></a>";

        $data = array(
            "<div align=\"center\">" . $no . "</div>",
            "<div align=\"left\">" . $r['name'] . "</div>",
            "<div align=\"left\">" . $r['description'] . "</div>",
            "<div align=\"center\">" . $r['status'] . "</div>",
            "<div align=\"center\">" . $controlDokumen . "</div>",
        );

        $json['aaData'][] = $data;
    }

    return json_encode($json);
}

function chk()
{
    global $par;

    if (getField("select group_id from app_users where group_id='".$par['group_id']."'"))
        return "sorry, data has been use";
}

function destroy()
{
    global $par, $user;

    DB::beginTransaction();

    try {

        AppGroup::where("id", $par['group_id'])->update(["deleted_by" => $user->id, "deleted_at" => date("Y-m-d H:i:s")]);
        AppGroupAccessModule::where("group_id", $par['group_id'])->delete();
        AppGroupAccessMenu::where("group_id", $par['group_id'])->delete();

        DB::commit();

        echo "<script>alert('Data berhasil dihapus')</script>";


    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Data gagal dihapus')</script>";
    }

    echo "<script>window.location='?" . getPar($par, "mode, group_id") . "';</script>";
}

function store()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        if ($par['mode'] == "add") {

            $arrGorup = [
                'name'        => $request->nama,
                'description' => $request->deskripsi,
                'status'      => 1,
                'created_by'  => $user->id,
                'updated_by'  => $user->id,
            ];

            $ins = AppGroup::create($arrGorup);
            $group_id = $ins->id;

        }

        if ($par['mode'] == "edit") {

            $arrGorup = [
                'name'        => $request->nama,
                'description' => $request->deskripsi,
                'updated_by'  => $user->id,
            ];

            AppGroup::find($par['group_id'])->update($arrGorup);
            AppGroupAccessModule::where("group_id", $par['group_id'])->delete();

            $group_id = $par['group_id'];

        }

        foreach ($request->det as $value) {

            AppGroupAccessModule::create([
                'group_id'   => $group_id,
                'module_id'  => $value,
                'created_by' => $user->id,
                'updated_by' => $user->id,
            ]);

            \Illuminate\Support\Facades\Cache::forget("app_group_access_menus-{$group_id}");
        }

        DB::commit();

        echo "<script>closeBox()</script>";
        echo "<script>alert('Data berhasil disimpan')</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>closeBox()</script>";
        echo "<script>alert('Data gagal disimpan')</script>";
    }

    echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";
}

function form()
{
    global $par;

    $r = AppGroup::find($par['group_id']);

    setValidation("is_null", "inp[name]", "you must fill name");
    echo getValidation();

    Layout::title(true);

    ?>

    <div id="contentwrapper" class="contentwrapper">
        <form id="form" name="form" method="post" class="stdform" action="?_submit=1<?= getPar($par) ?>" onsubmit="return validation(document.form);" autocomplete="off" enctype="multipart/form-data">
            <div id="general" class="subcontent">
                <?php
                Form::CSRF();
                Form::inputLabelText("Nama", "nama", $r['name']);
                Form::inputLabelTextArea("Deskripsi", "deskripsi", $r['description']);
                ?>

                <label class="l-input-small">Akses Modul</label>
                <div class="field" style="margin-left:175px;">
                    <?php
                    $det = AppGroupAccessModule::select("group_id", "module_id")->where("group_id", $par['group_id'])->pluck("group_id", "module_id")->toArray();

                    $arrkatModul = AppMaster::select("id", "name")->where([["category_id","S001"] , ["status", "1"]])->pluck("name", "id")->toArray();

                    $sql_ = AppModule::select("app_modules.*")
                            ->join("app_masters as t2", function ($join){
                                $join->on("t2.id", "app_modules.category_id");
                                $join->where("t2.category_id", "S001");
                            })
                            ->where("t2.status", "1")
                            ->orderBy("t2.order", "asc")
                            ->get();

                    foreach ($sql_ as $r_) {
                        $arrNamaModul[$r_['category_id']][$r_['id']] = $r_['name'];
                    }

                    asort($arrNamaModul);

                    foreach ($arrkatModul as $kode => $nama) {

                        ?>
                        <fieldset>
                            <legend><strong><?= $nama ?></strong></legend>
                            <?php
                            foreach ($arrNamaModul[$kode] as $module_id => $namaModul) {

                                $checked = isset($det[$module_id]) ? "checked='checked'" : "";
                                ?>
                                <input type="checkbox" id="det[<?= $module_id ?>]" name="det[<?= $module_id ?>]" value="<?= $module_id ?>" <?= $checked ?> /> <?= $namaModul ?>
                                <br>
                                <?php

                            }
                            ?>
                        </fieldset>
                        <?php

                    }
                    ?>
                </div>
            </div>
            <?= Layout::formBtnSubmit('true') ?>
        </form>
    </div>
    <?php
}

function index()
{
    global $par, $access;

    datatable(5, array(3, 4, 5));

    Layout::title();

    ?>
    <div id="contentwrapper" class="contentwrapper">

        <form action="" method="post" class="stdform">
            <div class="filter_container">
                <div class="filter_left">
                    <p>
                        <input type="text" id="search" name="search"/>
                    </p>
                </div>
                <div class="filter_right">
                    <?php if (isset($access["add"])) : ?>
                        <a href="#Add" class="stdbtn" onclick="openBox('popup?par[mode]=add<?= getPar($par, "mode, group_id") ?>', 800, 500);"><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>

        <table cellpadding="0" cellspacing="0" border="0" class="stdtable stdtablequick" id="table">
            <thead>
                <tr>
                    <th style="min-width: 20px;">No</th>
                    <th style="min-width: 200px;">Nama</th>
                    <th style="min-width: 250px;">Deskripsi</th>
                    <th style="min-width: 70px;">Status</th>
                    <th style="min-width: 50px;">Kontrol</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>

    </div>

    <?php
}
?>
