<?php
global $access, $par, $_submit, $template;

use App\Models\AppGroup;
use App\Models\AppGroupAccessMenu;
use App\Models\AppGroupAccessModule;
use App\Models\AppMaster;
use App\Models\AppMenu;
use App\Models\AppModule;
use App\Models\AppModuleSub;
use App\View\Components\Form;
use App\View\Components\Layout;

$template = collect([
    "name" => "Pengaturan",
    "directory" => "",
    "path_icon" => "_/module_sub/_setting.png",
    "description" => "",
    "order" => 1,
    "status" => 1,
    "created_by" => 1,
    "updated_by" => 1,
    "menus" => [
        [
            "name" => "User Manajemen",
            "target" => "",
            "parameter" => "",
            "access" => "1000",
            "path_icon" => "_/menu/_user_management.png",
            "order" => 1,
            "toolbar_side" => 1,
            "status" => 1,
            "subs" => [
                [
                    "name" => "User",
                    "target" => "_setting/_/setting_user",
                    "parameter" => "",
                    "access" => "1111",
                    "path_icon" => "",
                    "order" => 1,
                    "toolbar_side" => 1,
                    "status" => 1,
                ],
                [
                    "name" => "Grup Akses",
                    "target" => "_setting/_/setting_group_access",
                    "parameter" => "",
                    "access" => "1111",
                    "path_icon" => "",
                    "order" => 2,
                    "toolbar_side" => 1,
                    "status" => 1,
                ],
                [
                    "name" => "Akses Log",
                    "target" => "setting/_/log_access",
                    "parameter" => "",
                    "access" => "1111",
                    "path_icon" => "",
                    "order" => 3,
                    "toolbar_side" => 1,
                    "status" => 1,
                ],
            ],
        ],
        [
            "name" => "Data Spesifik",
            "target" => "",
            "parameter" => "",
            "access" => "1000",
            "path_icon" => "_/menu/_specific.png",
            "order" => 2,
            "toolbar_side" => 1,
            "status" => 1,
            "subs" => [
                [
                    "name" => "Sub Moduul",
                    "target" => "_setting/_/setting_module_sub",
                    "parameter" => "",
                    "access" => "1111",
                    "path_icon" => "",
                    "order" => 1,
                    "toolbar_side" => 1,
                    "status" => 1,
                ],
                [
                    "name" => "Menu",
                    "target" => "_setting/_/setting_menu",
                    "parameter" => "",
                    "access" => "1111",
                    "path_icon" => "",
                    "order" => 2,
                    "toolbar_side" => 1,
                    "status" => 1,
                ],
            ]
        ],
        [
            "name" => "Data Master",
            "target" => "_setting/_/setting_master",
            "parameter" => "",
            "access" => "1111",
            "path_icon" => "_/menu/_master.png",
            "order" => 3,
            "toolbar_side" => 1,
            "status" => 1,
            "subs" => []
        ]
    ]
]);

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;


    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    $categories = AppMaster::query()
        ->where("category_id", "S001")
        ->orderBy("order")
        ->get();

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">
                    &nbsp;
                    <?= Form::selectArray("Filter Category", "change_1", $categories, "id", "name", session("filter_category", ""), ""); ?>

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add&par[category_id]=${jQuery('#change_1').val()}`, 600, 400);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="30">Ikon</th>
                <th width="100">Kategori</th>
                <th width="*">Nama</th>
                <th width="20">Urut</th>
                <th width="50">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(7, [2, 3, 7]); ?>

    <?php
}

function form()
{
    global $access, $par;

    $categories = AppMaster::query()
        ->where("category_id", "S001")
        ->orderBy("order")
        ->get();
    $statuses = config("paramter.status_label");
    $types = [
        "module" => "Modul",
        "link" => "Link"
    ];

    $module = AppModule::query()->find($par["id"]);

    $module_order = $module->order ?? AppModule::query()->select("order")->where("category_id", $par["category_id"])->orderBy("order", "desc")->first()->order + 1;

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset>

                <?php Form::inputLabelSelectArray("Kategori", "category_id", $categories, "id", "name", $module->category_id ?? $par["category_id"], false, "", "l-input-small", "mediuminput", "", "63%") ?>
                <?php Form::inputLabelText("Nama", "name", $module->name, true); ?>
                <?php Form::inputLabelText("Direktori", "directory", $module->directory, true); ?>
                <?php Form::inputLabelDocument("Ikon", "icon", $module->path_icon, false, "l-input-small", ".png", false); ?>
                <?php Form::inputLabelNumber("Urut", "order", $module_order); ?>
                <?php Form::inputLabelSelectArray("Tipe", "type", $types, "", "", $module->type, false, "", "l-input-small", "smallinput", "", "23%") ?>
                <div id="with_link"
                     style="display: <?= $module->link_status == "link" ? "block" : "none"; ?>;">
                    <?php Form::inputLabelText("Link", "link", $module->link, true, "l-input-small", "longinpt", ""); ?>
                </div>
                <?php Form::inputLabelRadio("Status", "status", $statuses, $module->status ?? 1); ?>

            </fieldset>

        </form>

    </div>
    <script>

        jQuery(document).ready(function () {

            jQuery("#type").change(function () {

                let value = jQuery(this).val()

                jQuery("#with_link").toggle(value == "link")
            })

        })

    </script>
    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search, $change_1;

    session()->put("filter_category", $change_1);

    $parameter = getPar($par, "mode");
    $number = $iDisplayStart;

    $arr_order = [
        "order",
        "icon",
        "category_id",
        "name",
        "order",
        "status",
    ];

    $module = AppModule::query()
        ->with([
            "category" => function ($query) {
                return $query->orderBy("order");
            }
        ])
        ->where("category_id", $change_1)
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        });
    $count = clone $module;

    $module->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $module->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $module
        ->get()
        ->map(function ($module) use (&$number, $access, $par, $parameter) {

            $number++;

            $image_viewer = $module->path_icon ? openView($module->path_icon) : "-";

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$module->id}`, 600, 400);'></a>";
            }
            if ($access["delete"]) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus modul ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$module->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$image_viewer}</div>",
                "<div align='left'>{$module->category->name}</div>",
                "<div align='left'>{$module->name}</div>",
                "<div align='right'>{$module->order}</div>",
                "<div align='center'>{$module->status_image}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $request, $user, $template, $arr_permission;

    $permissions = array_keys($arr_permission);

    DB::beginTransaction();

    try {

        $module = AppModule::create([
            "category_id" => $request->category_id,
            "name" => $request->name,
            "directory" => $request->directory,
            "path_icon" => $request->file("icon") ? $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"]) : "",
            "type" => $request->type,
            "link" => $request->link ?? "",
            "order" => $request->order,
            "status" => $request->status,
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        $module_sub = $module->moduleSubs()
            ->create([
                "name" => $template["name"],
                "directory" => $template["directory"],
                "path_icon" => $template["path_icon"],
                "description" => $template["description"],
                "order" => $template["order"],
                "status" => $template["status"],
                "created_by" => $user->id,
                "updated_by" => $user->id,
            ]);

        $menus_with_accesses = [];

        foreach ($template["menus"] as $_menu) {

            $menu = $module_sub->menus()
                ->create([
                    "module_id" => $module->id,
                    "menu_id" => 0,
                    "level" => 1,
                    "name" => $_menu["name"],
                    "target" => $_menu["target"],
                    "parameter" => $_menu["parameter"],
                    "access" => $_menu["access"],
                    "path_icon" => $_menu["path_icon"],
                    "order" => $_menu["order"],
                    "toolbar_side" => $_menu["toolbar_side"],
                    "status" => $_menu["status"],
                    "created_by" => $user->id,
                    "updated_by" => $user->id,
                ]);
            $menus_with_accesses[] = $menu->only(["id", "access"]);

            foreach ($_menu["subs"] as $_menu_sub) {

                $menu_sub = $menu->menuSubs()
                    ->create([
                        "module_id" => $module->id,
                        "module_sub_id" => $module_sub->id,
                        "menu_id" => $menu->id,
                        "level" => 2,
                        "name" => $_menu_sub["name"],
                        "target" => $_menu_sub["target"],
                        "parameter" => $_menu_sub["parameter"],
                        "access" => $_menu_sub["access"],
                        "path_icon" => $_menu_sub["path_icon"],
                        "order" => $_menu_sub["order"],
                        "toolbar_side" => $_menu_sub["toolbar_side"],
                        "status" => $_menu_sub["status"],
                        "created_by" => $user->id,
                        "updated_by" => $user->id,
                    ]);

                $menus_with_accesses[] = $menu_sub->only(["id", "access"]);
            }

        }

        $user_group = AppGroup::find(1);

        $user_group->accessModules()
            ->create([
                "group_id" => 1,
                "module_id" => $module->id
            ]);

        $user_group->accessMenus()
            ->createMany(collect($menus_with_accesses)
                ->map(function ($menu_with_accesses) use ($module, $permissions, $user) {

                    $menu_access = [];

                    for ($n = 0; $n <= strlen($menu_with_accesses["access"]) - 1; $n++) {

                        if ($menu_with_accesses["access"][$n] == 0)
                            continue;

                        $menu_access[] = [
                            "module_id" => $module->id,
                            "menu_id" => $menu_with_accesses["id"],
                            "permission" => $permissions[$n],
                            "created_by" => $user->id,
                            "updated_by" => $user->id,
                        ];
                    }

                    return $menu_access;
                })
                ->flatten(1)
            );

        DB::commit();
        Cache::forget("app_modules");
        Cache::forget("app_module_sub-{$module->id}");
        Cache::forget("app_menu-{$module->id}");
        Cache::forget("app_menu_sub-{$module->id}");
        Cache::forget("app_group_access_menus-{$user_group->id}");

        echo "<script>alert('Modul berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Modul gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    DB::beginTransaction();

    try {

        $update = AppModule::query()->find($par["id"]);

        $update->update([
            "category_id" => $request->category_id,
            "name" => $request->name,
            "directory" => $request->directory,
            "type" => $request->type,
            "link" => $request->link ?? "",
            "order" => $request->order,
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        if ($request->file("icon") || $request->icon_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($update->path_icon) && strpos($update->path_icon, "_") !== false) {
                $storage->delete($update->path_icon);
            }

            $update->update([
                "path_icon" => ""
            ]);
        }

        if ($request->file("icon")) {
            $update->update([
                "path_icon" => $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"])
            ]);
        }

        DB::commit();
        Cache::forget("app_modules");

        echo "<script>alert('Modul berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Modul gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $module = AppModule::query()->find($par["id"]);

        AppModule::query()->where("id", $module->id)->delete();
        AppModuleSub::query()->where("module_id", $module->id)->delete();
        AppMenu::query()->where("module_id", $module->id)->delete();

        AppGroupAccessModule::query()->where("module_id", $module->id)->delete();
        AppGroupAccessMenu::query()->where("module_id", $module->id)->delete();

        DB::commit();
        Cache::forget("app_modules");
        Cache::forget("app_module_sub-{$module->id}");
        Cache::forget("app_menu-{$module->id}");
        Cache::forget("app_menu_sub-{$module->id}");

        echo "<script>alert('Modul berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Modul gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}
