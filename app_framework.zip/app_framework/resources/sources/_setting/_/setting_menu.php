<?php
global $access, $par, $_submit;

use App\Models\AppMenu;
use App\Models\AppModule;
use App\Models\AppModuleSub;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;


    case "child_add":
        if ($access["add"])
            $_submit ? storeChild() : formChild();
        else
            echo "Tidak ada akses";
        break;

    case "child_edit":
        if ($access["edit"])
            $_submit ? updateChild() : formChild();
        else
            echo "Tidak ada akses";
        break;

    case "child_delete":
        if ($access["delete"])
            destroyChild();
        else
            echo "Tidak ada akses";
        break;


    default:
        index();
        break;

}

function index()
{
    global $access, $par, $module_id;

    $parameter = getPar($par, "mode, id");

    $module = AppModule::query()
        ->with([
            "moduleSubs" => function ($query) {
                $query->select(["id", "module_id", "name"])->orderBy("order");
            }
        ])
        ->find($module_id);

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">
                    &nbsp;
                    <?= Form::selectArray("Filter Sub Modul", "change_1", $module->moduleSubs, "id", "name", session("filter_module_sub", ""), ""); ?>

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add&par[module_sub_id]=${jQuery('#change_1').val()}`, 800, 520);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="30">Ikon</th>
                <th width="*">Nama</th>
                <th width="20">Urut</th>
                <th width="50">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(6, [2, 5, 6]); ?>

    <?php
}

function form()
{
    global $access, $par, $module_id, $arr_permission;

    $module = AppModule::query()
        ->with([
            "moduleSubs" => function ($query) {
                $query->select(["id", "module_id", "name"])->orderBy("order");
            }
        ])
        ->find($module_id);
    $permissions = collect($arr_permission)
        ->map(function ($access, $permission) {

            return [
                "name" => "permission[$permission]",
                "value" => 1,
                "title" => $access
            ];
        })
        ->values()
        ->toArray();
    $arr_toolbar_side = [
        1 => "Tampil",
        0 => "Kecil",
        -1 => "sembunyikan"
    ];
    $statuses = config("paramter.status_label");

    $menu = AppMenu::query()->find($par["id"]);

    $menu_access = $menu->access ?? "";
    $menu_order = $menu->order ?? AppMenu::query()->select("order")->where("module_sub_id", $par["module_sub_id"])->orderBy("order", "desc")->first()->order + 1;

    $has_permissions = collect($arr_permission)
        ->keys()
        ->mapWithKeys(function ($access, $key) use ($menu_access) {
            return ["permission[$access]" => $menu_access[$key] ?? 0];
        })
        ->toArray();

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset>

                <?php Form::inputLabelSelectArray("Sub Modul", "module_sub_id", $module->moduleSubs, "id", "name", $menu->module_sub_id ?? $par["module_sub_id"], false, "", "l-input-small", "mediuminput", "", "63%") ?>
                <?php Form::inputLabelText("Kode", "code", $menu->code, false, "l-input-small", "vsmallinput uppercase", "max='10'"); ?>
                <?php Form::inputLabelText("Nama", "name", $menu->name, true); ?>
                <?php Form::inputLabelText("Target", "target", $menu->target, true); ?>
                <?php Form::inputLabelTextArea("Deskripsi", "description", $menu->description, false); ?>
                <?php Form::inputLabelText("Parameter", "parameter", $menu->parameter, false); ?>
                <?php Form::inputLabelCheckBoxes("Akses", "access", $permissions, "name", "value", "title", $has_permissions); ?>
                <?php Form::inputLabelDocument("Ikon", "icon", $menu->path_icon, false, "l-input-small", ".png", false); ?>
                <?php Form::inputLabelNumber("Urut", "order", $menu_order); ?>
                <?php Form::inputLabelRadio("Menu Samping", "toolbar_side", $arr_toolbar_side, $menu->toolbar_side ?? 1); ?>
                <?php Form::inputLabelRadio("Status", "status", $statuses, $menu->status ?? 1); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function formChild()
{
    global $access, $par, $module_id, $arr_permission;

    $module = AppModule::query()
        ->with([
            "menus" => function ($query) use ($par) {
                $query->select(["app_menus.id", "app_menus.name"])->where("module_sub_id", $par["module_sub_id"])->where("menu_id", 0)->orderBy("app_menus.order");
            },
        ])
        ->find($module_id);
    $permissions = collect($arr_permission)
        ->map(function ($access, $permission) {

            return [
                "name" => "permission[$permission]",
                "value" => 1,
                "title" => $access
            ];
        })
        ->values()
        ->toArray();
    $arr_toolbar_side = [
        1 => "Tampil",
        0 => "Kecil",
        -1 => "sembunyikan"
    ];
    $statuses = config("paramter.status_label");

    $module_sub = AppModuleSub::query()->find($par["module_sub_id"]);

    $menu = AppMenu::query()->find($par["id"]);

    $menu_access = $menu->access ?? "";
    $menu_order = $menu->order ?? AppMenu::query()->select("order")->where("module_sub_id", $par["module_sub_id"])->where("menu_id", $par["menu_id"])->orderBy("order", "desc")->first()->order + 1;

    $has_permissions = collect($arr_permission)
        ->keys()
        ->mapWithKeys(function ($access, $key) use ($menu_access) {
            return ["permission[$access]" => $menu_access[$key] ?? 0];
        })
        ->toArray();

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset>

                <?php Form::spanLabel("Sub Modul", $module_sub->name); ?>
                <?php Form::inputLabelSelectArray("Induk", "menu_id", $module->menus, "id", "name", $menu->menu_id ?? $par["menu_id"], false, "", "l-input-small", "mediuminput", "", "63%") ?>
                <?php Form::inputLabelText("Kode", "code", $menu->code, false, "l-input-small", "vsmallinput uppercase", "max='10'"); ?>
                <?php Form::inputLabelText("Nama", "name", $menu->name, true); ?>
                <?php Form::inputLabelText("Target", "target", $menu->target, true); ?>
                <?php Form::inputLabelTextArea("Deskripsi", "description", $menu->description, false); ?>
                <?php Form::inputLabelText("Parameter", "parameter", $menu->parameter, false); ?>
                <?php Form::inputLabelCheckBoxes("Akses", "access", $permissions, "name", "value", "title", $has_permissions); ?>
                <?php Form::inputLabelDocument("Ikon", "icon", $menu->path_icon, false, "l-input-small", ".png", false); ?>
                <?php Form::inputLabelNumber("Urut", "order", $menu_order); ?>
                <?php Form::inputLabelRadio("Menu Samping", "toolbar_side", $arr_toolbar_side, $menu->toolbar_side ?? 1); ?>
                <?php Form::inputLabelRadio("Status", "status", $statuses, $menu->status ?? 1); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function datas()
{
    global $access, $par, $module_id;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search, $change_1;

    session()->put("filter_module_sub", $change_1);

    $parameter = getPar($par, "mode");
    $number = $iDisplayStart;

    $arr_order = [
        "order",
        "icon",
        "name",
        "order",
        "status",
    ];

    $menus = AppMenu::query()
        ->where("module_id", $module_id)
        ->where("menu_id", 0)
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        })
        ->when($change_1, function ($query, $module_sub_id) {
            $query->where("module_sub_id", $module_sub_id);
        });
    $count = clone $menus;

    $menus->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $menus->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $menus
        ->with([
            "menuSubs" => function ($query) {
                return $query->orderBy("order");
            }
        ])
        ->with("moduleSub:id,name")
        ->withCount("menuSubs")
        ->get()
        ->map(function ($menu) use (&$number, $access, $par, $parameter) {

            $number++;

            $image_viewer = $menu->path_icon ? openView($menu->path_icon) : "-";

            $control = "";

            if ($access["add"]) {
                $control .= "<a title='Tambah Data' class='add' href='#Add' onclick='openBox(`popup?{$parameter}&par[mode]=child_add&par[module_sub_id]={$menu->module_sub_id}&par[menu_id]={$menu->id}`, 800, 520)'></a>";
            }
            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$menu->id}`, 800, 520);'></a>";
            }
            if ($access["delete"]) {
                if ($menu->menu_subs_count == 0) {
                    $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus menu ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$menu->id}`, 50, 50, false) : ``'></a>";
                } else {
                    $control .= "<a title='Hapus Data' class='delete' onclick='alert(`Sub Menu lebih dari 1 data`)'></a>";
                }
            }

            $menu_parent = [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$image_viewer}</div>",
                "<div align='left'>{$menu->name}</div>",
                "<div align='right'>{$menu->order}</div>",
                "<div align='center'>{$menu->status_image}</div>",
                "<div align='center'>{$control}</div>",
            ];

            $menus = $menu->menuSubs
                ->map(function ($menu) use (&$number, $access, $par, $parameter) {

                    $number++;

                    $image_viewer = $menu->path_icon ? openView($menu->path_icon) : "-";

                    $control = "";

                    if ($access["edit"]) {
                        $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=child_edit&par[module_sub_id]={$menu->module_sub_id}&par[menu_id]={$menu->menu_id}&par[id]={$menu->id}`, 800, 520);'></a>";
                    }
                    if ($access["delete"] && $menu->menu_subs_count == 0) {
                        $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus menu ini?`) ? openBox(`void?{$parameter}&par[mode]=child_delete&par[id]={$menu->id}`, 50, 50, false) : ``'></a>";
                    }

                    return [
                        "<div align='center'>{$number}.</div>",
                        "<div align='center'>{$image_viewer}</div>",
                        "<div align='left'>&emsp; {$menu->name}</div>",
                        "<div align='right' class='text-red-500'>{$menu->order}</div>",
                        "<div align='center'>{$menu->status_image}</div>",
                        "<div align='center'>{$control}</div>",
                    ];
                })
                ->prepend($menu_parent);

            return $menus;
        })
        ->flatten(1);

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $request, $user, $arr_permission, $module_id;

    DB::beginTransaction();

    try {

        $permission = $request->permission;
        $accesses = "";

        foreach ($arr_permission as $key => $_) {
            $accesses .= $permission[$key] ?? 0;
        }

        AppMenu::create([
            "module_id" => $module_id,
            "module_sub_id" => $request->module_sub_id,
            "menu_id" => 0,
            "level" => 1,
            "code" => $request->code ?? "",
            "name" => $request->name ?? "",
            "target" => $request->target ?? "",
            "description" => $request->description ?? "",
            "parameter" => $request->parameter ?? "",
            "access" => $accesses,
            "path_icon" => $request->file("icon") ? $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"]) : "",
            "order" => $request->order,
            "toolbar_side" => $request->toolbar_side,
            "status" => $request->status,
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();
        Cache::forget("app_menu-{$module_id}");
        Cache::forget("app_menu_sub-{$module_id}");

        echo "<script>alert('Menu berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Menu gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function storeChild()
{
    global $par, $request, $user, $arr_permission, $module_id;

    DB::beginTransaction();

    try {

        $permission = $request->permission;
        $accesses = "";

        foreach ($arr_permission as $key => $_) {
            $accesses .= $permission[$key] ?? 0;
        }

        AppMenu::create([
            "module_id" => $module_id,
            "module_sub_id" => $par["module_sub_id"],
            "menu_id" => $request->menu_id,
            "level" => 2,
            "code" => $request->code ?? "",
            "name" => $request->name ?? "",
            "target" => $request->target ?? "",
            "description" => $request->description ?? "",
            "parameter" => $request->parameter ?? "",
            "access" => $accesses,
            "path_icon" => $request->file("icon") ? $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"]) : "",
            "order" => $request->order,
            "toolbar_side" => $request->toolbar_side,
            "status" => $request->status,
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();
        Cache::forget("app_menu-{$module_id}");
        Cache::forget("app_menu_sub-{$module_id}");

        echo "<script>alert('Sub Menu berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Sub Menu gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request, $arr_permission, $module_id;

    DB::beginTransaction();

    try {

        $permission = $request->permission;
        $accesses = "";

        foreach ($arr_permission as $key => $_) {
            $accesses .= $permission[$key] ?? 0;
        }

        $update = AppMenu::query()->find($par["id"]);

        $update->update([
            "module_sub_id" => $request->module_sub_id,
            "code" => $request->code ?? "",
            "name" => $request->name ?? "",
            "target" => $request->target ?? "",
            "description" => $request->description ?? "",
            "parameter" => $request->parameter ?? "",
            "access" => $accesses,
            "order" => $request->order,
            "toolbar_side" => $request->toolbar_side,
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        if ($request->file("icon") || $request->icon_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($update->path_icon) && strpos($update->path_icon, "_") !== false) {
                $storage->delete($update->path_icon);
            }

            $update->update([
                "path_icon" => ""
            ]);
        }

        if ($request->file("icon")) {
            $update->update([
                "path_icon" => $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"])
            ]);
        }

        DB::commit();
        Cache::forget("app_menu-{$module_id}");
        Cache::forget("app_menu_sub-{$module_id}");

        echo "<script>alert('Menu berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Menu gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function updateChild()
{
    global $par, $user, $request, $arr_permission, $module_id;

    DB::beginTransaction();

    try {

        $permission = $request->permission;
        $accesses = "";

        foreach ($arr_permission as $key => $_) {
            $accesses .= $permission[$key] ?? 0;
        }

        $update = AppMenu::query()->find($par["id"]);

        $update->update([
            "menu_id" => $request->menu_id,
            "code" => $request->code ?? "",
            "name" => $request->name ?? "",
            "target" => $request->target ?? "",
            "description" => $request->description ?? "",
            "parameter" => $request->parameter ?? "",
            "access" => $accesses,
            "order" => $request->order,
            "toolbar_side" => $request->toolbar_side,
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        if ($request->file("icon") || $request->icon_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($update->path_icon) && strpos($update->path_icon, "_") !== false) {
                $storage->delete($update->path_icon);
            }

            $update->update([
                "path_icon" => ""
            ]);
        }

        if ($request->file("icon")) {
            $update->update([
                "path_icon" => $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"])
            ]);
        }

        DB::commit();
        Cache::forget("app_menu-{$module_id}");
        Cache::forget("app_menu_sub-{$module_id}");

        echo "<script>alert('Menu berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Menu gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par, $module_id;

    DB::beginTransaction();

    try {

        $delete = AppMenu::query()->find($par["id"]);

        $storage = Storage::disk("public");

        if ($storage->exists($delete->path_icon) && strpos($delete->path_icon, "_") !== false) {
            $storage->delete($delete->path_icon);
        }

        $delete->delete();

        DB::commit();
        Cache::forget("app_menu-{$module_id}");
        Cache::forget("app_menu_sub-{$module_id}");

        echo "<script>alert('Menu berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Menu gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}

function destroyChild()
{
    global $par, $module_id;

    DB::beginTransaction();

    try {

        $delete = AppMenu::query()->find($par["id"]);

        $storage = Storage::disk("public");

        if ($storage->exists($delete->path_icon)) {
            $storage->delete($delete->path_icon);
        }

        $delete->delete();

        DB::commit();
        Cache::forget("app_menu-{$module_id}");
        Cache::forget("app_menu_sub-{$module_id}");

        echo "<script>alert('Sub Menu berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Sub Menu gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}
