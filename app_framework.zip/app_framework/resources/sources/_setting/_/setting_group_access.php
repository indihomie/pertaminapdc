<?php
global $access, $par, $_submit;

use App\Models\AppGroup;
use App\Models\AppGroupAccessMenu;
use App\Models\AppModule;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "sync":
        formSync();
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">

                </div>
                <div class="filter_right">

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="*">Grup</th>
                <th width="*">Deskripsi</th>
                <th width="50">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(5, range(3, 5)); ?>

    <?php
}

function form()
{
    global $access, $par, $module_id, $arr_permission;

    $parameter = getPar($par, "mode");

    $group = AppGroup::query()->find($par["id"]);

    $module = AppModule::query()
        ->select(["id", "name"])
        ->with([
            "moduleSubs" => function ($query) {
                $query->select(["id", "module_id", "name"])->orderBy("order");
            },
            "moduleSubs.menus" => function ($query) {
                $query->select(["id", "module_sub_id", "name", "access"])->where("menu_id", 0)->orderBy("order");
            },
            "moduleSubs.menus.menuSubs" => function ($query) {
                $query->select(["id", "module_sub_id", "menu_id", "name", "access"])->where("menu_id", "<>", 0)->orderBy("order");
            },
        ])
        ->find($module_id);

    if ($par["sync_group_id"]) {

        $group_access = AppGroupAccessMenu::query()
            ->select(["menu_id", "permission"])
            ->where("group_id", $par["sync_group_id"])
            ->where("module_id", $module_id)
            ->get();

    } else {

        $group_access = $group->accessMenus()
            ->select(["menu_id", "permission"])
            ->where("module_id", $module_id)
            ->get();

    }

    $group_access = $group_access->mapWithKeys(function ($permission) {
        return ["{$permission->menu_id}.{$permission->permission}" => true];
    });

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <a href="popup?<?= $parameter ?>&par[mode]=sync" class="stdbtn">Singkronisasi</a>
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset>

                <?php Form::spanLabel("Grup User", $group->name); ?>

            </fieldset>

            <div class="h-4"></div>

            <ul class="hornav mx-0">
                <?php foreach ($module->moduleSubs as $key => $module_sub) : ?>
                    <li class="<?= $key == 0 ? "current" : "" ?>">
                        <a href="#module_sub_<?= $module_sub->id ?>"><?= $module_sub->name ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>

            <?php foreach ($module->moduleSubs as $key => $module_sub) : ?>
                <fieldset id="module_sub_<?= $module_sub->id ?>"
                          class="subcontent overflow-y-auto"
                          style="height: 280px; display: <?= $key == 0 ? "block" : "none" ?>;">

                    <table width="100%">
                        <tbody>
                        <?php foreach ($module_sub->menus as $menu) : ?>
                            <?php $is_not_empty = $menu->menuSubs->isNotEmpty() ?>
                            <tr>
                                <td width="*"
                                    class="text-gray-700 py-1 <?= $is_not_empty ? "pt-3 font-bold" : "" ?>"
                                    style="<?= $is_not_empty ? "" : "border-bottom: 1px solid #eee" ?>">
                                    <?= $menu->name ?>
                                </td>
                                <?php $index = -1; ?>
                                <?php foreach ($arr_permission as $permission => $access) : $index++; ?>
                                    <?php if (!$menu->access[$index]) continue; ?>
                                    <td width="90">
                                        <div class="field m-0">
                                            <input type="checkbox" name="permissions[<?= $menu->id ?>][<?= $permission ?>]"
                                                   value="<?= $permission ?>" <?= $group_access["{$menu->id}.{$permission}"] ? "checked" : "" ?>>
                                            <?= $access ?>
                                        </div>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                            <?php foreach ($menu->menuSubs as $menu_sub) : ?>
                                <tr>
                                    <td width="*"
                                        class="text-gray-700 py-1"
                                        style="border-bottom: 1px solid #eee">
                                        &emsp; - <?= $menu_sub->name ?>
                                    </td>
                                    <?php $index = -1; ?>
                                    <?php foreach ($arr_permission as $permission => $access) : $index++; ?>
                                        <?php if (!$menu_sub->access[$index]) continue; ?>
                                        <td width="90">
                                            <div class="field m-0">
                                                <input type="checkbox" name="permissions[<?= $menu_sub->id ?>][<?= $permission ?>]"
                                                       value="<?= $permission ?>" <?= $group_access["{$menu_sub->id}.{$permission}"] ? "checked" : "" ?>>
                                                <?= $access ?>
                                            </div>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                </fieldset>
            <?php endforeach; ?>

        </form>

    </div>
    <?php
}

function formSync()
{
    global $par;

    $parameter = getPar($par, "mode");

    $group = AppGroup::query()->find($par["id"]);
    $groups = AppGroup::query()->where("id", "<>", $group->id)->orderBy("name")->get();

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true, "Singkronisasi"); ?>

        <form method="get" action=""
              id="form"
              class="stdform"
              name="form"
              onsubmit="return process()"
              autocomplete="off">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <div style="position: absolute; top: 1rem; right: .3rem;">
                <a href="popup?<?= $parameter ?>&par[mode]=edit" class="stdbtn">Kembali</a>
                <input type="submit" class="submit radius2" value="Singkron"/>
            </div>

            <fieldset>

                <?php Form::spanLabel("Grup User", $group->name); ?>
                <?php Form::inputLabelSelectArray("Singkron Dari", "sync_group_id", $groups, "id", "name", "", true) ?>

            </fieldset>

        </form>

    </div>
    <script>

        function process() {

            let group_id = jQuery("#sync_group_id").val()

            window.location = `?<?= $parameter ?>&par[mode]=edit&par[sync_group_id]=${group_id}`

            return false
        }

    </script>
    <?php
}

function datas()
{
    global $access, $par, $module_id;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "name",
        "name"
    ];

    $groups = AppGroup::query()
        ->whereHas("accessModules", function ($query) use ($module_id) {
            $query->where("module_id", $module_id);
        })
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        });
    $count = clone $groups;

    $groups->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $groups->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $groups
        ->withCount("users")
        ->get()
        ->map(function ($group, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$group->id}`, 1000, 520);'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='left'>{$group->name}</div>",
                "<div align='left'>{$group->description}</div>",
                "<div align='center'>{$group->status_image}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function update()
{
    global $par, $user, $request, $module_id;

    DB::beginTransaction();

    try {

        $group = AppGroup::query()->find($par["id"]);

        $permissions = collect($request->permissions)
            ->map(function ($permissions, $menu_id) use ($module_id, $user) {

                return collect($permissions)
                    ->map(function ($permission) use ($module_id, $menu_id, $user) {

                        return [
                            "module_id" => $module_id,
                            "menu_id" => $menu_id,
                            "permission" => $permission,
                            "created_by" => $user->id
                        ];
                    })
                    ->toArray();
            })
            ->flatten(1);

        $group->accessMenus()
            ->where("module_id", $module_id)
            ->delete();

        $group->accessMenus()
            ->createMany($permissions);

        DB::commit();
        Cache::forget("app_group_access_menus-{$group->id}");

        echo "<script>alert('Grup Akses berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Grup Akses gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}
