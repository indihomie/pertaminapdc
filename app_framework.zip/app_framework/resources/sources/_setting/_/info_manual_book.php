<?php
global $access, $par, $_submit;

use App\Models\AppManualBook;
use App\View\Components\Form;
use App\View\Components\Layout;

switch ($par["mode"]) {

    default:
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

}

function form()
{
    global $access, $par;

    $manual_book = AppManualBook::find(1);

    echo getValidation();

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: 1.25rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <legend class="px-2">Manual Book</legend>

                <?php Form::inputLabelText("Name", "name", $manual_book->name, true, "l-input-small", "vsmallinput"); ?>
                <?php Form::inputLabelText("Deskripsi", "description", $manual_book->description, true); ?>
                <?php Form::inputLabelDocument("Manual Book", "document", $manual_book->path_document, false, "l-input-small", ".docx"); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function update()
{
    global $par, $user, $request;

    $parameter = getPar($par, "mode");

    $storage = Storage::disk("public");

    DB::beginTransaction();

    try {

        $update = AppManualBook::find(1);

        $update->update([
            "name" => $request->name,
            "description" => $request->description,
            "updated_by" => $user->id,
        ]);

        if ($request->file("document") || $request->document_delete) {

            if ($storage->exists($update->path_document)) {
                $storage->delete($update->path_document);
            }

            $update->update([
                "path_document" => ""
            ]);
        }

        if ($request->file("document")) {
            $update->update([
                "path_document" => $request->file("document")->store(AppManualBook::$path_document, ["disk" => "public"])
            ]);
        }

        DB::commit();
        echo "<script>alert('Buku Manual berhasil diubah')</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Buku Manual gagal diubah')</script>";
    }

    echo "<script>window.location='?{$parameter}'</script>";
}
