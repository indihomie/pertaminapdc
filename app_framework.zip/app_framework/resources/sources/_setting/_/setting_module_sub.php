<?php
global $access, $par, $_submit;

use App\Models\AppMenu;
use App\Models\AppModuleSub;
use App\View\Components\Form;
use App\View\Components\Layout;


switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;


    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add`, 500, 280);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="30">Ikon</th>
                <th width="*">Nama</th>
                <th width="20">Urut</th>
                <th width="50">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(6, [2, 6]); ?>

    <?php
}

function form()
{
    global $access, $par, $module_id;

    $statuses = config("paramter.status_label");

    $module_sub = AppModuleSub::query()->find($par["id"]);

    $order = $module_sub->order ?? AppModuleSub::query()->select("order")->where("module_id", $module_id)->orderBy("order", "desc")->first()->order + 1;

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit radius2" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset>

                <?php Form::inputLabelText("Nama", "name", $module_sub->name, true); ?>
                <?php Form::inputLabelDocument("Ikon", "icon", $module_sub->path_icon, false, "l-input-small", ".png", false); ?>
                <?php Form::inputLabelNumber("Urut", "order", $order); ?>
                <?php Form::inputLabelRadio("Status", "status", $statuses, $module_sub->status ?? 1); ?>

            </fieldset>

        </form>

    </div>
    <?php
}

function datas()
{
    global $access, $par, $module_id;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode");
    $number = $iDisplayStart;

    $arr_order = [
        "order",
        "icon",
        "name",
        "order",
        "status",
    ];

    $module_subs = AppModuleSub::query()
        ->where("module_id", $module_id)
        ->when($search, function ($query, $search) {
            $query->where("name", "like", "%{$search}%");
        });
    $count = clone $module_subs;

    $module_subs->orderBy($arr_order[$iSortCol_0], $sSortDir_0);

    if ($iDisplayLength > 0) {
        $module_subs->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $module_subs
        ->withCount("menus")
        ->get()
        ->map(function ($module_sub) use (&$number, $access, $par, $parameter) {

            $number++;

            $image_viewer = $module_sub->path_icon ? openView($module_sub->path_icon) : "-";

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$module_sub->id}`, 500, 280);'></a>";
            }
            if ($access["delete"]) {
                if ($module_sub->menus_count == 0) {
                    $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus Sub Modul ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$module_sub->id}`, 50, 50, false) : ``'></a>";
                } else {
                    $control .= "<a title='Hapus Data' class='delete' onclick='alert(`Menu lebih dari 1 data`)'></a>";
                }
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$image_viewer}</div>",
                "<div align='left'>{$module_sub->name}</div>",
                "<div align='right'>{$module_sub->order}</div>",
                "<div align='center'>{$module_sub->status_image}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $request, $user, $module_id;

    DB::beginTransaction();

    try {

        AppModuleSub::create([
            "module_id" => $module_id,
            "name" => $request->name ?? "",
            "path_icon" => $request->file("icon") ? $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"]) : "",
            "order" => $request->order,
            "status" => $request->status,
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();
        Cache::forget("app_module_sub-{$module_id}");

        echo "<script>alert('Sub Modul berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Sub Modul gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $request, $user, $par, $module_id;

    DB::beginTransaction();

    try {

        $update = AppModuleSub::query()->find($par["id"]);

        $update->update([
            "name" => $request->name,
            "order" => $request->order,
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        if ($request->file("icon") || $request->icon_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($update->path_icon) && strpos($update->path_icon, "_") !== false) {
                $storage->delete($update->path_icon);
            }

            $update->update([
                "path_icon" => ""
            ]);
        }

        if ($request->file("icon")) {
            $update->update([
                "path_icon" => $request->file("icon")->store(AppMenu::$path_icon, ["disk" => "public"])
            ]);
        }

        DB::commit();
        Cache::forget("app_module_sub-{$module_id}");

        echo "<script>alert('Sub Modul berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Sub Modul gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par, $module_id;

    DB::beginTransaction();

    try {

        $delete = AppModuleSub::query()->find($par["id"]);

        $storage = Storage::disk("public");

        if ($storage->exists($delete->path_icon) && strpos($delete->path_icon, "_") !== false) {
            $storage->delete($delete->path_icon);
        }

        $delete->delete();

        DB::commit();
        Cache::forget("app_module_sub-{$module_id}");

        echo "<script>alert('Sub Modul berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Sub Modul gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}
