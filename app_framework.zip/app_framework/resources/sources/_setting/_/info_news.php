<?php
global $access, $par, $_submit;

use App\Models\AppInformationNews;
use App\View\Components\Form;
use App\View\Components\Layout;
use Illuminate\Support\Carbon;

switch ($par["mode"]) {

    case "datas":
        echo datas();
        break;

    case "add":
        if ($access["add"])
            $_submit ? store() : form();
        else
            echo "Tidak ada akses";
        break;

    case "edit":
        if ($access["edit"])
            $_submit ? update() : form();
        else
            echo "Tidak ada akses";
        break;

    case "delete":
        if ($access["delete"])
            destroy();
        else
            echo "Tidak ada akses";
        break;

    default:
        index();
        break;

}

function index()
{
    global $access, $par;

    $parameter = getPar($par, "mode, id");

    ?>

    <?php Layout::title(); ?>

    <div class="contentwrapper">

        <form action="" class="stdform">

            <div class="filter_container">
                <div class="filter_left">

                    <input type="text" id="search">

                </div>
                <div class="filter_right">

                    <?php if ($access["add"]) : ?>
                        <a class="stdbtn"
                           href="#"
                           onclick="openBox(`popup?<?= $parameter ?>&par[mode]=add`, 800, 500);"
                        ><i class="fa fa-plus"></i> TAMBAH</a>
                    <?php endif; ?>

                </div>
            </div>

        </form>

        <table id="table" class="stdtable stdtablequick">
            <thead>
            <tr>
                <th width="20">#</th>
                <th width="120">Waktu</th>
                <th width="*">Judul</th>
                <th width="150">Sumber</th>
                <th width="120">Diubah Oleh</th>
                <th width="120">Diubah Waktu</th>
                <th width="20">Status</th>
                <th width="50">Kontrol</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>

    </div>

    <?php datatable(8, [1, 7, 8]); ?>
    <?php
}

function form()
{
    global $access, $par;

    $statuses = config("paramter.status_label");

    $news = AppInformationNews::query()->find($par["id"]);

    if ($news) {
        $news->date = $news->datetime->format("Y-m-d");
        $news->time = $news->datetime->format("H:i");
    }

    echo getValidation();

    ?>
    <div class="contentpopup">

        <?php Layout::title(true); ?>

        <form method="post" action="?<?= getPar($par) ?>&_submit=1"
              id="form"
              class="stdform"
              name="form"
              onsubmit="return validation(document.form) ? toggleLoader() : false;"
              autocomplete="off"
              enctype="multipart/form-data">

            <input type="hidden" name="_token" value="<?= csrf_token() ?>">

            <?php if ($access["add"] || $access["edit"]) : ?>
                <div style="position: absolute; top: 1rem; right: .3rem;">
                    <input type="submit" class="submit" value="Simpan"/>
                </div>
            <?php endif; ?>

            <fieldset class="rounded">

                <?php Form::inputLabelDateTimePicker("Waktu", "date", "time", $news->date, $news->time, true, "l-input-small"); ?>
                <?php Form::inputLabelText("Judul", "title", $news->title, true); ?>
                <?php Form::inputLabelText("Sumber", "source", $news->source, false); ?>
                <?php Form::inputLabelDocument("Banner", "image", $news->path_image, false, "l-input-small", ".png, .jpg, .jpeg", false); ?>
                <?php Form::inputLabelRadio("Status", "status", $statuses, $news->status ?? 1); ?>

            </fieldset>

            <div class="my-2"></div>

            <textarea name="content"
                      id="editor_news" class="box-border border border border-solid border-gray-300"><?= $news->content ?></textarea>

        </form>

    </div>
    <script>

        const editor_news = document.getElementById('editor_news')

        CKEDITOR.replace(editor_news)

    </script>
    <?php
}

function datas()
{
    global $access, $par;
    global $iDisplayStart, $iDisplayLength, $iSortCol_0, $sSortDir_0, $search;

    $parameter = getPar($par, "mode, id");

    $arr_order = [
        "datetime",
        "datetime",
        "title",
        "source",
        "updated_by",
        "updated_at",
    ];

    $newss = AppInformationNews::query()
        ->when($search, function ($query, $search) {
            $query->where("title", "like", "%{$search}%");
        });
    $count = clone $newss;

    $newss->orderBy($arr_order[$iSortCol_0], $iSortCol_0 > 0 ? $sSortDir_0 : "desc");

    if ($iDisplayLength > 0) {
        $newss->limit($iDisplayLength)->offset($iDisplayStart);
    }

    $datas = $newss
        ->get()
        ->map(function ($news, $key) use ($iDisplayStart, $access, $par, $parameter) {

            $number = $iDisplayStart + $key + 1;

            $control = "";

            if ($access["edit"]) {
                $control .= "<a title='Ubah Data' class='edit' href='#Edit' onclick='openBox(`popup?{$parameter}&par[mode]=edit&par[id]={$news->id}`, 800, 500);'></a>";
            }
            if ($access["delete"]) {
                $control .= "<a title='Hapus Data' class='delete' onclick='return confirm(`Konfirmasi hapus berita ini?`) ? openBox(`void?{$parameter}&par[mode]=delete&par[id]={$news->id}`, 50, 50, false) : ``'></a>";
            }

            return [
                "<div align='center'>{$number}.</div>",
                "<div align='center'>{$news->datetime->format("d m Y H:i")}</div>",
                "<div align='left'>{$news->title}</div>",
                "<div align='left'>{$news->source}</div>",
                "<div align='left'>{$news->updatedBy->name}</div>",
                "<div align='center'>{$news->updated_at->format("d m Y H:i")}</div>",
                "<div align='center'>{$news->status_image}</div>",
                "<div align='center'>{$control}</div>",
            ];
        });

    return json_encode([
        "iTotalDisplayRecords" => $count->count(),
        "iTotalRecords" => $datas->count(),
        "aaData" => $datas
    ]);
}

function store()
{
    global $user, $request, $par;

    $parameter = getPar($par);

    $validator = Validator::make($request->all(), [
        "date" => "required|date_format:d/m/Y",
        "time" => "required|date_format:H:i",
        "title" => "required|string",
        "source" => "sometimes",
        "image" => "sometimes|mimes:png,jpg,jpeg|max:1024",
        "content" => "sometimes",
        "status" => "required|bool",
    ]);

    if ($validator->fails()) {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?{$parameter}'</script>";
        return;
    }

    DB::beginTransaction();

    try {

        AppInformationNews::create([
            "datetime" => Carbon::createFromFormat("d/m/Y H:i", "{$request->date} {$request->time}")->format("Y-m-d H:i:s"),
            "title" => $request->title,
            "source" => $request->source ?? "",
            "content" => $request->content ?? "",
            "path_image" => $request->file("image") ? $request->file("image")->store(AppInformationNews::$path_image, ["disk" => "public"]) : "",
            "status" => $request->status,
            "created_by" => $user->id,
            "updated_by" => $user->id,
        ]);

        DB::commit();

        echo "<script>alert('Berita berhasil disimpan')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Berita gagal disimpan')</script>";
    }

    echo "<script>closeBox()</script>";
}

function update()
{
    global $par, $user, $request;

    $parameter = getPar($par);

    $validator = Validator::make($request->all(), [
        "date" => "required|date_format:d/m/Y",
        "time" => "required|date_format:H:i",
    ]);

    if ($validator->fails()) {
        session()->flashInput($request->except(["_token", "par"]));
        session()->flash("errors", $validator->errors()->toArray());
        echo "<script>window.location='?{$parameter}'</script>";
        return;
    }

    DB::beginTransaction();

    try {

        $update = AppInformationNews::find($par["id"]);

        $update->update([
            "datetime" => Carbon::createFromFormat("d/m/Y H:i", "{$request->date} {$request->time}")->format("Y-m-d H:i:s"),
            "title" => $request->title,
            "source" => $request->source ?? "",
            "content" => $request->content ?? "",
            "status" => $request->status,
            "updated_by" => $user->id,
        ]);

        if ($request->file("image") || $request->image_delete) {

            $storage = Storage::disk("public");

            if ($storage->exists($update->path_image)) {
                $storage->delete($update->path_image);
            }

            $update->update([
                "path_image" => ""
            ]);
        }

        if ($request->file("image")) {
            $update->update([
                "path_image" => $request->file("image")->store(AppInformationNews::$path_image, ["disk" => "public"])
            ]);
        }

        DB::commit();

        echo "<script>alert('Berita berhasil diubah')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Berita gagal diubah')</script>";
    }

    echo "<script>closeBox()</script>";
}

function destroy()
{
    global $par;

    DB::beginTransaction();

    try {

        $delete = AppInformationNews::find($par["id"]);

        $delete->delete();

        DB::commit();

        echo "<script>alert('Berita berhasil dihapus')</script>";
        echo "<script>parent.jQuery('#table').dataTable().fnReloadAjax()</script>";

    } catch (Exception $e) {

        DB::rollBack();
        Log::error($e);

        echo "<script>alert('Berita gagal dihapus')</script>";
    }

    echo "<script>parent.closeBox()</script>";
}
