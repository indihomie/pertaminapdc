<!DOCTYPE html>
<html lang="{{ str_replace("_", "-", app()->getLocale()) }}">
<head>

    <meta charset="utf-8">
    <title>{{ __("Document") }}</title>

    <style>
        * {
            margin: 0;
            padding: 0;
        }

        #doc {
            position: absolute;
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>

</head>
<body>
<iframe id="doc" src="https://view.officeapps.live.com/op/embed.aspx?src={{ $url }}"></iframe>
</body>
</html>
