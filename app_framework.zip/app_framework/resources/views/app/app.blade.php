<!DOCTYPE html>
<html lang="{{ str_replace("_", "-", app()->getLocale()) }}">
<head>

    <meta charset="utf-8">

    <title>@stack("title", config("app.name", "Laravel"))</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="shortcut icon" href="{{ asset("assets/info/icon.png") . "?" . config("environments.APP_VERSION") }}"/>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
    <!-- End Fonts -->

    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset("assets/css/style.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/global/plugins.bundle.css") . "?" . config("environments.APP_VERSION") }}">

    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/datatables/datatables.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/flatpickr/flatpickr.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/dragsort/dragsort.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/global/plugins-custom.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <livewire:styles/>
    @include("app.style")
    <!-- End Styles -->

    <!-- Scripts -->
    <script src="{{ asset("assets/plugins/global/plugins.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/js/scripts.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>

    <script src="{{ asset("assets/plugins/custom/datatables/datatables.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/flatpickr/flatpickr.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/typedjs/typedjs.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/dragsort/dragsort.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/ckeditor/ckeditor.js") . "?" . config("environments.APP_VERSION") }}"></script>

    <!-- Temporary for test library -->
    {{--    <script src="{{ asset("assets/js/custom/widgets.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-1.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-2.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-3.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-4.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-5.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-6.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-7.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-8.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-9.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-10.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-11.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-12.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-13.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-14.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-15.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-16.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-17.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/charts/widget-18.js") }}"></script>--}}

    {{--    <script src="{{ asset("assets/js/custom/documentation/cards/widget-1.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/cards/widget-4.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/cards/widget-6.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/cards/widget-8.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/cards/widget-9.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/cards/widget-10.js") }}"></script>--}}
    {{--    <script src="{{ asset("assets/js/custom/documentation/forms/nouislider.js") }}"></script>--}}

    {{--    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/map.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/geodata/worldLow.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/geodata/continentsLow.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/geodata/usaLow.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/geodata/worldTimeZonesLow.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/geodata/worldTimeZoneAreasLow.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/percent.js"></script>--}}
    {{--    <script src="https://cdn.amcharts.com/lib/5/radar.js"></script>--}}
    <!-- End Temporary for test library -->

    <livewire:scripts/>
    <!-- End Scripts -->

    @stack("style")

</head>
<body id="kt_body"
      class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed @stack("body-class") scroll-y overlay overlay-block overlay-hidden"
      style="--kt-toolbar-height: 48px; --kt-toolbar-height-tablet-and-mobile: 48px; @stack("body-style")">

@yield("body")

@stack("livewire")
@stack("modals")

<div id="modal_viewer"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header py-3 border-bottom-0">
                <h3 class="modal-title">
                    <div id="modal_viewer_title"></div>
                    <div class="w-30px border border-bottom border-primary"></div>
                </h3>
                <div class="d-flex">
                    <a id="modal_viewer_download"
                       class="btn btn-sm btn-light"
                       href=""
                       target="_blank">
                        {{ __("Unduh") }}
                    </a>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>
            </div>

            <iframe id="modal_viewer_frame"
                    src=""
                    class="modal-body p-0 w-100"
                    style="height: 80vh; margin: 0"></iframe>

        </div>
    </div>
</div>

<div id="kt_scrolltop"
     class="scrolltop"
     data-kt-scrolltop="true">
    <span class="svg-icon">
        {!! asset_svg("assets/media/icons/duotune/arrows/arr081.svg") !!}
    </span>
</div>

<div class="overlay-layer bg-light bg-opacity-75 rounded"
     style="z-index: 200">
    <div class="spinner-border text-primary" role="status"></div>
</div>

@stack("script")
@include("app.script")
</body>
</html>
