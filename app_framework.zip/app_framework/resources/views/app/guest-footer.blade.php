<div class="d-flex flex-center flex-column-auto p-10">
    <div class="d-flex flex-center fw-bold fs-6">
        <a class="text-muted text-hover-primary px-2"
           href="{{ url("/#about-us") }}"
           target="_blank">{{ __("Tentang") }}</a>
        <a class="text-muted text-hover-primary px-2"
           href="{{ url("/help") }}"
           target="_blank">{{ __("Bantuan") }}</a>
    </div>
</div>
