<!DOCTYPE html>
<html lang="{{ str_replace("_", "-", app()->getLocale()) }}">
<head>

    <meta charset="utf-8">

    <title>@stack("title", config("app.name", "Laravel"))</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="shortcut icon" href="{{ asset("assets/info/icon.png") . "?" . config("environments.APP_VERSION") }}"/>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
    <!-- End Fonts -->

    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset("assets/css/style.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/global/plugins.bundle.css") . "?" . config("environments.APP_VERSION") }}">

    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/datatables/datatables.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/flatpickr/flatpickr.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <link rel="stylesheet" href="{{ asset("assets/plugins/global/plugins-custom.bundle.css") . "?" . config("environments.APP_VERSION") }}">
    <livewire:styles/>
    @include("app.style")
    <!-- End Styles -->

    <!-- Scripts -->
    <script src="{{ asset("assets/plugins/global/plugins.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/js/scripts.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>

    <script src="{{ asset("assets/plugins/custom/alpinejs/alpinejs.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/datatables/datatables.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/tiny-slider/tiny-slider.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/flatpickr/flatpickr.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/spotlightjs/spotlightjs.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/fullcalendar/fullcalendar.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>
    <script src="{{ asset("assets/plugins/custom/typedjs/typedjs.bundle.js") . "?" . config("environments.APP_VERSION") }}"></script>

    <livewire:scripts/>
    <!-- End Scripts -->

    @yield("style")

</head>
<body id="kt_body"
      class="blockui @stack("body-class")">

<div class="d-flex flex-column flex-root">
    <div class="page d-flex flex-row flex-column-fluid">

        @yield("body")

    </div>

</div>

@yield("modals")

<div id="kt_scrolltop"
     class="scrolltop"
     data-kt-scrolltop="true">
    <span class="svg-icon">
        {!! asset_svg("assets/media/icons/duotone/Navigation/Up-2.svg") !!}
    </span>
</div>

<div class="blockui-overlay rounded bg-light bg-opacity-50 d-none"
     wire:loading.class.remove="d-none">
    <span class="spinner-border text-primary"></span>
</div>

@stack("script")
@include("app.script")
</body>
</html>
