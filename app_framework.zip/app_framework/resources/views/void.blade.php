<?php

include resource_path("sources/global.php");
include resource_path("sources/void.php");
