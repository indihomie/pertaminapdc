@extends("app.app")

@push("title", "Beranda - {$app_information->company}")

@section("body")
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div id="kt_wrapper"
                 class="wrapper d-flex flex-column flex-row-fluid">

                <div id="kt_header"
                     class="header align-items-stretch">
                    <div class="container-fluid d-flex align-items-stretch justify-content-between">

                        <div class="d-none d-lg-flex align-items-center">
                            <a href="{{ url("/") }}">
                                <img alt="Logo"
                                     src="{{ asset("assets/info/logo.png") }}"
                                     class="h-35px"
                                     loading="lazy"/>
                            </a>
                        </div>

                        <div class="d-none d-lg-flex mx-6 align-items-center">
                            <div class="h-40px border border-dashed border-start"></div>
                        </div>

                        <div class="d-flex d-lg-none align-items-center flex-grow-0 me-4">
                            <a href="{{ url("/") }}">
                                <img alt="Logo"
                                     src="{{ asset("assets/info/icon.png") }}"
                                     class="h-35px"
                                     loading="lazy"/>
                            </a>
                        </div>

                        <div class="d-flex align-items-stretch justify-content-between flex-grow-1">

                            <div
                                class="d-flex flex-column justify-content-center">
                                <h1 class="text-dark fw-bolder fs-3 mb-0">{{ $app_information->name }}</h1>
                                <div class="text-muted">{{ $app_information->company }}</div>
                            </div>

                            <div id="kt_header_nav"
                                 class="d-flex align-items-stretch flex-shrink-0">

                                <div class="d-flex align-items-center"
                                     title="{{ __("Notifikasi") }}"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
                                         data-bs-toggle="modal"
                                         data-bs-target="#modal_notification">
                                        <span class="svg-icon svg-icon-1">
                                            {!! asset_svg("assets/media/icons/duotune/general/gen007.svg") !!}
                                        </span>
                                    </div>
                                </div>

                                <div class="mx-2"></div>

                                <div id="kt_header_user_menu_toggle"
                                     class="d-flex align-items-center"
                                     title="{{ __("Profil") }}"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div class="cursor-pointer symbol symbol-30px symbol-md-40px"
                                         data-kt-menu-trigger="click"
                                         data-kt-menu-attach="parent"
                                         data-kt-menu-placement="bottom-end">
                                        <img alt="user"
                                             src="{{ asset($user?->path_photo ? "storage/{$user->path_photo}" : "assets/media/avatars/blank.png") }}"
                                             loading="lazy"/>
                                    </div>
                                    <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-325px"
                                         data-kt-menu="true">

                                        <div class="menu-item px-3">
                                            <div class="menu-content d-flex align-items-center px-3">
                                                <div class="symbol symbol-50px me-5">
                                                    <img alt="Logo"
                                                         src="{{ asset($user->path_photo ? "storage/{$user->path_photo}" : "assets/media/avatars/blank.png") }}"
                                                         loading="lazy"/>
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <div class="fw-bolder fs-5">{{ $user->name }}</div>
                                                    <div class="fw-bolder fs-8">{{ $user->roles->first()?->name ?? "-" }}</div>
                                                    <a href="#" class="fw-bold text-muted text-hover-primary fs-7">{{ $user->email }}</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="separator my-2"></div>
                                        <div class="menu-item px-5">
                                            <a href="#"
                                               class="menu-link px-5"
                                               data-bs-toggle="modal"
                                               data-bs-target="#modal_profile">{{ __("Profil Saya") }}</a>
                                        </div>
                                        <div class="menu-item px-5">
                                            <a href="#"
                                               class="menu-link px-5 button-ajax"
                                               data-action="{{ route("logout") }}"
                                               data-method="post"
                                               data-csrf="{{ csrf_token() }}"
                                               data-reload="true">{{ __("Keluar Aplikasi") }}</a>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>

                <div id="kt_content"
                     class="content py-lg-3 d-flex flex-column flex-column-fluid">

                    <div id="kt_toolbar"
                         class="toolbar">

                        <div id="kt_toolbar_container"
                             class="container-fluid d-flex flex-stack">

                            <div class="d-block d-lg-none"></div>

                            <div class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                 data-kt-swapper="true"
                                 data-kt-swapper-mode="prepend"
                                 data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}">
                                <div id="typed_content"
                                     class="d-none">
                                    <div>
                                        <b>{{ __("Selamat ") . with(now()->format("H"), fn($h) => $h < 11 ? "Pagi" : ($h < 14 ? "Siang" : ($h < 16 ? "Sore" : "Malam"))) }}</b>&nbsp; {{ $user->name }}.
                                    </div>
                                </div>
                                <div id="typed_welcome"
                                     class="d-flex align-items-center fs-7 my-1"
                                     data-controls="typed"
                                     data-reference="#typed_content"></div>
                            </div>

                            <div class="d-flex align-items-center">
                                <div class="clock-tick d-none d-lg-block fs-7 text-center user-select-none font-monospace">
                                    {{ now()->locale("id")->translatedFormat("l, d F Y H:i:s") }}
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="container-fluid px-lg-3">
                        <div class="row g-6">
                            <div class="col-xl-8 order-1 order-lg-2">

                                <div class="card d-none d-lg-block">
                                    <div class="card-body p-4">

                                        <div class="d-flex flex-wrap flex-sm-nowrap">
                                            <div class="me-7">
                                                <div class="symbol symbol-125px symbol-fixed position-relative bg-gray-300">
                                                    <img alt="image"
                                                         class="viewer cursor-pointer"
                                                         src="{{ asset($user->path_photo ? "storage/{$user->path_photo}" : "assets/media/avatars/blank.png") }}"
                                                         href="{{ asset("storage/{$user->path_photo}") }}"
                                                         data-ext="image"
                                                         data-title="{{ $user->name }}"
                                                         loading="lazy">
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">

                                                <div class="d-flex justify-content-between align-items-start flex-wrap mb-1">
                                                    <div class="d-flex align-items-center mb-2">
                                                        <a href="#" class="text-gray-900 text-hover-primary fs-2 fw-bolder me-1">
                                                            {{ $user->name }}
                                                        </a>
                                                        <a href="#"
                                                           title="{{ __($user->email_verified_at ? "Email sudah diverifikasi" : "Email belum diverifikasi") }}"
                                                           data-bs-toggle="tooltip"
                                                           data-bs-placement="top">
                                                            <span class="svg-icon svg-icon-1 {{ $user->email_verified_at ? "svg-icon-primary" : "svg-icon-gray-300" }}">
                                                                {!! asset_svg("assets/media/icons/duotune/general/gen026.svg") !!}
                                                            </span>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col">

                                                        <div class="fw-bolder text-gray-800">{{ __("Grup User") }}</div>
                                                        <div class="text-gray-800">{{ $user->roles->first()?->name ?? "-" }}</div>

                                                        <div class="my-2"></div>

                                                        <div class="fw-bolder text-gray-800">{{ __("Bergabung") }}</div>
                                                        <div class="text-gray-800">{{ $user->created_at->format("d F Y") }}</div>

                                                    </div>
                                                    <div class="col">

                                                        <div class="fw-bolder text-gray-800">{{ __("Telepon") }}</div>
                                                        <div class="text-gray-800">{{ $user->group->phone ?? "-" }}</div>

                                                        <div class="my-2"></div>

                                                        <div class="fw-bolder text-gray-800">{{ __("Email") }}</div>
                                                        <div class="text-gray-800">{{ $user->email ?? "-" }}</div>

                                                    </div>
                                                    <div class="col">

                                                        <div class="fw-bolder text-gray-800">{{ __("Login Terakhir") }}</div>
                                                        <div class="text-gray-800">{{ $user->login_at->format("d F Y H:i") }}</div>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @can("home")
                                    {{ __("Akses Home akan terlihat apabila user memiliki akses ke modul Home.") }}
                                @endcan

                                @foreach($app_module_categories->sortByDesc("order") as $category)
                                    <div class="mt-6 mb-4">
                                        <h2 class="fs-3 fw-bold">
                                            {{ $category->name }}
                                            <div class="w-30px border border-bottom border-primary"></div>
                                        </h2>
                                    </div>
                                    <div class="row row-cols-auto g-0">
                                        @foreach($app_modules[$category->id]->sortBy("order") as $module)
                                            <a class="col w-100px h-100px p-4 d-flex flex-column align-items-center justify-content-center me-4 mb-4 rounded-2 shadow-xs bg-white hoverable user-select-none"
                                               href="{{ url($module->type == \App\Models\AppModule::TYPE_MODULE ? $module->path : $module->link) }}">
                                                <div class="bgi-no-repeat bgi-size-cover w-40px h-40px mb-2"
                                                     style="background-image: url('{{ asset("storage/" . ($module->path_icon ?: "_/module/_blank.png")) }}')"></div>
                                                <div class="h-35px d-flex align-items-center justify-content-center text-gray-700 fw-bold fs-8 lh-1">
                                                    <div class="text-center">{{ $module->name }}</div>
                                                </div>
                                            </a>
                                        @endforeach
                                    </div>
                                @endforeach

                            </div>
                            <div class="col-xl-3 order-3 order-lg-1">

                                <a href="#"
                                   id="drawer_manual_book_toggle"
                                   class="card bg-primary bgi-no-repeat hoverable mb-4"
                                   style="
                                       background-position: right top;
                                       background-size: 20% auto;
                                       background-image: url('{{ asset("assets/media/svg/shapes/abstract-3.svg") }}')
                                       "
                                   onclick="Livewire.emit('selectManualApp')">

                                    <div class="card-body p-4">
                                        <div class="text-white fw-bolder fs-2 mb-2">
                                            {{ __("Buku Manual") }}
                                        </div>
                                        <div class="fw-bold text-white">
                                            {{ $app_manual->name }}
                                        </div>
                                        <div class="fs-7 text-white mb-2">
                                            {{ $app_manual->updated_at->format("d F Y") }} - {{ $app_manual->updatedBy->name }}
                                        </div>
                                        <div class="text-white">
                                            {{ $app_manual->description ?: "Tidak ada deskripsi" }}
                                        </div>
                                    </div>
                                </a>

                                <div class="card bgi-no-repeat mb-4"
                                     style="
                                         background-position: right top;
                                         background-size: 35% auto;
                                         background-image: url('{{ asset("assets/media/svg/shapes/abstract-1.svg") }}')
                                         ">
                                    <div class="card-body p-4">

                                        <div id="carousel_announcement"
                                             class="min-h-150px carousel carousel-custom slide"
                                             data-bs-ride="carousel"
                                             data-bs-interval="8000">
                                            <div class="d-flex align-items-center flex-wrap">
                                                <span class="fs-4 fw-bolder">
                                                    {{ __("Pengumuman") }}
                                                    <div class="w-30px border border-bottom border-primary"></div>
                                                </span>
                                                <div class="flex-equal"></div>
                                                <ol class="p-0 m-0 carousel-indicators carousel-indicators-dots">
                                                    @foreach($app_announcements as $announcement)
                                                        <li class="ms-1 {{ $loop->first ? "active" : "" }}"
                                                            data-bs-target="#carousel_announcement"
                                                            data-bs-slide-to="{{ $loop->index }}"></li>
                                                    @endforeach
                                                </ol>
                                            </div>
                                            <div class="carousel-inner pt-4">
                                                @foreach($app_announcements as $announcement)
                                                    <div class="carousel-item {{ $loop->first ? "active" : "" }}">
                                                        <a class="card-title fw-bolder text-muted text-hover-primary fs-4"
                                                           href="#"
                                                           onclick="Livewire.emit('announcementSelect', {{ $announcement->id }})"
                                                           data-bs-toggle="modal"
                                                           data-bs-target="#modal_announcement">
                                                            {{ $announcement->name }}
                                                        </a>
                                                        <div class="fs-7 text-primary mb-4">
                                                            {{ $announcement->updated_at->format("d F Y H:i") }} - {{ $announcement->updatedBy->name }}
                                                        </div>
                                                        <p class="text-dark-75 fw-bold fs-7 m-0">
                                                            {!! $announcement->content !!}
                                                        </p>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>

                                        <div class="my-3"></div>

                                        <a class="w-100 btn btn-sm btn-light-primary"
                                           href="#"
                                           data-bs-toggle="modal"
                                           data-bs-target="#modal_announcement"
                                           onclick="Livewire.emit('announcementMore')">{{ __("Selengkapnya") }}</a>

                                    </div>
                                </div>

                                <div class="card bgi-no-repeat"
                                     style="
                                         background-position: right top;
                                         background-size: 35% auto;
                                         background-image: url('{{ asset("assets/media/svg/shapes/abstract-2.svg") }}')
                                         ">
                                    <div class="card-body p-4">

                                        <div id="carousel_news"
                                             class="min-h-150px carousel carousel-custom slide"
                                             data-bs-ride="carousel"
                                             data-bs-interval="8000">
                                            <div class="d-flex align-items-center flex-wrap">
                                                <span class="fs-4 fw-bolder">
                                                    {{ __("Berita") }}
                                                    <div class="w-30px border border-bottom border-primary"></div>
                                                </span>
                                                <div class="flex-equal"></div>
                                                <ol class="p-0 m-0 carousel-indicators carousel-indicators-dots">
                                                    @foreach($app_news as $news)
                                                        <li class="ms-1 {{ $loop->first ? "active" : "" }}"
                                                            data-bs-target="#carousel_news"
                                                            data-bs-slide-to="{{ $loop->index }}"></li>
                                                    @endforeach
                                                </ol>
                                            </div>
                                            <div class="carousel-inner pt-4">
                                                @foreach($app_news as $news)
                                                    <div class="carousel-item {{ $loop->first ? "active" : "" }}">
                                                        <a class="card-title fw-bolder text-muted text-hover-primary fs-4"
                                                           href="#"
                                                           onclick="Livewire.emit('newsSelect', {{ $news->id }})"
                                                           data-bs-toggle="modal"
                                                           data-bs-target="#modal_news">
                                                            {{ $news->name }}
                                                        </a>
                                                        <div class="fs-7 text-primary mb-4">
                                                            {{ $news->updated_at->format("d F Y H:i") }} - {{ $news->updatedBy->name }}
                                                        </div>
                                                        <p class="text-dark-75 fw-bold fs-7 m-0">
                                                            {!! $news->content !!}
                                                        </p>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>

                                        <div class="my-3"></div>

                                        <a class="w-100 btn btn-sm btn-light-primary"
                                           href="#"
                                           data-bs-toggle="modal"
                                           data-bs-target="#modal_news"
                                           onclick="Livewire.emit('newsMore')">{{ __("Selengkapnya") }}</a>

                                    </div>
                                </div>

                            </div>
                            <div class="col-xl-3 order-2 order-lg-3">

                                <div class="card">
                                    <div class="card-body p-4">

                                        <div class="d-flex flex-row align-items-center justify-content-between">
                                            <div class="fs-4 fw-bolder ms-4">
                                                {{ __("Notifikasi") }}
                                                <div class="w-30px border border-bottom border-primary"></div>
                                            </div>
                                            <a class="btn btn-sm btn-link me-4"
                                               href="#"
                                               data-bs-toggle="modal"
                                               data-bs-target="#modal_notification">{{ __("Selengkapnya") }}</a>
                                        </div>

                                        <div class="my-4"></div>

                                        @foreach($notifications as $notification)
                                            <a href="#"
                                               class="d-block p-4 rounded bg-hover-light-primary cursor-pointer"
                                               onclick="Livewire.emit('notificationSelect', {{ $notification->id }})"
                                               data-bs-toggle="modal"
                                               data-bs-target="#modal_notification">
                                                <div class="d-flex flex-row">
                                                    <div class="flex-row-fluid text-dark fw-bolder fs-7">{{ $notification->category }}</div>
                                                    <div class="d-flex align-items-center">
                                                        <div class="flex-none fs-9 text-muted">{{ $notification->created_at->diffForHumans() }}</div>
                                                        <div class="mx-1"></div>
                                                        <i class="fa fa-xs fa-circle {{ $notification->read ? "text-gray-300" : "text-success" }}"></i>
                                                    </div>
                                                </div>
                                                <div class="d-block fs-7 text-gray-500">{{ $notification->title }}</div>
                                            </a>
                                        @endforeach

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

                @include("app.app-footer")

            </div>

        </div>
    </div>
@endsection

@push("livewire")
    @livewire("app-profile", compact(["user", "user_role"]))
    @livewire("app-notification", compact("user"))
    @livewire("app-manual-book")
    @livewire("app-announcement")
    @livewire("app-news")
@endpush
