@extends("main")

@push("content-container-class", "py-xxl-0 py-xl-0 py-lg-0 py-0")
@push("content-class", "h-100 w-100 p-0")

@section("content")
    <iframe src="{{ $app_menu->target }}"
            frameborder="0"
            class="w-100 h-100"></iframe>
@endsection
