@extends("app.app")

@push("title", "{$app_module->name} - {$app_information->company}")

@push("body-class", "aside-enabled aside-fixed bg-white")

@section("body")
    <div class="d-flex flex-column flex-root">
        <div class="page d-flex flex-row flex-column-fluid">

            <div id="kt_aside"
                 class="aside aside-light aside-hoverable"
                 data-kt-drawer="true"
                 data-kt-drawer-name="aside"
                 data-kt-drawer-activate="{default: true, lg: false}"
                 data-kt-drawer-overlay="true"
                 data-kt-drawer-width="{default:'200px', '300px': '250px'}"
                 data-kt-drawer-direction="start"
                 data-kt-drawer-toggle="#kt_aside_mobile_toggle">

                <div id="kt_aside_logo"
                     class="aside-logo flex-column-auto">
                    <a href="{{ url("/home") }}">
                        <img alt="Logo"
                             src="{{ asset("assets/info/logo.png") }}"
                             class="h-35px logo"
                             loading="lazy"/>
                    </a>
                    <div id="kt_aside_toggle"
                         class="btn btn-icon w-auto px-0 btn-active-color-primary aside-toggle"
                         data-kt-toggle="true"
                         data-kt-toggle-state="active"
                         data-kt-toggle-target="body"
                         data-kt-toggle-name="aside-minimize">
                        <span class="svg-icon svg-icon-1 rotate-180">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr079.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="aside-menu flex-column-fluid">
                    <div id="kt_aside_menu_wrapper"
                         class="hover-scroll-overlay-y my-5 my-lg-5 user-select-none"
                         data-kt-scroll="true"
                         data-kt-scroll-activate="{default: false, lg: true}"
                         data-kt-scroll-height="auto"
                         data-kt-scroll-dependencies="#kt_aside_logo, #kt_aside_footer"
                         data-kt-scroll-wrappers="#kt_aside_menu"
                         data-kt-scroll-offset="0">

                        <div id="#kt_aside_menu"
                             class="menu menu-column menu-active-bg menu-title-gray-800 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-500"
                             data-kt-menu="true"
                             data-kt-menu-expand="false">
                            @foreach($app_module_sub->menus as $_menu)
                                @php
                                    if ($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_MASTER) {
                                        $target = "master";
                                    } else if ($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_LINK) {
                                        $target = "link";
                                    } else {
                                        $target = "";
                                    }
                                @endphp
                                <div
                                    class="menu-item {{ $_menu->target_type == \App\Models\AppMenu::MENU_TARGET_DROPDOWN ? "menu-accordion" : "" }} {{ $_menu->path == $request->segment(3) ? "here show" : "" }}"
                                    {{ $_menu->target_type == \App\Models\AppMenu::MENU_TARGET_DROPDOWN ? "data-kt-menu-trigger='click'" : "" }}>

                                    <a class="menu-link {{ $_menu->path == $request->segment(3) ? "active" : "" }}"
                                       href="{{ url("{$request->segment(1)}/{$request->segment(2)}/{$_menu->path}/_/{$target}") }}">
                                        <span class="menu-icon bgi-size-cover"
                                              style="
                                            width: 18px;
                                            height: 18px;
                                            background-image: url('{{ asset($_menu->path_icon ? "/storage/{$_menu->path_icon}" : "/storage/_/menu/_blank.png") }}');
                                            ">
                                        </span>
                                        <span class="menu-title">{{ $_menu->name }}</span>
                                        @if ($_menu->target_type == \App\Models\AppMenu::MENU_TARGET_DROPDOWN)
                                            <span class="menu-arrow"></span>
                                        @endif
                                    </a>

                                    @foreach($_menu->menuSubs as $_menu_sub)
                                        @php
                                            if ($_menu_sub->target_type == \App\Models\AppMenu::MENU_TARGET_MASTER) {
                                                $target = "master";
                                            } else if ($_menu_sub->target_type == \App\Models\AppMenu::MENU_TARGET_LINK) {
                                                $target = "link";
                                            } else {
                                                $target = "";
                                            }
                                        @endphp
                                        <div class="menu-sub menu-sub-accordion">
                                            <div class="menu-item">
                                                <a class="menu-link {{ $_menu_sub->path == $request->segment(4) ? "active" : "" }}"
                                                   href="{{ url("{$request->segment(1)}/{$request->segment(2)}/{$_menu->path}/{$_menu_sub->path}/{$target}") }}">
                                                    <span class="menu-bullet">
                                                        <span class="bullet bullet-dot"></span>
                                                    </span>
                                                    <span class="menu-title">{{ $_menu_sub->name }}</span>
                                                </a>
                                            </div>
                                        </div>
                                    @endforeach

                                </div>
                            @endforeach
                        </div>

                    </div>
                </div>

                <div id="kt_aside_footer"
                     class="aside-footer flex-column-auto p-3">
                    <a class="w-100 btn btn-custom btn-light"
                       href="#"
                       title="{{ __("Versi " . config("environment.APP_VERSION")) }}"
                       data-bs-toggle="tooltip"
                       data-bs-trigger="hover"
                       data-bs-dismiss-="click">
                        <span class="btn-label">{{ config("environment.APP_VERSION") }}</span>
                        <span class="svg-icon btn-icon svg-icon-2">
                            {!! asset_svg("assets/media/icons/duotune/general/gen005.svg") !!}
                        </span>
                    </a>
                </div>

            </div>

            <div id="kt_wrapper"
                 class="wrapper d-flex flex-column flex-row-fluid">

                <div id="kt_header"
                     class="header align-items-stretch">
                    <div class="container-fluid d-flex align-items-stretch justify-content-between">

                        <div class="d-flex align-items-center d-lg-none ms-n2 me-2"
                             title="Show aside menu">
                            <div id="kt_aside_mobile_toggle"
                                 class="btn btn-icon btn-active-light-primary w-30px h-30px w-md-40px h-md-40px">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/abstract/abs015.svg") !!}
                                </span>
                            </div>
                        </div>

                        <div class="d-none d-lg-none align-items-center flex-grow-0 me-4">
                            <a href="{{ url("/") }}">
                                <img alt="Logo"
                                     src="{{ asset("assets/info/icon.png") }}"
                                     class="h-30px"
                                     loading="lazy"/>
                            </a>
                        </div>

                        <div class="d-flex align-items-stretch justify-content-between flex-grow-1">

                            <div
                                class="d-flex flex-column justify-content-center">
                                <h1 class="text-dark fw-bolder fs-3 mb-0">{{ $app_module->category->name }}</h1>
                                <div class="text-muted">{{ $app_module->name }} - {{ $app_module_sub->name }}</div>
                            </div>

                            <div id="kt_header_nav"
                                 class="d-flex align-items-stretch flex-shrink-0">

                                <div class="d-lg-flex"
                                     data-kt-drawer="true"
                                     data-kt-drawer-name="header-menu"
                                     data-kt-drawer-activate="{default: true, lg: false}"
                                     data-kt-drawer-overlay="true"
                                     data-kt-drawer-width="{default:'200px', '300px': '250px'}"
                                     data-kt-drawer-direction="end"
                                     data-kt-drawer-toggle="#kt_header_menu_mobile_toggle"
                                     data-kt-swapper="true"
                                     data-kt-swapper-mode="prepend"
                                     data-kt-swapper-parent="{default: '#kt_body', lg: '#kt_header_nav'}">
                                    <div id="#kt_header_menu"
                                         class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch"
                                         data-kt-menu="true">
                                        @foreach($app_module->moduleSubs as $_module_sub)
                                            <a class="menu-item menu-lg-down-accordion me-lg-1 {{ $_module_sub->path == $request->segment(2) ? "here show" : "" }}"
                                               href="{{ url("{$app_module->path}/{$_module_sub->path}") }}">
                                                <span class="menu-link py-3">
                                                    <span class="menu-title">{{ $_module_sub->name }}</span>
                                                </span>
                                            </a>
                                        @endforeach
                                    </div>
                                </div>

                                <div class="mx-3 d-none d-lg-flex align-items-center">
                                    <div class="h-30px border-start border-gray-300"></div>
                                </div>

                                <div class="d-flex align-items-center"
                                     title="{{ __("Buku Manual") }}"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div id="drawer_manual_book_toggle"
                                         class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
                                         onclick="Livewire.emit('selectManual', {{ $app_module_sub->id }})">
                                        <span class="svg-icon svg-icon-1">
                                            {!! asset_svg("assets/media/icons/duotune/general/gen046.svg") !!}
                                        </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center"
                                     title="{{ __("Notifikasi") }}"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
                                         data-bs-toggle="modal"
                                         data-bs-target="#modal_notification">
                                        <span class="svg-icon svg-icon-1">
                                            {!! asset_svg("assets/media/icons/duotune/general/gen007.svg") !!}
                                        </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center"
                                     title="{{ __("Beranda") }}"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <a class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
                                       href="{{ url("/home") }}">
                                        <span class="svg-icon svg-icon-1">
                                            {!! asset_svg("assets/media/icons/duotune/general/gen001.svg") !!}
                                        </span>
                                    </a>
                                </div>

                                <div class="mx-2"></div>

                                <div id="kt_header_user_menu_toggle"
                                     class="d-flex align-items-center"
                                     title="{{ __("Profil") }}"
                                     data-bs-toggle="tooltip"
                                     data-bs-dimiss="click"
                                     data-bs-custom-class="tooltip-dark"
                                     data-bs-placement="bottom">
                                    <div class="cursor-pointer symbol symbol-30px symbol-md-40px"
                                         data-kt-menu-trigger="click"
                                         data-kt-menu-attach="parent"
                                         data-kt-menu-placement="bottom-end">
                                        <img alt="user"
                                             src="{{ asset($user?->path_photo ? "storage/{$user->path_photo}" : "assets/media/avatars/blank.png") }}"
                                             loading="lazy"/>
                                    </div>
                                    <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-325px"
                                         data-kt-menu="true">

                                        <div class="menu-item px-3">
                                            <div class="menu-content d-flex align-items-center px-3">
                                                <div class="symbol symbol-50px me-5">
                                                    <img alt="Logo"
                                                         src="{{ asset($user?->path_photo ? "storage/{$user?->path_photo}" : "assets/media/avatars/blank.png") }}"
                                                         loading="lazy"/>
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <div class="fw-bolder fs-5">{{ $user->name }}</div>
                                                    <div class="fw-bolder fs-8">{{ $user->roles->first()?->name ?? "-" }}</div>
                                                    <a href="#" class="fw-bold text-muted text-hover-primary fs-7">{{ $user->email }}</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="separator my-2"></div>
                                        <div class="menu-item px-5">
                                            <a href="#"
                                               class="menu-link px-5"
                                               data-bs-toggle="modal"
                                               data-bs-target="#modal_profile">{{ __("Profil Saya") }}</a>
                                        </div>
                                        <div class="menu-item px-5">
                                            <a href="#"
                                               class="menu-link px-5 button-ajax"
                                               data-action="{{ route("logout") }}"
                                               data-method="post"
                                               data-csrf="{{ csrf_token() }}"
                                               data-reload="true">{{ __("Keluar Aplikasi") }}</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center d-lg-none ms-2 me-n3"
                                     title="Show header menu">
                                    <div id="kt_header_menu_mobile_toggle"
                                         class="btn btn-icon btn-active-light-primary w-30px h-30px w-md-40px h-md-40px">
                                        <span class="svg-icon svg-icon-1">
                                            {!! asset_svg("assets/media/icons/duotune/text/txt001.svg") !!}
                                        </span>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>

                <div id="kt_content"
                     class="content py-lg-3 d-flex flex-column flex-column-fluid @stack("content-container-class")">

                    <div id="kt_toolbar"
                         class="toolbar">

                        <div id="kt_toolbar_container"
                             class="container-fluid d-flex flex-stack">

                            <div class="d-block d-lg-none"></div>

                            <div class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0"
                                 data-kt-swapper="true"
                                 data-kt-swapper-mode="prepend"
                                 data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}">
                                @if ($app_menu->toolbar_title)
                                    <h2 class="d-flex align-items-center text-dark fw-bolder fs-4 my-1">{{ $app_menu->name }}</h2>
                                    <span class="h-20px border-gray-300 border-start mx-4"></span>
                                @endif
                                <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-8 my-1">
                                    <li class="breadcrumb-item text-muted">
                                        <a href="{{ url("/home") }}"
                                           class="text-muted text-hover-primary">{{ __("Beranda") }}</a>
                                    </li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-dark">{{ $app_module_name }}</li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-dark">{{ $app_module_sub_name }}</li>
                                    <li class="breadcrumb-item">
                                        <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                    </li>
                                    <li class="breadcrumb-item text-dark">{{ $app_menu_name }}</li>
                                    @if ($app_menu_sub_name)
                                        <li class="breadcrumb-item">
                                            <span class="bullet bg-gray-300 w-5px h-2px"></span>
                                        </li>
                                        <li class="breadcrumb-item text-dark">{{ $app_menu_sub_name }}</li>
                                    @endif
                                </ul>
                            </div>

                            <div class="d-flex align-items-center">
                                <div class="clock-tick d-none d-lg-block fs-7 text-center user-select-none font-monospace">
                                    {{ now()->locale("id")->translatedFormat("l, d F Y H:i:s") }}
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="container-fluid @stack("content-class", "my-4")"
                         style="@stack("content-style")">
                        @yield("content")
                    </div>

                </div>

                @include("app.app-footer")

            </div>

        </div>
    </div>
@endsection

@push("livewire")
    @livewire("app-profile", compact(["user", "user_role"]))
    @livewire("app-notification", compact("user"))
    @livewire("app-manual-book")
@endpush
