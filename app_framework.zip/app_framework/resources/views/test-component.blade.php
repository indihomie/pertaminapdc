@extends("app.app")
@push("title", "Home")
@section("body")
    <div class="d-flex">
        <div class="tab-content">
            <div class="card">
                <div class="card-body">
                    <x-input-text name="name" required label="Nama Pegawai" />
                    <x-textarea name="textarea" required label="Alamat" />
                    <x-select label="Pangkat" name="rank" required all="- Pilih Pangkat -" />
                </div>
            </div>
        </div>
    </div>
@endsection
