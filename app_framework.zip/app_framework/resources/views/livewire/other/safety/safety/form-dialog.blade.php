<div id="modal_form"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off"
                  enctype="multipart/form-data">

                <div class="modal-header pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        {{ __("Hubungan") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                            <span class="svg-icon svg-icon-2x">
                                {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                            </span>
                    </div>
                </div>

                <div class="modal-body">

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Nama") }}</label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   disabled
                                   wire:model.defer="account.name">
                        </div>
                        <x-input-error for="account.name"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Login Terakhir") }}</label>
                        <div class="w-250px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   disabled
                                   wire:model.defer="account.login_at">
                        </div>
                        <x-input-error for="account.login_at"/>
                    </div>

                    <x-input-error class="mb-2" for="account.relations"/>

                    <div class="d-flex align-items-center justify-content-between">
                        <div class="fs-5 fw-bold">{{ __("Daftar") }}</div>
                        <div>
                            <a href="#"
                               wire:click="editAdd">
                                <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                      title="{{ __("Tambah") }}"
                                      data-bs-toggle="tooltip"
                                      data-bs-trigger="hover"
                                      data-bs-dismiss="click">
                                    <img src="{{ asset("assets/media/icons/table-add.png") }}"
                                         class="w-15px">
                                </span>
                            </a>
                        </div>
                    </div>

                    <div class="separator separator-dashed my-2"></div>

                    @forelse($account["relations"] as $relation)
                        <div class="mb-2 d-flex flex-row">
                            <div class="flex-row-fluid">
                                <select class="form-select"
                                        data-controls="select2"
                                        data-placeholder="{{ __("- Pilih User -") }}"
                                        wire:model="account.relations.{{ $loop->index }}.relation_id">
                                    <option value=""></option>
                                    @foreach($users as $_user)
                                        <option value="{{ $_user->id }}">{{ $_user->name }}</option>
                                    @endforeach
                                </select>
                                <x-input-error for="account.relations.{{ $loop->index }}.relation_id"/>
                            </div>
                            <div class="w-10px"></div>
                            <div class="w-row-auto">
                                <a href="#"
                                wire:click="editRemove({{ $loop->index }})">
                                    <span class="btn btn-sm btn-icon btn-color-danger btn-active-light-danger"
                                          title="{{ __("Hapus") }}"
                                          data-bs-toggle="tooltip"
                                          data-bs-trigger="hover"
                                          data-bs-dismiss="click">
                                        <img src="{{ asset("assets/media/icons/table-delete.png") }}"
                                             class="w-15px">
                                    </span>
                                </a>
                            </div>
                        </div>
                    @empty
                        <div class="min-h-100px d-flex flex-center">{{ __("Tidak ada data") }}</div>
                    @endforelse

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <div>
                        <a class="btn btn-light btn-active-light-primary"
                           href="#"
                           data-bs-dismiss="modal">{{ __("Batal") }}</a>
                        @canany(["{$app_path}.create", "{$app_path}.update"])
                            <button type="submit"
                                    class="btn btn-primary ms-2">
                                {{ __("Simpan") }}
                            </button>
                        @endcanany
                    </div>
                </div>

            </form>

        </div>

    </div>
</div>
