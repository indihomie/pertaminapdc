<div id="modal_detail"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-xl modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        {{ __("Detil Log") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body">

                    <div class="fv-row d-flex">
                        <label class="form-label min-w-100px">{{ __("Environment") }}</label>
                        <div class="fs-7">{{ $log["environment"] ?? "" }}</div>
                    </div>

                    <div class="fv-row d-flex">
                        <label class="form-label min-w-100px">{{ __("Waktu") }}</label>
                        <div class="fs-7">{{ $log["date"] ?? "" }}</div>
                    </div>

                    <div class="fv-row d-flex">
                        <label class="form-label min-w-100px">{{ __("Level") }}</label>
                        <div class="fs-7">{{ $log["level"] ?? "" }}</div>
                    </div>

                    <div class="my-3"></div>

                    <div class="fs-6 fw-bolder">{{ __("Error") }}</div>
                    <pre class="p-2 bg-light rounded overflow-scroll fs-8">{!! $log["error"] ?? "" !!}</pre>

                    <div class="my-3"></div>

                    <div class="fs-6 fw-bolder">{{ __("Stack Trace") }}</div>
                    <pre class="p-2 bg-light rounded overflow-scroll fs-9"
                         style="height: 50vh">{!! $log["trace"] ?? "" !!}</pre>

                </div>

            </form>

        </div>

    </div>

</div>
