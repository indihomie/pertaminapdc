<div class="livewire">

    <div class="mb-8">
        <div class="fs-2 fw-bold">
            {{ $app_menu->name }}
            <div class="w-30px border border-bottom border-primary"></div>
        </div>
    </div>

    <div class="d-flex flex-column flex-lg-row justify-content-between mb-4">
        <div class="d-flex mb-4 mb-lg-0">

            <div class="w-350px"
                 wire:ignore>
                <select class="form-select form-select-solid"
                        data-controls="select2"
                        data-placeholder="{{ __("- Pilih Log -") }}"
                        wire:model="log_filename">
                    <option value=""></option>
                    @foreach($log_filenames as $_log)
                        <option value="{{ $_log }}">{{ $_log }}</option>
                    @endforeach
                </select>
            </div>

        </div>
        <div class="d-flex">
        </div>
    </div>

    <div class="dataTables_wrapper">
        <div class="table-responsive table-loading">
            <div class="table-loading-message d-none"
                 wire:loading.class.remove="d-none">
                {{ __("Loading...") }}
            </div>
            <table class="table table-row-dashed table-hover dataTable gy-3 gx-3">
                <thead class="fs-7 fw-bolder text-gray-800 text-uppercase border border-dashed user-select-none">
                <tr class="align-middle text-center">
                    <th class="w-30px pe-3">#</th>
                    <th class="w-150px min-w-150px pe-3 border-start-0 sorting {{ $sortBy == "date" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : "" }}"
                        wire:click="sortBy('date')">{{ __("Waktu") }}</th>
                    <th class="w-100px min-w-100px pe-3 border-start-0">{{ __("Level") }}</th>
                    <th class="w-125px min-w-125px">{{ __("Environment") }}</th>
                    <th class="w-auto max-w-250px">{{ __("Log") }}</th>
                    <th class="w-75px min-w-75px pe-3 border-start-0">{{ __("Kontrol") }}</th>
                </tr>
                </thead>
                <tbody class="">
                @forelse($logs as $_log)
                    <tr class="align-middle">
                        <td class="text-end">{{ $loop->iteration }}.</td>
                        <td class="text-center font-monospace">{{ $_log->date->format("d/m/Y H:i:s") }}</td>
                        <td class="text-start">
                            <span class="badge {{ $level_classes[$_log->level] }}">
                                {{ $_log->level }}
                            </span>
                        </td>
                        <td class="text-start">{{ $_log->environment }}</td>
                        <td class="text-start fs-8">{{ $_log->context->message }}</td>
                        <td class="text-end">
                            <a href="#"
                               data-bs-toggle="modal"
                               data-bs-target="#modal_detail"
                               wire:click="detail('{{ $_log->id }}')">
                                <span class="btn btn-sm btn-icon btn-color-dark btn-active-light-dark"
                                      title="{{ __("Lihat") }}"
                                      data-bs-toggle="tooltip"
                                      data-bs-trigger="hover"
                                      data-bs-dismiss="click">
                                    <img src="{{ asset("assets/media/icons/table-view.png") }}"
                                         class="w-15px">
                                </span>
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8"
                            class="p-6 bg-light text-center text-gray-600">
                            {{ __("Tidak ada data") }}
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-start">
                <div class="dataTables_length me-5"
                     wire:ignore>
                    <select class="form-select form-select-solid w-80px"
                            data-controls="select2"
                            data-search="false"
                            wire:model="perPage">
                        @foreach(config("paramter.pagination") as $_key => $_value)
                            <option value="{{ $_key }}">{{ $_value }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="dataTables_info fs-6 fw-bold text-gray-700">
                    {{ __("Showing")  }}
                    {{ count($logs->items()) > 0 ? ($logs->currentPage() - 1) * $logs->perPage() + 1 : null }}
                    {{ __("to") }}
                    {{ count($logs->items()) > 0 ? $logs->firstItem() + $logs->count() - 1 : null }}
                    {{ __("of") }} {{ $logs->total() }} {{ __("entries") }}
                </div>
            </div>
            <div class="dataTables_paginate ms-0 col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
                {{ $logs->links() }}
            </div>
        </div>
    </div>

    @include("livewire.monitor.application-log.detail-dialog")

</div>
