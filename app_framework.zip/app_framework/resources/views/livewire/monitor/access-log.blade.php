<div class="livewire">

    <div class="mb-8">
        <div class="fs-2 fw-bold">
            {{ $app_menu->name }}
            <div class="w-30px border border-bottom border-primary"></div>
        </div>
    </div>

    <div class="d-flex flex-column flex-lg-row justify-content-between mb-4">
        <div class="d-flex mb-4 mb-lg-0">

            <div class="row g-2">
                <div class="col">

                    <div class="d-flex align-items-center position-relative">
                        <span class="svg-icon svg-icon-1 position-absolute ms-4">
                            {!! asset_svg("assets/media/icons/duotune/general/gen021.svg") !!}
                        </span>
                        <input type="text"
                               class="form-control form-control-solid w-250px ps-15"
                               placeholder="{{ __("Cari") }}"
                               wire:model.debounce.500ms="search"/>
                    </div>

                </div>
                <div class="col">

                    <div class="w-lg-200px position-relative d-flex align-items-center">
                        <div class="svg-icon svg-icon-2 position-absolute mx-4">
                            {!! asset_svg("assets/media/icons/duotune/general/gen014.svg") !!}
                        </div>
                        <input type="text"
                               class="form-control form-control-solid ps-12"
                               placeholder=""
                               readonly
                               data-controls="date-picker"
                               wire:model="date_start">
                    </div>

                </div>
                <div class="col">

                    <div class="w-lg-200px position-relative d-flex align-items-center">
                        <div class="svg-icon svg-icon-2 position-absolute mx-4">
                            {!! asset_svg("assets/media/icons/duotune/general/gen014.svg") !!}
                        </div>
                        <input type="text"
                               class="form-control form-control-solid ps-12"
                               placeholder=""
                               readonly
                               data-controls="date-picker"
                               wire:model="date_end">
                    </div>

                </div>
            </div>

        </div>
        <div class="d-flex">
        </div>
    </div>

    <div class="dataTables_wrapper">
        <div class="table-responsive table-loading">
            <div class="table-loading-message d-none"
                 wire:loading.class.remove="d-none">
                {{ __("Loading...") }}
            </div>
            <table class="table table-row-dashed table-hover dataTable gy-3 gx-3">
                <thead class="fs-7 fw-bolder text-gray-800 text-uppercase border border-dashed user-select-none">
                <tr class="align-middle text-center">
                    <th class="w-30px pe-3">#</th>
                    <th class="w-200px min-w-200px pe-3 border-start-0">{{ __("Nama") }}</th>
                    <th class="w-auto max-w-250px">{{ __("Halaman") }}</th>
                    <th class="w-100px min-w-100px">{{ __("Alamat IP") }}</th>
                    <th class="w-50px min-w-50px pe-3 border-start-0">{{ __("Metode") }}</th>
                    <th class="w-125px min-w-125px pe-3 border-start-0">{{ __("Status") }}</th>
                    <th class="w-150px min-w-150px pe-3 border-start-0 sorting {{ $sortBy == "created_at" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : "" }}"
                        wire:click="sortBy('created_at')">{{ __("Waktu Akses") }}</th>
                </tr>
                </thead>
                <tbody class="">
                @forelse($access_logs as $_access_log)
                    <tr class="align-middle">
                        <td class="text-end">{{ $loop->iteration }}.</td>
                        <td class="text-start">{{ $_access_log->user->name ?? "guest" }}</td>
                        <td class="text-start">{{ Str::limit($_access_log->path, 88, "...") }}</td>
                        <td class="text-start font-monospace">{{ $_access_log->ip_address }}</td>
                        <td class="text-start">{{ $_access_log->method }}</td>
                        <td class="text-start">
                            <span class="badge {{ $status_codes[$_access_log->status]["class"] }}">
                                {{ $_access_log->status }}
                                {{ $status_codes[$_access_log->status]["message"] }}
                            </span>
                        </td>
                        <td class="text-center font-monospace">{{ $_access_log->created_at->format("d/m/Y H:i:s") }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8"
                            class="p-6 bg-light text-center text-gray-600">
                            {{ __("Tidak ada data") }}
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-start">
                <div class="dataTables_length me-5"
                     wire:ignore>
                    <select class="form-select form-select-solid w-80px"
                            data-controls="select2"
                            data-search="false"
                            wire:model="perPage">
                        @foreach(config("paramter.pagination") as $_key => $_value)
                            <option value="{{ $_key }}">{{ $_value }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="dataTables_info fs-6 fw-bold text-gray-700">
                    {{ __("Showing")  }} {{ $access_logs->firstItem() }} {{ __("to") }} {{ $access_logs->lastItem() }} {{ __("of") }} {{ $access_logs->total() }} {{ __("entries") }}
                </div>
            </div>
            <div class="dataTables_paginate ms-0 col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
                {{ $access_logs->links() }}
            </div>
        </div>
    </div>

</div>
