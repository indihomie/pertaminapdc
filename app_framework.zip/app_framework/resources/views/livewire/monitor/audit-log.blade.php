<div class="livewire">

    <div class="mb-8">
        <div class="fs-2 fw-bold">
            {{ $app_menu->name }}
            <div class="w-30px border border-bottom border-primary"></div>
        </div>
    </div>

    <div class="d-flex flex-column flex-lg-row justify-content-between mb-4">
        <div class="d-flex mb-4 mb-lg-0">

            <div class="row gy-2 gx-2">
                <div class="col">

                    <div class="w-300px"
                         wire:ignore>
                        <select class="form-select form-select-solid"
                                data-controls="select2"
                                data-allow-clear="true"
                                data-placeholder="{{ __("- Pilih Model -") }}"
                                wire:model="model_class">
                            <option value=""></option>
                            @foreach($model_classes as $_key => $_value)
                                <option value="{{ $_key }}">{{ $_value }}</option>
                            @endforeach
                        </select>
                    </div>

                </div>
                <div class="col">

                    <div class="w-150px"
                         wire:ignore>
                        <select class="form-select form-select-solid"
                                data-controls="select2"
                                data-search="false"
                                data-allow-clear="true"
                                data-placeholder="{{ __("- Pilih Status -") }}"
                                wire:model="model_status">
                            <option value=""></option>
                            @foreach($model_statuses as $_key => $_value)
                                <option value="{{ $_key }}">{{ $_value }}</option>
                            @endforeach
                        </select>
                    </div>

                </div>
                <div class="col">

                    <div class="w-lg-200px position-relative d-flex align-items-center">
                        <div class="svg-icon svg-icon-2 position-absolute mx-4">
                            {!! asset_svg("assets/media/icons/duotune/general/gen014.svg") !!}
                        </div>
                        <input type="text"
                               class="form-control form-control-solid ps-12"
                               placeholder=""
                               readonly
                               data-controls="date-picker"
                               wire:model="date_start">
                    </div>

                </div>
                <div class="col">

                    <div class="w-lg-200px position-relative d-flex align-items-center">
                        <div class="svg-icon svg-icon-2 position-absolute mx-4">
                            {!! asset_svg("assets/media/icons/duotune/general/gen014.svg") !!}
                        </div>
                        <input type="text"
                               class="form-control form-control-solid ps-12"
                               placeholder=""
                               readonly
                               data-controls="date-picker"
                               wire:model="date_end">
                    </div>

                </div>
            </div>

        </div>
        <div class="d-flex">
        </div>
    </div>

    <div class="dataTables_wrapper">
        <div class="table-responsive table-loading">
            <div class="table-loading-message d-none"
                 wire:loading.class.remove="d-none">
                {{ __("Loading...") }}
            </div>
            <table class="table table-row-dashed table-hover dataTable gy-3 gx-3">
                <thead class="fs-7 fw-bolder text-gray-800 text-uppercase border border-dashed user-select-none">
                <tr class="align-middle text-center">
                    <th class="w-30px pe-3">#</th>
                    <th class="w-150px min-w-150px pe-3 border-start-0 sorting {{ $sortBy == "created_at" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : "" }}"
                        wire:click="sortBy('created_at')">{{ __("Waktu") }}</th>
                    <th class="w-75px min-w-75px pe-3 border-start-0">{{ __("Lokasi") }}</th>
                    <th class="w-100px min-w-100px">{{ __("Aktifitas") }}</th>
                    <th class="w-300px max-w-300px">{{ __("Model") }}</th>
                    <th class="w-auto min-w-250px pe-3 border-start-0">{{ __("Nama") }}</th>
                    <th class="w-150px min-w-150px pe-3 border-start-0">{{ __("User") }}</th>
                    <th class="w-75px min-w-75px pe-3 border-start-0">{{ __("Kontrol") }}</th>
                </tr>
                </thead>
                <tbody class="">
                @forelse($logs as $_log)
                    <tr class="align-middle">
                        <td class="text-end">{{ $loop->iteration }}.</td>
                        <td class="text-center">{{ $_log->created_at->format("d/m/Y H:i:s") }}</td>
                        <td class="text-start">{{ $_log->log_name }}</td>
                        <td class="text-start">
                            <span class="badge {{ $status_colors[$_log->description] ?? "" }}">
                                {{ $_log->description }}
                            </span>
                        </td>
                        <td class="text-start">{{ $_log->subject_type }}</td>
                        <td class="text-start">{{ $_log->subject?->name ?? "" }}</td>
                        <td class="text-start">{{ $_log->causer?->name ?? "" }}</td>
                        <td class="text-end">
                            <a href="#"
                               data-bs-toggle="modal"
                               data-bs-target="#modal_detail"
                               wire:click="detail('{{ $_log->id }}')">
                                <span class="btn btn-sm btn-icon btn-color-dark btn-active-light-dark"
                                      title="{{ __("Lihat") }}"
                                      data-bs-toggle="tooltip"
                                      data-bs-trigger="hover"
                                      data-bs-dismiss="click">
                                    <img src="{{ asset("assets/media/icons/table-view.png") }}"
                                         class="w-15px">
                                </span>
                            </a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8"
                            class="p-6 bg-light text-center text-gray-600">
                            {{ __("Tidak ada data") }}
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-start">
                <div class="dataTables_length me-5"
                     wire:ignore>
                    <select class="form-select form-select-solid w-80px"
                            data-controls="select2"
                            data-search="false"
                            wire:model="perPage">
                        @foreach(config("paramter.pagination") as $_key => $_value)
                            <option value="{{ $_key }}">{{ $_value }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="dataTables_info fs-6 fw-bold text-gray-700">
                    {{ __("Showing")  }} {{ $logs->firstItem() }} {{ __("to") }} {{ $logs->lastItem() }} {{ __("of") }} {{ $logs->total() }} {{ __("entries") }}
                </div>
            </div>
            <div class="dataTables_paginate ms-0 col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
                {{ $logs->links() }}
            </div>
        </div>
    </div>

    @include("livewire.monitor.audit-log.detail-dialog")

</div>
