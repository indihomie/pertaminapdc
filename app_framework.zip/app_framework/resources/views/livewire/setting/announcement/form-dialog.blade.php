<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="d-flex justify-content-center mb-6">

                        @php($_path = $image["file"] ? $image["file"]->temporaryUrl() : ($announcement["path_image"] ? asset("storage/{$announcement["path_image"]}") : ""))
                        <div class="image-input bgi-position-center bg-light {{ $_path ? "" : "image-input-empty" }}"
                             style="
                                 background-size: 50px;
                                 background-image: url('{{ asset("assets/media/misc/image.png") }}')
                                 ">

                            <a class="viewer d-block image-input-wrapper w-300px h-150px bgi-size-contain bgi-position-center"
                               href="{{ $_path }}"
                               data-ext="{{ "image" }}"
                               data-title="{{ $announcement["name"] }}"
                               data-download="true"
                               style="background-image: url('{{ $_path }}')">
                            </a>

                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow {{ $_path ? "d-none" : "" }}"
                                   data-kt-image-input-action="change">
                                <i class="bi bi-pencil-fill fs-7"></i>
                                <input type="file"
                                       accept=".png, .jpg, .jpeg"
                                       wire:model="image.file"/>
                            </label>

                            <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                  data-kt-image-input-action="remove"
                                  wire:click="removeImage">
                                <i class="bi bi-x fs-2"></i>
                            </span>

                        </div>
                    </div>

                    <x-input-error for="image"
                                   class="my-4"/>

                    <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x fs-6"
                        wire:ignore>
                        <li class="nav-item">
                            <a class="nav-link active"
                               href="#form"
                               data-bs-toggle="tab">{{ __("Informasi") }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               href="#content"
                               data-bs-toggle="tab">{{ __("Konten") }}</a>
                        </li>
                    </ul>

                    <div class="py-4 tab-content overflow-scroll scroll-y"
                         style="min-height: 45vh;"
                         wire:ignore.self>
                        <div id="form"
                             class="tab-pane fade active show"
                             wire:ignore.self>

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Waktu") }}</label>
                                <div class="w-lg-225px position-relative d-flex align-items-center">
                                    <div class="svg-icon svg-icon-2 position-absolute mx-4">
                                        {!! asset_svg("assets/media/icons/duotune/general/gen014.svg") !!}
                                    </div>
                                    <input type="text"
                                           class="form-control ps-12"
                                           placeholder=""
                                           readonly
                                           data-controls="date-time-picker"
                                           wire:model.defer="announcement.datetime">
                                </div>
                                <x-input-error for="announcement.datetime"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Judul") }}</label>
                                <div class="w-lg-325px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           wire:model.defer="announcement.name">
                                </div>
                                <x-input-error for="announcement.name"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Sumber") }}</label>
                                <div class="w-lg-325px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           wire:model.defer="announcement.source">
                                </div>
                                <x-input-error for="announcement.source"/>
                            </div>

                            <div class="fv-row mb-6">
                                <label class="fs-6 fw-bold mb-2">{{ __("Status") }}</label>
                                <div>
                                    <div class="form-check form-check-solid form-switch">
                                        <input type="checkbox"
                                               class="form-check-input w-45px h-30px"
                                               wire:model.defer="announcement.status">
                                        <label class="form-check-label"></label>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div id="content"
                             class="tab-pane fade"
                             wire:ignore.self>

                            <div wire:ignore>
                                <textarea id="editor"
                                          class="box-border border border border-solid border-gray-300"
                                          wire:model.defer="announcement.content"></textarea>
                            </div>

                        </div>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
