<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-md modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Nama") }}</label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="group.name">
                        </div>
                        <x-input-error for="group.name"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Guard") }}</label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="group.guard_name">
                        </div>
                        <div class="fs-8 text-muted">{{ __("gunakan web untup grup user web") }}</div>
                        <x-input-error for="group.guard_name"/>
                    </div>

                    <div class="scroll-x">
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x fs-6 user-select-none">
                            @foreach($module_categories->sortByDesc("order") as $_category)
                                <li class="nav-item">
                                    <a class="nav-link {{ $loop->first ? "active" : "" }}"
                                       href="#sub_{{ $_category->id }}"
                                       data-bs-toggle="tab"
                                    >{{ $_category->name }}</a>
                                </li>
                            @endforeach
                        </ul>
                    </div>

                    <div class="py-4 tab-content min-h-250px">
                        @foreach($module_categories->sortByDesc("order") as $_category)
                            <div id="sub_{{ $_category->id }}"
                                 class="tab-pane fade {{ $loop->first ? "active show" : "" }}">

                                @foreach(($modules[$_category->id] ?? collect())->sortBy("order") as $_module)
                                    <label class="my-2 form-check form-check-custom form-check-solid user-select-none">
                                        <input class="form-check-input w-25px h-25px"
                                               type="checkbox"
                                               wire:model.defer="group.permissions.module_{{ $_module->id }}">
                                        <span class="form-check-label">{{ $_module->name }}</span>
                                    </label>
                                @endforeach

                            </div>
                        @endforeach
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
