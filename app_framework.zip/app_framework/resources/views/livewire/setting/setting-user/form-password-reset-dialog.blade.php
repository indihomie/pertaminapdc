<div id="modal_form_password_reset"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="savePassword"
                  autocomplete="off">

                <div class="modal-header pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        {{ __("Ubah Password") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                </div>

                <div class="modal-body">

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Username") }}</label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.username"
                                   disabled>
                        </div>
                        <x-input-error for="account.username"/>
                    </div>

                    <div class="my-4 separator separator-dashed"></div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Password") }}</label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password">
                        </div>
                        <x-input-error for="account.password"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Konfirmasi Password") }}</label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password_confirm">
                        </div>
                        <x-input-error for="account.password_confirm"/>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-toggle="modal"
                       data-bs-target="#modal_form">{{ __("Batal") }}</a>
                    @can("{$app_path}.update")
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcan
                </div>

            </form>

        </div>

    </div>
</div>
