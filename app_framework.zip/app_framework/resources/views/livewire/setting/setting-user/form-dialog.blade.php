<div id="modal_form"
     class="modal fade"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off"
                  enctype="multipart/form-data">

                <div class="modal-header pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        {{ __("Profil") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                            <span class="svg-icon svg-icon-2x">
                                {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                            </span>
                    </div>
                </div>

                <div class="modal-body">

                    <div class="d-flex justify-content-center mb-6">

                        @php($_path = $image["file"] ? $image["file"]->temporaryUrl() : ($account["path_photo"] ? asset("storage/{$account["path_photo"]}") : ""))
                        <div class="image-input image-input-circle bgi-size-cover bg-light {{ $_path ? "" : "image-input-empty" }}"
                             style="
                                 background-image: url('{{ asset("assets/media/avatars/blank.png") }}')
                                 ">
                            <a class="viewer d-block image-input-wrapper w-100px h-100px bgi-size-contain bgi-position-center"
                               href="{{ $_path }}"
                               data-ext="image"
                               data-title="{{ $account["name"] }}"
                               style="background-image: url('{{ $_path }}')"></a>
                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow {{ $_path ? "d-none" : "" }}"
                                   data-kt-image-input-action="change">
                                <i class="bi bi-pencil-fill fs-7"></i>
                                <input type="file"
                                       accept=".png, .jpg, .jpeg"
                                       wire:model="image.file"/>
                            </label>
                            <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                  data-kt-image-input-action="remove"
                                  wire:click="removeImage">
                                <i class="bi bi-x fs-2"></i>
                            </span>
                        </div>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Grup User") }}</label>
                        <div class="w-lg-300px"
                             wire:ignore>
                            <select class="form-select"
                                    data-controls="select2"
                                    data-placeholder="{{ __("- Pilih Grup User -") }}"
                                    wire:model.defer="account.role_id">
                                <option value=""></option>
                                @foreach($roles as $_role)
                                    <option value="{{ $_role->id }}">{{ $_role->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <x-input-error for="account.role_id"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Nama") }}</label>
                        <div>
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.name">
                        </div>
                        <x-input-error for="account.name"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Username") }}</label>
                        <div class="w-lg-200px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   autocomplete="off"
                                   wire:model.defer="account.username">
                        </div>
                        <x-input-error for="account.username"/>
                    </div>

                    <div class="fv-row mb-4 {{ $state == \App\Const\State::EDIT ? "d-none" : "" }}">
                        <label class="form-label required">{{ __("Password") }}</label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password">
                        </div>
                        <x-input-error for="account.password"/>
                    </div>

                    <div class="fv-row mb-4 {{ $state == \App\Const\State::EDIT ? "d-none" : "" }}">
                        <label class="form-label required">{{ __("Konfirmasi Password") }}</label>
                        <div class="w-lg-200px">
                            <input type="password"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.password_confirm">
                        </div>
                        <x-input-error for="account.password_confirm"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Email") }}</label>
                        <div class="w-lg-300px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="account.email">
                        </div>
                        <div class="text-muted fs-8">{{ __("Email bersifat unik, gunakan email aktif untuk menyelesaikan verifikasi email saat email diubah.") }}</div>
                        <x-input-error for="account.email"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Telepon") }}</label>
                        <div class="w-lg-200px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   data-controls="mask"
                                   data-mask="(9999) 9999 9999 9999"
                                   data-unmask="true"
                                   wire:model.defer="account.phone">
                        </div>
                        <x-input-error for="account.phone"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Verifikasi Email") }}</label>
                        <div class="w-200px">
                            <input type="text"
                                   class="form-control bg-light"
                                   placeholder=""
                                   readonly
                                   wire:model.defer="account.email_verified_at">
                        </div>
                        <x-input-error for="account.email_verified_at"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Catatan") }}</label>
                        <div>
                            <textarea type="text"
                                      class="form-control"
                                      placeholder=""
                                      wire:model.defer="account.description"></textarea>
                        </div>
                        <x-input-error for="account.description"/>
                    </div>

                    <div class="fv-row">
                        <label class="fs-6 fw-bold mb-2">{{ __("Status") }}</label>
                        <div>
                            <div class="form-check form-check-solid form-switch">
                                <input type="checkbox"
                                       class="form-check-input w-45px h-30px"
                                       wire:model.defer="account.status">
                                <label class="form-check-label"></label>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0 d-flex justify-content-between">
                    <div>
                        @can("{$app_path}.update")
                            @if ($state == \App\Const\State::EDIT)
                                <button type="button"
                                        class="btn btn-light btn-light"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modal_form_password_reset">{{ __("Ubah Password") }}</button>
                            @endif
                        @endcan
                    </div>
                    <div>
                        <a class="btn btn-light btn-active-light-primary"
                           href="#"
                           data-bs-dismiss="modal">{{ __("Batal") }}</a>
                        @canany(["{$app_path}.create", "{$app_path}.update"])
                            <button type="submit"
                                    class="btn btn-primary ms-2">
                                {{ __("Simpan") }}
                            </button>
                        @endcanany
                    </div>
                </div>

            </form>

        </div>

    </div>
</div>
