<div>

    <div id="modal_announcement"
         class="modal fade"
         data-bs-backdrop="static"
         data-bs-keyboard="false"
         wire:ignore.self>
        <div class="modal-dialog modal-md modal-dialog-centered">

            <div class="modal-content overlay overlay-block overlay-hidden"
                 wire:loading.class.remove="overlay-hidden">

                <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                    <div class="spinner-border text-primary" role="status"></div>
                </div>

                <div class="modal-header p-4 pb-0 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $announcement->name ?? __("Pengumuman") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal"
                         aria-label="Close">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body h-550px p-4 overflow-auto position-relative">

                    @if (!$announcement)
                        @foreach($announcements as $_announcement)
                            <a class="p-4 d-flex flex-row bg-hover-light rounded user-select-none"
                               href="#"
                               wire:click="select({{ $_announcement->id }})">
                                <div class="symbol symbol-40px symbol-2by3 flex-shrink-0 me-4">
                                    <img src="{{ asset("storage/{$_announcement->path_image}") }}"
                                         class="mw-100"
                                         alt=""
                                         loading="lazy">
                                </div>
                                <div class="">
                                    <div class="fs-6 fw-bold text-gray-800">{{ $_announcement->name }}</div>
                                    <div class="fs-7 text-gray-700">
                                        {{ $_announcement->updated_at->format("d F Y H:i") }} - {{ $_announcement->updatedBy->name }}
                                    </div>
                                </div>
                            </a>
                        @endforeach
                    @else
                        <div>

                            <a href="{{ asset("storage/{$announcement->path_image}") }}"
                               class="viewer d-block h-150px bg-light bgi-no-repeat bgi-size-contain bgi-position-center rounded"
                               data-title="{{ $announcement->name }}"
                               data-ext="{{ File::extension($announcement->path_image) }}"
                               data-download="true"
                               style="background-image: url('{{ asset("storage/{$announcement->path_image}") }}')"></a>

                            <div class="fs-7 text-primary my-2">{{ $announcement->updated_at->format("d F Y H:i") }} - {{ $announcement->updatedBy->name }}</div>

                            {!! $announcement->content !!}

                            <div class="border border-top border-dashed border-gray-300"></div>
                            <div class="fs-8 p-1">{{ $announcement->source }}</div>
                        </div>
                    @endif

                </div>

                <div class="modal-footer p-4 border-top-0 justify-content-center">
                    @if (!$announcement)
                        {{ $announcements->links() }}
                    @else
                        <a href="#"
                           class="w-100 btn btn-sm btn-light-primary text-hover-light"
                           wire:click="back">{{ __("Kembali") }}</a>
                    @endif
                </div>

            </div>

        </div>
    </div>

</div>
