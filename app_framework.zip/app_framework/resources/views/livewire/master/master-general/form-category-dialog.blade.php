<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-md modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="d-flex justify-content-center mb-6">
                        @php($_path = $image["file"] ? $image["file"]->temporaryUrl() : ($master["path_icon"] ? asset("storage/{$master["path_icon"]}") : ""))
                        <div class="image-input bgi-position-center bg-light {{ $_path ? "" : "image-input-empty" }}"
                             style="
                                 background-size: 50px;
                                 background-image: url('{{ asset("assets/media/misc/image.png") }}')
                                 ">
                            <a class="viewer d-block image-input-wrapper w-75px h-75px bgi-size-contain bgi-position-center"
                               href="{{ $_path }}"
                               data-ext="image"
                               data-title="{{ $app_menu->name }}"
                               data-download="true"
                               style="background-image: url('{{ $_path }}')"></a>
                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow {{ $_path ? "d-none" : "" }}"
                                   data-kt-image-input-action="change">
                                <i class="bi bi-pencil-fill fs-7"></i>
                                <input type="file"
                                       accept=".png, .jpg, .jpeg"
                                       wire:model="image.file"/>
                            </label>
                            <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                  data-kt-image-input-action="remove"
                                  wire:click="removeImage">
                                <i class="bi bi-x fs-2"></i>
                            </span>
                        </div>
                    </div>

                    <x-input-error for="image.file"
                                   class="mb-6"/>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Induk") }}</label>
                        <div wire:ignore>
                            <select class="form-select"
                                    data-controls="select2"
                                    data-allow-clear="true"
                                    data-placeholder="{{ __("- Pilih Induk -") }}"
                                    data-dropdown-parent="#modal_form"
                                    wire:model.defer="master.category_id">
                                <option value=""></option>
                                @foreach($master_parents->sortBy("name") as $_master)
                                    <option value="{{ $_master->id }}">{{ $_master->id }} - {{ $_master->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <x-input-error for="master.category_id"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Kode") }}</label>
                        <div class="w-100px">
                            <input type="text"
                                   class="form-control text-uppercase"
                                   placeholder=""
                                   data-controls="mask"
                                   data-mask="****"
                                   data-unmask="true"
                                   wire:model.defer="master.id"
                                {{ $state == App\Const\State::EDIT ? "readonly" : "" }}>
                        </div>
                        <x-input-error for="master.id"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Nama") }}</label>
                        <div class="w-250px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="master.name">
                        </div>
                        <x-input-error for="master.name"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Deskripsi") }}</label>
                        <div>
                            <textarea type="text"
                                      class="form-control"
                                      placeholder=""
                                      wire:model.defer="master.description"></textarea>
                        </div>
                        <x-input-error for="master.description"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Data") }}</label>
                        <div>
                            <textarea type="text"
                                      class="form-control min-h-100px"
                                      placeholder=""
                                      wire:model.defer="master.data"></textarea>
                        </div>
                        <span class="fs-8 text-muted">{{ __("Data harus berupa json") }}</span>
                        <x-input-error for="master.data"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Urut") }}</label>
                        <div class="position-relative w-md-100px"
                             data-kt-dialer="true"
                             data-kt-dialer-min="0"
                             data-kt-dialer-max="99"
                             data-kt-dialer-step="1"
                             wire:ignore>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 start-0"
                                    data-kt-dialer-control="decrease">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen036.svg") !!}
                                </span>
                            </button>
                            <input type="text"
                                   id="test-event"
                                   class="form-control form-control-solid border-0 ps-12"
                                   data-kt-dialer-control="input"
                                   wire:model.defer="master.order"
                                   readonly/>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 end-0"
                                    data-kt-dialer-control="increase">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen035.svg") !!}
                                </span>
                            </button>
                        </div>
                        <x-input-error for="master.order"/>
                    </div>

                    <div class="fv-row mb-6">
                        <label class="fs-6 fw-bold mb-2">{{ __("Status") }}</label>
                        <div>
                            <div class="form-check form-check-solid form-switch">
                                <input type="checkbox"
                                       class="form-check-input w-45px h-30px"
                                       wire:model.defer="master.status">
                                <label class="form-check-label"></label>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
