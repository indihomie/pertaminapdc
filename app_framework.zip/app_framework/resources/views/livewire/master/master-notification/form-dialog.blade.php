<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     data-bs-focus="false"
     wire:ignore.self>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body pt-0 px-8">

                    <ul class="nav nav-tabs nav-line-tabs mb-4"
                        wire:ignore>
                        <li class="nav-item">
                            <a class="nav-link cursor-pointer user-select-none active"
                               href="#information"
                               data-bs-toggle="tab">{{ __("Informasi") }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link cursor-pointer user-select-none"
                               href="#content_application"
                               data-bs-toggle="tab">{{ __("Aplikasi") }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link cursor-pointer user-select-none"
                               href="#content_email"
                               data-bs-toggle="tab">{{ __("Email") }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link cursor-pointer user-select-none"
                               href="#content_sms"
                               data-bs-toggle="tab">{{ __("SMS") }}</a>
                        </li>
                    </ul>

                    <div class="tab-content"
                         wire:ignore.self>
                        <div id="information"
                             class="tab-pane fade show active"
                             role="tabpanel"
                             wire:ignore.self>

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Kode") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control text-uppercase"
                                           placeholder=""
                                           wire:model.defer="notification.code">
                                </div>
                                <x-input-error for="notification.code"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Kategori") }}</label>
                                <div class="w-250px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           wire:model.defer="notification.category">
                                </div>
                                <div class="fs-8 text-muted">{{ __("Digunakan untuk grouping notifikasi") }}</div>
                                <x-input-error for="notification.category"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Nama") }}</label>
                                <div class="w-250px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           wire:model.defer="notification.name">
                                </div>
                                <x-input-error for="notification.name"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Deskripsi") }}</label>
                                <div class="w-300px">
                            <textarea type="text"
                                      class="form-control min-h-50px"
                                      placeholder=""
                                      wire:model.defer="notification.description"></textarea>
                                </div>
                                <x-input-error for="notification.margin_top"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Level") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-dropdown-parent="#modal_form"
                                            wire:model.defer="notification.level">
                                        @foreach($levels as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="notification.level"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Kode Menu") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control text-uppercase"
                                           placeholder=""
                                           wire:model.defer="notification.menu_code">
                                </div>
                                <x-input-error for="notification.menu_code"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Target") }}</label>
                                <div class="d-flex flex-row">
                                    <label class="form-check form-check-custom form-check-solid user-select-none me-4">
                                        <input class="form-check-input w-25px h-25px"
                                               type="checkbox"
                                               value="1"
                                               wire:model.defer="notification.target_application">
                                        <span class="form-check-label fs-7">{{ __("Aplikasi") }}</span>
                                    </label>
                                    <label class="form-check form-check-custom form-check-solid user-select-none me-4">
                                        <input class="form-check-input w-25px h-25px"
                                               type="checkbox"
                                               value="1"
                                               wire:model.defer="notification.target_email">
                                        <span class="form-check-label fs-7">{{ __("Email") }}</span>
                                    </label>
                                    <label class="form-check form-check-custom form-check-solid user-select-none me-4">
                                        <input class="form-check-input w-25px h-25px"
                                               type="checkbox"
                                               value="1"
                                               wire:model.defer="notification.target_sms">
                                        <span class="form-check-label fs-7">{{ __("SMS") }}</span>
                                    </label>
                                </div>
                            </div>

                        </div>
                        <div id="content_application"
                             class="tab-pane fade min-h-500px"
                             role="tabpanel"
                             wire:ignore>

                            <textarea id="editor"
                                      class="box-border border border border-solid border-gray-300"
                                      wire:model.defer="notification.content_application"></textarea>

                        </div>
                        <div id="content_email"
                             class="tab-pane fade min-h-500px"
                             role="tabpanel"
                             wire:ignore>

                            <textarea id="editor2"
                                      class="box-border border border border-solid border-gray-300"
                                      wire:model.defer="notification.content_email"></textarea>

                        </div>
                        <div id="content_sms"
                             class="tab-pane fade min-h-500px p-2"
                             role="tabpanel"
                             wire:ignore>

                            <textarea class="w-100 min-h-100px box-border border border border-solid border-gray-300 p-3 rounded"
                                      wire:model.defer="notification.content_sms"></textarea>

                        </div>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
