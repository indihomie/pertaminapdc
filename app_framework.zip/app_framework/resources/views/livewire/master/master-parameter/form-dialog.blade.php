<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-md modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Kode") }}</label>
                        <div class="w-150px">
                            <input type="text"
                                   class="form-control text-uppercase"
                                   placeholder=""
                                   data-controls="mask"
                                   data-mask="********"
                                   data-unmask="true"
                                   wire:model.defer="parameter.id">
                        </div>
                        <x-input-error for="parameter.id"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Nama") }}</label>
                        <div class="w-300px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="parameter.name">
                        </div>
                        <x-input-error for="parameter.name"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label required">{{ __("Nilai") }}</label>
                        <div class="w-200px">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="parameter.value">
                        </div>
                        <x-input-error for="parameter.value"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Data") }}</label>
                        <div>
                            <textarea type="text"
                                      class="form-control min-h-100px"
                                      placeholder=""
                                      wire:model.defer="parameter.data"></textarea>
                        </div>
                        <span class="fs-8 text-muted">{{ __("Data harus berupa json") }}</span>
                        <x-input-error for="parameter.data"/>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
