<div id="modal_form_group_actor"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     data-bs-focus="false"
     wire:ignore.self>

    <div class="modal-dialog modal-sm modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="saveGroupActor"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ __("Grup Aktor") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body pt-0 px-8">

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Tipe Referensi") }}</label>
                        <div class=""
                             wire:ignore>
                            <select class="form-select"
                                    data-controls="select2"
                                    data-allow-clear="true"
                                    data-placeholder="{{ __("- Pilih Tipe Referensi -") }}"
                                    wire:model="approval_group_actor.reference_type">
                                <option value=""></option>
                                @foreach($reference_types as $_key => $_value)
                                    <option value="{{ $_key }}">{{ $_value }}</option>
                                @endforeach
                            </select>
                        </div>
                        <x-input-error for="approval_group_actor.reference_type"/>
                    </div>

                    <div class="fv-row mb-4">
                        @php($reference_type = $reference_types[$approval_group_actor["reference_type"] ?? ""] ?? false)
                        <label class="form-label">{{ $reference_type ?: "Referensi" }}</label>
                        <div class="">
                            <select class="form-select"
                                    data-controls="select2"
                                    data-allow-clear="true"
                                    data-placeholder="{{ __("- Pilih {$reference_type} -") }}"
                                    wire:model.defer="approval_group_actor.reference_id">
                                <option value=""></option>
                                @foreach($references as $_key => $_value)
                                    <option value="{{ $_key }}">{{ $_value }}</option>
                                @endforeach
                            </select>
                        </div>
                        <x-input-error for="approval_group_actor.reference_id"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Operator") }}</label>
                        <div class="">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="approval_group_actor.operator">
                        </div>
                        <div class="fs-8 text-muted">{{ __("hanya bisa diisi and, or, dan angka (jumlah approver)") }}</div>
                        <x-input-error for="approval_group_actor.operator"/>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
