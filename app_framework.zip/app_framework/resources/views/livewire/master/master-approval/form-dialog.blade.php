<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     data-bs-focus="false"
     wire:ignore.self>

    <div class="modal-dialog modal-xl modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body pt-0 px-8">

                    <div class="row">
                        <div class="col-md-4">

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Kode") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control text-uppercase"
                                           placeholder=""
                                           wire:model.defer="approval.code">
                                </div>
                                <x-input-error for="approval.code"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Nama") }}</label>
                                <div class="w-250px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           wire:model.defer="approval.name">
                                </div>
                                <x-input-error for="approval.name"/>
                            </div>

                        </div>
                        <div class="col-md-6">

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Deskripsi") }}</label>
                                <div class="w-300px">
                                    <textarea type="text"
                                              class="form-control min-h-50px"
                                              placeholder=""
                                              wire:model.defer="approval.description"></textarea>
                                </div>
                                <x-input-error for="approval.margin_top"/>
                            </div>

                        </div>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Dataset") }}</label>
                        <div class="w-500px"
                             wire:ignore>
                            <input type="text"
                                   class="form-control min-h-75px text-start p-2"
                                   placeholder=""
                                   data-controls="tags"
                                   data-copy="true"
                                   data-placeholder="{{ __("Dataset") }}"
                                   wire:model="approval.dataset">
                        </div>
                        <div class="fs-8 text-muted">{{ __("Dataset digunakan untuk membantu user membaca variable yang disediakan untuk menseting flow kontrak") }}</div>
                        <x-input-error for="approval.dataset"/>
                    </div>

                    <div class="d-flex align-items-end justify-content-between mb-4">
                        <div class="fs-5 fw-bold">
                            {{ __("Flow Approval") }}
                            <div class="w-30px border border-bottom border-primary"></div>
                        </div>
                        <x-input-error class="w-auto" for="approval.groups"/>
                        <a href="#"
                           wire:click="editGroup(-1)"
                           class="btn btn-sm btn-primary">
                            {{ __("Tambah Grup") }}
                        </a>
                    </div>

                    <table class="table table-row-dashed dataTable gy-2 gx-2">
                        <thead class="fs-7 fw-bolder text-gray-800 text-uppercase border border-dashed user-select-none">
                        <tr class="align-middle text-center">
                            <th class="w-30px pe-3">#</th>
                            <th class="w-75px min-w-75px pe-3 border-start-0">
                                {{ __("Urut") }}
                            </th>
                            <th class="w-auto min-w-auto pe-3 border-start-0">
                                {{ __("Aktor") }}
                            </th>
                            <th class="w-150px min-w-150px pe-3 border-start-0">
                                {{ __("Kondisi") }}
                            </th>
                            <th class="w-75px min-w-75px pe-3 border-start-0">
                                {{ __("Parameter") }}
                            </th>
                            <th class="w-75px min-w-75px pe-3 border-start-0">{{ __("Prev Step") }}</th>
                            <th class="w-75px min-w-75px pe-3 border-start-0">{{ __("Next Step") }}</th>
                            <th class="w-100px min-w-100px pe-3 border-start-0">{{ __("Kontrol") }}</th>
                        </tr>
                        </thead>
                        <tbody class="align-middle">
                        @forelse(collect($approval["groups"])->sortBy("order") as $group_index => $group)
                            @if (!$loop->first)
                                <tr>
                                    <td class="p-0 bg-dark" colspan="8"></td>
                                </tr>
                            @endif
                            <tr>
                                <td class="text-end">{{ $loop->iteration }}</td>
                                <td class="text-end">{{ $group["order"] }}</td>
                                <td colspan="3"></td>
                                <td class="text-end">{{ $group["step_prev"] }}</td>
                                <td class="text-end">{{ $group["step_next"] }}</td>
                                <td class="text-end py-0">
                                    @can("{$app_path}.update")
                                        <a href="#"
                                           wire:click="editGroup({{ $group_index }})">
                                            <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                                  title="{{ __("Ubah") }}"
                                                  data-bs-toggle="tooltip"
                                                  data-bs-trigger="hover"
                                                  data-bs-dismiss="click">
                                                <img src="{{ asset("assets/media/icons/table-edit.png") }}"
                                                     class="w-15px">
                                            </span>
                                        </a>
                                    @endcan
                                    @can("{$app_path}.delete")
                                        <a href="#"
                                           class="swal-livewire-confirm"
                                           data-message="{{ __("Konfirmasi hapus grup dipilih.") }}"
                                           data-event="destroyGroup"
                                           data-target="{{ $group_index }}"
                                           data-loader="true">
                                            <span class="btn btn-sm btn-icon btn-color-danger btn-active-light-danger"
                                                  title="{{ __("Hapus") }}"
                                                  data-bs-toggle="tooltip"
                                                  data-bs-trigger="hover"
                                                  data-bs-dismiss="click">
                                                <img src="{{ asset("assets/media/icons/table-delete.png") }}"
                                                     class="w-15px">
                                            </span>
                                        </a>
                                    @endcan
                                </td>
                            </tr>
                            <tr>
                                <td class="text-start bg-light"
                                    colspan="7">{{ __("Kondisi") }}</td>
                                <td class="text-end bg-light py-0">
                                    @can("{$app_path}.store")
                                        <a href="#"
                                           wire:click="editGroupCondition({{ $group_index }}, -1)">
                                            <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                                  title="{{ __("Tambah Kondisi") }}"
                                                  data-bs-toggle="tooltip"
                                                  data-bs-trigger="hover"
                                                  data-bs-dismiss="click">
                                                <img src="{{ asset("assets/media/icons/table-add.png") }}"
                                                     class="w-15px">
                                            </span>
                                        </a>
                                    @endcan
                                </td>
                            </tr>
                            @foreach($group["conditions"] as $condition_index => $condition)
                                <tr>
                                    <td class="text-end">-</td>
                                    <td class="text-end"
                                        colspan="2"></td>
                                    <td class="text-start">{{ $condition["dataset"] }} {{ $condition["operator"] }} {{ $condition["value"] }}</td>
                                    <td class="text-center">{{ $condition["join"] }}</td>
                                    <td class="text-end"
                                        colspan="2"></td>
                                    <td class="text-end py-0">
                                        @can("{$app_path}.update")
                                            <a href="#"
                                               wire:click="editGroupCondition({{ $group_index }}, {{ $condition_index }})">
                                                <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                                      title="{{ __("Ubah") }}"
                                                      data-bs-toggle="tooltip"
                                                      data-bs-trigger="hover"
                                                      data-bs-dismiss="click">
                                                    <img src="{{ asset("assets/media/icons/table-edit.png") }}"
                                                         class="w-15px">
                                                </span>
                                            </a>
                                        @endcan
                                        @can("{$app_path}.delete")
                                            <a href="#"
                                               class="swal-livewire-confirm"
                                               data-message="{{ __("Konfirmasi hapus kondisi dipilih.") }}"
                                               data-event="destroyGroupCondition"
                                               data-target="{{ $group_index }}_{{ $condition_index }}"
                                               data-loader="true">
                                                <span class="btn btn-sm btn-icon btn-color-danger btn-active-light-danger"
                                                      title="{{ __("Hapus") }}"
                                                      data-bs-toggle="tooltip"
                                                      data-bs-trigger="hover"
                                                      data-bs-dismiss="click">
                                                    <img src="{{ asset("assets/media/icons/table-delete.png") }}"
                                                         class="w-15px">
                                                </span>
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                            <tr>
                                <td class="text-start bg-light"
                                    colspan="7">{{ __("Aktor") }}</td>
                                <td class="text-end bg-light py-0">
                                    @can("{$app_path}.store")
                                        <a href="#"
                                           wire:click="editGroupActor({{ $group_index }}, -1)">
                                            <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                                  title="{{ __("Tambah Aktor") }}"
                                                  data-bs-toggle="tooltip"
                                                  data-bs-trigger="hover"
                                                  data-bs-dismiss="click">
                                                <img src="{{ asset("assets/media/icons/table-add.png") }}"
                                                     class="w-15px">
                                            </span>
                                        </a>
                                    @endcan
                                </td>
                            </tr>
                            @foreach(collect($group["actors"])->sortBy("operator") as $actor_index => $actor)
                                <tr>
                                    <td class="text-end">-</td>
                                    <td class="text-end"></td>
                                    <td class="text-start">{{ $actor["reference"]["name"] ?? "" }}</td>
                                    <td class="text-end"></td>
                                    <td class="text-start">{{ $actor["operator"] }}</td>
                                    <td class="text-end"
                                        colspan="2"></td>
                                    <td class="text-end py-0">
                                        @can("{$app_path}.update")
                                            <a href="#"
                                               wire:click="editGroupActor({{ $group_index }}, {{ $actor_index }})">
                                                <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                                      title="{{ __("Ubah") }}"
                                                      data-bs-toggle="tooltip"
                                                      data-bs-trigger="hover"
                                                      data-bs-dismiss="click">
                                                    <img src="{{ asset("assets/media/icons/table-edit.png") }}"
                                                         class="w-15px">
                                                </span>
                                            </a>
                                        @endcan
                                        @can("{$app_path}.delete")
                                            <a href="#"
                                               class="swal-livewire-confirm"
                                               data-message="{{ __("Konfirmasi hapus aktor dipilih.") }}"
                                               data-event="destroyGroupActor"
                                               data-target="{{ $group_index }}_{{ $actor_index }}"
                                               data-loader="true">
                                                <span class="btn btn-sm btn-icon btn-color-danger btn-active-light-danger"
                                                      title="{{ __("Hapus") }}"
                                                      data-bs-toggle="tooltip"
                                                      data-bs-trigger="hover"
                                                      data-bs-dismiss="click">
                                                    <img src="{{ asset("assets/media/icons/table-delete.png") }}"
                                                         class="w-15px">
                                                </span>
                                            </a>
                                        @endcan
                                    </td>
                                </tr>
                            @endforeach
                        @empty
                            <tr>
                                <td class="p-4 text-center bg-light"
                                    colspan="8">{{ __("Tidak ada data grup") }}</td>
                            </tr>
                        @endforelse
                        </tbody>
                    </table>

                    <div class="fs-8 text-muted mt-4">{{ __("Nilai 0 digunakan untuk status reject, nilai 99 digunakan untuk status approved") }}</div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
