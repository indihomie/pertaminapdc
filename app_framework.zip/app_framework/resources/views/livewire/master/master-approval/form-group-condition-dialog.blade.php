<div id="modal_form_group_condition"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-sm modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="saveGroupCondition"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ __("Grup Kondisi") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Dataset") }}</label>
                        <div>
                            <select class="form-select"
                                    data-controls="select2"
                                    data-allow-clear="true"
                                    data-placeholder="{{ __("- Pilih Dataset -") }}"
                                    data-dropdown-parent="#modal_form_group_condition"
                                    wire:model.defer="approval_group_condition.dataset">
                                <option value=""></option>
                                @foreach(explode(",", $approval["dataset"]) as $dataset)
                                    <option value="{{ $dataset }}">{{ $dataset }}</option>
                                @endforeach
                            </select>
                        </div>
                        <x-input-error for="approval_group_condition.dataset"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Operator") }}</label>
                        <div wire:ignore>
                            <select class="form-select"
                                    data-controls="select2"
                                    data-allow-clear="true"
                                    data-placeholder="{{ __("- Pilih Operator -") }}"
                                    data-dropdown-parent="#modal_form_group_condition"
                                    wire:model.defer="approval_group_condition.operator">
                                <option value=""></option>
                                @foreach($operators as $operator)
                                    <option value="{{ $operator }}">{{ $operator }}</option>
                                @endforeach
                            </select>
                        </div>
                        <x-input-error for="approval_group_condition.operator"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Nilai") }}</label>
                        <div class="">
                            <input type="text"
                                   class="form-control"
                                   placeholder=""
                                   wire:model.defer="approval_group_condition.value">
                        </div>
                        <x-input-error for="approval_group_condition.value"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Relasi Operator") }}</label>
                        <div wire:ignore>
                            <select class="form-select"
                                    data-controls="select2"
                                    data-allow-clear="true"
                                    data-placeholder="{{ __("- Pilih Relasi Operator -") }}"
                                    data-dropdown-parent="#modal_form_group_condition"
                                    wire:model.defer="approval_group_condition.join">
                                <option value=""></option>
                                @foreach($operator_simples as $operator)
                                    <option value="{{ $operator }}">{{ $operator }}</option>
                                @endforeach
                            </select>
                        </div>
                        <x-input-error for="approval_group_condition.join"/>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
