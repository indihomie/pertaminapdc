<div id="modal_form_group"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-sm modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="saveGroup"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ __("Grup Approval") }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body py-0 px-8">

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Urut") }}</label>
                        <div class="position-relative"
                             data-kt-dialer="true"
                             data-kt-dialer-min="1"
                             data-kt-dialer-max="99"
                             data-kt-dialer-step="1"
                             wire:ignore>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 start-0"
                                    data-kt-dialer-control="decrease">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen036.svg") !!}
                                </span>
                            </button>
                            <input type="text"
                                   id="test-event"
                                   class="form-control form-control-solid border-0 ps-12"
                                   data-kt-dialer-control="input"
                                   wire:model.defer="approval_group.order"
                                   readonly/>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 end-0"
                                    data-kt-dialer-control="increase">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen035.svg") !!}
                                </span>
                            </button>
                        </div>
                        <x-input-error for="approval_group.order"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Step Prev") }}</label>
                        <div class="position-relative"
                             data-kt-dialer="true"
                             data-kt-dialer-min="0"
                             data-kt-dialer-max="98"
                             data-kt-dialer-step="1"
                             wire:ignore>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 start-0"
                                    data-kt-dialer-control="decrease">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen036.svg") !!}
                                </span>
                            </button>
                            <input type="text"
                                   id="test-event"
                                   class="form-control form-control-solid border-0 ps-12"
                                   data-kt-dialer-control="input"
                                   wire:model.defer="approval_group.step_prev"/>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 end-0"
                                    data-kt-dialer-control="increase">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen035.svg") !!}
                                </span>
                            </button>
                        </div>
                        <x-input-error for="approval_group.step_prev"/>
                    </div>

                    <div class="fv-row mb-4">
                        <label class="form-label">{{ __("Step Prev") }}</label>
                        <div class="position-relative"
                             data-kt-dialer="true"
                             data-kt-dialer-min="0"
                             data-kt-dialer-max="99"
                             data-kt-dialer-step="1"
                             wire:ignore>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 start-0"
                                    data-kt-dialer-control="decrease">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen036.svg") !!}
                                </span>
                            </button>
                            <input type="text"
                                   id="test-event"
                                   class="form-control form-control-solid border-0 ps-12"
                                   data-kt-dialer-control="input"
                                   wire:model.defer="approval_group.step_next"/>
                            <button type="button"
                                    class="btn btn-icon btn-active-color-gray-700 position-absolute translate-middle-y top-50 end-0"
                                    data-kt-dialer-control="increase">
                                <span class="svg-icon svg-icon-1">
                                    {!! asset_svg("assets/media/icons/duotune/general/gen035.svg") !!}
                                </span>
                            </button>
                        </div>
                        <x-input-error for="approval_group.step_next"/>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
