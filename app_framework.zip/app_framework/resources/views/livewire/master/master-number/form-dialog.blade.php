<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     data-bs-focus="false"
     wire:ignore.self>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                         data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                        </span>
                    </div>
                </div>

                <div class="modal-body pt-0 px-8">

                    <div class="row">
                        <div class="col-md-7">

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Kode") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control text-uppercase"
                                           placeholder=""
                                           wire:model.defer="number.code">
                                </div>
                                <x-input-error for="number.code"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Nama") }}</label>
                                <div class="w-250px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           wire:model.defer="number.name">
                                </div>
                                <x-input-error for="number.name"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Delimiter") }}</label>
                                <div class="w-200px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Tanpa Pemisah -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model.defer="number.delimiter">
                                        <option value=""></option>
                                        @foreach($delimiters as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.delimiter"/>
                            </div>

                        </div>
                        <div class="col-md-7">

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Deskripsi") }}</label>
                                <div>
                                    <textarea type="text"
                                              class="form-control min-h-100px"
                                              placeholder=""
                                              wire:model.defer="number.description"></textarea>
                                </div>
                                <x-input-error for="number.margin_top"/>
                            </div>

                            <div class="fs-8 text-danger">{{ __("Urutan tahun / bulan / sequence akan tereset apabila berubah") }}</div>

                        </div>
                    </div>

                    <div class="my-4 separator separator-dashed"></div>

                    <div class="row mb-4">
                        <div class="col-md-4">

                            <div class="fv-row">
                                <label class="form-label">{{ __("Parameter 1") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_1">
                                        @foreach($types as $_key => $_value)
                                            @continue($_key == "")
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_1"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_1"] == \App\Models\AppFormatNumber::TYPE_YEAR ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_1_type">
                                        <option value=""></option>
                                        @foreach($type_years as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_1_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_1"] == \App\Models\AppFormatNumber::TYPE_MONTH ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_1_type">
                                        <option value=""></option>
                                        @foreach($type_months as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_1_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_1"] == \App\Models\AppFormatNumber::TYPE_CODE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Kode") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_1_type">
                                </div>
                                <x-input-error for="number.parameter_1_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_1"] == \App\Models\AppFormatNumber::TYPE_SEQUENCE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Panjang") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="9"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_1_type">
                                </div>
                                <x-input-error for="number.parameter_1_type"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_1"] == \App\Models\AppFormatNumber::TYPE_CODE ? "d-none" : "" }}">
                                <label class="form-label">{{ __("Nilai") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_1_value">
                                </div>
                                <x-input-error for="number.parameter_1_value"/>
                            </div>

                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-4">

                            <div class="fv-row">
                                <label class="form-label">{{ __("Parameter 2") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_2">
                                        @foreach($types as $_key => $_value)
                                            @continue($_key == "")
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_2"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_2"] == \App\Models\AppFormatNumber::TYPE_YEAR ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_2_type">
                                        <option value=""></option>
                                        @foreach($type_years as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_2_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_2"] == \App\Models\AppFormatNumber::TYPE_MONTH ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_2_type">
                                        <option value=""></option>
                                        @foreach($type_months as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_2_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_2"] == \App\Models\AppFormatNumber::TYPE_CODE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Kode") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_2_type">
                                </div>
                                <x-input-error for="number.parameter_2_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_2"] == \App\Models\AppFormatNumber::TYPE_SEQUENCE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Panjang") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="9"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_2_type">
                                </div>
                                <x-input-error for="number.parameter_2_type"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_2"] == \App\Models\AppFormatNumber::TYPE_CODE ? "d-none" : "" }}">
                                <label class="form-label">{{ __("Nilai") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_2_value">
                                </div>
                                <x-input-error for="number.parameter_2_value"/>
                            </div>

                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-4">

                            <div class="fv-row">
                                <label class="form-label">{{ __("Parameter 3") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_3">
                                        @foreach($types as $_key => $_value)
                                            @continue($_key == "")
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_3"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_3"] == \App\Models\AppFormatNumber::TYPE_YEAR ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_3_type">
                                        <option value=""></option>
                                        @foreach($type_years as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_3_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_3"] == \App\Models\AppFormatNumber::TYPE_MONTH ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_3_type">
                                        <option value=""></option>
                                        @foreach($type_months as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_3_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_3"] == \App\Models\AppFormatNumber::TYPE_CODE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Kode") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_3_type">
                                </div>
                                <x-input-error for="number.parameter_3_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_3"] == \App\Models\AppFormatNumber::TYPE_SEQUENCE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Panjang") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="9"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_3_type">
                                </div>
                                <x-input-error for="number.parameter_3_type"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_3"] == \App\Models\AppFormatNumber::TYPE_CODE ? "d-none" : "" }}">
                                <label class="form-label">{{ __("Nilai") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_3_value">
                                </div>
                                <x-input-error for="number.parameter_3_value"/>
                            </div>

                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-4">

                            <div class="fv-row">
                                <label class="form-label">{{ __("Parameter 4") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Kosong -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_4">
                                        @foreach($types as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_4"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_4"] == \App\Models\AppFormatNumber::TYPE_YEAR ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_4_type">
                                        <option value=""></option>
                                        @foreach($type_years as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_4_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_4"] == \App\Models\AppFormatNumber::TYPE_MONTH ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_4_type">
                                        <option value=""></option>
                                        @foreach($type_months as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_4_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_4"] == \App\Models\AppFormatNumber::TYPE_CODE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Kode") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_4_type">
                                </div>
                                <x-input-error for="number.parameter_4_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_4"] == \App\Models\AppFormatNumber::TYPE_SEQUENCE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Panjang") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="9"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_4_type">
                                </div>
                                <x-input-error for="number.parameter_4_type"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ !$number["parameter_4"] || $number["parameter_4"] == \App\Models\AppFormatNumber::TYPE_CODE ? "d-none" : "" }}">
                                <label class="form-label">{{ __("Nilai") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_4_value">
                                </div>
                                <x-input-error for="number.parameter_4_value"/>
                            </div>

                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-4">

                            <div class="fv-row">
                                <label class="form-label">{{ __("Parameter 5") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Kosong -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_5">
                                        @foreach($types as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_5"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ $number["parameter_5"] == \App\Models\AppFormatNumber::TYPE_YEAR ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_5_type">
                                        <option value=""></option>
                                        @foreach($type_years as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_5_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_5"] == \App\Models\AppFormatNumber::TYPE_MONTH ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Tipe") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Tipe -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model="number.parameter_5_type">
                                        <option value=""></option>
                                        @foreach($type_months as $_key => $_value)
                                            <option value="{{ $_key }}">{{ $_value }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="number.parameter_5_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_5"] == \App\Models\AppFormatNumber::TYPE_CODE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Kode") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_5_type">
                                </div>
                                <x-input-error for="number.parameter_5_type"/>
                            </div>

                            <div class="fv-row {{ $number["parameter_5"] == \App\Models\AppFormatNumber::TYPE_SEQUENCE ? "" : "d-none" }}">
                                <label class="form-label">{{ __("Panjang") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="9"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_5_type">
                                </div>
                                <x-input-error for="number.parameter_5_type"/>
                            </div>

                        </div>
                        <div class="col-md-5">

                            <div class="fv-row {{ !$number["parameter_5"] || $number["parameter_5"] == \App\Models\AppFormatNumber::TYPE_CODE ? "d-none" : "" }}">
                                <label class="form-label">{{ __("Nilai") }}</label>
                                <div class="w-150px"
                                     wire:ignore>
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-mask="********"
                                           data-unmask="true"
                                           wire:model.defer="number.parameter_5_value">
                                </div>
                                <x-input-error for="number.parameter_5_value"/>
                            </div>

                        </div>
                    </div>

                </div>

                <div class="modal-footer pt-0 border-top-0">
                    <a class="btn btn-light btn-active-light-primary"
                       href="#"
                       data-bs-dismiss="modal">{{ __("Batal") }}</a>
                    @canany(["{$app_path}.create", "{$app_path}.update"])
                        <button type="submit"
                                class="btn btn-primary ms-2">
                            {{ __("Simpan") }}
                        </button>
                    @endcanany
                </div>

            </form>

        </div>

    </div>

</div>
