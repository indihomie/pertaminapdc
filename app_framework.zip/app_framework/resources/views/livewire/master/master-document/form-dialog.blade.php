<div id="modal_form"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     data-bs-focus="false"
     wire:ignore.self>

    <div class="modal-dialog modal-dialog-centered"
         style="min-width: 1180px;">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <form action="#"
                  method="post"
                  wire:submit.prevent="save"
                  autocomplete="off">

                <div class="modal-header p-8 border-bottom-0">
                    <h3 class="modal-title">
                        {{ $app_menu->name }}
                        <div class="w-30px border border-bottom border-primary"></div>
                    </h3>
                    <div>
                        @canany(["{$app_path}.create", "{$app_path}.update"])
                            <button type="submit"
                                    class="btn btn-sm btn-primary">
                                {{ __("Simpan") }}
                            </button>
                        @endcanany
                        <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                             data-bs-dismiss="modal">
                            <span class="svg-icon svg-icon-2x">
                                {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                            </span>
                        </div>
                    </div>
                </div>

                <div class="modal-body pt-0 px-8">

                    <div class="row">
                        <div class="col-md-6">

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Kode") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control text-uppercase"
                                           placeholder=""
                                           wire:model.defer="document.code">
                                </div>
                                <x-input-error for="document.code"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label required">{{ __("Nama") }}</label>
                                <div class="w-250px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           wire:model.defer="document.name">
                                </div>
                                <x-input-error for="document.name"/>
                            </div>

                            <div class="fv-row mb-8">
                                <label class="form-label">{{ __("Kertas") }}</label>
                                <div class="w-300px"
                                     wire:ignore>
                                    <select class="form-select"
                                            data-controls="select2"
                                            data-allow-clear="true"
                                            data-placeholder="{{ __("- Pilih Kertas -") }}"
                                            data-dropdown-parent="#modal_form"
                                            wire:model.defer="document.paper_id"
                                            onchange="updatePaper(this.value)">
                                        <option value=""></option>
                                        @foreach($papers->sortBy("code") as $_paper)
                                            <option value="{{ $_paper->id }}">{{ $_paper->id }} - {{ $_paper->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <x-input-error for="document.paper_id"/>
                            </div>

                            <x-input-error for="document.content"/>

                        </div>
                        <div class="col-md-4">

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Margin Atas") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="999"
                                           data-unmask="true"
                                           wire:model.defer="document.margin_top">
                                </div>
                                <x-input-error for="document.margin_top"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Margin Bawah") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="999"
                                           data-unmask="true"
                                           wire:model.defer="document.margin_bottom">
                                </div>
                                <x-input-error for="document.margin_bottom"/>
                            </div>

                        </div>
                        <div class="col-md-4">

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Margin Kanan") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="999"
                                           data-unmask="true"
                                           wire:model.defer="document.margin_right">
                                </div>
                                <x-input-error for="document.margin_right"/>
                            </div>

                            <div class="fv-row mb-4">
                                <label class="form-label">{{ __("Margin Kiri") }}</label>
                                <div class="w-150px">
                                    <input type="text"
                                           class="form-control"
                                           placeholder=""
                                           data-controls="mask"
                                           data-numeric="true"
                                           data-mask="999"
                                           data-unmask="true"
                                           wire:model.defer="document.margin_left">
                                </div>
                                <x-input-error for="document.margin_left"/>
                            </div>

                        </div>
                    </div>

                    <div class="fs-7 text-muted text-center">
                        {{ __("Apabila menggunakan tab source, silahkan update WYSIWYG untuk mentrigger perubahan") }}
                    </div>
                    <div class="d-flex justify-content-center"
                         wire:ignore>
                        <textarea id="editor"
                                  class="box-border border border border-solid border-gray-300"
                                  wire:model.defer="document.content"></textarea>
                    </div>

                </div>

            </form>

        </div>

    </div>

</div>
