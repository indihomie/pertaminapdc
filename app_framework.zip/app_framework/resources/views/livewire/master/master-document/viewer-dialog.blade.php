<div id="modal_view"
     class="modal fade"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false"
     wire:ignore.self>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content overlay overlay-block overlay-hidden"
             wire:loading.class.remove="overlay-hidden">

            <div class="overlay-layer z-index-1 bg-light bg-opacity-50 rounded">
                <div class="spinner-border text-primary" role="status"></div>
            </div>

            <div class="modal-header py-3 border-bottom-0">
                <h3 class="modal-title">
                    {{ $document["name"] ?: "Memuat..." }}
                    <div class="w-30px border border-bottom border-primary"></div>
                </h3>
                <div class="btn btn-icon btn-sm btn-active-light-primary ms-2"
                     data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-2x">
                        {!! asset_svg("assets/media/icons/duotune/arrows/arr061.svg") !!}
                    </span>
                </div>
            </div>

            <iframe src="{{ $document_stream }}"
                    class="modal-body p-0 w-100"
                    style="height: 80vh; margin: 0"></iframe>

        </div>

    </div>

</div>
