<div class="livewire">

    <div class="mb-8">
        <div class="fs-2 fw-bold">
            {{ $app_menu->name }}
            <div class="w-30px border border-bottom border-primary"></div>
        </div>
    </div>

    <div class="d-flex flex-column flex-lg-row justify-content-between mb-4">
        <div class="d-flex mb-4 mb-lg-0">

            <div class="d-flex align-items-center position-relative">
                <span class="svg-icon svg-icon-1 position-absolute ms-4">
                    {!! asset_svg("assets/media/icons/duotune/general/gen021.svg") !!}
                </span>
                <input type="text"
                       class="form-control form-control-solid w-250px ps-15"
                       placeholder="{{ __("Cari") }}"
                       wire:model.debounce.500ms="search"/>
            </div>

        </div>
        <div class="d-flex">
            @can("{$app_path}.store")
                <a href="#"
                   class="btn btn-primary"
                   data-bs-toggle="modal"
                   data-bs-target="#modal_form"
                   wire:click="create">
                    <span class="svg-icon svg-icon-2">
                        {!! asset_svg("assets/media/icons/duotune/arrows/arr075.svg") !!}
                    </span>
                    {{ __("Tambah") }}
                </a>
            @endcan
        </div>
    </div>

    <div class="dataTables_wrapper">
        <div class="table-responsive table-loading">
            <div class="table-loading-message d-none"
                 wire:loading.class.remove="d-none">
                {{ __("Loading...") }}
            </div>
            <table class="table table-row-dashed table-hover dataTable gy-3 gx-3">
                <thead class="fs-7 fw-bolder text-gray-800 text-uppercase border border-dashed user-select-none">
                <tr class="align-middle text-center">
                    <th class="w-30px pe-3">#</th>
                    <th class="w-125px min-w-125px pe-3 border-start-0 sorting {{ $sortBy == "id" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : "" }}"
                        wire:click="sortBy('id')">
                        {{ __("Kode") }}
                    </th>
                    <th class="w-auto min-w-auto pe-3 border-start-0 sorting {{ $sortBy == "name" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : "" }}"
                        wire:click="sortBy('name')">
                        {{ __("Nama") }}
                    </th>
                    <th class="w-125px min-w-125px pe-3 border-start-0 sorting {{ $sortBy == "updated_at" ? ($sortAsc ? "sorting_asc" : "sorting_desc") : "" }}"
                        wire:click="sortBy('updated_at')">{{ __("Diubah") }}</th>
                    <th class="w-150px min-w-150px pe-3 border-start-0">{{ __("Diubah Oleh") }}</th>
                    <th class="w-125px min-w-125px pe-3 border-start-0">{{ __("Kontrol") }}</th>
                </tr>
                </thead>
                <tbody class="">
                @forelse($numbers as $_number)
                    <tr class="align-middle">
                        <td class="text-end">{{ $loop->iteration }}.</td>
                        <td class="text-center">{{ $_number->code }}</td>
                        <td class="text-start">{{ $_number->name }}</td>
                        <td class="text-center fs-7 font-monospace">{{ $_number->updated_at->format("d/m/Y H:i") }}</td>
                        <td class="text-start fs-8">{{ $_number->updatedBy->name ?? "-" }}</td>
                        <td class="text-end">
                            @can("{$app_path}.update")
                                <a href="#"
                                   data-bs-toggle="modal"
                                   data-bs-target="#modal_form"
                                   wire:click="edit('{{ $_number->id }}')">
                                    <span class="btn btn-sm btn-icon btn-color-primary btn-active-light-primary"
                                          title="{{ __("Ubah") }}"
                                          data-bs-toggle="tooltip"
                                          data-bs-trigger="hover"
                                          data-bs-dismiss="click">
                                        <img src="{{ asset("assets/media/icons/table-edit.png") }}"
                                             class="w-15px">
                                    </span>
                                </a>
                            @endcan
                            @can("{$app_path}.delete")
                                <a href="#"
                                   class="swal-livewire-confirm"
                                   data-message="{{ __("Konfirmasi hapus format penomoran dipilih.") }}"
                                   data-event="destroy"
                                   data-target="{{ $_number->id }}"
                                   data-loader="true">
                                    <span class="btn btn-sm btn-icon btn-color-danger btn-active-light-danger"
                                          title="{{ __("Hapus") }}"
                                          data-bs-toggle="tooltip"
                                          data-bs-trigger="hover"
                                          data-bs-dismiss="click">
                                        <img src="{{ asset("assets/media/icons/table-delete.png") }}"
                                             class="w-15px">
                                    </span>
                                </a>
                            @endcan
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6"
                            class="p-6 bg-light text-center text-gray-600">
                            {{ __("Tidak ada data") }}
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-start">
                <div class="dataTables_length me-5"
                     wire:ignore>
                    <select class="form-select form-select-solid w-80px"
                            data-controls="select2"
                            data-search="false"
                            wire:model="perPage">
                        @foreach(config("paramter.pagination") as $_key => $_value)
                            <option value="{{ $_key }}">{{ $_value }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="dataTables_info fs-6 fw-bold text-gray-700">
                    {{ __("Showing")  }} {{ $numbers->firstItem() }} {{ __("to") }} {{ $numbers->lastItem() }} {{ __("of") }} {{ $numbers->total() }} {{ __("entries") }}
                </div>
            </div>
            <div class="dataTables_paginate ms-0 col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
                {{ $numbers->links() }}
            </div>
        </div>
    </div>

    @include("livewire.master.master-number.form-dialog")

</div>
