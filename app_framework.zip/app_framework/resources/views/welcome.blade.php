@extends("app.app")

@push("title", $app_information->company)
@push("body-class", "bg-white")

@push("style")
    <style>
        @keyframes animated_text {
            to {
                background-position: 200% center;
            }
        }
    </style>
@endpush

@section("body")
    <div class="d-flex flex-column flex-root">

        <div id="home"
             class="mb-0">

            <div class="bgi-no-repeat bgi-size-contain bgi-position-x-center bgi-position-y-bottom landing-dark-bg"
                 style="background-image: url('{{ asset("assets/media/svg/illustrations/landing.svg") }}')">

                <div class="landing-header"
                     data-kt-sticky="true"
                     data-kt-sticky-name="landing-header"
                     data-kt-sticky-offset="{default: '200px', lg: '300px'}">

                    <div class="container">
                        <div class="d-flex align-items-center justify-content-between">

                            <div class="d-flex align-items-center flex-equal">
                                <button id="kt_landing_menu_toggle"
                                        class="btn btn-icon btn-active-color-primary me-3 d-flex d-lg-none">
                                    <span class="svg-icon svg-icon-2hx">
                                        {!! asset_svg("assets/media/icons/duotune/abstract/abs015.svg") !!}
                                    </span>
                                </button>
                                <a href="#">
                                    <img src="{{ asset("assets/info/logo.png") }}"
                                         class="logo-default h-30px h-lg-35px"
                                         style="filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(93deg) brightness(103%) contrast(103%);"
                                         alt="Logo"/>
                                    <img src="{{ asset("assets/info/logo.png") }}"
                                         class="logo-sticky h-30px h-lg-35px"
                                         alt="Logo"/>
                                </a>
                            </div>

                            <div id="kt_header_nav_wrapper"
                                 class="d-lg-block">
                                <div class="d-lg-block p-5 p-lg-0"
                                     data-kt-drawer="true"
                                     data-kt-drawer-name="landing-menu"
                                     data-kt-drawer-activate="{default: true, lg: false}"
                                     data-kt-drawer-overlay="true"
                                     data-kt-drawer-width="200px"
                                     data-kt-drawer-direction="start"
                                     data-kt-drawer-toggle="#kt_landing_menu_toggle"
                                     data-kt-swapper="true"
                                     data-kt-swapper-mode="prepend"
                                     data-kt-swapper-parent="{default: '#kt_body', lg: '#kt_header_nav_wrapper'}">
                                    <div id="kt_landing_menu"
                                         class="menu menu-column flex-nowrap menu-rounded menu-lg-row menu-title-gray-500 menu-state-title-primary nav nav-flush fs-5 fw-bold">
                                        <div class="menu-item">
                                            <a class="menu-link nav-link py-3 px-4 px-xxl-6"
                                               href="#home"
                                               data-kt-scroll-toggle="true"
                                               data-kt-drawer-dismiss="true">{{ __("Home") }}</a>
                                        </div>
                                        <div class="menu-item">
                                            <a class="menu-link nav-link py-3 px-4 px-xxl-6"
                                               href="#about-us"
                                               data-kt-scroll-toggle="true"
                                               data-kt-drawer-dismiss="true">{{ __("About Us") }}</a>
                                        </div>
                                        <div class="menu-item">
                                            <a class="menu-link nav-link py-3 px-4 px-xxl-6"
                                               href="#services"
                                               data-kt-scroll-toggle="true"
                                               data-kt-drawer-dismiss="true">{{ __("Services") }}</a>
                                        </div>
                                        <div class="menu-item">
                                            <a class="menu-link nav-link py-3 px-4 px-xxl-6"
                                               href="#clients"
                                               data-kt-scroll-toggle="true"
                                               data-kt-drawer-dismiss="true">{{ __("Our Clients") }}</a>
                                        </div>
                                        <div class="menu-item">
                                            <a class="menu-link nav-link py-3 px-4 px-xxl-6"
                                               href="#contact"
                                               data-kt-scroll-toggle="true"
                                               data-kt-drawer-dismiss="true">{{ __("Contact") }}</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>

                <div class="d-flex flex-column flex-center w-100 min-h-250px min-h-lg-400px px-9">
                    <div class="text-center mb-5 mb-lg-10 py-10 py-lg-20">
                        <h1 class="text-white lh-base fw-bolder fs-2x fs-lg-3x mb-15">
                            <span style="
                                        background: linear-gradient(to right, {{ $app_information->color_primary }} 20%, #FFF 40%, #FFF 60%, {{ $app_information->color_primary }} 80%);
                                        background-size: 200% auto;
                                        -webkit-background-clip: text;
                                        -webkit-text-fill-color: transparent;
                                        animation: animated_text 3s ease-in-out infinite;
                                        -moz-animation: animated_text 3s ease-in-out infinite;
                                        -webkit-animation: animated_text 3s ease-in-out infinite;
                                        ">
                                {{ $app_information->company }}
							</span>
                            <div class="fs-5 fw-light text-gray-300 w-auto w-lg-500px">
                                few people strive for deliver innovation in developing products and engineering services to develop solutions according to demand and even exceed customer expectations.
                            </div>
                        </h1>
                    </div>
                </div>

            </div>

        </div>

        <div id="about-us"
             class="mt-8"></div>

        <div class="container-xxl">

            <div class="bg-light bgi-size-cover bgi-position-center bgi-no-repeat min-h-300px card-rounded"
                 style="background-image: url('{{ asset("assets/media/stock/landing.jpg") }}');"></div>

            <div class="mt-8"></div>

            <h4 class="fs-1 text-gray-800 w-bolder mb-6">{{ __("About us") }}</h4>
            <p class="fs-5 text-gray-600">
                Sinergics. A group of people highly specialised in communicating with the Net, computer solutions and unusual marketing. We obsessivly seek solutions and details that bring
                competitive and economic advantages thorugh innovation. Internet was born. Not many knew what it was, even fewer believed in it. We were there
            </p>

            <div class="mt-16"></div>

            <div class="d-flex flex-column flex-lg-row">
                <div class="px-8">

                    <div class="w-125px h-175px my-0 mx-auto bgi-size-cover bgi-position-center bgi-no-repeat card-rounded"
                         style="background-image: url('{{ asset("assets/media/illustrations/sketchy-1/10.png") }}')"></div>

                </div>
                <div class="col-md-8 order-md-2">
                    <div class="fs-4 fw-bold text-gray-800">
                        {{ __("Mission") }}
                    </div>
                    <div class="order-md-2 fs-6 text-gray-600">
                        The markets are conversations.
                        <br>
                        Communication between people and with companies must improve.
                        <br>
                        Sinergics aims to create new information passageways.
                        With the Net, the technologies, the new approaches. Because time is the new currency and incomprehension is the
                        new threat.
                    </div>
                </div>
                <div class="col-md-4 order-md-3"></div>
            </div>

            <div class="mt-8"></div>

            <div class="d-flex flex-column flex-lg-row">
                <div class="px-8">

                    <div class="w-125px h-175px my-0 mx-auto bgi-size-cover bgi-position-center bgi-no-repeat card-rounded"
                         style="background-image: url('{{ asset("assets/media/illustrations/sketchy-1/4.png") }}')"></div>

                </div>
                <div class="">
                    <div class="fs-4 fw-bold text-gray-800">
                        {{ __("Philosophy") }}
                    </div>
                    <div class="order-md-1 fs-6 text-gray-600">
                        <p>In order-md of importance.</p>
                        <p>
                            <span class="fw-bold text-gray-700">Put good ideas into practice</span>
                            <br>
                            Study optimal solutions and realise them. The culture of thinking and doing. We all like planning and completing a good project. It brings true satisfaction.
                        </p>
                        <p>
                            <span class="fw-bold text-gray-700">Make a profit</span>
                            <br>
                            Sinergics is a business, and businesses exist to make a profit, otherwise they don't last long. Many won't talk about it. We like to be clear and include it in our
                            philosophy. In second place.
                        </p>
                        <p>
                            <span class="fw-bold text-gray-700">Be serene and concentrated</span>
                            <br>
                            Agitated, tense people create bad projects. We believe in speaking clearly, in listening carefully, in setting out and resolving the problems, in the positive
                            tension
                            at the conclusion of a project.
                        </p>
                    </div>
                </div>
            </div>

            <div class="mt-8"></div>

            <div class="d-flex flex-column flex-lg-row">
                <div class="mx-8">

                    <div class="w-125px h-175px my-0 mx-auto bgi-size-cover bgi-position-center bgi-no-repeat card-rounded"
                         style="background-image: url('{{ asset("assets/media/illustrations/sketchy-1/20.png") }}')"></div>

                </div>
                <div class="">
                    <div class="fs-4 fw-bold text-gray-800">
                        {{ __("Ethics") }}
                    </div>
                    <div class="order-md-2 fs-6 text-gray-600">
                        It is our habit to deal with the people who work with us and with our clients, guided by three principles:
                        <div class="mb-2"></div>
                        <ul>
                            <li>
                                Honesty
                                <p>We don't tell lies. Amongst ourselves and to our clients. We have learned that it is neither right nor useful.</p>
                            </li>
                            <li>
                                Coherence
                                <p>We are coherent with the values that we believe in. We propose solutions only when we are convinced they are right.</p>
                            </li>
                            <li>
                                Morality
                                <p>We appreciate and respect those who behave correctly. That's our way of working.</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="mt-8"></div>

            <div class="row">
                <div class="col"></div>
                <div class="col-md-10 fs-6 text-gray-600 text-center">
                    This may sound like a boy scout's promise, but we believe that being honest, coherent and moral is what makes our clients faithful and Sinergics a good company.
                </div>
                <div class="col"></div>
            </div>

        </div>

        <div id="services"
             class="mt-20"></div>

        <div class="container">

            <div class="text-center mb-8">
                <h3 class="fs-2hx text-dark mb-0"
                    data-kt-scroll-offset="{default: 125, lg: 150}">Services</h3>
                <div class="mb-5 fs-5 text-muted fw-bold">
                    Sinergics creates and realizes projects for web and digital media.
                </div>
                <div class="fs-6 text-muted">
                    The team is organised to handle the most diverse requests coming from the market: from a strategic proposal with a real USP to the creation of carefully selected contents.
                    SinergicsTM is subdivided into four areas, which handle the definition of goals, project implementation, the attainment of objectives and the changes to be made, if any.
                </div>
            </div>

            <div class="row g-8 mb-6">

                <div class="col-lg-5">
                    <div class="fs-2 fw-bolder text-dark mb-3">
                        Strategy Functional Design
                    </div>
                    <div class="fs-6 text-gray-500">
                        Deals principally with gathering and elaborating the client's needs during a dedicated briefing that highlights the salient characteristics and strategic objectives. On
                        the basis of the profile that emerges, draws up the guidelines according to which the service is developed.
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="fs-2 fw-bolder text-dark mb-3">
                        Design And Usability
                    </div>
                    <div class="fs-6 text-gray-500">
                        In this stage we move from the analysis to the individual contents of the overall <b>communication project</b>, which lead to the identification of the <b>graphic project</b>
                        and the <b>design</b> most functional for the objectives established.
                        For this purpose particular emphasis is placed on the analysis of usability, of user experience and accessibility.
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="fs-2 fw-bolder text-dark mb-3">
                        Technology And Production
                    </div>
                    <div class="fs-6 text-gray-500">
                        The aim of this area is to supply the <b>technical support necessary</b> for the creation of the sites; and to foresee the application and maintenance of the hardware/software
                        systems in use.
                    </div>
                </div>

            </div>

        </div>

        <div id="clients"
             class="mt-8"></div>

        <div class="py-16">
            <div class="container">

                <div class="text-center mb-12">
                    <h3 id="team"
                        class="fs-2hx text-dark mb-5"
                        data-kt-scroll-offset="{default: 100, lg: 150}">{{ __("Our Clients") }}</h3>
                </div>

                <div class="tns tns-default">

                    <div
                        data-tns="true"
                        data-tns-loop="true"
                        data-tns-swipe-angle="false"
                        data-tns-speed="2000"
                        data-tns-autoplay="true"
                        data-tns-autoplay-timeout="4000"
                        data-tns-controls="true"
                        data-tns-nav="false"
                        data-tns-items="1"
                        data-tns-center="false"
                        data-tns-dots="false"
                        data-tns-prev-button="#kt_team_slider_prev"
                        data-tns-next-button="#kt_team_slider_next"
                        data-tns-responsive="{1200: {items: 5}, 992: {items: 2}}">

                        <div class="d-block text-center tns-item">
                            <a class="octagon mx-auto d-flex w-200px h-200px bg-white bgi-no-repeat bgi-size-contain bgi-position-center shadow"
                               href="#clients"
                               style="background-image:url('{{ asset('assets/media/clients/vaniashowroom.png') }}')">
                            </a>
                        </div>

                        <div class="text-center tns-item">
                            <a class="octagon mx-auto d-flex w-200px h-200px bg-white bgi-no-repeat bgi-size-contain bgi-position-center shadow"
                               href="#clients"
                               style="background-image:url('{{ asset('assets/media/clients/epiwalk.png') }}')">
                            </a>
                        </div>

                        <div class="d-block text-center tns-item">
                            <a class="octagon mx-auto d-flex w-200px h-200px bg-white bgi-no-repeat bgi-size-contain bgi-position-center shadow"
                               href="#clients"
                               style="background-image:url('{{ asset('assets/media/clients/hariff.png') }}')">
                            </a>
                        </div>

                        <div class="d-block text-center tns-item">
                            <a class="octagon mx-auto d-flex w-200px h-200px bg-white bgi-no-repeat bgi-size-contain bgi-position-center shadow"
                               href="#clients"
                               style="background-image:url('{{ asset('assets/media/clients/bakrieland.png') }}')">
                            </a>
                        </div>

                        <div class="d-block text-center tns-item">
                            <a class="octagon mx-auto d-flex w-200px h-200px bg-white bgi-no-repeat bgi-size-contain bgi-position-center shadow"
                               href="#clients"
                               style="background-image:url('{{ asset('assets/media/clients/hollandbakery.png') }}')">
                            </a>
                        </div>

                        <div class="d-block text-center tns-item">
                            <a class="octagon mx-auto d-flex w-200px h-200px bg-white bgi-no-repeat bgi-size-contain bgi-position-center shadow"
                               href="#clients"
                               style="background-image:url('{{ asset('assets/media/clients/upj.png') }}')">
                            </a>
                        </div>

                    </div>

                    <button id="kt_team_slider_prev"
                            class="btn btn-icon btn-active-color-primary">
                        <span class="svg-icon svg-icon-3x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr074.svg") !!}
                        </span>
                    </button>

                    <button id="kt_team_slider_next"
                            class="btn btn-icon btn-active-color-primary">
                        <span class="svg-icon svg-icon-3x">
                            {!! asset_svg("assets/media/icons/duotune/arrows/arr071.svg") !!}
                        </span>
                    </button>

                </div>

            </div>
        </div>


        <div id="contact"
             class="mb-0">

            <div class="landing-curve landing-dark-color">
                <svg viewBox="15 -1 1470 48"
                     fill="none"
                     xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 48C4.93573 47.6644 8.85984 47.3311 12.7725 47H1489.16C1493.1 47.3311 1497.04 47.6644 1501 48V47H1489.16C914.668 -1.34764 587.282 -1.61174 12.7725 47H1V48Z"
                          fill="currentColor"></path>
                </svg>
            </div>

            <div class="landing-dark-bg pt-4">

                <div class="container">

                    <div class="row py-10 py-lg-20">
                        <div class="col-lg-6 pe-lg-16 mb-10 mb-lg-0">

                            <div class="rounded landing-dark-border p-9">
                                <h2 class="text-white">{{ __("Glad you found us") }}</h2>
                                <div class="fw-normal fs-5 text-gray-400">
                                    <a href="mailto:cakra@sinergics.net"
                                       class="text-white text-hover-primary">
                                        cakra@sinergics.net
                                    </a>
                                    <p>Jl. Pondok Kelapa 4b blok b12 number 10, Duren Sawit, Jakarta Timur</p>
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-6 ps-lg-16">

                            <div class="d-flex fw-bold flex-column ms-lg-20">
                                <h4 class="fw-bolder text-gray-400 mb-6">{{ __("Stay Connected") }}</h4>

                                <a class="mb-6"
                                   href="https://github.com/sinergics-developer"
                                   target="_blank">
                                    <img src="{{ asset("assets/media/svg/brand-logos/github.svg") }}"
                                         class="h-20px me-2"
                                         alt="Github"/>
                                    <span class="text-white text-hover-primary fs-5 mb-6">
                                        Github
                                    </span>
                                </a>

                                <a class="mb-6"
                                   href="https://gitlab.com/sinergics.developer"
                                   target="_blank">
                                    <img src="{{ asset("assets/media/svg/brand-logos/gitlab.svg") }}"
                                         class="h-20px me-2"
                                         alt="Gitlab"/>
                                    <span class="text-white text-hover-primary fs-5 mb-6">
                                        Gitlab
                                    </span>
                                </a>

                                <a class="mb-6"
                                   href="tel:628129930096">
                                        <span class="svg-icon svg-icon-1 me-1">
                                            {!! asset_svg("assets/media/icons/duotune/communication/com005.svg") !!}
                                        </span>
                                    <span class="text-white text-hover-primary fs-5 mb-6">
                                        +62 812 9930096
                                    </span>
                                </a>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="landing-dark-separator"></div>

                <div class="container">
                    <div class="d-flex flex-column align-items-center py-7 py-lg-10">
                        <span class="mx-5 fs-6 fw-bold text-gray-600 pt-1"
                              href="">© {{ now()->year }} {{ $app_information->company }}.</span>
                    </div>
                </div>

            </div>

        </div>
    </div>
@endsection
