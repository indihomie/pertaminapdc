<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content=""/>
    <meta name="keywords" content=""/>

    <title>{{ __("Dokumentasi") }}</title>

    <link rel="shortcut icon" href="{{ asset("favicon.ico") }}"/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Global Stylesheets Bundle -->
    <link rel="stylesheet" type="text/css" href="{{ asset("assets/css/webpack.build.css") }}"/>
    <!-- End Global Stylesheets Bundle -->

    <!-- Global Javascript Bundle -->
    <script type="text/javascript" src="{{ asset("assets/js/webpack.build.js") }}" defer></script>
    <!-- End Global Javascript Bundle -->

</head>
<body class="font-sans">

<div class="absolute top-2 right-2">
    <a class="w-6 h-6 p-2 rounded rounded-full flex justify-center items-center no-underline bg-gray-200 text-black"
       href="{{ url("/popup?page=documentation&id={$request["id"]}") }}">
        <i class="fa fa-times"></i>
    </a>
</div>

{!! Str::of($content)->markdown() !!}

</body>
</html>
