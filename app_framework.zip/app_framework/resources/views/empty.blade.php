@extends("main")

@push("content-class", "h-100 d-flex flex-center")

@section("content")
    <div class="text-center user-select-none">
        <img alt="info"
             class="w-200px h-200px"
             src="{{ asset("assets/media/illustrations/sigma-1/10.png") }}"
             loading="lazy">
        <div class="my-8"></div>
        <div class="fs-6 text-gray-600">{{ __("Halaman sedang dalam pengembangan") }}</div>
    </div>
@endsection
