@extends("main")

@section("content")

    @livewire(
        "app-master.master-parameter",
        compact("app_module", "app_module_sub", "app_menu", "app_path")
    )

@endsection
