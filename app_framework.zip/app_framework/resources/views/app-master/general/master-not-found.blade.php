@extends("main")

@push("content-class", "my-4 flex-column-fluid d-flex flex-column flex-center")

@section("content")

    <div class="mb-10 bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom w-300px min-h-200px"
         style="background-image: url('{{ asset("assets/media/illustrations/sigma-1/18-dark.png") }}')"></div>

    <div class="fw-bold fs-3 text-muted mb-15">
        {{ __("Master yang anda cari tidak ditemukan") }}
    </div>

@endsection
