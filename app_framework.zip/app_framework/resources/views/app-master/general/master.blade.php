@extends("main")

@section("content")

    @livewire(
        "app-master.general.master",
        compact("app_module", "app_module_sub", "app_menu", "app_path", "master_category")
    )

@endsection
