@extends("main")

@section("content")

    @livewire(
        "app-monitor.access-log",
        compact("app_module", "app_module_sub", "app_menu", "app_path")
    )

@endsection
