@extends("app.guest")

@push("title", "Password Reset")

@section("body")

    <div class="flex justify-center font-sans antialiased">

        <div class="w-96">
            <div class="mt-10"></div>
            <img class="w-64 block mx-auto"
                 src="{{ asset("storage/images/info/logo.png") }}"
                 loading="lazy"/>
            <div class="mt-8"></div>
            <div class="p-4 border border-solid border-gray-300 rounded">

                <form action="{{ route("password.update") }}" method="post" autocomplete="off">

                    @csrf
                    <input type="hidden" name="token" value="{{ request()->route('token') }}">

                    <h3 class="text-red-600">Buat Password Baru</h3>
                    <div class="text-md text-gray-500"></div>

                    <div class="h-6"></div>

                    @if (session()->get("success"))
                        <div class="
                            mb-4
                            block
                            text-sm text-left text-white
                            bg-green-500
                            flex
                            items-center
                            p-2
                            rounded-md
                          " role="alert">{{ session()->get("success") }}
                        </div>
                    @endif

                    @error("failed")
                    <div class="
                            mb-4
                            block
                            text-sm text-left text-white
                            bg-red-500
                            flex
                            items-center
                            p-2
                            rounded-md
                          " role="alert">{{ $message }}
                    </div>
                    @enderror

                    <div class="">
                        <div class="text-md font-bold">Email</div>
                        <input type="email"
                               name="email"
                               class="w-full box-border rounded border-2 hover:border-red-400 focus:border-red-400 shadow-none"
                               value="{{ request()->get("email") }}"
                               readonly/>
                        @error("email")
                        <div class="text-xs text-red-400 mb-1">{{ $message }}</div>
                        @enderror
                        <div class="text-xs text-gray-400">Masukan email akun anda.</div>
                    </div>

                    <div class="my-4"></div>

                    <div class="{{ session()->get("success") ? "hidden" : "" }}">
                        <div class="text-md font-bold">Password</div>
                        <input type="password"
                               name="password"
                               class="w-full box-border rounded border-2 hover:border-red-400 focus:border-red-400 shadow-none"/>
                        @error("password")
                        <div class="text-xs text-red-400 mb-1">{{ $message }}</div>
                        @enderror
                        <div class="text-xs text-gray-400">Gunakan 8 karakter atau lebih dan terdiri dari gabungan huruf, angka dan simbol.</div>
                    </div>

                    <div class="my-4"></div>

                    <div class="{{ session()->get("success") ? "hidden" : "" }}">
                        <div class="text-md font-bold">Password Kofirmasi</div>
                        <input type="password"
                               name="password_confirmation"
                               class="w-full box-border rounded border-2 hover:border-red-400 focus:border-red-400 shadow-none"/>
                        @error("password_confirmation")
                        <div class="text-xs text-red-400 mb-1">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="h-4"></div>

                    <div class="my-4 border-t border-solid border-gray-300"></div>

                    <div class="flex">
                        <button type="button"
                                class="py-2 px-4 bg-transparent hover:bg-red-100 border-red-500 rounded font-bold uppercase text-red-500">
                            Kembali
                        </button>
                        <div class="mx-1"></div>
                        <button type="submit"
                                class="flex-1 py-2 px-4 bg-red-500 hover:bg-red-600 rounded font-bold uppercase text-white {{ session()->get("success") ? "hidden" : "" }}">
                            Kirim
                        </button>
                    </div>

                </form>

            </div>
        </div>

    </div>

@endsection
