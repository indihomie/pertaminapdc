@extends("app.guest")

@push("title", "Masuk Aplikasi")

@push("body-class", "bg-body")

@section("body")
    <div class="d-flex flex-column flex-root">

        <div class="d-flex flex-column flex-lg-row flex-column-fluid">

            <div class="d-flex flex-column flex-lg-row-auto w-xl-600px position-xl-relative bg-secondary">

                <div class="d-flex flex-column position-xl-fixed top-0 bottom-0 w-xl-600px scroll-y">
                    <div class="d-flex flex-row-fluid flex-column text-center p-10 pt-lg-20">
                        <a class="py-9 mb-4"
                           href="{{ url("/") }}">
                            <img alt="Logo" src="{{ asset("assets/info/logo.png") }}"
                                 class="h-60px"
                                 loading="lazy"/>
                        </a>
                        <h1 class="fw-bolder fs-2 mb-4">
                            {{ $app_information->company }}
                        </h1>
                        <p class="fw-bold fs-3">
                            {{ $app_information->name }}
                        </p>
                    </div>
                    <div class="d-flex flex-row-auto bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom min-h-100px min-h-lg-350px"
                         style="background-image: url('{{ asset("assets/media/illustrations/sigma-1/7.png") }}')"></div>
                </div>

            </div>

            <div class="d-flex flex-column flex-lg-row-fluid">

                <div class="d-flex flex-center flex-column flex-column-fluid">
                    <div class="w-lg-500px p-10 p-lg-15 mx-auto">

                        <form action="{{ route("login") }}"
                              method="post"
                              class="form w-100"
                              novalidate="novalidate">

                            @csrf

                            <div class="text-center mb-12">
                                <h1 class="text-dark mb-4">{{ __("Masuk Aplikasi") }}</h1>
                                @if (\Laravel\Fortify\Features::enabled(\Laravel\Fortify\Features::registration()))
                                    <div class="text-gray-400">
                                        {{ __("Belum punya akun?") }}
                                        <a href="{{ route("register") }}"
                                           class="link-primary fw-bolder">{{ __("Buat Akun") }}</a>
                                    </div>
                                @endif
                            </div>

                            <div class="fv-row mb-6">
                                <label class="form-label fw-bolder text-dark">{{ __("Username") }}</label>
                                <div>
                                    <input type="text"
                                           name="username"
                                           class="form-control form-control-solid"
                                           autocomplete="off"/>
                                </div>
                                <x-input-error for="username"/>
                            </div>

                            <div class="fv-row mb-6">
                                <div class="d-flex flex-stack mb-2">
                                    <label class="form-label fw-bolder text-dark mb-0">{{ __("Password") }}</label>
                                    <a href="{{ route("password.request") }}"
                                       class="link-primary">{{ __("Lupa Sandi?") }}</a>
                                </div>
                                <div>
                                    <div>
                                        <input type="password"
                                               name="password"
                                               class="form-control form-control-solid"
                                               autocomplete="off"/>
                                    </div>
                                </div>
                                <x-input-error for="password"/>
                            </div>

                            <div class="fv-row mb-12">
                                <div class="form-check form-check-solid user-select-none">
                                    <input type="checkbox"
                                           name="remember"
                                           id="remember"
                                           class="form-check-input"
                                           value="">
                                    <label class="form-check-label"
                                           for="remember">{{ __("Ingat Saya") }}</label>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit"
                                        class="btn btn-primary w-100 mb-5">
                                    {{ __("Masuk") }}
                                </button>
                            </div>

                        </form>

                    </div>
                </div>

                @include("app.guest-footer")

            </div>

        </div>

    </div>
@endsection
