@props(["href", "ext", "title", "download"])

<a class="viewer"
   href="{{ $href }}"
   data-ext="{{ $ext }}"
   data-title="{{ $title }}"
   data-download="{{ $download }}">
    <img src="{{ $href }}"
         {{ $attributes->merge() }}
         loading="lazy">
</a>
