@props(["fors"])

@foreach($errors->messages() as $key => $messages)

    @continue(!in_array($key, $fors))

    @foreach($messages as $message)
        <div {{ $attributes->merge(['class' => 'fv-plugins-message-container invalid-feedback']) }}>{{ $message }}</div>
    @endforeach

@endforeach
