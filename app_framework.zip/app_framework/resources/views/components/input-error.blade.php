@props(["for"])

@error($for)
<div {{ $attributes->merge(['class' => 'fs-8 fv-plugins-message-container invalid-feedback']) }}>{{ $message }}</div>
@enderror
