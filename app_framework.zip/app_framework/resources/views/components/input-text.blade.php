@if(isset($label))
    <label class="{{ isset($required) ? 'required' : '' }} form-label">{{ $label }}</label>
 @endif
<input type="text"
           id="{{ $name }}"
           name="{{ $name }}"
           {{ $attributes->merge(['class' => 'form-control mb-2']) }}
           placeholder="{{ $placeholder ?? '' }}"
           value="{{ old($name, $value ?? '') }}"
/>
    @if(isset($hint))
        <div class="text-muted fs-7">{{ $hint }}</div>
    @endif
