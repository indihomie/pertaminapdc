@if(isset($label))
    <label class="{{ isset($required) ? 'required' : '' }} form-label">{{ $label }}</label>
@endif
<textarea id="{{ $name }}"
        name="{{ $name }}"
        {{ $attributes->merge(['class' => 'form-control mb-2']) }}
        >{{ old($name, $value ?? '') }}</textarea>
@if(isset($hint))
    <div class="text-muted fs-7">{{ $hint }}</div>
@endif
