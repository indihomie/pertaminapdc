@if(isset($label))
    <label class="{{ isset($required) ? 'required' : '' }} form-label">{{ $label }}</label>
@endif
<select
        {{ $attributes->merge(['class' => 'form-control mb-2']) }}
        id="{{ $name }}"
        name="{{ $name }}"
        data-control="select2"
        data-placeholder="{{ $all }}">
    <option></option>
    <option value="1">Option 1</option>
    <option value="2">Option 2</option>
</select>
@if(isset($hint))
    <div class="text-muted fs-7">{{ $hint }}</div>
@endif
