@if ($errors->any())
    <div {{ $attributes->merge(["class" => "notice d-flex bg-light-danger rounded border-danger border border-dashed p-6"]) }}>
        <span class="svg-icon svg-icon-2tx svg-icon-danger me-4">
            {!! asset_svg("assets/media/icons/duotune/general/gen044.svg") !!}
        </span>
        <div class="d-flex flex-stack flex-grow-1">
            <div class="fw-bold">
                <h4 class="text-gray-800 fw-bolder">{{ __('Whoops! Something went wrong.') }}</h4>
                @foreach ($errors->getMessages() as $key => $error)
                    <div class="fs-6 text-gray-600">
                        {{ $key }}
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endif
