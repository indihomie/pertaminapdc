@props(["href", "ext", "title", "download"])

<a {{ $attributes->class(["viewer"])->merge() }}
   href="{{ $href }}"
   data-ext="{{ $ext }}"
   data-title="{{ $title }}"
   data-download="{{ $download }}">
    <img src="{{ asset("/assets/media/extensions/{$ext}") }}"
         class="w-20px h-20px"
         loading="lazy">
</a>
