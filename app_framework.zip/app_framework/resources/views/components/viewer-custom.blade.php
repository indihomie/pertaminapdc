@props(["href", "ext", "title", "download"])

<a {{ $attributes->class(["viewer"])->merge() }}
   href="{{ $href }}"
   data-ext="{{ $ext }}"
   data-title="{{ $title }}"
   data-download="{{ $download }}">
    {{ $slot }}
</a>
