<?php

include resource_path("sources/global.php");
include resource_path("sources/index.php");
