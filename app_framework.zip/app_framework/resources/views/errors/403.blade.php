@extends("app.guest")

@push("title", __("Forbidden"))

@push("body-class", "bg-light")

@section("body")
    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid">

            <div class="d-flex flex-column flex-column-fluid text-center justify-content-center p-10 py-lg-15">

                <a href="{{ url("/") }}"
                   class="mb-10 pt-lg-10">
                    <img alt="Logo"
                         src="{{ asset("assets/info/logo.png") }}"
                         class="h-40px mb-5"
                         loading="lazy"/>
                </a>

                <div class="pt-lg-10 mb-10">

                    <div class="mb-10 d-flex flex-row-auto bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom min-h-200px"
                         style="background-image: url('{{ asset("assets/media/illustrations/sigma-1/5.png") }}')"></div>

                    <div class="fw-bold fs-3 text-muted mb-15">
                        {{ __("Sepertinya anda tidak punyak akses ke halaman ini.") }}
                    </div>

                    <div class="text-center">
                        <a href="{{ url("/home") }}" class="btn btn-lg btn-primary fw-bolder">{{ __("Kembali ke halaman utama") }}</a>
                    </div>

                </div>

            </div>

            @include("app.guest-footer")

        </div>
    </div>
@endsection
