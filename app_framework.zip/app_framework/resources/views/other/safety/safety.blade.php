@extends("main")

@section("content")

    @livewire(
        "other.safety.safety",
        compact("app_module", "app_module_sub", "app_menu", "app_path")
    )

@endsection
