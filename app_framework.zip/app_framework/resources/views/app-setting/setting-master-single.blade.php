@extends("main")

@push("content-class", "h-100 w-100")

@section("content")
    Setting master single {{ $app_menu->target }}
@endsection
