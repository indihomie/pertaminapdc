@extends("main")

@push("content-container-class", "bg-light")
@push("content-class", "my-4 container-xxl")

@section("content")

    <form action="" method="post"
          autocomplete="off"
          enctype="multipart/form-data">

        @csrf

        <div class="d-flex align-items-end justify-content-between mb-4">
            <div class="fs-2 fw-bold">
                {{ $app_menu->name }}
                <div class="w-30px border border-bottom border-primary"></div>
            </div>
            @can("{$app_path}.update")
                <button type="submit"
                        class="btn btn-primary">
                    {{ __("Simpan") }}
                </button>
            @endcan
        </div>

        <div class="card mb-6">
            <div class="card-body">

                <div class="fv-row w-lg-50 mb-6">
                    <label class="form-label">{{ __("Aplikasi") }}</label>
                    <div>
                        <input type="text"
                               name="name"
                               class="form-control"
                               value="{{ old("name", $information->name) }}"
                               placeholder="">
                    </div>
                    <x-input-error for="name"/>
                </div>

                <div class="fv-row w-lg-50 mb-6">
                    <label class="form-label">{{ __("Perusahaan") }}</label>
                    <div>
                        <input type="text"
                               name="company"
                               class="form-control"
                               value="{{ old("company", $information->company) }}"
                               placeholder="">
                    </div>
                    <x-input-error for="company"/>
                </div>

                <div class="fv-row w-lg-50 mb-6">
                    <label class="form-label">{{ __("Copyright") }}</label>
                    <div>
                        <input type="text"
                               name="copyright"
                               class="form-control"
                               value="{{ old("copyright", $information->copyright) }}"
                               placeholder="">
                    </div>
                    <x-input-error for="copyright"/>
                </div>

                <div class="row w-lg-50">
                    <div class="col">

                        <div class="fv-row">
                            <label class="form-label">{{ __("Warna") }}</label>
                            <div class="">
                                <input type="color"
                                       name="color_primary"
                                       class="form-control form-control-color w-50px"
                                       value="{{ old("color_primary", $information->color_primary) }}"
                                       placeholder="">
                            </div>
                            <x-input-error for="color_primary"/>
                        </div>

                    </div>
                    <div class="col">

                        <div class="fv-row">
                            <label class="form-label">{{ __("Warna Gelap") }}</label>
                            <div class="">
                                <input type="color"
                                       name="color_primary_dark"
                                       class="form-control form-control-color w-50px"
                                       value="{{ old("color_primary_dark", $information->color_primary_dark) }}"
                                       placeholder="">
                            </div>
                            <x-input-error for="color_primary_dark"/>
                        </div>

                    </div>
                </div>

            </div>
        </div>

        <h6 class="fs-4 fw-normal text-gray-600">{{ __("WEB") }}</h6>

        <div class="d-block my-2"></div>

        <div class="d-flex flex-row">

            <div class="card">
                <div class="card-body p-5 text-center">

                    <div class="image-input image-input-circle bgi-position-center bg-light {{ $information->path_icon ? "" : "image-input-empty" }}"
                         data-kt-image-input="true"
                         style="
                             background-size: 50px;
                             background-image: url('{{ asset("assets/media/misc/image.png") }}')
                             ">
                        <a class="viewer d-block image-input-wrapper w-75px h-75px bgi-size-contain"
                           href="{{ asset("assets/{$information->path_icon}") }}"
                           data-ext="{{ File::extension($information->path_icon) }}"
                           data-title="{{ __("Ikon") }}"
                           data-download="true"
                           style="background-image: url('{{ $information->path_icon ? asset("assets/{$information->path_icon}") : "" }}')"></a>
                        <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                               data-kt-image-input-action="change"
                               data-bs-toggle="tooltip"
                               data-bs-dismiss="click"
                               title="{{ __("Ubah Ikon") }}">
                            <i class="bi bi-pencil-fill fs-7"></i>
                            <input type="file" name="icon" accept=".png"/>
                            <input type="hidden" name="icon_remove"/>
                        </label>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="cancel"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Batalkan Ikon") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="remove"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Hapus Ikon") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                    </div>

                    <div class="my-2"></div>

                    <div class="d-flex flex-column align-items-center">
                        <span class="fs-5">{{ __("Ikon") }}</span>
                        <span class="fs-7 text-muted">128px * 128px</span>
                    </div>

                </div>
            </div>

            <div class="mx-2"></div>

            <div class="card">
                <div class="card-body p-5 text-center">

                    <div class="image-input bgi-position-center bg-light {{ $information->path_logo ? "" : "image-input-empty" }}"
                         data-kt-image-input="true"
                         style="
                             background-size: 50px;
                             background-image: url('{{ asset("assets/media/misc/image.png") }}')">
                        <a class="viewer d-block image-input-wrapper w-325px h-75px bgi-size-contain"
                           href="{{ asset("assets/{$information->path_logo}") }}"
                           data-ext="{{ File::extension($information->path_logo) }}"
                           data-title="{{ __("Logo") }}"
                           data-download="true"
                           style="background-image: url('{{ $information->path_logo ? asset("assets/{$information->path_logo}") : "" }}')"></a>
                        <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                               data-kt-image-input-action="change"
                               data-bs-toggle="tooltip"
                               data-bs-dismiss="click"
                               title="{{ __("Ubah Logo") }}">
                            <i class="bi bi-pencil-fill fs-7"></i>
                            <input type="file" name="logo" accept=".png"/>
                            <input type="hidden" name="logo_remove"/>
                        </label>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="cancel"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Batalkan Logo") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="remove"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Hapus Logo") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                    </div>

                    <div class="my-2"></div>

                    <div class="d-flex flex-column align-items-center">
                        <span class="fs-5">{{ __("Logo") }}</span>
                        <span class="fs-7 text-muted">164px * 40px</span>
                    </div>

                </div>
            </div>

        </div>
        <x-input-errors :fors="['icon', 'logo']"/>

        <div class="d-block my-8"></div>

        <h6 class="fs-4 fw-normal text-gray-600">{{ __("Mobile") }}</h6>

        <div class="d-block my-2"></div>

        <div class="d-flex flex-column flex-lg-row">

            <div class="card">
                <div class="card-body p-5 text-center">
                    <div class="image-input image-input-circle bgi-position-center bg-light {{ $information->path_image_mobile_logo ? "" : "image-input-empty" }}"
                         data-kt-image-input="true"
                         style="
                             background-size: 50px;
                             background-image: url('{{ asset("assets/media/misc/image.png") }}')">
                        <a class="viewer d-block image-input-wrapper w-150px h-150px bgi-size-contain"
                           href="{{ asset("assets/{$information->path_image_mobile_logo}") }}"
                           data-ext="{{ File::extension($information->path_image_mobile_logo) }}"
                           data-title="{{ __("Ikon Mobile") }}"
                           data-download="true"
                           style="background-image: url('{{ $information->path_image_mobile_logo ? asset("assets/{$information->path_image_mobile_logo}") : "" }}')"></a>
                        <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                               data-kt-image-input-action="change"
                               data-bs-toggle="tooltip"
                               data-bs-dismiss="click"
                               title="{{ __("Ubah Ikon") }}">
                            <i class="bi bi-pencil-fill fs-7"></i>
                            <input type="file" name="image_mobile_logo" accept=".png"/>
                            <input type="hidden" name="image_mobile_logo_remove"/>
                        </label>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="cancel"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Batalkan Ikon") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="remove"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Hapus Ikon") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                    </div>

                    <div class="my-2"></div>

                    <div class="d-flex flex-column align-items-center">
                        <span class="fs-5">{{ __("Ikon") }}</span>
                        <span class="fs-7 text-muted">128px * 128px</span>
                    </div>

                </div>
            </div>

            <div class="mx-2"></div>

            <div class="card">
                <div class="card-body p-5 text-center">

                    <div class="image-input bgi-position-center bg-light {{ $information->path_image_mobile_login_logo ? "" : "image-input-empty" }}"
                         data-kt-image-input="true"
                         style="
                             background-size: 50px;
                             background-image: url('{{ asset("assets/media/misc/image.png") }}')">
                        <a class="viewer d-block image-input-wrapper w-300px h-150px bgi-size-contain"
                           href="{{ asset("assets/{$information->path_image_mobile_login_logo}") }}"
                           data-ext="{{ File::extension($information->path_image_mobile_login_logo) }}"
                           data-title="{{ __("Logo Login Mobile") }}"
                           data-download="true"
                           style="background-image: url('{{ $information->path_image_mobile_login_logo ? asset("assets/{$information->path_image_mobile_login_logo}") : "" }}')"></a>
                        <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                               data-kt-image-input-action="change"
                               data-bs-toggle="tooltip"
                               data-bs-dismiss="click"
                               title="{{ __("Ubah Logo Login") }}">
                            <i class="bi bi-pencil-fill fs-7"></i>
                            <input type="file" name="image_mobile_login_logo" accept=".png"/>
                            <input type="hidden" name="image_mobile_login_logo_remove"/>
                        </label>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="cancel"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Batalkan Logo Login") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="remove"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Hapus Logo Login") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                    </div>

                    <div class="my-2"></div>

                    <div class="d-flex flex-column align-items-center">
                        <span class="fs-5">{{ __("Logo Login") }}</span>
                        <span class="fs-7 text-muted">200px * 100px</span>
                    </div>

                </div>
            </div>

            <div class="mx-2"></div>

            <div class="card">
                <div class="card-body p-5 text-center">

                    <div class="image-input bgi-position-center bg-light {{ $information->path_image_mobile_login_background ? "" : "image-input-empty" }}"
                         data-kt-image-input="true"
                         style="
                             background-size: 50px;
                             background-image: url('{{ asset("assets/media/misc/image.png") }}')">
                        <a class="viewer d-block image-input-wrapper w-75px h-150px bgi-size-contain"
                           href="{{ asset("assets/{$information->path_image_mobile_login_background}") }}"
                           data-ext="{{ File::extension($information->path_image_mobile_login_background) }}"
                           data-title="{{ __("Logo Background Mobile") }}"
                           data-download="true"
                           style="background-image: url('{{ $information->path_image_mobile_login_background ? asset("assets/{$information->path_image_mobile_login_background}") : "" }}')"></a>
                        <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                               data-kt-image-input-action="change"
                               data-bs-toggle="tooltip"
                               data-bs-dismiss="click"
                               title="{{ __("Ubah Login Background") }}">
                            <i class="bi bi-pencil-fill fs-7"></i>
                            <input type="file" name="image_mobile_login_background" accept=".jpeg"/>
                            <input type="hidden" name="image_mobile_login_background_remove"/>
                        </label>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="cancel"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Batalkan Login Background") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                              data-kt-image-input-action="remove"
                              data-bs-toggle="tooltip"
                              data-bs-dismiss="click"
                              title="{{ __("Hapus Login Background") }}">
                            <i class="bi bi-x fs-2"></i>
                        </span>
                    </div>

                    <div class="my-2"></div>

                    <div class="d-flex flex-column align-items-center">
                        <span class="fs-5">{{ __("Login Background") }}</span>
                        <span class="fs-7 text-muted">400px * 800px</span>
                    </div>

                </div>
            </div>

        </div>

    </form>

@endsection
