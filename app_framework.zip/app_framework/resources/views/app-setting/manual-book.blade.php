@extends("main")

@push("content-container-class", "bg-light")
@push("content-class", "my-4 container-xxl")

@section("content")

    <form action=""
          method="post"
          autocomplete="off"
          enctype="multipart/form-data">

        @csrf

        <div class="d-flex align-items-end justify-content-between mb-4">
            <div class="fs-2 fw-bold">
                {{ $app_menu->name }}
                <div class="w-30px border border-bottom border-primary"></div>
            </div>
            @can("{$app_path}.update")
                <button type="submit"
                        class="btn btn-primary">
                    {{ __("Simpan") }}
                </button>
            @endcan
        </div>

        <div class="card mb-6">
            <div class="card-body">

                <div class="fv-row w-lg-50 mb-6">
                    <label class="form-label">{{ __("Judul") }}</label>
                    <div>
                        <input type="text"
                               name="name"
                               class="form-control"
                               value="{{ old("name", $manual->name) }}"
                               placeholder="">
                    </div>
                    <x-input-error for="name"/>
                </div>

                <div class="fv-row w-lg-50 mb-6">
                    <label class="form-label">{{ __("Deskripsi") }}</label>
                    <div>
                        <textarea type="text"
                                  name="description"
                                  class="form-control"
                                  placeholder="">{{ old("description", $manual->description) }}</textarea>
                    </div>
                    <x-input-error for="description"/>
                </div>

                <div class="fv-row w-lg-50 mb-6">
                    <label class="form-label">{{ __("Buku Manual") }}</label>
                    <div class="input-group"
                         data-controls="input-remove"
                         data-show="{{ !blank($manual->path_document) }}">
                        <input type="file"
                               name="document"
                               class="form-control"
                               value="{{ old("path_document") }}"
                               placeholder=""
                               accept=".pdf, .doc, .docx">
                        <input type="hidden"
                               name="document_remove">
                        <x-viewer-custom class="btn btn-secondary px-4 d-none"
                                         view
                                         :href='$manual->path_document ? asset("view/" . encrypt($manual->path_document)) : ""'
                                         :ext='File::extension($manual->path_document)'
                                         title="Buku Manual"
                                         download="true">
                            <i class="fa fa-eye p-0"></i>
                        </x-viewer-custom>
                        <button type="button"
                                class="btn btn-danger px-4 d-none"
                                remove>
                            <i class="fa fa-trash p-0"></i>
                        </button>
                    </div>
                    <x-input-error for="document"/>
                </div>

            </div>
        </div>

    </form>

@endsection
