@extends("main")

@section("content")

    @livewire(
        "app-setting.setting-module",
        compact("app_module", "app_module_sub", "app_menu", "app_path")
    )

@endsection
