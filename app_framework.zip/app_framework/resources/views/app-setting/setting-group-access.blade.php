@extends("main")

@section("content")

    @livewire(
        "app-setting.setting-group-access",
        compact("app_module", "app_module_sub", "app_menu", "app_path")
    )

@endsection
